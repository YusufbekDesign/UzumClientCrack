package aethereal;

import java.awt.Color;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9848;

public class InventoryHudEditor {
   private static final float field0566 = 104.0F;
   private static final float field0003 = 19.0F;
   private static final float field1410 = 6.0F;
   private static final float field0957 = 10.0F;
   private static final float field0758 = 6.0F;
   private static final float field1242 = 10.0F;
   private static final float field0314 = 7.0F;
   private static final float field0177 = 2.5F;
   private static final float field0458 = 5.0F;
   private static final float field1614 = 1.5F;
   private static final float field1538 = 3.0F;
   private static final Color field1726 = new Color(21, 21, 27, 224);
   private static final Color field1153 = new Color(255, 255, 255, 10);
   private static final Color field1104 = new Color(255, 255, 255, 80);
   private static final Color field1210 = new Color(255, 255, 255, 184);
   private static final String[] field0892 = new String[]{"Q", "R", "S", "U", "I", "w", "s", "T", "D"};
   private static final String[] field0846 = new String[]{"Displays the unique client name and version on the screen.", "Provides real-time data such as FPS, TPS, and server info.", "Renders a compact view of your inventory items on the HUD.", "Displays your current armor durability and equipped items.", "Displays a list of your assigned hotkeys and their states.", "Tracks active potion effects and their remaining durations.", "Shows module toggle alerts when enabling or disabling.", "Shows detailed information about the entity you are attacking.", "Displays a list of detected staff members and their status."};
   private static final String[] field0932 = new String[]{"Отображает уникальное имя клиента и версию на экране.", "Предоставляет данные в реальном времени: FPS, TPS, информация о сервере.", "Рисует компактный вид инвентаря на HUD.", "Отображает прочность брони и экипированные предметы.", "Показывает список назначенных клавиш и их состояний.", "Отслеживает активные эффекты зелий и их оставшееся время.", "Показывает уведомления при включении и выключении модулей.", "Показывает информацию о сущности, которую вы атакуете.", "Отображает список обнаруженных стаффов и их статус."};
   private boolean field1350 = false;
   private float field1292;
   private float field1369;
   private final Animation[] field0405 = new Animation[9];
   private float field0351 = 0.0F;
   private boolean field0442 = false;

   private static String[] method2084() {
      try {
         if (ClickGuiDashboard.field0984.method0492() == ClickGuiDashboard.Language.field0631) {
            return field0932;
         }
      } catch (Exception var1) {
      }

      return field0846;
   }

   public InventoryHudEditor() {
      for(int i = 0; i < this.field0405.length; ++i) {
         this.field0405[i] = new Animation(200L, (double)1.0F, false, EasingCurve.field1477);
      }

   }

   public void method0675(float mouseX, float mouseY) {
      float screenW = ScreenLayoutHelper.method2047();
      float screenH = ScreenLayoutHelper.method1762();
      float panelH = this.method1762();
      this.field1292 = mouseX;
      this.field1369 = mouseY;
      if (this.field1292 + 104.0F > screenW) {
         this.field1292 = screenW - 104.0F - 4.0F;
      }

      if (this.field1369 + panelH > screenH) {
         this.field1369 = screenH - panelH - 4.0F;
      }

      if (this.field1292 < 4.0F) {
         this.field1292 = 4.0F;
      }

      if (this.field1369 < 4.0F) {
         this.field1369 = 4.0F;
      }

      this.field1350 = true;
      this.field0442 = true;
      this.method1634();
   }

   public void method0578() {
      this.field0442 = false;
   }

   public boolean method0026() {
      return this.field1350;
   }

   private int method0829(FontSize descFont, int index) {
      String[] descs = method2084();
      String desc = index < descs.length ? descs[index] : "";
      float maxW = 92.0F;
      int lines = 1;
      StringBuilder line = new StringBuilder();

      for(String word : desc.split(" ")) {
         String test = line.isEmpty() ? word : String.valueOf(line) + " " + word;
         if (descFont.method0998(test) > maxW && !line.isEmpty()) {
            ++lines;
            line = new StringBuilder(word);
         } else {
            line = new StringBuilder(test);
         }
      }

      return lines;
   }

   private float method0172(FontSize descFont, int index) {
      int lines = this.method0829(descFont, index);
      float descH = (float)lines * (descFont.method0530() + 1.0F);
      return 9.0F + descH + 2.0F;
   }

   private float method1762() {
      FontSize descFont = Fonts.field0075.method0654(5.0F);
      NewHUD hud = this.method1955();
      int count = hud != null ? Math.min(hud.method1751().size(), field0892.length) : field0892.length;
      float total = 25.0F;

      for(int i = 0; i < count; ++i) {
         total += this.method0172(descFont, i);
         if (i < count - 1) {
            total += 6.0F;
         }
      }

      return total + 1.0F;
   }

   private void method1634() {
      NewHUD hud = this.method1955();
      if (hud != null) {
         List<BooleanSetting> elements = hud.method1751();

         for(int i = 0; i < Math.min(elements.size(), this.field0405.length); ++i) {
            this.field0405[i].method1570((Boolean)((BooleanSetting)elements.get(i)).method0492());
         }

      }
   }

   private NewHUD method1955() {
      return (NewHUD)ArbuzClient.method2004().method1783().method0976(NewHUD.class);
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.field1350) {
         float target = this.field0442 ? 1.0F : 0.0F;
         this.field0351 += (target - this.field0351) * 0.15F;
         if (this.field0351 >= 0.99F) {
            this.field0351 = 1.0F;
         }

         if (this.field0351 <= 0.01F) {
            this.field0351 = 0.0F;
            this.field1350 = false;
         } else {
            float alpha = this.field0351;
            class_4587 stack = context.method_51448();
            float panelH = this.method1762();
            float scale = 0.9F + 0.1F * this.field0351;
            float pivotX = this.field1292 + 52.0F;
            float pivotY = this.field1369 + panelH;
            stack.method_22903();
            stack.method_46416(pivotX, pivotY, 0.0F);
            stack.method_22905(scale, scale, 1.0F);
            stack.method_46416(-pivotX, -pivotY, 0.0F);
            Color bgColor = ThemeColorManager.method1908().method0141(224);
            GuiRenderHelper.method1462(stack, this.field1292, this.field1369, 104.0F, panelH, 10.0F, 14.0F, method0964(Color.WHITE, alpha));
            GuiRenderHelper.method1463(stack, this.field1292, this.field1369, 104.0F, panelH, 10.0F, method0964(bgColor, alpha));
            FontSize headerFont = Fonts.field0075.method0654(5.5F);
            FontSize headerIconFont = Fonts.field0774.method0654(5.5F);
            Color brandColor = ThemeColorManager.method1908().method2063();
            float headerY = this.field1369 + 6.0F;
            float hx = this.field1292 + 6.0F;
            GuiRenderHelper.method1491(stack, headerIconFont, "C", hx, headerY, method0964(brandColor, alpha));
            hx += headerIconFont.method0998("C") + 3.0F;
            float hSepY = this.field1369 + 8.0F - 1.5F;
            GuiRenderHelper.method0326(stack, hx, hSepY, 1.3F, 6.0F, 0.2F, method0964(field1104, alpha));
            hx += 3.5F;
            GuiRenderHelper.method1491(stack, headerFont, "Settings", hx, headerY, method0964(Color.WHITE, alpha));
            FontSize closeFont = Fonts.field0774.method0654(4.0F);
            float closeX = this.field1292 + 104.0F - 6.0F - closeFont.method0998("F") - 5.0F;
            GuiRenderHelper.method1491(stack, closeFont, "F", closeX, headerY + 1.0F, method0964(new Color(170, 170, 170, 122), alpha));
            float fullSepY = this.field1369 + 19.0F - 0.5F;
            GuiRenderHelper.method1463(stack, this.field1292, fullSepY, 104.0F, 0.5F, 0.0F, method0964(field1153, alpha));
            NewHUD hud = this.method1955();
            if (hud == null) {
               stack.method_22909();
            } else {
               List<BooleanSetting> elements = hud.method1751();
               FontSize nameFont = Fonts.field0075.method0654(5.5F);
               FontSize descFont = Fonts.field0075.method0654(5.0F);
               FontSize iconFont = Fonts.field0774.method0654(5.5F);
               FontSize staffIconFont = Fonts.field1558.method0654(5.5F);
               float currentRowY = this.field1369 + 19.0F + 6.0F;

               for(int i = 0; i < Math.min(elements.size(), field0892.length); ++i) {
                  BooleanSetting elem = (BooleanSetting)elements.get(i);
                  float rowH = this.method0172(descFont, i);
                  if (this.field0405[i].method0376() != (Boolean)elem.method0492()) {
                     this.field0405[i].method1570((Boolean)elem.method0492());
                  }

                  String icon = field0892[i % field0892.length];
                  FontSize curIconFont = i == 8 ? staffIconFont : iconFont;
                  float maxIconW = 0.0F;

                  for(int j = 0; j < field0892.length; ++j) {
                     FontSize f = j == 8 ? staffIconFont : iconFont;
                     maxIconW = Math.max(maxIconW, f.method0998(field0892[j]));
                  }

                  float iconW = curIconFont.method0998(icon);
                  float iconXOffset = i == 0 ? 0.5F : (i == 2 ? 0.5F : (i == 5 ? 1.0F : (i == 6 ? -0.5F : 0.0F)));
                  float iconX = this.field1292 + 6.0F + (maxIconW - iconW) / 2.0F + iconXOffset;
                  Color iconColor = (Boolean)elem.method0492() ? method0964(brandColor, alpha) : new Color(246, 247, 255, (int)(122.399994F * alpha));
                  GuiRenderHelper.method1491(stack, curIconFont, icon, iconX, currentRowY, iconColor);
                  float sepX = this.field1292 + 6.0F + maxIconW + 3.0F;
                  float sepCenterY = currentRowY + nameFont.method0530() / 2.0F - 3.0F;
                  GuiRenderHelper.method0326(stack, sepX, sepCenterY, 1.3F, 6.0F, 0.2F, method0964(field1104, alpha));
                  String displayName = elem.method1888() != null ? elem.method1888() : elem.method2067();
                  float textX = sepX + 0.5F + 3.0F;
                  GuiRenderHelper.method1491(stack, nameFont, displayName, textX, currentRowY, method0964(Color.WHITE, alpha));
                  float cbX = this.field1292 + 104.0F - 6.0F - 10.0F;
                  float cbY = currentRowY + (nameFont.method0530() - 7.0F) / 2.0F;
                  float cbProgress = this.field0405[i].method0002();
                  int boxBg = class_9848.method_61319(cbProgress, method0195(new Color(255, 255, 255, (int)(2.55F * (12.0F + 12.0F * cbProgress))), alpha), method0195(brandColor, alpha));
                  int knobColor = method0195(new Color(246, 247, 255, 255), alpha);
                  GuiRenderHelper.method0326(stack, cbX, cbY, 10.0F, 7.0F, 2.5F, new Color(boxBg, true));
                  GuiRenderHelper.method0326(stack, cbX + 1.0F + 3.0F * cbProgress, cbY + 1.0F, 5.0F, 5.0F, 1.5F, new Color(knobColor, true));
                  String[] descs = method2084();
                  String desc = i < descs.length ? descs[i] : "";
                  int descAlphaVal = (int)((float)field1210.getAlpha() * alpha);
                  Color descColor = new Color(255, 255, 255, Math.max(0, Math.min(255, descAlphaVal)));
                  float maxDescW = 92.0F;
                  float descLineY = currentRowY + nameFont.method0530() + 2.0F;
                  String[] words = desc.split(" ");
                  StringBuilder line = new StringBuilder();

                  for(String word : words) {
                     String test = line.isEmpty() ? word : String.valueOf(line) + " " + word;
                     if (descFont.method0998(test) > maxDescW && !line.isEmpty()) {
                        GuiRenderHelper.method1491(stack, descFont, line.toString(), this.field1292 + 6.0F, descLineY, descColor);
                        descLineY += descFont.method0530() + 1.0F;
                        line = new StringBuilder(word);
                     } else {
                        line = new StringBuilder(test);
                     }
                  }

                  if (!line.isEmpty()) {
                     GuiRenderHelper.method1491(stack, descFont, line.toString(), this.field1292 + 6.0F, descLineY, descColor);
                  }

                  currentRowY += rowH + 6.0F;
                  if (i < Math.min(elements.size(), field0892.length) - 1) {
                     GuiRenderHelper.method1463(stack, this.field1292 + 6.0F, currentRowY - 3.0F, 92.0F, 0.5F, 0.0F, method0964(field1104, alpha));
                  }
               }

               stack.method_22909();
            }
         }
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      if (!this.field1350) {
         return false;
      } else {
         float panelH = this.method1762();
         if (!MathHelper.method0689(this.field1292, this.field1369, 104.0F, panelH, (float)mouseX, (float)mouseY)) {
            this.method0578();
            return false;
         } else {
            if (button == 0) {
               FontSize closeFont = Fonts.field0774.method0654(4.0F);
               float closeX = this.field1292 + 104.0F - 6.0F - closeFont.method0998("F") - 5.0F;
               float closeY = this.field1369 + 6.0F + 1.0F;
               if (MathHelper.method0689(closeX, closeY, closeFont.method0998("F"), closeFont.method0530(), (float)mouseX, (float)mouseY)) {
                  this.method0578();
                  return true;
               }

               NewHUD hud = this.method1955();
               if (hud == null) {
                  return true;
               }

               List<BooleanSetting> elements = hud.method1751();
               FontSize descFont = Fonts.field0075.method0654(5.0F);
               float currentClickY = this.field1369 + 19.0F + 6.0F;

               for(int i = 0; i < Math.min(elements.size(), field0892.length); ++i) {
                  float rowH = this.method0172(descFont, i);
                  if (MathHelper.method0689(this.field1292, currentClickY, 104.0F, rowH, (float)mouseX, (float)mouseY)) {
                     BooleanSetting elem = (BooleanSetting)elements.get(i);
                     elem.method0206(!(Boolean)elem.method0492());
                     this.field0405[i].method1570((Boolean)elem.method0492());
                     this.field0405[i].method1634();
                     ArbuzClient.method2004().method2216().method1634();
                     return true;
                  }

                  currentClickY += rowH + 6.0F;
               }
            }

            return true;
         }
      }
   }

   private static Color method0964(Color c, float alpha) {
      return alpha >= 0.99F ? c : new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, (int)((float)c.getAlpha() * alpha))));
   }

   private static int method0195(Color c, float alpha) {
      int a = Math.max(0, Math.min(255, (int)((float)c.getAlpha() * alpha)));
      return a << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }
}
