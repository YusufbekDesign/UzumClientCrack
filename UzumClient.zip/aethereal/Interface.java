package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public class Interface extends Module {
   private static final float field0003 = 10.0F;
   private static final float field1410 = 14.0F;
   private static final Color field1026 = new Color(21, 21, 27, 224);
   private static final Color field0207 = new Color(255, 255, 255, 55);
   private static final Color field0486 = new Color(255, 255, 255, 80);
   private static final Color field1641 = new Color(255, 255, 255, 10);
   private static final Color field1564 = new Color(255, 255, 255, 41);
   private static final Color field1726 = new Color(255, 255, 255);
   private static final Color field1153 = new Color(255, 255, 255, 184);
   private static final Color field1104 = new Color(37, 37, 50);
   private static final Color field1210 = new Color(255, 255, 255, 28);
   private static final Color field0884 = new Color(255, 255, 255, 22);
   private static final Color field0840 = new Color(230, 90, 90);
   private static final Color field0927 = new Color(220, 60, 60);
   private static final Color field1346 = new Color(255, 215, 0);
   private static final Color field1307 = new Color(205, 140, 60);
   private static final Color field1383 = new Color(180, 200, 220);
   private static final Color field0399 = new Color(120, 220, 80);
   private final MultiSelectSetting field0363 = (MultiSelectSetting)(new MultiSelectSetting("interface.elements", Arrays.asList("Hotbar", "Inventory", "Scoreboard", "Tab"), true, () -> true)).method1007("Elements").method0210("Vanilla UI parts to replace").method2130("Интерфейса для замены");
   private final BooleanSetting field0426 = (BooleanSetting)(new BooleanSetting("interface.blur", true)).method1007("Blur").method0210("Apply background blur").method2130("Размытие");
   private final BooleanSetting field0259 = (BooleanSetting)(new BooleanSetting("interface.outline", true)).method1007("Outline").method0210("Draw subtle panel borders").method2130("Рисовать рамки панелей");
   private final ColorSetting field0231 = (ColorSetting)(new ColorSetting("interface.accent", 74, 214, 160, 255)).method1882().method1007("Accent").method0210("Accent color").method2130("Цвет");
   private final BooleanSetting field0292 = (BooleanSetting)(new BooleanSetting("interface.scoreboard.title", true, () -> this.field0363.method0439("Scoreboard") != null && (Boolean)this.field0363.method0439("Scoreboard").method0492())).method1007("Scoreboard Title").method0210("Show objective title").method2130("Показывать заголовок");
   private float field0523 = 0.0F;
   private float field0501 = 0.0F;
   private float field0547 = 0.0F;
   private float field1671 = 0.0F;
   private float field1657 = 0.0F;
   private long field1690 = 0L;

   public Interface() {
      super("Interface", ModuleCategory.field1004, "Replaces vanilla hotbar, inventory and scoreboard");
      this.method1013("Улучшает игровой интерфейс в стиле клиента");
   }

   private static float method0685(float current, float target, float dt, float speed) {
      float t = 1.0F - (float)Math.exp((double)(-dt * speed));
      return current + (target - current) * t;
   }

   public boolean method1736() {
      BooleanSetting s = this.field0363.method0439("Hotbar");
      return this.method2195() && s != null && (Boolean)s.method0492();
   }

   public boolean method1692() {
      BooleanSetting s = this.field0363.method0439("Inventory");
      return this.method2195() && s != null && (Boolean)s.method0492();
   }

   public boolean method1755() {
      BooleanSetting s = this.field0363.method0439("Scoreboard");
      return this.method2195() && s != null && (Boolean)s.method0492();
   }

   public boolean method2030() {
      BooleanSetting s = this.field0363.method0439("Tab");
      return this.method2195() && s != null && (Boolean)s.method0492();
   }

   public void method1404(class_332 context, float x, float y, float width, float height) {
      this.method1457(context.method_51448(), x, y, width, height);
   }

   private Color method2010() {
      return this.field0231.method1726();
   }

   private void method1457(class_4587 stack, float x, float y, float width, float height) {
      if ((Boolean)this.field0426.method0492()) {
         GuiRenderHelper.method1462(stack, x, y, width, height, 10.0F, 14.0F, new Color(255, 255, 255));
      }

      GuiRenderHelper.method1463(stack, x, y, width, height, 10.0F, field1026);
      if ((Boolean)this.field0259.method0492()) {
         GuiRenderHelper.method1460(stack, x, y, width, height, 10.0F, 0.2F, 0.5F, 0.5F, field1210);
      }

   }

   @EventHandler
   public void onRender2D(HudRenderEvent e) {
      if (!method1974()) {
         boolean blockingScreen = field0796.field_1755 != null && !(field0796.field_1755 instanceof class_408) && !(field0796.field_1755 instanceof class_465);
         boolean f3 = field0796.method_53526().method_53536();
         if (this.method1736() && !blockingScreen && !f3) {
            this.method0843(e);
         }

         if (this.method1755() && !blockingScreen && !f3) {
            this.method0176(e);
         }

      }
   }

   private void method0843(HudRenderEvent e) {
      class_332 ctx = e.method1806();
      class_4587 stack = ctx.method_51448();
      class_1661 inv = field0796.field_1724.method_31548();
      float sw = ScreenLayoutHelper.method2047();
      float sh = ScreenLayoutHelper.method1762();
      float itemSize = 16.0F;
      float itemGap = 2.0F;
      float padding = 6.0F;
      int slots = 9;
      float contentW = (float)slots * itemSize + (float)(slots - 1) * itemGap;
      float hotbarW = contentW + padding * 2.0F;
      float hotbarH = itemSize + padding * 2.0F;
      float x = (sw - hotbarW) / 2.0F;
      float y = sh - hotbarH - 4.0F;
      boolean hasOffhand = field0796.field_1724.method_6079() != null && !field0796.field_1724.method_6079().method_7960();
      this.method1457(stack, x, y, hotbarW, hotbarH);
      int selected = inv.field_7545;
      float slotY = y + padding;

      for(int i = 0; i < slots; ++i) {
         float slotX = x + padding + (float)i * (itemSize + itemGap);
         boolean isSel = i == selected;
         if (isSel) {
            GuiRenderHelper.method1463(stack, slotX - 1.0F, slotY - 1.0F, itemSize + 2.0F, itemSize + 2.0F, 3.0F, method0966(this.method2010(), 60));
            GuiRenderHelper.method1460(stack, slotX - 1.0F, slotY - 1.0F, itemSize + 2.0F, itemSize + 2.0F, 3.0F, 0.2F, 0.5F, 0.5F, this.method2010());
         }

         class_1799 itemStack = inv.method_5438(i);
         if (!itemStack.method_7960()) {
            stack.method_22903();
            stack.method_46416(slotX, slotY, 0.0F);
            ctx.method_51427(itemStack, 0, 0);
            ctx.method_51432(field0796.field_1772, itemStack, 0, 0, (String)null);
            stack.method_22909();
         } else {
            FontSize emptyFont = Fonts.field0774.method0654(6.0F);
            String s = "t";
            float tw = emptyFont.method0998(s);
            GuiRenderHelper.method1491(stack, emptyFont, s, slotX + (itemSize - tw) / 2.0F, slotY + (itemSize - emptyFont.method0530()) / 2.0F, field1564);
         }

         if (i < slots - 1) {
            float sepX = slotX + itemSize + (itemGap - 1.0F) / 2.0F;
            float sepY = slotY + (itemSize - 7.0F) / 2.0F;
            GuiRenderHelper.method0326(stack, sepX, sepY, 1.0F, 7.0F, 1.0F, field0486);
         }
      }

      float markerW = itemSize - 4.0F;
      float markerX = x + padding + (float)selected * (itemSize + itemGap) + 2.0F;
      float markerY = y + hotbarH - 1.5F;
      GuiRenderHelper.method0326(stack, markerX, markerY, markerW, 1.5F, 0.75F, this.method2010());
      if (hasOffhand) {
         float ow = itemSize + padding * 2.0F;
         float ox = x - ow - 3.0F;
         this.method1457(stack, ox, y, ow, hotbarH);
         float ix = ox + padding;
         float iy = y + padding;
         class_1799 off = field0796.field_1724.method_6079();
         stack.method_22903();
         stack.method_46416(ix, iy, 0.0F);
         ctx.method_51427(off, 0, 0);
         ctx.method_51432(field0796.field_1772, off, 0, 0, (String)null);
         stack.method_22909();
      }

      if (!field0796.field_1724.method_7337() && !field0796.field_1724.method_7325()) {
         this.method1456(stack, x, y - 6.0F, hotbarW);
      }

   }

   private void method1456(class_4587 stack, float x, float topY, float width) {
      float maxHp = Math.max(1.0F, field0796.field_1724.method_6063());
      float hp = field0796.field_1724.method_6032();
      float abs = field0796.field_1724.method_6067();
      float food = (float)field0796.field_1724.method_7344().method_7586();
      int armor = field0796.field_1724.method_6096();
      int xpLevel = field0796.field_1724.field_7520;
      float xpProgress = field0796.field_1724.field_7510;
      float hpRatio = Math.min(1.0F, hp / maxHp);
      float absRatio = abs > 0.0F ? Math.min(1.0F, abs / Math.max(maxHp, abs)) : 0.0F;
      float foodRatio = Math.min(1.0F, food / 20.0F);
      float armRatio = armor > 0 ? Math.min(1.0F, (float)armor / 20.0F) : 0.0F;
      long now = System.nanoTime();
      float dt = this.field1690 == 0L ? 0.0F : (float)(now - this.field1690) / 1.0E9F;
      this.field1690 = now;
      if (dt > 0.1F) {
         dt = 0.1F;
      }

      float speed = 12.0F;
      this.field0523 = method0685(this.field0523, hpRatio, dt, speed);
      this.field0501 = method0685(this.field0501, absRatio, dt, speed);
      this.field0547 = method0685(this.field0547, foodRatio, dt, speed);
      this.field1671 = method0685(this.field1671, armRatio, dt, speed);
      this.field1657 = method0685(this.field1657, xpProgress, dt, speed);
      float barH = 2.6F;
      float half = (width - 2.0F) / 2.0F;
      float rightX = x + width / 2.0F + 1.0F;
      GuiRenderHelper.method0326(stack, x, topY, half, barH, 1.0F, field1104);
      if (this.field0523 > 0.001F) {
         Color hpc = hp <= maxHp * 0.25F ? field0927 : field0840;
         GuiRenderHelper.method0326(stack, x, topY, half * this.field0523, barH, 1.0F, hpc);
      }

      if (this.field0501 > 0.001F) {
         GuiRenderHelper.method0326(stack, x, topY - barH - 1.0F, half * this.field0501, barH, 1.0F, field1346);
      }

      GuiRenderHelper.method0326(stack, rightX, topY, half, barH, 1.0F, field1104);
      if (this.field0547 > 0.001F) {
         float foodFill = half * this.field0547;
         GuiRenderHelper.method0326(stack, rightX + half - foodFill, topY, foodFill, barH, 1.0F, field1307);
      }

      if (armor > 0 || this.field1671 > 0.001F) {
         float armorY = topY - barH - 1.0F;
         GuiRenderHelper.method0326(stack, rightX, armorY, half, barH, 1.0F, field1104);
         float armorFill = half * this.field1671;
         GuiRenderHelper.method0326(stack, rightX + half - armorFill, armorY, armorFill, barH, 1.0F, field1383);
      }

      float xpY = topY - barH - 1.0F;
      if (abs > 0.0F || armor > 0) {
         xpY = topY - (barH + 1.0F) * 2.0F;
      }

      GuiRenderHelper.method0326(stack, x, xpY, width, barH, 1.0F, field1104);
      if (this.field1657 > 0.001F) {
         GuiRenderHelper.method0326(stack, x, xpY, width * this.field1657, barH, 1.0F, field0399);
      }

      if (xpLevel > 0) {
         FontSize xpFont = Fonts.field0075.method0654(7.0F);
         String lvl = String.valueOf(xpLevel);
         float tw = xpFont.method0998(lvl);
         GuiRenderHelper.method1491(stack, xpFont, lvl, x + (width - tw) / 2.0F, xpY - xpFont.method0530() - 0.5F, field0399);
      }

   }

   private void method0176(HudRenderEvent e) {
      if (field0796.field_1687 != null) {
         class_269 scoreboard = field0796.field_1687.method_8428();
         class_266 objective = scoreboard.method_1189(class_8646.field_45157);
         if (objective != null) {
            Collection<class_9011> entries = scoreboard.method_1184(objective);
            List<class_9011> visible = (List)entries.stream().filter((entryx) -> entryx.comp_2127() != null && !entryx.comp_2127().startsWith("#")).sorted(Comparator.comparing(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER)).limit(15L).collect(Collectors.toList());
            class_332 ctx = e.method1806();
            class_4587 stack = ctx.method_51448();
            class_2561 titleText = objective.method_1114();
            boolean showTitle = (Boolean)this.field0292.method0492();
            Objects.requireNonNull(field0796.field_1772);
            int fontHeight = 9;
            float padding = 8.0F;
            float rowGap = 1.0F;
            float lineH = (float)fontHeight + rowGap;
            float headerH = showTitle ? (float)fontHeight + 6.0F : 0.0F;
            List<class_2561> lines = new ArrayList(visible.size());
            float contentW = showTitle ? (float)field0796.field_1772.method_27525(titleText) : 0.0F;

            for(class_9011 entry : visible) {
               class_268 team = scoreboard.method_1164(entry.comp_2127());
               class_2561 line = class_268.method_1142(team, class_2561.method_43470(entry.comp_2127()));
               lines.add(line);
               float w = (float)field0796.field_1772.method_27525(line);
               if (w > contentW) {
                  contentW = w;
               }
            }

            float width = contentW + padding * 2.0F;
            float bodyH = (float)lines.size() * lineH + padding;
            float height = headerH + bodyH;
            float sw = ScreenLayoutHelper.method2047();
            float sh = ScreenLayoutHelper.method1762();
            float x = sw - width - 4.0F;
            float y = (sh - height) / 2.0F;
            this.method1457(stack, x, y, width, height);
            int textCol = method0956(field1726);
            float curY = y;
            if (showTitle) {
               float tw = (float)field0796.field_1772.method_27525(titleText);
               ctx.method_27535(field0796.field_1772, titleText, (int)(x + (width - tw) / 2.0F), (int)(y + 4.0F), textCol);
               float sepY = y + headerH - 1.0F;
               GuiRenderHelper.method1463(stack, x + padding, sepY, width - padding * 2.0F, 1.0F, 0.4F, field0207);
               curY = y + headerH;
            }

            curY += padding * 0.5F;

            for(class_2561 line : lines) {
               ctx.method_27535(field0796.field_1772, line, (int)(x + padding), (int)curY, textCol);
               curY += lineH;
            }

         }
      }
   }

   private static int method0956(Color c) {
      return c.getAlpha() << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }

   public void method1415(class_332 context, int screenX, int screenY, int bgWidth, int bgHeight, String title) {
      class_4587 stack = context.method_51448();
      float pad = 8.0F;
      float x = (float)screenX - pad;
      float y = (float)screenY - pad;
      float width = (float)bgWidth + pad * 2.0F;
      float height = (float)bgHeight + pad * 2.0F;
      this.method1457(stack, x, y, width, height);
      FontSize titleFont = Fonts.field0075.method0654(7.0F);
      if (title != null && !title.isEmpty()) {
         float tw = titleFont.method0998(title);
         GuiRenderHelper.method1491(stack, titleFont, title, x + (width - tw) / 2.0F, y + 4.0F, field1726);
         float sepY = y + titleFont.method0530() + 6.0F;
         GuiRenderHelper.method1463(stack, x + pad, sepY, width - pad * 2.0F, 1.0F, 0.4F, field0207);
      }

      this.method1473(stack, (float)(screenX + 8), (float)(screenY + 84), 9, 3);
      this.method1473(stack, (float)(screenX + 8), (float)(screenY + 142), 9, 1);
      this.method1473(stack, (float)(screenX + 8), (float)(screenY + 8), 1, 4);
      this.method1455(stack, (float)(screenX + 77), (float)(screenY + 62));
      this.method1473(stack, (float)(screenX + 98), (float)(screenY + 18), 2, 2);
      this.method1455(stack, (float)(screenX + 154), (float)(screenY + 28));
   }

   private void method1473(class_4587 stack, float startX, float startY, int cols, int rows) {
      float slot = 18.0F;

      for(int r = 0; r < rows; ++r) {
         for(int c = 0; c < cols; ++c) {
            float sx = startX + (float)c * slot;
            float sy = startY + (float)r * slot;
            this.method1455(stack, sx, sy);
         }
      }

   }

   private void method1455(class_4587 stack, float startX, float startY) {
      GuiRenderHelper.method1463(stack, startX, startY, 16.0F, 16.0F, 3.0F, field1104);
      if ((Boolean)this.field0259.method0492()) {
         GuiRenderHelper.method1460(stack, startX, startY, 16.0F, 16.0F, 3.0F, 0.2F, 0.5F, 0.5F, field0884);
      }

   }

   private static Color method0966(Color c, int alpha) {
      return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, alpha)));
   }
}
