package aethereal;

import java.util.Arrays;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class AimAssistant extends Module {
   private final MultiSelectSetting targets = (MultiSelectSetting)(new MultiSelectSetting("aimassist.targets", Arrays.asList("Players", "Mobs", "Animals", "Friends"), false, () -> true)).method1007("Nishonlar");
   private final BooleanSetting walls = (BooleanSetting)(new BooleanSetting("aimassist.walls", false)).method1007("Devor orqali");
   private final FloatSetting speed = (FloatSetting)(new FloatSetting("aimassist.speed", 5.0F, 1.0F, 10.0F, 0.5F)).method1007("Tezlik");
   private final BooleanSetting weapon = (BooleanSetting)(new BooleanSetting("aimassist.weapon", true)).method1007("Faqat qurol bilan");
   private class_1309 target;

   public AimAssistant() {
      super("Aim Assistant", ModuleCategory.field0661, "Nishonni avtomatik kuzatib boradi");
      this.method1013("Aim Assistant");
      BooleanSetting players = this.targets.method0439("Players");
      if (players != null) {
         players.method0206(true);
      }

      BooleanSetting friends = this.targets.method0439("Friends");
      if (friends != null) {
         friends.method0206(true);
      }

   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!Module.method1974()) {
         TriggerBot tb = TriggerBot.method1724();
         class_1309 found = tb == null ? null : tb.field1569;
         if (found == null || !tb.method1635() || !this.isValid(found)) {
            found = this.findTarget();
         }

         this.target = found;
         if (this.target != null) {
            if (!field0796.field_1724.method_6115()) {
               if (!(Boolean)this.weapon.method0492() || this.hasWeapon()) {
                  class_243 eye = field0796.field_1724.method_33571();
                  class_243 center = this.target.method_5829().method_1005();
                  Rotation desired = RotationHelper.method1296(center.method_1020(eye));
                  Rotation.VectorRotation vec = new Rotation.VectorRotation(desired, desired.method0024());
                  float fraction = (Float)this.speed.method0492() / 20.0F;
                  RotationHandler handler = new RotationHandler(new AimAssistRotationStrategy(fraction), true, true);
                  RotationManager.field0618.method0867(vec, this.target, 1, handler, RotationPriority.field1261, this);
               }
            }
         }
      }
   }

   private class_1309 findTarget() {
      class_243 eye = field0796.field_1724.method_33571();
      Rotation cur = RotationManager.field0618.method0545();
      class_1309 best = null;
      float bestAng = 30.0F;

      for(class_1297 e : field0796.field_1687.method_18112()) {
         if (e instanceof class_1309 t) {
            if (this.isValid(t)) {
               class_243 center = t.method_5829().method_1005();
               if (!(eye.method_1022(center) > (double)6.0F) && ((Boolean)this.walls.method0492() || !this.isBlocked(eye, center))) {
                  Rotation want = RotationHelper.method1296(center.method_1020(eye));
                  float ang = (float)Math.hypot((double)class_3532.method_15393(want.method2047() - cur.method2047()), (double)(want.method1762() - cur.method1762()));
                  if (ang < bestAng) {
                     bestAng = ang;
                     best = t;
                  }
               }
            }
         }
      }

      return best;
   }

   private boolean isBlocked(class_243 eye, class_243 center) {
      try {
         class_3965 hit = field0796.field_1687.method_17742(new class_3959(eye, center, class_3960.field_17558, class_242.field_1348, field0796.field_1724));
         return hit.method_17783() == class_240.field_1332;
      } catch (Exception var4) {
         return false;
      }
   }

   private boolean isValid(class_1309 e) {
      if (e != null && e != field0796.field_1724) {
         if (e.method_5805() && !e.method_31481()) {
            if (e instanceof class_1657) {
               return !this.isEnabled("Friends") && FriendManager.method0538().method2135(e.method_5477().getString()) ? false : this.isEnabled("Players");
            } else if (e instanceof class_1588) {
               return this.isEnabled("Mobs");
            } else {
               return e instanceof class_1296 ? this.isEnabled("Animals") : false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isEnabled(String name) {
      BooleanSetting s = this.targets.method0439(name);
      return s != null && (Boolean)s.method0492();
   }

   private boolean hasWeapon() {
      class_1799 stack = field0796.field_1724.method_6047();
      return stack.method_7909() instanceof class_1829 || stack.method_7909() instanceof class_1743 || stack.method_7909() instanceof class_9362;
   }
}
