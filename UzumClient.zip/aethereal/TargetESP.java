package aethereal;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public class TargetESP extends Module {
   private static final class_2960 field0160 = class_2960.method_60655("arbuzhack", "textures/target.png");
   private static final class_2960 field1522 = class_2960.method_60655("arbuzhack", "textures/glow.png");
   private static final class_2960 field1044 = class_2960.method_60655("arbuzhack", "textures/spark.png");
   private final EnumSetting<Mode> field0189;
   private final EnumSetting<TextureStyle> field0469;
   private final EnumSetting<ShapeType> field1626;
   private final ColorSetting field1550;
   private final FloatSetting field1716;
   private final FloatSetting field1144;
   private final BooleanSetting field1093;
   private final FloatSetting field1206;
   private static final int field0872 = 96;
   private static final float field0826 = 0.15F;
   private final EnumSetting<AnimationMode> field0918;
   private final FloatSetting field1341;
   private final FloatSetting field1302;
   private final FloatSetting field1377;
   private final FloatSetting field0393;
   private final BooleanSetting field0355;
   private class_1309 field0440;
   private class_1309 field0272;
   private final List<RenderPoint> field0238;
   private float field0289;
   private long field0525;
   private float field0501;
   private float field0547;
   private double field1670;
   private double field1656;
   private double field1687;
   private boolean field1597;
   private float field1577;
   private float field1601;
   private long field1755;
   private int field1740;
   private boolean field1774;
   private int field1175;
   private static final long field1165 = 240L;
   private static final float field1186 = 0.65F;
   private long field1120;
   private static final float field1112 = 0.18F;
   private static final float field1129 = 0.3F;
   private static final float field1227 = 0.4F;
   private static final float field1219 = 0.27F;
   private static final float field1234 = 0.6F;
   private static final float field0899 = 0.08F;
   private final List<TargetState> field0896;
   private boolean field0907;
   private double field0855;
   private double field0847;
   private double field0862;
   private double field0940;
   private float field0933;
   private float field0948;
   private float field1356;
   private final List<RenderShape> field1353;
   private class_1309 field1366;
   private final List<TargetAnimation> field1323;
   private float field1314;
   private static final class_243[][] field1329 = new class_243[][]{{new class_243((double)0.0F, 0.8500003162575299, 0.8000000015134241), new class_243(0.20000001585804067, 0.8500003162575299, -0.6750000685489941), new class_243(0.6000003159631385, 1.3499998137357587, 0.6000003159631385), new class_243(-0.7400002388842586, 1.0499995624093656, 0.39999995534312804), new class_243(0.7400000600814527, 0.950000007956495, -0.40000007458364306), new class_243(-0.475000060783353, 0.8500003162575299, (double)-0.375F), new class_243((double)0.0F, 1.3499998137357587, -0.6000002870957047), new class_243(0.8500003162575299, 0.7000001202807937, 0.09999998819572534), new class_243(-0.7000000376259103, 1.3499998137357587, -0.30000000195726123), new class_243(-0.30000000195726123, 1.3499998137357587, 0.550000008949574), new class_243((double)-0.5F, 0.7000001202807937, 0.7000001202807937), new class_243((double)0.5F, 0.7000001202807937, 0.7000001202807937), new class_243(-0.7000000376259103, (double)0.75F, (double)0.0F), new class_243(-0.20000003729295496, 0.6499997319148408, -0.7000000376259103)}};
   private static final class_243[][] field1401 = new class_243[][]{{new class_243((double)-49.0F, (double)0.0F, (double)40.0F), new class_243((double)35.0F, (double)0.0F, (double)-30.0F), new class_243((double)-30.0F, (double)0.0F, (double)35.0F), new class_243((double)-25.0F, (double)0.0F, (double)-30.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)30.0F, (double)0.0F, (double)-25.0F), new class_243((double)45.0F, (double)0.0F, (double)0.0F), new class_243((double)-30.0F, (double)0.0F, (double)30.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)0.0F)}};
   private static final int field1390 = 6;
   private static final float field1403 = 0.25F;
   private static final float field0412 = 0.5F;
   private static final float field0407 = 0.2F;
   private static final float field0418 = 0.06F;
   private static final float[] field0378 = new float[]{0.55F, 0.72F, 0.48F, 0.65F, 0.58F, 0.8F};
   private static final float[] field0374 = new float[]{0.0F, 1.2F, 2.8F, 4.1F, 5.5F, 0.7F};
   private static final float[] field0383 = new float[]{50.0F, 65.0F, 40.0F, 60.0F, 55.0F, 70.0F};
   private static final float[] field0452 = new float[]{0.35F, 0.5F, 0.42F, 0.6F, 0.38F, 0.55F};
   private static final float[] field0447 = new float[]{1.0F, 3.5F, 0.5F, 2.2F, 4.8F, 1.8F};
   private static final float[] field0456 = new float[]{20.0F, 30.0F, 25.0F, 35.0F, 22.0F, 28.0F};
   private static final float[] field0283 = new float[]{0.4F, 0.55F, 0.35F, 0.5F, 0.45F, 0.62F};
   private static final float[] field0278 = new float[]{0.5F, 2.0F, 3.8F, 1.3F, 4.5F, 0.2F};
   private static final float[] field0288 = new float[]{0.08F, 0.12F, 0.07F, 0.1F, 0.09F, 0.11F};
   private static final float[][] field0250;

   public TargetESP() {
      super("TargetESP", ModuleCategory.field1004, "Renders visual indicators around targets");
      this.field0189 = (EnumSetting)(new EnumSetting("targetesp.mode", TargetESP.Mode.field0699)).method1007("Mode").method0210("Visual style of the target indicator").method2130("Стиль модуля");
      this.field0469 = (EnumSetting)(new EnumSetting("targetesp.texture", TargetESP.TextureStyle.field0698, () -> this.field0189.method0492() == TargetESP.Mode.field0123)).method1007("Texture").method0210("Particle texture type").method2130("Тип текстуры");
      this.field1626 = (EnumSetting)(new EnumSetting("targetesp.shapetype", TargetESP.ShapeType.field0700, () -> this.field0189.method0492() == TargetESP.Mode.field1492)).method1007("Shape").method0210("Geometry shape for Shapes mode").method2130("Тип фигуры");
      this.field1550 = (ColorSetting)(new ColorSetting("targetesp.color", 255, 152, 226, 200)).method1882().method1007("Color").method0210("Color of the target indicator").method2130("Цвет");
      this.field1716 = (FloatSetting)(new FloatSetting("targetesp.speed", 1.5F, 1.0F, 15.0F, 0.5F)).method1007("Speed").method0210("Animation speed of the indicator").method2130("Скорость");
      this.field1144 = (FloatSetting)(new FloatSetting("targetesp.spread", 0.8F, 0.2F, 2.0F, 0.1F)).method1007("Spread").method0210("How far particles spread from target").method2130("Как далеко частицы разлетаются от таргета");
      this.field1093 = (BooleanSetting)(new BooleanSetting("targetesp.throughwalls", true)).method1007("Through Walls").method0210("Render indicator through blocks").method2130("Отображать таргет сквозь блоки");
      this.field1206 = (FloatSetting)(new FloatSetting("targetesp.fallbackrange", 12.0F, 2.0F, 20.0F, 0.5F)).method1007("Range").method0210("Max range for target detection").method2130("Максимальная дальность обнаружения цели");
      this.field0918 = (EnumSetting)(new EnumSetting("targetesp.bladeorbit", TargetESP.AnimationMode.field0697, () -> this.field0189.method0492() == TargetESP.Mode.field1019)).method1007("Blade Orbit").method0210("Orbit plane of blades").method2130("Плоскость орбиты лезвий");
      this.field1341 = (FloatSetting)(new FloatSetting("targetesp.bladeradius", 1.3F, 0.5F, 2.5F, 0.1F, () -> this.field0189.method0492() == TargetESP.Mode.field1019)).method1007("Blade Spread").method0210("Orbit radius as multiplier of hitbox width").method2130("Радиус орбиты как множитель ширины хитбокса");
      this.field1302 = (FloatSetting)(new FloatSetting("targetesp.bladesize", 1.0F, 0.4F, 1.0F, 0.1F, () -> this.field0189.method0492() == TargetESP.Mode.field1019)).method1007("Blade Size").method0210("Size of each blade").method2130("Размер лезвия");
      this.field1377 = (FloatSetting)(new FloatSetting("targetesp.bladespeed", 1.0F, 0.2F, 3.0F, 0.1F, () -> this.field0189.method0492() == TargetESP.Mode.field1019)).method1007("Blade Speed").method0210("Rotation speed of blades").method2130("Скорость вращения лезвий");
      this.field0393 = (FloatSetting)(new FloatSetting("targetesp.bladecount", 4.0F, 2.0F, 12.0F, 1.0F, () -> this.field0189.method0492() == TargetESP.Mode.field1019)).method1007("Blade Count").method0210("Number of blades").method2130("Количество лезвий");
      this.field0355 = (BooleanSetting)(new BooleanSetting("targetesp.cubesparks", false, () -> this.field0189.method0492() == TargetESP.Mode.field1266)).method1007("Sparks").method0210("Emit a small spark burst from the cube on each hit").method2130("Искорки вылетают из куба при ударе");
      this.field0238 = new ArrayList();
      this.field1755 = -1L;
      this.field1740 = -1;
      this.field1774 = false;
      this.field1175 = 0;
      this.field1120 = -1L;
      this.field0896 = new ArrayList();
      this.field0907 = false;
      this.field1353 = new ArrayList();
      this.field1323 = new ArrayList();
      this.method1013("Рисует красивые частицы вокруг таргет");
   }

   public void method0025() {
      super.method0025();
      this.field0440 = null;
      this.field0272 = null;
      this.field0238.clear();
      this.field0289 = 0.0F;
      this.field0525 = System.currentTimeMillis();
      this.field0501 = 0.0F;
      this.field0547 = 0.0F;
      this.field1597 = false;
      this.field1120 = -1L;
      this.field1774 = false;
      this.field1175 = 0;
      this.field0896.clear();
      this.field0907 = false;
      this.field1353.clear();
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         this.method1691();
         this.field1601 = this.field1577;
         this.field1577 += 4.0F;
         boolean isSwinging = field0796.field_1724.field_6252;
         int swingTicks = field0796.field_1724.field_6279;
         boolean newSwing = isSwinging && (!this.field1774 || swingTicks < this.field1175);
         this.field1774 = isSwinging;
         this.field1175 = swingTicks;
         if (newSwing && this.field0272 != null) {
            if (this.field0189.method0492() == TargetESP.Mode.field1019) {
               this.method1735();
            } else if (this.field0189.method0492() == TargetESP.Mode.field1266) {
               this.field1120 = System.currentTimeMillis();
               if ((Boolean)this.field0355.method0492()) {
                  this.method2043();
               }
            }
         }

      }
   }

   private void method1735() {
      if (this.field0272 != null) {
         int blades = ((Float)this.field0393.method0492()).intValue();
         if (blades > 0) {
            float angle = this.field1577 * (Float)this.field1377.method0492();
            float bestDistSq = Float.MAX_VALUE;
            int bestIndex = 0;
            float entityWidth = this.field0272.method_17681();
            float baseRadius = Math.max(0.4F, entityWidth) * (Float)this.field1341.method0492();
            float halfHeight = this.field0272.method_17682() * 0.5F + 0.25F;

            for(int i = 0; i < blades; ++i) {
               float bladeAngleDeg = angle + (float)i * (360.0F / (float)blades);
               float rad = (float)Math.toRadians((double)bladeAngleDeg);
               float bx = (float)this.field1670 + class_3532.method_15362(rad) * baseRadius;
               float by = (float)this.field1656 + halfHeight;
               float bz = (float)this.field1687 + class_3532.method_15374(rad) * baseRadius;
               float distSq = bx * bx + by * by + bz * bz;
               if (distSq < bestDistSq) {
                  bestDistSq = distSq;
                  bestIndex = i;
               }
            }

            this.field1740 = bestIndex;
            this.field1755 = System.currentTimeMillis();
         }
      }
   }

   private void method1691() {
      class_1309 newTarget = this.method1753();
      if (newTarget != this.field0440) {
         if (this.field0440 != null) {
            this.field0238.add(new RenderPoint(this.field0440));
         }

         this.field0440 = newTarget;
         this.field0547 = newTarget != null ? 0.0F : this.field0547;
      }

   }

   private class_1309 method1753() {
      Aura aura = Aura.method1701();
      return aura != null && aura.method2195() ? aura.method0409() : null;
   }

   @EventHandler
   public void onRender3D(WorldRenderEvent.GamePass event) {
      if (!method1974()) {
         long now = System.currentTimeMillis();
         float delta = (float)(now - this.field0525) / 1000.0F;
         this.field0525 = now;
         float animSpeed = this.field0189.method0492() == TargetESP.Mode.field0123 ? 1.5F : 4.0F;
         Iterator<RenderPoint> iterator = this.field0238.iterator();

         while(iterator.hasNext()) {
            RenderPoint fading = (RenderPoint)iterator.next();
            fading.field0003 -= delta * 2.0F;
            if (fading.field0003 <= 0.01F) {
               iterator.remove();
            } else {
               fading.field1409 = fading.field0731.method_23317();
               fading.field0956 = fading.field0731.method_23318();
               fading.field0757 = fading.field0731.method_23321();
            }
         }

         if (this.field0440 != null && this.field0440.method_5805()) {
            this.field0272 = this.field0440;
            this.field1597 = true;
            this.field0547 = Math.min(1.0F, this.field0547 + delta * animSpeed);
         } else {
            this.field1597 = false;
            this.field0547 = Math.max(0.0F, this.field0547 - delta * animSpeed);
         }

         this.field0501 = method2092(this.field0547);
         if (this.field0189.method0492() == TargetESP.Mode.field1266) {
            if (this.field0907 && !this.field1597) {
               this.method2015();
               this.field0907 = false;
            }

            if (!this.field0896.isEmpty()) {
               this.method2172(event.method1629(), delta, this.field1550.method1726());
            }

            if (!this.field1353.isEmpty()) {
               this.method1872(event.method1629(), delta, this.field1550.method1726());
            }
         } else {
            if (!this.field0896.isEmpty()) {
               this.field0896.clear();
            }

            if (!this.field1353.isEmpty()) {
               this.field1353.clear();
            }
         }

         if (this.field0501 <= 0.001F && this.field0238.isEmpty()) {
            if (!this.field1597) {
               this.field0272 = null;
            }

         } else {
            this.field0289 += (Float)this.field1716.method0492() * delta * 1.667F;
            float tickDelta = event.method1811().method_60637(false);
            class_243 camPos = field0796.field_1773.method_19418().method_19326();
            if (this.field0272 != null) {
               this.field1670 = class_3532.method_16436((double)tickDelta, this.field0272.field_6014, this.field0272.method_23317()) - camPos.field_1352;
               this.field1656 = class_3532.method_16436((double)tickDelta, this.field0272.field_6036, this.field0272.method_23318()) - camPos.field_1351;
               this.field1687 = class_3532.method_16436((double)tickDelta, this.field0272.field_5969, this.field0272.method_23321()) - camPos.field_1350;
            }

            Color c = this.field1550.method1726();
            float ease = this.field0501;
            if (this.field0189.method0492() == TargetESP.Mode.field0699) {
               if (this.field0272 != null && ease > 0.001F) {
                  int fadedAlpha = (int)((float)c.getAlpha() * ease);
                  this.method1494(event.method1629(), c, fadedAlpha, ease);
               }
            } else if (this.field0189.method0492() == TargetESP.Mode.field1492) {
               if (this.field0272 != null && ease > 0.001F) {
                  this.method1454(event.method1629(), ease);
               }
            } else if (this.field0189.method0492() == TargetESP.Mode.field1019) {
               if (this.field0272 != null && ease > 0.001F) {
                  this.method1474(event.method1629(), ease, tickDelta, c);
               }
            } else if (this.field0189.method0492() == TargetESP.Mode.field0783) {
               if (this.field0272 != null && ease > 0.001F) {
                  this.method1477(event.method1629(), ease, c);
               }
            } else if (this.field0189.method0492() == TargetESP.Mode.field1266) {
               if (this.field0272 != null && ease > 0.001F) {
                  this.method0330(event.method1629(), ease, c);
               }
            } else {
               RenderSystem.setShader(class_10142.field_53880);
               RenderSystem.setShaderTexture(0, this.method2028());
               RenderSystem.enableBlend();
               RenderSystem.blendFuncSeparate(770, 1, 0, 1);
               RenderSystem.disableCull();
               if ((Boolean)this.field1093.method0492()) {
                  RenderSystem.disableDepthTest();
               }

               RenderSystem.depthMask(false);
               int baseAlpha = c.getAlpha();
               if (this.field0272 != null && ease > 0.001F) {
                  int fadedAlpha = (int)((float)baseAlpha * ease);
                  Color fadedColor = new Color(c.getRed(), c.getGreen(), c.getBlue(), fadedAlpha);
                  float radius = (Float)this.field1144.method0492() * ease;
                  this.method1453(event.method1629(), this.field1670, this.field1656, this.field1687, this.field0289, radius, fadedColor, ease);
               }

               for(RenderPoint fading : this.field0238) {
                  float fadeEase = method2092(fading.field0003);
                  if (!(fadeEase <= 0.001F)) {
                     double fx = class_3532.method_16436((double)tickDelta, fading.field0731.field_6038, fading.field1409) - camPos.field_1352;
                     double fy = class_3532.method_16436((double)tickDelta, fading.field0731.field_5971, fading.field0956) - camPos.field_1351;
                     double fz = class_3532.method_16436((double)tickDelta, fading.field0731.field_5989, fading.field0757) - camPos.field_1350;
                     int fadedAlpha = (int)((float)baseAlpha * fadeEase);
                     Color fadedColor = new Color(c.getRed(), c.getGreen(), c.getBlue(), fadedAlpha);
                     float radius = (Float)this.field1144.method0492() * fadeEase;
                     this.method1453(event.method1629(), fx, fy, fz, this.field0289, radius, fadedColor, fadeEase);
                  }
               }

               RenderSystem.enableDepthTest();
               RenderSystem.depthMask(true);
               RenderSystem.disableBlend();
               RenderSystem.blendFunc(770, 771);
               RenderSystem.enableCull();
            }

         }
      }
   }

   private void method1453(class_4587 matrices, double x, double y, double z, float elapsed, float radius, Color color, float ease) {
      int layers = 3;
      int particles = 12;
      int total = layers * particles;
      class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);

      for(int i = 0; i < total; ++i) {
         int layer = i / particles;
         int idx = i % particles;
         float angle = (float)idx * (((float)Math.PI * 2F) / (float)particles);
         float phase = elapsed + angle;
         float drift = 0.3F * ease * class_3532.method_15374(elapsed + angle * 2.0F);
         float yOff = 0.5F + drift + 0.2F * (float)layer;
         float ox = radius * class_3532.method_15374(phase + (float)Math.pow((double)layer, (double)2.0F));
         float oz = radius * class_3532.method_15362(phase - (float)Math.pow((double)layer, (double)2.0F));
         float baseScale = 0.005F + (float)idx / 2000.0F;
         float scale = baseScale * ease;
         matrices.method_22903();
         matrices.method_22904(x + (double)ox, y + (double)yOff, z + (double)oz);
         matrices.method_22905(scale, scale, scale);
         matrices.method_22907(field0796.field_1773.method_19418().method_23767());
         float half = -25.0F;
         float size = 50.0F;
         int rgba = color.getRGB();
         buffer.method_22918(matrices.method_23760().method_23761(), half, half + size, 0.0F).method_22913(0.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrices.method_23760().method_23761(), half + size, half + size, 0.0F).method_22913(1.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrices.method_23760().method_23761(), half + size, half, 0.0F).method_22913(1.0F, 0.0F).method_39415(rgba);
         buffer.method_22918(matrices.method_23760().method_23761(), half, half, 0.0F).method_22913(0.0F, 0.0F).method_39415(rgba);
         matrices.method_22909();
      }

      class_286.method_43433(buffer.method_60800());
   }

   private class_2960 method2028() {
      class_2960 var10000;
      switch (((TextureStyle)this.field0469.method0492()).ordinal()) {
         case 1 -> var10000 = field1522;
         case 2 -> var10000 = field1044;
         default -> var10000 = field0160;
      }

      return var10000;
   }

   private void method1477(class_4587 matrices, float ease, Color baseColor) {
      float height = this.field0272.method_17682();
      float radius = Math.max(0.45F, this.field0272.method_17681() * 0.55F) * (Float)this.field1144.method0492();
      float phase = this.field0289 * 0.6F;
      float t = (class_3532.method_15374(phase) + 1.0F) * 0.5F;
      float y = t * height;
      float intensity = 0.5F + 0.5F * Math.abs(class_3532.method_15362(phase));
      int alpha = Math.max(0, Math.min(255, (int)((float)baseColor.getAlpha() * ease * intensity)));
      if (alpha >= 2) {
         int rgba = this.method0965(baseColor, alpha);
         class_4184 camera = field0796.field_1773.method_19418();
         RenderSystem.setShader(class_10142.field_53880);
         RenderSystem.setShaderTexture(0, field1522);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         RenderSystem.disableCull();
         if ((Boolean)this.field1093.method0492()) {
            RenderSystem.disableDepthTest();
         }

         RenderSystem.depthMask(false);

         for(int i = 0; i < 96; ++i) {
            float angle = ((float)Math.PI * 2F) * (float)i / 96.0F;
            float cos = class_3532.method_15362(angle);
            float sin = class_3532.method_15374(angle);
            this.method1512(matrices, camera, cos * radius, y, sin * radius, 0.15F, rgba);
         }

         RenderSystem.depthMask(true);
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.disableBlend();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private void method1512(class_4587 matrices, class_4184 camera, float px, float py, float pz, float size, int rgba) {
      if (rgba >>> 24 >= 2) {
         matrices.method_22903();
         matrices.method_46416((float)this.field1670 + px, (float)this.field1656 + py, (float)this.field1687 + pz);
         matrices.method_22907(camera.method_23767());
         Matrix4f matrix = matrices.method_23760().method_23761();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
         buffer.method_22918(matrix, -size, -size, 0.0F).method_22913(0.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrix, size, -size, 0.0F).method_22913(1.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrix, size, size, 0.0F).method_22913(1.0F, 0.0F).method_39415(rgba);
         buffer.method_22918(matrix, -size, size, 0.0F).method_22913(0.0F, 0.0F).method_39415(rgba);
         class_286.method_43433(buffer.method_60800());
         matrices.method_22909();
      }
   }

   private void method0330(class_4587 matrices, float ease, Color baseColor) {
      if (this.field1597) {
         class_4184 camera = field0796.field_1773.method_19418();
         float width = Math.max(0.4F, this.field0272.method_17681());
         float midY = this.field0272.method_17682() * 0.5F;
         float half = width * 0.5F / 1.7320508F * (Float)this.field1144.method0492() * ease * this.method0461();
         if (!(half < 0.001F)) {
            float angleY = this.method0645(this.field0289 * 0.4F);
            float angleX = this.method0645(this.field0289 * 0.27F + 0.5F);
            int rgba = this.method0965(baseColor, (int)((float)baseColor.getAlpha() * ease));
            RenderSystem.setShader(class_10142.field_53876);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.disableCull();
            if ((Boolean)this.field1093.method0492()) {
               RenderSystem.disableDepthTest();
            } else {
               RenderSystem.enableDepthTest();
            }

            RenderSystem.depthMask(false);
            matrices.method_22903();
            matrices.method_22904(this.field1670, this.field1656 + (double)midY, this.field1687);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(angleY));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(angleX));
            this.method1558(matrices.method_23760().method_23761(), half, half * 0.08F, rgba);
            matrices.method_22909();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            this.method1513(matrices, camera, angleY, angleX, half, midY, baseColor, ease);
            class_243 cp = camera.method_19326();
            this.field0855 = cp.field_1352 + this.field1670;
            this.field0847 = cp.field_1351 + this.field1656 + (double)midY;
            this.field0862 = cp.field_1350 + this.field1687;
            this.field0940 = cp.field_1351 + this.field1656;
            this.field0933 = half;
            this.field0948 = angleY;
            this.field1356 = angleX;
            this.field0907 = true;
         }
      }
   }

   private float method0645(float stepsFloat) {
      int step = (int)Math.floor((double)stepsFloat);
      float frac = stepsFloat - (float)step;
      float local = frac < 0.6F ? method0115(frac / 0.6F) : 1.0F;
      return ((float)(step % 4) + local) * 90.0F;
   }

   private void method1558(Matrix4f m, float half, float t, int rgba) {
      class_287 buf = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
      float f = 0.3F;

      for(int i = 0; i < 8; ++i) {
         float vx = (i & 1) != 0 ? half : -half;
         float vy = (i & 2) != 0 ? half : -half;
         float vz = (i & 4) != 0 ? half : -half;
         this.method1383(buf, m, vx, vy, vz, vx - 2.0F * vx * f, vy, vz, t, rgba);
         this.method1383(buf, m, vx, vy, vz, vx, vy - 2.0F * vy * f, vz, t, rgba);
         this.method1383(buf, m, vx, vy, vz, vx, vy, vz - 2.0F * vz * f, t, rgba);
      }

      class_286.method_43433(buf.method_60800());
   }

   private void method1383(class_287 buf, Matrix4f m, float ax, float ay, float az, float bx, float by, float bz, float t, int rgba) {
      float u0;
      float u1;
      float u2;
      float w0;
      float w1;
      float w2;
      if (ax != bx) {
         u0 = 0.0F;
         u1 = t;
         u2 = 0.0F;
         w0 = 0.0F;
         w1 = 0.0F;
         w2 = t;
      } else if (ay != by) {
         u0 = t;
         u1 = 0.0F;
         u2 = 0.0F;
         w0 = 0.0F;
         w1 = 0.0F;
         w2 = t;
      } else {
         u0 = t;
         u1 = 0.0F;
         u2 = 0.0F;
         w0 = 0.0F;
         w1 = t;
         w2 = 0.0F;
      }

      float a0x = ax - u0 - w0;
      float a0y = ay - u1 - w1;
      float a0z = az - u2 - w2;
      float a1x = ax + u0 - w0;
      float a1y = ay + u1 - w1;
      float a1z = az + u2 - w2;
      float a2x = ax + u0 + w0;
      float a2y = ay + u1 + w1;
      float a2z = az + u2 + w2;
      float a3x = ax - u0 + w0;
      float a3y = ay - u1 + w1;
      float a3z = az - u2 + w2;
      float b0x = bx - u0 - w0;
      float b0y = by - u1 - w1;
      float b0z = bz - u2 - w2;
      float b1x = bx + u0 - w0;
      float b1y = by + u1 - w1;
      float b1z = bz + u2 - w2;
      float b2x = bx + u0 + w0;
      float b2y = by + u1 + w1;
      float b2z = bz + u2 + w2;
      float b3x = bx - u0 + w0;
      float b3y = by - u1 + w1;
      float b3z = bz - u2 + w2;
      this.method1381(buf, m, a0x, a0y, a0z, a1x, a1y, a1z, a2x, a2y, a2z, a3x, a3y, a3z, rgba);
      this.method1381(buf, m, b0x, b0y, b0z, b3x, b3y, b3z, b2x, b2y, b2z, b1x, b1y, b1z, rgba);
      this.method1381(buf, m, a0x, a0y, a0z, b0x, b0y, b0z, b1x, b1y, b1z, a1x, a1y, a1z, rgba);
      this.method1381(buf, m, a1x, a1y, a1z, b1x, b1y, b1z, b2x, b2y, b2z, a2x, a2y, a2z, rgba);
      this.method1381(buf, m, a2x, a2y, a2z, b2x, b2y, b2z, b3x, b3y, b3z, a3x, a3y, a3z, rgba);
      this.method1381(buf, m, a3x, a3y, a3z, b3x, b3y, b3z, b0x, b0y, b0z, a0x, a0y, a0z, rgba);
   }

   private void method1381(class_287 buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, int rgba) {
      buf.method_22918(m, x0, y0, z0).method_39415(rgba);
      buf.method_22918(m, x1, y1, z1).method_39415(rgba);
      buf.method_22918(m, x2, y2, z2).method_39415(rgba);
      buf.method_22918(m, x3, y3, z3).method_39415(rgba);
   }

   private void method1513(class_4587 matrices, class_4184 camera, float angleY, float angleX, float half, float midY, Color baseColor, float ease) {
      class_4587 rotStack = new class_4587();
      rotStack.method_22907(class_7833.field_40716.rotationDegrees(angleY));
      rotStack.method_22907(class_7833.field_40714.rotationDegrees(angleX));
      Matrix4f rot = new Matrix4f(rotStack.method_23760().method_23761());
      RenderSystem.setShader(class_10142.field_53880);
      RenderSystem.setShaderTexture(0, field1522);
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
      RenderSystem.disableCull();
      if ((Boolean)this.field1093.method0492()) {
         RenderSystem.disableDepthTest();
      } else {
         RenderSystem.enableDepthTest();
      }

      RenderSystem.depthMask(false);
      int glowColor = this.method0965(baseColor, (int)((float)baseColor.getAlpha() * ease * 0.3F));
      float glowSize = half * 0.42F;
      float f = 0.3F;
      matrices.method_22903();
      matrices.method_22904(this.field1670, this.field1656 + (double)midY, this.field1687);
      class_287 buf = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);

      for(int i = 0; i < 8; ++i) {
         float vx = (i & 1) != 0 ? half : -half;
         float vy = (i & 2) != 0 ? half : -half;
         float vz = (i & 4) != 0 ? half : -half;
         this.method1380(buf, matrices, camera, rot, vx, vy, vz, vx - 2.0F * vx * f, vy, vz, glowSize, glowColor);
         this.method1380(buf, matrices, camera, rot, vx, vy, vz, vx, vy - 2.0F * vy * f, vz, glowSize, glowColor);
         this.method1380(buf, matrices, camera, rot, vx, vy, vz, vx, vy, vz - 2.0F * vz * f, glowSize, glowColor);
      }

      class_286.method_43433(buf.method_60800());
      matrices.method_22909();
      RenderSystem.depthMask(true);
      RenderSystem.enableDepthTest();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private void method1380(class_287 buf, class_4587 matrices, class_4184 camera, Matrix4f rot, float ax, float ay, float az, float bx, float by, float bz, float size, int color) {
      int samples = 3;

      for(int s = 0; s < samples; ++s) {
         float t = (float)s / (float)(samples - 1);
         float lx = ax + (bx - ax) * t;
         float ly = ay + (by - ay) * t;
         float lz = az + (bz - az) * t;
         Vector4f p = new Vector4f(lx, ly, lz, 1.0F);
         rot.transform(p);
         matrices.method_22903();
         matrices.method_46416(p.x, p.y, p.z);
         matrices.method_22907(camera.method_23767());
         Matrix4f m = matrices.method_23760().method_23761();
         buf.method_22918(m, -size, size, 0.0F).method_22913(0.0F, 1.0F).method_39415(color);
         buf.method_22918(m, size, size, 0.0F).method_22913(1.0F, 1.0F).method_39415(color);
         buf.method_22918(m, size, -size, 0.0F).method_22913(1.0F, 0.0F).method_39415(color);
         buf.method_22918(m, -size, -size, 0.0F).method_22913(0.0F, 0.0F).method_39415(color);
         matrices.method_22909();
      }

   }

   private void method2015() {
      this.field0896.clear();
      float half = this.field0933;
      if (!(half < 0.001F)) {
         float stubLen = 0.6F * half;
         class_4587 rs = new class_4587();
         rs.method_22907(class_7833.field_40716.rotationDegrees(this.field0948));
         rs.method_22907(class_7833.field_40714.rotationDegrees(this.field1356));
         Matrix4f rot = new Matrix4f(rs.method_23760().method_23761());

         for(int i = 0; i < 8; ++i) {
            float sx = (i & 1) != 0 ? 1.0F : -1.0F;
            float sy = (i & 2) != 0 ? 1.0F : -1.0F;
            float sz = (i & 4) != 0 ? 1.0F : -1.0F;
            Vector4f corner = new Vector4f(sx * half, sy * half, sz * half, 1.0F);
            rot.transform(corner);
            TargetState f = new TargetState();
            f.field0565 = this.field0855 + (double)corner.x;
            f.field0002 = this.field0847 + (double)corner.y;
            f.field1409 = this.field0862 + (double)corner.z;
            f.field0314 = half;
            f.field0177 = stubLen;
            f.field0458 = sx;
            f.field1614 = sy;
            f.field1538 = sz;
            double len = Math.sqrt((double)(corner.x * corner.x + corner.y * corner.y + corner.z * corner.z));
            if (len < 1.0000000052583687E-4) {
               len = (double)1.0F;
            }

            float burst = 1.7F;
            f.field0956 = (double)corner.x / len * (double)burst + (Math.random() - (double)0.5F) * 0.7000001202807937;
            f.field0757 = 1.299999465574693 + Math.random() * 0.9000000124056896;
            f.field1241 = (double)corner.z / len * (double)burst + (Math.random() - (double)0.5F) * 0.7000001202807937;
            f.field1704 = (float)(Math.random() * (double)360.0F);
            f.field1136 = (float)(Math.random() * (double)360.0F);
            f.field1087 = (float)(Math.random() * (double)360.0F);
            f.field1196 = (float)((Math.random() - (double)0.5F) * (double)520.0F);
            f.field0871 = (float)((Math.random() - (double)0.5F) * (double)520.0F);
            f.field0826 = (float)((Math.random() - (double)0.5F) * (double)520.0F);
            f.field0910 = 0.0F;
            f.field1331 = 1.1F + (float)(Math.random() * (double)0.5F);
            this.field0896.add(f);
         }

      }
   }

   private void method2172(class_4587 matrices, float delta, Color baseColor) {
      float dt = Math.min(delta, 0.1F);
      float gravity = 16.0F;
      Iterator<TargetState> it = this.field0896.iterator();

      while(it.hasNext()) {
         TargetState f = (TargetState)it.next();
         f.field0910 += dt;
         if (f.field0910 >= f.field1331) {
            it.remove();
         } else {
            f.field0757 -= (double)(gravity * dt);
            f.field0565 += f.field0956 * (double)dt;
            f.field0002 += f.field0757 * (double)dt;
            f.field1409 += f.field1241 * (double)dt;
            f.field1704 += f.field1196 * dt;
            f.field1136 += f.field0871 * dt;
            f.field1087 += f.field0826 * dt;
            if (f.field0002 <= this.field0940) {
               f.field0002 = this.field0940;
               if (f.field0757 < (double)0.0F) {
                  f.field0757 = -f.field0757 * 0.18000000001546174;
               }

               float damp = (float)Math.pow(5.000000474975632E-4, (double)dt);
               f.field0956 *= (double)damp;
               f.field1241 *= (double)damp;
               f.field1196 *= damp;
               f.field0871 *= damp;
               f.field0826 *= damp;
            }
         }
      }

      if (!this.field0896.isEmpty()) {
         class_4184 camera = field0796.field_1773.method_19418();
         class_243 camPos = camera.method_19326();
         int baseAlpha = baseColor.getAlpha();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.disableCull();
         if ((Boolean)this.field1093.method0492()) {
            RenderSystem.disableDepthTest();
         } else {
            RenderSystem.enableDepthTest();
         }

         RenderSystem.depthMask(false);
         class_287 buf = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);

         for(TargetState f : this.field0896) {
            int rgba = this.method0965(baseColor, (int)((float)baseAlpha * method0940(f)));
            float t = f.field0314 * 0.08F;
            matrices.method_22903();
            matrices.method_22904(f.field0565 - camPos.field_1352, f.field0002 - camPos.field_1351, f.field1409 - camPos.field_1350);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(f.field1136));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(f.field1704));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(f.field1087));
            Matrix4f m = matrices.method_23760().method_23761();
            this.method1383(buf, m, 0.0F, 0.0F, 0.0F, -f.field0458 * f.field0177, 0.0F, 0.0F, t, rgba);
            this.method1383(buf, m, 0.0F, 0.0F, 0.0F, 0.0F, -f.field1614 * f.field0177, 0.0F, t, rgba);
            this.method1383(buf, m, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -f.field1538 * f.field0177, t, rgba);
            matrices.method_22909();
         }

         class_286.method_43433(buf.method_60800());
         RenderSystem.depthMask(true);
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.setShader(class_10142.field_53880);
         RenderSystem.setShaderTexture(0, field1522);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         RenderSystem.disableCull();
         if ((Boolean)this.field1093.method0492()) {
            RenderSystem.disableDepthTest();
         } else {
            RenderSystem.enableDepthTest();
         }

         RenderSystem.depthMask(false);
         class_287 gb = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);

         for(TargetState f : this.field0896) {
            int gc = this.method0965(baseColor, (int)((float)baseAlpha * method0940(f) * 0.4F));
            float gs = f.field0314 * 0.6F;
            matrices.method_22903();
            matrices.method_22904(f.field0565 - camPos.field_1352, f.field0002 - camPos.field_1351, f.field1409 - camPos.field_1350);
            matrices.method_22907(camera.method_23767());
            Matrix4f m = matrices.method_23760().method_23761();
            gb.method_22918(m, -gs, gs, 0.0F).method_22913(0.0F, 1.0F).method_39415(gc);
            gb.method_22918(m, gs, gs, 0.0F).method_22913(1.0F, 1.0F).method_39415(gc);
            gb.method_22918(m, gs, -gs, 0.0F).method_22913(1.0F, 0.0F).method_39415(gc);
            gb.method_22918(m, -gs, -gs, 0.0F).method_22913(0.0F, 0.0F).method_39415(gc);
            matrices.method_22909();
         }

         class_286.method_43433(gb.method_60800());
         RenderSystem.depthMask(true);
         RenderSystem.enableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private static float method0940(TargetState f) {
      float t = f.field0910 / f.field1331;
      if (t < 0.6F) {
         return 1.0F;
      } else {
         float a = 1.0F - (t - 0.6F) / 0.4F;
         return a < 0.0F ? 0.0F : a;
      }
   }

   private void method2043() {
      float half = this.field0933;
      if (!(half < 0.001F) && this.field1353.size() <= 500) {
         class_4587 rs = new class_4587();
         rs.method_22907(class_7833.field_40716.rotationDegrees(this.field0948));
         rs.method_22907(class_7833.field_40714.rotationDegrees(this.field1356));
         Matrix4f rot = new Matrix4f(rs.method_23760().method_23761());
         int count = 12 + (int)(Math.random() * (double)5.0F);

         for(int i = 0; i < count; ++i) {
            int c = (int)(Math.random() * (double)8.0F);
            float lx = (c & 1) != 0 ? half : -half;
            float ly = (c & 2) != 0 ? half : -half;
            float lz = (c & 4) != 0 ? half : -half;
            Vector4f p = new Vector4f(lx, ly, lz, 1.0F);
            rot.transform(p);
            double len = Math.sqrt((double)(p.x * p.x + p.y * p.y + p.z * p.z));
            if (len < 1.0000000052583687E-4) {
               len = (double)1.0F;
            }

            double sp = 1.6000000484436039 + Math.random() * 2.2000000973542457;
            RenderShape s = new RenderShape();
            s.field0565 = this.field0855 + (double)p.x;
            s.field0002 = this.field0847 + (double)p.y;
            s.field1409 = this.field0862 + (double)p.z;
            s.field0956 = (double)p.x / len * sp + (Math.random() - (double)0.5F) * 1.2000006430216648;
            s.field0757 = (double)p.y / len * sp + (Math.random() - (double)0.5F) * 1.2000006430216648 + 0.6000003159631385;
            s.field1241 = (double)p.z / len * sp + (Math.random() - (double)0.5F) * 1.2000006430216648;
            s.field0314 = 0.0F;
            s.field0177 = 0.32F + (float)(Math.random() * 0.39999995534312804);
            s.field0458 = 0.02F + (float)(Math.random() * 0.035000023406755926);
            this.field1353.add(s);
         }

      }
   }

   private void method1872(class_4587 matrices, float delta, Color baseColor) {
      float dt = Math.min(delta, 0.1F);
      float gravity = 7.0F;
      Iterator<RenderShape> it = this.field1353.iterator();

      while(it.hasNext()) {
         RenderShape s = (RenderShape)it.next();
         s.field0314 += dt;
         if (s.field0314 >= s.field0177) {
            it.remove();
         } else {
            s.field0757 -= (double)(gravity * dt);
            s.field0565 += s.field0956 * (double)dt;
            s.field0002 += s.field0757 * (double)dt;
            s.field1409 += s.field1241 * (double)dt;
            double drag = Math.pow(0.3500000596053877, (double)dt);
            s.field0956 *= drag;
            s.field1241 *= drag;
         }
      }

      if (!this.field1353.isEmpty()) {
         class_4184 camera = field0796.field_1773.method_19418();
         class_243 camPos = camera.method_19326();
         int baseAlpha = baseColor.getAlpha();
         RenderSystem.setShader(class_10142.field_53880);
         RenderSystem.setShaderTexture(0, field1044);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         RenderSystem.disableCull();
         if ((Boolean)this.field1093.method0492()) {
            RenderSystem.disableDepthTest();
         } else {
            RenderSystem.enableDepthTest();
         }

         RenderSystem.depthMask(false);
         class_287 buf = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);

         for(RenderShape s : this.field1353) {
            float a = 1.0F - s.field0314 / s.field0177;
            int col = this.method0965(baseColor, (int)((float)baseAlpha * a));
            float sz = s.field0458 * (0.55F + 0.45F * a);
            matrices.method_22903();
            matrices.method_22904(s.field0565 - camPos.field_1352, s.field0002 - camPos.field_1351, s.field1409 - camPos.field_1350);
            matrices.method_22907(camera.method_23767());
            Matrix4f m = matrices.method_23760().method_23761();
            buf.method_22918(m, -sz, sz, 0.0F).method_22913(0.0F, 1.0F).method_39415(col);
            buf.method_22918(m, sz, sz, 0.0F).method_22913(1.0F, 1.0F).method_39415(col);
            buf.method_22918(m, sz, -sz, 0.0F).method_22913(1.0F, 0.0F).method_39415(col);
            buf.method_22918(m, -sz, -sz, 0.0F).method_22913(0.0F, 0.0F).method_39415(col);
            matrices.method_22909();
         }

         class_286.method_43433(buf.method_60800());
         RenderSystem.depthMask(true);
         RenderSystem.enableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private float method0461() {
      if (this.field1120 < 0L) {
         return 1.0F;
      } else {
         long e = System.currentTimeMillis() - this.field1120;
         if (e >= 240L) {
            this.field1120 = -1L;
            return 1.0F;
         } else {
            float t = (float)e / 240.0F;
            float squash = t < 0.5F ? method2092(t * 2.0F) * 0.18F : (1.0F - method2092((t - 0.5F) * 2.0F)) * 0.18F;
            return 1.0F - squash;
         }
      }
   }

   private static float method0115(float t) {
      float c1 = 1.70158F;
      float c3 = c1 + 1.0F;
      float p = t - 1.0F;
      return 1.0F + c3 * p * p * p + c1 * p * p;
   }

   private void method1494(class_4587 matrices, Color c, int fadedAlpha, float ease) {
      float targetHeight = this.field0272.method_17682();
      float radius = (Float)this.field1144.method0492() * ease;
      int curves = 7;
      int segments = 80;
      this.method0457();
      Matrix4f matrix = matrices.method_23760().method_23761();
      float[][] bloomLayers = new float[][]{{0.06F, 0.18F}, {0.14F, 0.07F}, {0.26F, 0.03F}};
      float[][] bloomDirs = new float[][]{{1.0F, 0.0F}, {-1.0F, 0.0F}, {0.0F, 1.0F}, {0.0F, -1.0F}};

      for(float[] layer : bloomLayers) {
         float br = layer[0];
         float ba = layer[1];

         for(float[] dir : bloomDirs) {
            float ox = dir[0] * br;
            float oz = dir[1] * br;

            for(int curve = 0; curve < curves; ++curve) {
               float phaseX = (float)curve * 1.7F;
               float phaseY = (float)curve * 2.3F;
               float phaseZ = (float)curve * 1.1F;
               float freqX = 1.0F + (float)curve * 0.3F;
               float freqY = 0.7F + (float)curve * 0.2F;
               float freqZ = 1.2F + (float)curve * 0.25F;
               class_287 bloom = class_289.method_1348().method_60827(class_5596.field_29345, class_290.field_1576);

               for(int i = 0; i <= segments; i += 4) {
                  float t = (float)i / (float)segments;
                  float time = this.field0289 * 0.5F;
                  float x = radius * class_3532.method_15374(time * freqX + t * 6.0F + phaseX) * (0.5F + 0.5F * class_3532.method_15362(t * 3.0F + time * 0.3F));
                  float y = targetHeight * 0.5F + radius * 0.8F * class_3532.method_15374(time * freqY + t * 4.0F + phaseY);
                  float z = radius * class_3532.method_15362(time * freqZ + t * 5.0F + phaseZ) * (0.5F + 0.5F * class_3532.method_15374(t * 2.0F + time * 0.4F));
                  float trailFade = class_3532.method_15374(t * (float)Math.PI);
                  bloom.method_22918(matrix, (float)(this.field1670 + (double)x + (double)ox), (float)(this.field1656 + (double)y), (float)(this.field1687 + (double)z + (double)oz)).method_39415(this.method0965(c, (int)((float)fadedAlpha * trailFade * ba)));
               }

               class_286.method_43433(bloom.method_60800());
            }
         }
      }

      for(int curve = 0; curve < curves; ++curve) {
         float phaseX = (float)curve * 1.7F;
         float phaseY = (float)curve * 2.3F;
         float phaseZ = (float)curve * 1.1F;
         float freqX = 1.0F + (float)curve * 0.3F;
         float freqY = 0.7F + (float)curve * 0.2F;
         float freqZ = 1.2F + (float)curve * 0.25F;
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29345, class_290.field_1576);

         for(int i = 0; i <= segments; ++i) {
            float t = (float)i / (float)segments;
            float time = this.field0289 * 0.5F;
            float x = radius * class_3532.method_15374(time * freqX + t * 6.0F + phaseX) * (0.5F + 0.5F * class_3532.method_15362(t * 3.0F + time * 0.3F));
            float y = targetHeight * 0.5F + radius * 0.8F * class_3532.method_15374(time * freqY + t * 4.0F + phaseY);
            float z = radius * class_3532.method_15362(time * freqZ + t * 5.0F + phaseZ) * (0.5F + 0.5F * class_3532.method_15374(t * 2.0F + time * 0.4F));
            float trailFade = class_3532.method_15374(t * (float)Math.PI);
            int alpha = (int)((float)fadedAlpha * trailFade * 0.85F);
            buffer.method_22918(matrix, (float)(this.field1670 + (double)x), (float)(this.field1656 + (double)y), (float)(this.field1687 + (double)z)).method_39415(this.method0965(c, alpha));
         }

         class_286.method_43433(buffer.method_60800());
         class_287 glow = class_289.method_1348().method_60827(class_5596.field_29345, class_290.field_1576);

         for(int i = 0; i <= segments; i += 2) {
            float t = (float)i / (float)segments;
            float time = this.field0289 * 0.5F;
            float x = radius * class_3532.method_15374(time * freqX + t * 6.0F + phaseX) * (0.5F + 0.5F * class_3532.method_15362(t * 3.0F + time * 0.3F));
            float y = targetHeight * 0.5F + radius * 0.8F * class_3532.method_15374(time * freqY + t * 4.0F + phaseY);
            float z = radius * class_3532.method_15362(time * freqZ + t * 5.0F + phaseZ) * (0.5F + 0.5F * class_3532.method_15374(t * 2.0F + time * 0.4F));
            float trailFade = class_3532.method_15374(t * (float)Math.PI);
            glow.method_22918(matrix, (float)(this.field1670 + (double)x + (double)0.020000007F), (float)(this.field1656 + (double)y + (double)0.020000007F), (float)(this.field1687 + (double)z)).method_39415(this.method0965(c, (int)((float)fadedAlpha * trailFade * 0.2F)));
         }

         class_286.method_43433(glow.method_60800());
      }

      this.method0479();
   }

   private void method1454(class_4587 matrices, float ease) {
      if (this.field0272 != null) {
         if (this.field1323.isEmpty() || this.field0272 != this.field1366) {
            this.field1366 = this.field0272;
            this.field1323.clear();
            class_243[] positions = field1329[0];
            class_243[] rotations = field1401[0];

            for(int i = 0; i < positions.length; ++i) {
               this.field1323.add(new TargetAnimation(positions[i], rotations[i]));
            }
         }

         RenderSystem.enableDepthTest();
         this.field1314 = (this.field1314 + 0.5F) % 360.0F;
         class_4184 camera = field0796.field_1773.method_19418();
         matrices.method_22903();
         matrices.method_22904(this.field1670, this.field1656, this.field1687);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(this.field1314));
         Color c = this.field1550.method1726();
         int baseColor = this.method0965(c, (int)((float)c.getAlpha() * ease));
         ShapeType shape = (ShapeType)this.field1626.method0492();
         float sp = (Float)this.field1144.method0492();

         for(TargetAnimation node : this.field1323) {
            node.method1476(matrices, ease, baseColor, camera, shape, sp);
         }

         matrices.method_22909();
         RenderSystem.enableDepthTest();
      }
   }

   private void method0457() {
      RenderSystem.setShader(class_10142.field_53876);
      RenderSystem.enableBlend();
      RenderSystem.blendFuncSeparate(770, 1, 0, 1);
      RenderSystem.disableCull();
      if ((Boolean)this.field1093.method0492()) {
         RenderSystem.disableDepthTest();
      }

      RenderSystem.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
   }

   private void method0479() {
      GL11.glDisable(2848);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
      RenderSystem.blendFunc(770, 771);
      RenderSystem.enableCull();
   }

   private int method0965(Color c, int alpha) {
      return (new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, alpha)))).getRGB();
   }

   private static float method2092(float t) {
      return t < 0.5F ? 4.0F * t * t * t : 1.0F - (float)Math.pow((double)(-2.0F * t + 2.0F), (double)3.0F) / 2.0F;
   }

   private void method1474(class_4587 matrices, float ease, float partialTicks, Color baseColor) {
      class_4184 camera = field0796.field_1773.method_19418();
      float rotationSpeed = (Float)this.field1377.method0492();
      int blades = ((Float)this.field0393.method0492()).intValue();
      boolean shineEnabled = true;
      float angle = class_3532.method_16439(partialTicks, this.field1601, this.field1577) * rotationSpeed;
      float targetHalfHeight = this.field0272.method_17682() * 0.5F;
      float entityWidth = this.field0272.method_17681();
      float baseRadius = Math.max(0.4F, entityWidth) * (Float)this.field1341.method0492();
      float burst = 1.0F - ease;
      float easeBurst = burst * burst * (3.0F - 2.0F * burst);
      float actualRadius = baseRadius + easeBurst * 0.4F;
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
      if ((Boolean)this.field1093.method0492()) {
         RenderSystem.disableDepthTest();
      } else {
         RenderSystem.enableDepthTest();
      }

      RenderSystem.setShader(class_10142.field_53876);
      boolean cameraOrbit = this.field0918.method0492() == TargetESP.AnimationMode.field0697;
      float size = (Float)this.field1302.method0492();
      matrices.method_22903();
      matrices.method_22904(this.field1670, this.field1656 + (double)targetHalfHeight + (double)0.25F, this.field1687);
      if (cameraOrbit) {
         matrices.method_22907(camera.method_23767());
      }

      class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27379, class_290.field_1576);

      for(int i = 0; i < blades; ++i) {
         float bladeAngleDeg = angle + (float)i * (360.0F / (float)blades);
         this.method1510(matrices, buffer, bladeAngleDeg, 0.0F, actualRadius, ease, i, angle, baseColor, cameraOrbit, size);
      }

      class_286.method_43433(buffer.method_60800());
      if (shineEnabled) {
         RenderSystem.setShaderTexture(0, field1522);
         RenderSystem.setShader(class_10142.field_53880);
         class_287 glowBuffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);

         for(int i = 0; i < blades; ++i) {
            float bladeAngleDeg = angle + (float)i * (360.0F / (float)blades);
            this.method1511(matrices, glowBuffer, camera, bladeAngleDeg, 0.0F, actualRadius, ease, i, angle, baseColor, cameraOrbit, size);
         }

         class_286.method_43433(glowBuffer.method_60800());
      }

      matrices.method_22909();
      RenderSystem.enableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private float method0715(int bladeIndex) {
      if (bladeIndex == this.field1740 && this.field1755 >= 0L) {
         long elapsed = System.currentTimeMillis() - this.field1755;
         if (elapsed >= 240L) {
            this.field1755 = -1L;
            this.field1740 = -1;
            return 1.0F;
         } else {
            float t = (float)elapsed / 240.0F;
            float thrust = t < 0.5F ? method2092(t * 2.0F) * 0.65F : (1.0F - method2092((t - 0.5F) * 2.0F)) * 0.65F;
            return 1.0F - thrust;
         }
      } else {
         return 1.0F;
      }
   }

   private void method1510(class_4587 matrices, class_287 buffer, float bladeAngleDeg, float yCenter, float orbitRadius, float alpha, int bladeIndex, float globalAngle, Color baseColor, boolean cameraOrbit, float size) {
      float angleRad = (float)Math.toRadians((double)bladeAngleDeg);
      float radiusFactor = this.method0715(bladeIndex);
      float posA = class_3532.method_15362(angleRad) * orbitRadius * radiusFactor;
      float posB = class_3532.method_15374(angleRad) * orbitRadius * radiusFactor;
      int idx = bladeIndex % 6;
      float tiltTime = (float)Math.toRadians((double)(globalAngle * field0378[idx])) + field0374[idx];
      float rollTime = (float)Math.toRadians((double)(globalAngle * field0452[idx])) + field0447[idx];
      float bobTime = (float)Math.toRadians((double)(globalAngle * field0283[idx])) + field0278[idx];
      float tiltAngle = class_3532.method_15374(tiltTime) * field0383[idx];
      float rollAngle = class_3532.method_15374(rollTime) * field0456[idx];
      float bob = class_3532.method_15374(bobTime) * field0288[idx];
      matrices.method_22903();
      if (cameraOrbit) {
         matrices.method_46416(posA, yCenter + posB, bob);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(bladeAngleDeg - 90.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-90.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(tiltAngle));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(rollAngle));
      } else {
         matrices.method_46416(posA, yCenter + bob, posB);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-bladeAngleDeg - 90.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(tiltAngle));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(rollAngle));
      }

      matrices.method_22905(size, size, size);
      Matrix4f matrix = matrices.method_23760().method_23761();
      int cTip = this.method0965(baseColor, (int)(alpha * 255.0F));
      int cWing = this.method0965(baseColor, (int)(alpha * 240.0F));
      int cEdge = this.method0965(baseColor, (int)(alpha * 200.0F));
      float tipZ = -0.25F;
      float leftOutX = -0.5F;
      float leftOutZ = 0.2F;
      float leftInX = -0.06F;
      float rightOutX = 0.5F;
      float rightOutZ = 0.2F;
      float rightInX = 0.06F;
      buffer.method_22918(matrix, 0.0F, 0.0F, tipZ).method_39415(cTip);
      buffer.method_22918(matrix, leftInX, 0.0F, 0.0F).method_39415(cWing);
      buffer.method_22918(matrix, leftOutX, 0.0F, leftOutZ).method_39415(cEdge);
      buffer.method_22918(matrix, 0.0F, 0.0F, tipZ).method_39415(cTip);
      buffer.method_22918(matrix, 0.0F, 0.0F, 0.0F).method_39415(cWing);
      buffer.method_22918(matrix, leftInX, 0.0F, 0.0F).method_39415(cWing);
      buffer.method_22918(matrix, 0.0F, 0.0F, tipZ).method_39415(cTip);
      buffer.method_22918(matrix, rightOutX, 0.0F, rightOutZ).method_39415(cEdge);
      buffer.method_22918(matrix, rightInX, 0.0F, 0.0F).method_39415(cWing);
      buffer.method_22918(matrix, 0.0F, 0.0F, tipZ).method_39415(cTip);
      buffer.method_22918(matrix, rightInX, 0.0F, 0.0F).method_39415(cWing);
      buffer.method_22918(matrix, 0.0F, 0.0F, 0.0F).method_39415(cWing);
      matrices.method_22909();
   }

   private void method1511(class_4587 matrices, class_287 buffer, class_4184 camera, float bladeAngleDeg, float yCenter, float orbitRadius, float alpha, int bladeIndex, float globalAngle, Color baseColor, boolean cameraOrbit, float size) {
      float angleRad = (float)Math.toRadians((double)bladeAngleDeg);
      float radiusFactor = this.method0715(bladeIndex);
      float posA = class_3532.method_15362(angleRad) * orbitRadius * radiusFactor;
      float posB = class_3532.method_15374(angleRad) * orbitRadius * radiusFactor;
      int idx = bladeIndex % 6;
      float tiltTime = (float)Math.toRadians((double)(globalAngle * field0378[idx])) + field0374[idx];
      float rollTime = (float)Math.toRadians((double)(globalAngle * field0452[idx])) + field0447[idx];
      float bobTime = (float)Math.toRadians((double)(globalAngle * field0283[idx])) + field0278[idx];
      float tiltAngle = class_3532.method_15374(tiltTime) * field0383[idx];
      float rollAngle = class_3532.method_15374(rollTime) * field0456[idx];
      float bob = class_3532.method_15374(bobTime) * field0288[idx];
      class_4587 tempStack = new class_4587();
      if (cameraOrbit) {
         tempStack.method_46416(posA, yCenter + posB, bob);
         tempStack.method_22907(class_7833.field_40718.rotationDegrees(bladeAngleDeg - 90.0F));
         tempStack.method_22907(class_7833.field_40714.rotationDegrees(-90.0F));
         tempStack.method_22907(class_7833.field_40716.rotationDegrees(tiltAngle));
         tempStack.method_22907(class_7833.field_40714.rotationDegrees(rollAngle));
      } else {
         tempStack.method_46416(posA, yCenter + bob, posB);
         tempStack.method_22907(class_7833.field_40716.rotationDegrees(-bladeAngleDeg - 90.0F));
         tempStack.method_22907(class_7833.field_40714.rotationDegrees(tiltAngle));
         tempStack.method_22907(class_7833.field_40718.rotationDegrees(rollAngle));
      }

      tempStack.method_22905(size, size, size);
      Matrix4f bladeTransform = new Matrix4f(tempStack.method_23760().method_23761());

      for(float[] point : field0250) {
         float localX = point[0];
         float localY = point[1];
         float localZ = point[2];
         float glowSize = point[3];
         float alphaFactor = point[4];
         Vector4f transformed = new Vector4f(localX, localY, localZ, 1.0F);
         bladeTransform.transform(transformed);
         int c = this.method0965(baseColor, (int)(alpha * 22.0F * alphaFactor));
         matrices.method_22903();
         matrices.method_46416(transformed.x, transformed.y, transformed.z);
         if (!cameraOrbit) {
            matrices.method_22907(camera.method_23767());
         }

         Matrix4f matrix = matrices.method_23760().method_23761();
         buffer.method_22918(matrix, -glowSize, glowSize, 0.0F).method_22913(0.0F, 1.0F).method_39415(c);
         buffer.method_22918(matrix, glowSize, glowSize, 0.0F).method_22913(1.0F, 1.0F).method_39415(c);
         buffer.method_22918(matrix, glowSize, -glowSize, 0.0F).method_22913(1.0F, 0.0F).method_39415(c);
         buffer.method_22918(matrix, -glowSize, -glowSize, 0.0F).method_22913(0.0F, 0.0F).method_39415(c);
         matrices.method_22909();
      }

   }

   static {
      int armSamples = 12;
      int total = 3 + armSamples * 2;
      field0250 = new float[total][5];
      int idx = 0;
      field0250[idx++] = new float[]{0.0F, 0.0F, -0.25F, 0.22F, 1.0F};

      for(int i = 1; i <= armSamples; ++i) {
         float t = (float)i / (float)(armSamples + 1);
         float x = -0.5F * t;
         float z = class_3532.method_16439(t, -0.25F, 0.2F);
         float size = class_3532.method_16439(t, 0.18F, 0.14F);
         float alphaF = class_3532.method_16439(t, 0.9F, 0.7F);
         field0250[idx++] = new float[]{x, 0.0F, z, size, alphaF};
      }

      field0250[idx++] = new float[]{-0.5F, 0.0F, 0.2F, 0.2F, 0.9F};

      for(int i = 1; i <= armSamples; ++i) {
         float t = (float)i / (float)(armSamples + 1);
         float x = 0.5F * t;
         float z = class_3532.method_16439(t, -0.25F, 0.2F);
         float size = class_3532.method_16439(t, 0.18F, 0.14F);
         float alphaF = class_3532.method_16439(t, 0.9F, 0.7F);
         field0250[idx++] = new float[]{x, 0.0F, z, size, alphaF};
      }

      field0250[idx] = new float[]{0.5F, 0.0F, 0.2F, 0.2F, 0.9F};
   }

   private static class TargetState {
      double field0565;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      float field0314;
      float field0177;
      float field0458;
      float field1614;
      float field1538;
      float field1704;
      float field1136;
      float field1087;
      float field1196;
      float field0871;
      float field0826;
      float field0910;
      float field1331;
   }

   private static class RenderShape {
      double field0565;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      float field0314;
      float field0177;
      float field0458;
   }

   private static class RenderPoint {
      class_1309 field0731;
      float field0003;
      double field1409;
      double field0956;
      double field0757;

      RenderPoint(class_1309 entity) {
         this.field0731 = entity;
         this.field0003 = 1.0F;
         this.field1409 = entity.method_23317();
         this.field0956 = entity.method_23318();
         this.field0757 = entity.method_23321();
      }
   }

   private static class TargetAnimation {
      final class_243 field0735;
      final class_243 field0157;
      static final float field1410 = 0.05F;
      final float field0957;

      TargetAnimation(class_243 position, class_243 rotation) {
         this.field0735 = position;
         this.field0157 = rotation;
         this.field0957 = 0.5F + (float)(Math.random() * (double)1.5F);
      }

      void method1476(class_4587 ms, float anim, int baseColor, class_4184 camera, ShapeType shape, float spread) {
         ms.method_22903();
         ms.method_22904(this.field0735.field_1352 * (double)spread, this.field0735.field_1351, this.field0735.field_1350 * (double)spread);
         float pulsation = 1.0F + (float)(Math.sin((double)System.currentTimeMillis() / (double)500.0F) * (double)0.1F);
         ms.method_22905(pulsation, pulsation, pulsation);
         float selfRot = (float)(System.currentTimeMillis() % 36000L) / 100.0F * this.field0957;
         ms.method_22907(class_7833.field_40714.rotationDegrees((float)this.field0157.field_1352));
         ms.method_22907(class_7833.field_40716.rotationDegrees((float)this.field0157.field_1351 + selfRot));
         ms.method_22907(class_7833.field_40718.rotationDegrees((float)this.field0157.field_1350));
         RenderSystem.disableCull();
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         method1480(ms, baseColor, 0.2F, true, anim, shape);
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         method1480(ms, baseColor, 0.3F, true, anim, shape);
         method1480(ms, baseColor, 0.8F, false, anim, shape);
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         ms.method_22903();
         ms.method_22905(1.2F, 1.2F, 1.2F);
         method1480(ms, baseColor, 0.3F, true, anim, shape);
         ms.method_22909();
         this.method1479(ms, baseColor, anim, camera);
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         ms.method_22909();
      }

      private void method1479(class_4587 ms, int baseColor, float anim, class_4184 camera) {
         RenderSystem.setShader(class_10142.field_53880);
         RenderSystem.setShaderTexture(0, TargetESP.field1522);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         RenderSystem.depthMask(false);
         int bloomColor = baseColor & 16777215 | Math.min(255, (int)(10.0F * anim)) << 24;
         float bloomSize = 0.65000004F;

         for(int i = 0; i < 6; ++i) {
            ms.method_22903();
            ms.method_22907(class_7833.field_40716.rotationDegrees(60.0F * (float)i));
            ms.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            Matrix4f matrix = ms.method_23760().method_23761();
            class_287 buf = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
            buf.method_22918(matrix, -bloomSize / 2.0F, -bloomSize / 2.0F, 0.0F).method_22913(0.0F, 1.0F).method_39415(bloomColor);
            buf.method_22918(matrix, bloomSize / 2.0F, -bloomSize / 2.0F, 0.0F).method_22913(1.0F, 1.0F).method_39415(bloomColor);
            buf.method_22918(matrix, bloomSize / 2.0F, bloomSize / 2.0F, 0.0F).method_22913(1.0F, 0.0F).method_39415(bloomColor);
            buf.method_22918(matrix, -bloomSize / 2.0F, bloomSize / 2.0F, 0.0F).method_22913(0.0F, 0.0F).method_39415(bloomColor);
            class_286.method_43433(buf.method_60800());
            ms.method_22909();
         }

         RenderSystem.depthMask(true);
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      }

      private static void method1480(class_4587 ms, int baseColor, float alpha, boolean filled, float anim, ShapeType shape) {
         RenderSystem.setShader(class_10142.field_53876);
         int finalColor = baseColor & 16777215 | Math.min(255, (int)(alpha * 255.0F * anim)) << 24;
         Matrix4f matrix = ms.method_23760().method_23761();
         switch (shape.ordinal()) {
            case 0 -> method0344(matrix, finalColor, filled);
            case 1 -> method2177(matrix, finalColor, filled);
            case 2 -> method1875(matrix, finalColor, filled);
            case 3 -> method1675(matrix, finalColor, filled);
         }

      }

      private static void method1561(Matrix4f matrix, int color, boolean filled) {
         float s = 0.05F;
         int n = 8;
         List<class_243> top = new ArrayList();
         List<class_243> bot = new ArrayList();

         for(int i = 0; i < n; ++i) {
            float a = (float)(6.283187810787048 * (double)i / (double)n);
            top.add(new class_243((double)s * Math.cos((double)a), (double)(s / 2.0F), (double)s * Math.sin((double)a)));
            bot.add(new class_243((double)s * Math.cos((double)a), (double)(-s / 2.0F), (double)s * Math.sin((double)a)));
         }

         class_243 vt = new class_243((double)0.0F, (double)(s * 2.0F), (double)0.0F);
         class_243 vb = new class_243((double)0.0F, (double)(-s * 2.0F), (double)0.0F);
         method1562(matrix, color, filled, top, bot, vt, vb, n);
      }

      private static void method0344(Matrix4f matrix, int color, boolean filled) {
         float s = 0.075F;
         class_243 t = new class_243((double)0.0F, (double)s, (double)0.0F);
         class_243 b = new class_243((double)0.0F, (double)(-s), (double)0.0F);
         class_243 f = new class_243((double)s, (double)0.0F, (double)0.0F);
         class_243 bk = new class_243((double)(-s), (double)0.0F, (double)0.0F);
         class_243 l = new class_243((double)0.0F, (double)0.0F, (double)s);
         class_243 r = new class_243((double)0.0F, (double)0.0F, (double)(-s));
         class_287 buf = method1569(filled);
         if (filled) {
            method1388(buf, matrix, t, f, l, color);
            method1388(buf, matrix, t, l, bk, color);
            method1388(buf, matrix, t, bk, r, color);
            method1388(buf, matrix, t, r, f, color);
            method1388(buf, matrix, b, l, f, color);
            method1388(buf, matrix, b, bk, l, color);
            method1388(buf, matrix, b, r, bk, color);
            method1388(buf, matrix, b, f, r, color);
         } else {
            method1387(buf, matrix, t, f, color);
            method1387(buf, matrix, t, bk, color);
            method1387(buf, matrix, t, l, color);
            method1387(buf, matrix, t, r, color);
            method1387(buf, matrix, b, f, color);
            method1387(buf, matrix, b, bk, color);
            method1387(buf, matrix, b, l, color);
            method1387(buf, matrix, b, r, color);
            method1387(buf, matrix, f, l, color);
            method1387(buf, matrix, l, bk, color);
            method1387(buf, matrix, bk, r, color);
            method1387(buf, matrix, r, f, color);
         }

         class_286.method_43433(buf.method_60800());
      }

      private static void method2177(Matrix4f matrix, int color, boolean filled) {
         float s = 0.05F;
         class_243[] v = new class_243[]{new class_243((double)(-s), (double)(-s), (double)(-s)), new class_243((double)s, (double)(-s), (double)(-s)), new class_243((double)s, (double)s, (double)(-s)), new class_243((double)(-s), (double)s, (double)(-s)), new class_243((double)(-s), (double)(-s), (double)s), new class_243((double)s, (double)(-s), (double)s), new class_243((double)s, (double)s, (double)s), new class_243((double)(-s), (double)s, (double)s)};
         int[][] faces = new int[][]{{0, 1, 2, 3}, {5, 4, 7, 6}, {1, 5, 6, 2}, {4, 0, 3, 7}, {3, 2, 6, 7}, {4, 5, 1, 0}};
         class_287 buf = method1569(filled);
         if (filled) {
            for(int[] f : faces) {
               method1388(buf, matrix, v[f[0]], v[f[1]], v[f[2]], color);
               method1388(buf, matrix, v[f[0]], v[f[2]], v[f[3]], color);
            }
         } else {
            int[][] edges = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

            for(int[] e : edges) {
               method1387(buf, matrix, v[e[0]], v[e[1]], color);
            }
         }

         class_286.method_43433(buf.method_60800());
      }

      private static void method1875(Matrix4f matrix, int color, boolean filled) {
         float s = 0.060000002F;
         float phi = (1.0F + (float)Math.sqrt((double)5.0F)) / 2.0F;
         float b = s * phi;
         class_243[] v = new class_243[]{new class_243((double)(-s), (double)b, (double)0.0F), new class_243((double)s, (double)b, (double)0.0F), new class_243((double)(-s), (double)(-b), (double)0.0F), new class_243((double)s, (double)(-b), (double)0.0F), new class_243((double)0.0F, (double)(-s), (double)b), new class_243((double)0.0F, (double)s, (double)b), new class_243((double)0.0F, (double)(-s), (double)(-b)), new class_243((double)0.0F, (double)s, (double)(-b)), new class_243((double)b, (double)0.0F, (double)(-s)), new class_243((double)b, (double)0.0F, (double)s), new class_243((double)(-b), (double)0.0F, (double)(-s)), new class_243((double)(-b), (double)0.0F, (double)s)};
         int[][] faces = new int[][]{{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8}, {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
         class_287 buf = method1569(filled);
         if (filled) {
            for(int[] f : faces) {
               method1388(buf, matrix, v[f[0]], v[f[1]], v[f[2]], color);
            }
         } else {
            Set<Long> drawn = new HashSet();

            for(int[] f : faces) {
               for(int i = 0; i < 3; ++i) {
                  int e0 = Math.min(f[i], f[(i + 1) % 3]);
                  int e1 = Math.max(f[i], f[(i + 1) % 3]);
                  long key = (long)e0 << 32 | (long)e1;
                  if (drawn.add(key)) {
                     method1387(buf, matrix, v[e0], v[e1], color);
                  }
               }
            }
         }

         class_286.method_43433(buf.method_60800());
      }

      private static void method1675(Matrix4f matrix, int color, boolean filled) {
         float s = 0.05F;
         float tip = 0.125F;
         class_243[] tips = new class_243[]{new class_243((double)tip, (double)0.0F, (double)0.0F), new class_243((double)(-tip), (double)0.0F, (double)0.0F), new class_243((double)0.0F, (double)tip, (double)0.0F), new class_243((double)0.0F, (double)(-tip), (double)0.0F), new class_243((double)0.0F, (double)0.0F, (double)tip), new class_243((double)0.0F, (double)0.0F, (double)(-tip))};
         class_243[] mid = new class_243[]{new class_243((double)s, (double)s, (double)s), new class_243((double)s, (double)s, (double)(-s)), new class_243((double)s, (double)(-s), (double)s), new class_243((double)s, (double)(-s), (double)(-s)), new class_243((double)(-s), (double)s, (double)s), new class_243((double)(-s), (double)s, (double)(-s)), new class_243((double)(-s), (double)(-s), (double)s), new class_243((double)(-s), (double)(-s), (double)(-s))};
         int[][] faces = new int[][]{{0, 0, 1}, {0, 1, 3}, {0, 3, 2}, {0, 2, 0}, {1, 4, 5}, {1, 5, 7}, {1, 7, 6}, {1, 6, 4}, {2, 0, 1}, {2, 1, 5}, {2, 5, 4}, {2, 4, 0}, {3, 2, 3}, {3, 3, 7}, {3, 7, 6}, {3, 6, 2}, {4, 0, 2}, {4, 2, 6}, {4, 6, 4}, {4, 4, 0}, {5, 1, 3}, {5, 3, 7}, {5, 7, 5}, {5, 5, 1}};
         class_287 buf = method1569(filled);
         if (filled) {
            for(int[] f : faces) {
               method1388(buf, matrix, tips[f[0]], mid[f[1]], mid[f[2]], color);
            }
         } else {
            for(class_243 t : tips) {
               for(class_243 m : mid) {
                  double d = t.method_1022(m);
                  if (d < (double)tip * (double)1.5F) {
                     method1387(buf, matrix, t, m, color);
                  }
               }
            }
         }

         class_286.method_43433(buf.method_60800());
      }

      private static void method1562(Matrix4f matrix, int color, boolean filled, List<class_243> top, List<class_243> bot, class_243 vt, class_243 vb, int n) {
         class_287 buf = method1569(filled);
         if (filled) {
            for(int i = 0; i < n; ++i) {
               int j = (i + 1) % n;
               method1388(buf, matrix, (class_243)bot.get(i), (class_243)bot.get(j), (class_243)top.get(j), color);
               method1388(buf, matrix, (class_243)bot.get(i), (class_243)top.get(j), (class_243)top.get(i), color);
               method1388(buf, matrix, vt, (class_243)top.get(i), (class_243)top.get(j), color);
               method1388(buf, matrix, vb, (class_243)bot.get(j), (class_243)bot.get(i), color);
            }
         } else {
            for(int i = 0; i < n; ++i) {
               int j = (i + 1) % n;
               method1387(buf, matrix, (class_243)top.get(i), (class_243)top.get(j), color);
               method1387(buf, matrix, (class_243)bot.get(i), (class_243)bot.get(j), color);
               method1387(buf, matrix, (class_243)top.get(i), (class_243)bot.get(i), color);
               method1387(buf, matrix, vt, (class_243)top.get(i), color);
               method1387(buf, matrix, vb, (class_243)bot.get(i), color);
            }
         }

         class_286.method_43433(buf.method_60800());
      }

      private static class_287 method1569(boolean filled) {
         return class_289.method_1348().method_60827(filled ? class_5596.field_27379 : class_5596.field_29344, class_290.field_1576);
      }

      private static void method1388(class_287 buf, Matrix4f m, class_243 a, class_243 b, class_243 c, int color) {
         buf.method_22918(m, (float)a.field_1352, (float)a.field_1351, (float)a.field_1350).method_39415(color);
         buf.method_22918(m, (float)b.field_1352, (float)b.field_1351, (float)b.field_1350).method_39415(color);
         buf.method_22918(m, (float)c.field_1352, (float)c.field_1351, (float)c.field_1350).method_39415(color);
      }

      private static void method1387(class_287 buf, Matrix4f m, class_243 a, class_243 b, int color) {
         buf.method_22918(m, (float)a.field_1352, (float)a.field_1351, (float)a.field_1350).method_39415(color);
         buf.method_22918(m, (float)b.field_1352, (float)b.field_1351, (float)b.field_1350).method_39415(color);
      }
   }

   public static enum Mode implements DisplayNamed {
      field0699("Orbit"),
      field0123("Particles"),
      field1492("Shapes"),
      field1019("Blades"),
      field0783("Circle"),
      field1266("Cube");

      private final String field0336;

      private Mode(String name) {
         this.field0336 = name;
      }

      public String method0557() {
         return this.field0336;
      }

      // $FF: synthetic method
      private static Mode[] method0094() {
         return new Mode[]{field0699, field0123, field1492, field1019, field0783, field1266};
      }
   }

   public static enum AnimationMode implements DisplayNamed {
      field0697("Camera"),
      field0121("Horizontal");

      private final String field1504;

      private AnimationMode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static AnimationMode[] method0092() {
         return new AnimationMode[]{field0697, field0121};
      }
   }

   public static enum TextureStyle implements DisplayNamed {
      field0698("Target"),
      field0122("Glow"),
      field1491("Spark");

      private final String field1030;

      private TextureStyle(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static TextureStyle[] method0093() {
         return new TextureStyle[]{field0698, field0122, field1491};
      }
   }

   public static enum ShapeType implements DisplayNamed {
      field0700("Octahedron"),
      field0124("Cube"),
      field1493("Icosahedron"),
      field1020("Star");

      private final String field0791;

      private ShapeType(String name) {
         this.field0791 = name;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static ShapeType[] method0095() {
         return new ShapeType[]{field0700, field0124, field1493, field1020};
      }
   }
}
