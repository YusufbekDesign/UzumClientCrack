package aethereal;

import java.util.List;

public final class GpsCommand extends Command implements MinecraftAccess {
   public GpsCommand() {
      super("gps", "Quick unnamed waypoint at given X Z");
      this.method1013("Berilgan X Z bo'yicha tez nomasiz belgi");
   }

   public void method0800(CommandContext var1) {
      String[] var2 = var1.method1814();
      if (var2.length == 0) {
         this.method0167(var1);
      } else {
         String var3 = var2[0].toLowerCase();
         if (!var3.equals("clear") && !var3.equals("off") && !var3.equals("del") && !var3.equals("remove")) {
            if (var2.length < 2) {
               this.method0167(var1);
            } else if (field0796.field_1687 == null) {
               var1.method0213("Dunyoda emas");
            } else {
               double var10;
               double var6;
               try {
                  var10 = Double.parseDouble(var2[0]);
                  var6 = Double.parseDouble(var2[1]);
               } catch (NumberFormatException var9) {
                  var1.method0213("Noto'g'ri koordinatalar");
                  return;
               }

               ArbuzClient.method2004().method1956().method0615(var10, var6);
               var1.method1013(String.format("GPS maqsadi: %d, %d", (int)Math.floor(var10), (int)Math.floor(var6)));
            }
         } else {
            boolean var4 = ArbuzClient.method2004().method1956().method2079();
            if (var4) {
               var1.method1013("GPS maqsadi tozalandi");
            } else {
               var1.method0213("GPS maqsadi o'rnatilmagan");
            }
         }
      }

   }

   private void method0167(CommandContext var1) {
      String var2 = ArbuzClient.method2004().method2257().method2067();
      var1.method2134("Ishlatish: " + var2 + "gps <x> <z>  |  " + var2 + "gps clear");
   }

   public String method2179(String[] var1) {
      String var10000;
      switch (var1.length) {
         case 1 -> var10000 = "<x> <z>";
         case 2 -> var10000 = "<z>";
         default -> var10000 = "";
      }

      return var10000;
   }

   public List<String> method1593(String[] var1) {
      if (var1.length == 1) {
         String var2 = var1[0].toLowerCase();
         return "clear".startsWith(var2) ? List.of("clear") : List.of();
      } else {
         return List.of();
      }
   }
}
