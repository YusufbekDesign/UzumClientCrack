package aethereal;

import java.util.function.Supplier;

public class EnumSetting<Value extends Enum<?>> extends Setting<Value> {
   public EnumSetting(String name, Value defaultValue) {
      super(name, defaultValue);
   }

   public EnumSetting(String name, Value defaultValue, Supplier<Boolean> visible) {
      super(name, defaultValue, visible);
   }

   public void method1890() {
      this.method0206(EnumCycler.method0203(this.field0714));
   }

   public String method1935() {
      return ((DisplayNamed)this.field0714).method0557();
   }

   public void method0442(String value) {
      for(Value e : (Enum[])((Enum)this.field0714).getClass().getEnumConstants()) {
         if (((DisplayNamed)e).method0557().equalsIgnoreCase(value)) {
            this.method0206(e);
            break;
         }
      }

   }
}
