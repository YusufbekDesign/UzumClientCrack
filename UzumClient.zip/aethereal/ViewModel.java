package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1764;
import net.minecraft.class_4587;

public class ViewModel extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("viewmodel.mainhandx", 0.0F, -3.0F, 3.0F, 0.05F)).method1007("Asosiy qo'l X").method0210("Asosiy qol uchun gorizontal siljish").method2130("O'ng qolning gorizontal siljishi");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("viewmodel.mainhandy", 0.0F, -2.0F, 2.0F, 0.05F)).method1007("Asosiy qo'l Y").method0210("Asosiy qol uchun vertikal siljish").method2130("O'ng qolning vertikal siljishi");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("viewmodel.mainhandz", 0.0F, -3.0F, 3.0F, 0.05F)).method1007("Asosiy qo'l Z").method0210("Asosiy qol uchun chuqurlik siljishi").method2130("O'ng qolning chuqurlik siljishi");
   private final FloatSetting field0190 = (FloatSetting)(new FloatSetting("viewmodel.offhandx", 0.0F, -3.0F, 3.0F, 0.05F)).method1007("Qo'shimcha qo'l X").method0210("Qo'shimcha qol uchun gorizontal siljish").method2130("Chap qolning gorizontal siljishi");
   private final FloatSetting field0470 = (FloatSetting)(new FloatSetting("viewmodel.offhandy", 0.0F, -2.0F, 2.0F, 0.05F)).method1007("Qo'shimcha qo'l Y").method0210("Qo'shimcha qol uchun vertikal siljish").method2130("Chap qolning vertikal siljishi");
   private final FloatSetting field1627 = (FloatSetting)(new FloatSetting("viewmodel.offhandz", 0.0F, -3.0F, 3.0F, 0.05F)).method1007("Qo'shimcha qo'l Z").method0210("Qo'shimcha qol uchun chuqurlik siljishi").method2130("Chap qolning chuqurlik siljishi");

   public ViewModel() {
      super("ViewModel", ModuleCategory.field1004, "Qo'lga olingan buyum ko'rsatish joyini va masshtabini sozlaydi");
      this.method1013("Qo'lga olingan buyumning pozitsiyasi va o'lchamini sozlaydi");
   }

   @EventHandler
   public void onHandOffset(HandOffsetEvent var1) {
      class_1268 var2 = var1.method1966();
      if (var2 != class_1268.field_5808 || !(var1.method1625().method_7909() instanceof class_1764)) {
         class_4587 var3 = var1.method1808();
         float var4;
         float var5;
         float var6;
         if (var2 == class_1268.field_5808) {
            var4 = (Float)this.field0060.method0492();
            var5 = (Float)this.field1450.method0492();
            var6 = (Float)this.field0985.method0492();
         } else {
            var4 = (Float)this.field0190.method0492();
            var5 = (Float)this.field0470.method0492();
            var6 = (Float)this.field1627.method0492();
         }

         var3.method_46416(var4, var5, var6);
      }

   }
}
