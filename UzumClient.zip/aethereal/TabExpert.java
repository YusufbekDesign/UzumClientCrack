package aethereal;

public class TabExpert extends Module {
   public final FloatSetting field0060 = (FloatSetting)(new FloatSetting("tabexpert.limit", 200.0F, 1.0F, 1000.0F, 1.0F)).method1007("Cheklov").method0210("Maximum number of players shown in tab list").method2130("Tab ro'yxatida ko'rsatiladigan o'yinchilar soni");
   public final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("tabexpert.friends", true)).method1007("Do'stlar").method0210("Highlight friends in the tab list").method2130("Tab ro'yxatida do'stlarni ajratish");

   public TabExpert() {
      super("TabExpert", ModuleCategory.field0776, "Yaxshilangan tab ro'yxati ko'rsatishi");
      this.method1013("Yaxshilangan o'yinchilar ro'yxati ko'rsatishi");
   }
}
