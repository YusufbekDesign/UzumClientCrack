package aethereal;

import net.minecraft.class_1921;

public interface RenderLayerParametersAccessor {
   class_1921.class_4688 arbuz$getParameters();
}
