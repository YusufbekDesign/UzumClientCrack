package aethereal;

import java.util.Arrays;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class TargetStrafe extends Module {
   private final EnumSetting<Mode> field0058;
   private final EnumSetting<ActivationMode> field1448;
   private final EnumSetting<ActivationMode> field0984;
   private final EnumSetting<Direction> field0189;
   private final FloatSetting field0470;
   private final FloatSetting field1627;
   private final FloatSetting field1553;
   private final MultiSelectSetting field1723;
   private int field1137;

   public TargetStrafe() {
      super("TargetStrafe", ModuleCategory.field0088, "Joriy maqsad atrofida strafe qiladi");
      this.field0058 = (EnumSetting)(new EnumSetting("targetstrafe.mode", TargetStrafe.Mode.field0703)).method1007("Rejim").method0210("Strafe movement algorithm").method2130("Strafe harakat algoritmi");
      this.field1448 = (EnumSetting)(new EnumSetting("targetstrafe.grimpoint", TargetStrafe.ActivationMode.field0704, () -> this.field0058.method0492() == TargetStrafe.Mode.field0127)).method1007("Grim nuqtasi").method0210("Path shape for Grim mode strafing").method2130("Grim rejimida strafe uchun yo'l shakli");
      this.field0984 = (EnumSetting)(new EnumSetting("targetstrafe.matrixpoint", TargetStrafe.ActivationMode.field1496, () -> this.field0058.method0492() == TargetStrafe.Mode.field0703)).method1007("Matrix nuqtasi").method0210("Path shape for Matrix mode strafing").method2130("Matrix rejimida strafe uchun yo'l shakli");
      this.field0189 = (EnumSetting)(new EnumSetting("targetstrafe.direction", TargetStrafe.Direction.field0702)).method1007("Yo'nalish").method0210("Strafe rotation direction around target").method2130("Maqsad atrofida strafe aylanish yo'nalishi");
      this.field0470 = (FloatSetting)(new FloatSetting("targetstrafe.grimradius", 0.87F, 0.1F, 1.5F, 0.01F, () -> this.field0058.method0492() == TargetStrafe.Mode.field0127)).method1007("Grim radiusi").method0210("Strafe distance from target in Grim mode").method2130("Grim rejimida maqsaddan strafe masofasi");
      this.field1627 = (FloatSetting)(new FloatSetting("targetstrafe.radius", 2.5F, 0.1F, 7.0F, 0.01F, () -> this.field0058.method0492() == TargetStrafe.Mode.field0703)).method1007("Radius").method0210("Strafe distance from target in Matrix mode").method2130("Matrix rejimida maqsaddan strafe masofasi");
      this.field1553 = (FloatSetting)(new FloatSetting("targetstrafe.speed", 0.3F, 0.1F, 1.0F, 0.01F, () -> this.field0058.method0492() == TargetStrafe.Mode.field0703)).method1007("Tezlik").method0210("Movement speed while strafing").method2130("Strafe paytida harakat tezligi");
      this.field1723 = (MultiSelectSetting)(new MultiSelectSetting("targetstrafe.options", Arrays.asList("Auto Jump", "Only Key Pressed", "In front of the target", "Direction Mode"), false, () -> true)).method1007("Variantlar").method0210("Additional strafe behavior toggles").method2130("Qo'shimcha strafe xususiyatlari");
      this.method1013("Joriy maqsad atrofida strafe qiladi");
   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (!method1974()) {
         class_1309 var2 = this.method1753();
         if (var2 != null && var2.method_5805() && this.field0058.method0492() == TargetStrafe.Mode.field0703 && (!this.method2135("Only Key Pressed") || this.method1692())) {
            class_243 var3 = field0796.field_1724.method_19538();
            class_243 var4 = var2.method_19538();
            double var5 = (double)(Float)this.field1627.method0492();
            if (this.method2135("Auto Jump") && field0796.field_1724.method_24828()) {
               field0796.field_1724.method_6043();
            }

            int var7 = this.method1698();
            if (this.method2135("In front of the target")) {
               float var19 = var2.method_36454();
               double var20 = var4.field_1352 - Math.sin(Math.toRadians((double)var19)) * var5 * (double)var7;
               double var22 = var4.field_1350 + Math.cos(Math.toRadians((double)var19)) * var5 * (double)var7;
               float var13 = (float)Math.toDegrees(Math.atan2(var22 - var3.field_1350, var20 - var3.field_1352)) - 90.0F;
               double var24 = (double)(Float)this.field1553.method0492();
               field0796.field_1724.method_18800(-Math.sin(Math.toRadians((double)var13)) * var24, field0796.field_1724.method_18798().field_1351, Math.cos(Math.toRadians((double)var13)) * var24);
            } else if (this.field0984.method0492() == TargetStrafe.ActivationMode.field0704) {
               class_243[] var8 = new class_243[]{new class_243(var4.field_1352 - var5, var3.field_1351, var4.field_1350 - var5), new class_243(var4.field_1352 - var5, var3.field_1351, var4.field_1350 + var5), new class_243(var4.field_1352 + var5, var3.field_1351, var4.field_1350 + var5), new class_243(var4.field_1352 + var5, var3.field_1351, var4.field_1350 - var5)};
               if (var3.method_1022(var8[this.field1137]) < (double)0.5F) {
                  this.field1137 = (this.field1137 + var7 + var8.length) % var8.length;
               }

               class_243 var9 = var8[this.field1137];
               class_243 var10 = var9.method_1020(var3).method_1029();
               float var11 = (float)Math.toDegrees(Math.atan2(var10.field_1350, var10.field_1352)) - 90.0F;
               double var12 = (double)(Float)this.field1553.method0492();
               field0796.field_1724.method_18800(-Math.sin(Math.toRadians((double)var11)) * var12, field0796.field_1724.method_18798().field_1351, Math.cos(Math.toRadians((double)var11)) * var12);
            } else {
               double var17 = Math.atan2(var3.field_1350 - var4.field_1350, var3.field_1352 - var4.field_1352);
               var17 += (double)((float)var7 * (Float)this.field1553.method0492()) / Math.max(var3.method_1022(var4), var5);
               double var21 = var4.field_1352 + var5 * Math.cos(var17);
               double var23 = var4.field_1350 + var5 * Math.sin(var17);
               float var14 = (float)Math.toDegrees(Math.atan2(var23 - var3.field_1350, var21 - var3.field_1352)) - 90.0F;
               double var15 = (double)(Float)this.field1553.method0492();
               field0796.field_1724.method_18800(-Math.sin(Math.toRadians((double)var14)) * var15, field0796.field_1724.method_18798().field_1351, Math.cos(Math.toRadians((double)var14)) * var15);
            }
         }
      }

   }

   public void method0025() {
      this.field1137 = 0;
      super.method0025();
   }

   private boolean method2135(String var1) {
      BooleanSetting var2 = this.field1723.method0439(var1);
      return var2 != null && (Boolean)var2.method0492();
   }

   private int method1698() {
      int var10000;
      switch (((Direction)this.field0189.method0492()).ordinal()) {
         case 1 -> var10000 = -1;
         case 2 -> var10000 = System.currentTimeMillis() / 3000L % 2L == 0L ? 1 : -1;
         default -> var10000 = 1;
      }

      return var10000;
   }

   private boolean method1692() {
      return field0796.field_1690.field_1894.method_1434() || field0796.field_1690.field_1881.method_1434() || field0796.field_1690.field_1913.method_1434() || field0796.field_1690.field_1849.method_1434();
   }

   private class_1309 method1753() {
      if (field0796.field_1724 != null && field0796.field_1687 != null) {
         class_1309 var1 = null;
         double var2 = 1.7976922776554316E308;
         double var4 = (double)(Float)this.field1627.method0492() * (double)2.0F;

         for(class_1297 var7 : field0796.field_1687.method_18112()) {
            if (var7 instanceof class_1309) {
               class_1309 var8 = (class_1309)var7;
               if (var8 != field0796.field_1724 && var8.method_5805()) {
                  if (var8 instanceof class_1657) {
                     class_1657 var9 = (class_1657)var8;
                     if (var9.method_7337()) {
                        continue;
                     }
                  }

                  double var11 = field0796.field_1724.method_5858(var8);
                  if (!(var11 > var4 * var4) && var11 < var2) {
                     var2 = var11;
                     var1 = var8;
                  }
               }
            }
         }

         return var1;
      } else {
         return null;
      }
   }

   public static enum Direction implements DisplayNamed {
      field0702("Clockwise"),
      field0126("Counterclockwise"),
      field1495("Random");

      private final String field1030;

      private Direction(String var3) {
         this.field1030 = var3;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static Direction[] $values() {
         return new Direction[]{field0702, field0126, field1495};
      }
   }

   public static enum Mode implements DisplayNamed {
      field0703("Matrix"),
      field0127("Grim");

      private final String field1504;

      private Mode(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0703, field0127};
      }
   }

   public static enum ActivationMode implements DisplayNamed {
      field0704("Cube"),
      field0128("Center"),
      field1496("Circle");

      private final String field1030;

      private ActivationMode(String var3) {
         this.field1030 = var3;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static ActivationMode[] $values() {
         return new ActivationMode[]{field0704, field0128, field1496};
      }
   }
}
