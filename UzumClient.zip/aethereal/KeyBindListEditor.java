package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class KeyBindListEditor extends GuiElement {
   private static final float field0566 = 110.0F;
   private static final float field0003 = 10.0F;
   private static final float field1410 = 0.625F;
   private static final float field0957 = 15.0F;
   private static final float field0177 = 10.0F;
   private static final float field0458 = 3.0F;
   private static final int field1615 = 6;
   private static final float field1538 = 14.0F;
   private static final float field1704 = 4.0F;
   private static final float field1136 = 0.5F;
   private static final float field1087 = 8.0F;
   private static final float field1196 = 1.2F;
   private static final float field0871 = 2.0F;
   private static final float field0826 = 106.8F;
   private static final float field0910 = 119.0F;
   private static final float field1331 = 3.0F;
   private static FontSize field1300;
   private static FontSize field1375;
   private static FontSize field0392;
   private static FontSize field0358;
   private static FontSize field0428;
   private static FontSize field0261;
   private static FontSize field0232;
   private static FontSize field0294;
   private static boolean field0538 = false;
   private final KeyBindListSetting field0511;
   private final Supplier<Float> field0557;
   private final Animation field1679;
   private final Animation field1663;
   private final SearchFieldState field1695;
   private float field1590;
   private float field1577;
   private float field1601;
   private float field1753;
   private float field1739;
   private KeyBindSetting field1770;

   private static void method2266() {
      if (!field0538) {
         field1300 = Fonts.field0075.method0654(5.5F);
         field1375 = Fonts.field0075.method0654(5.0F);
         field0392 = Fonts.field0075.method0654(5.5F);
         field0358 = Fonts.field0774.method0654(4.0F);
         field0428 = Fonts.field1718.method0654(5.5F);
         field0261 = Fonts.field0774.method0654(3.0F);
         field0232 = Fonts.field0774.method0654(4.0F);
         field0294 = Fonts.field0075.method0654(5.0F);
         field0538 = true;
      }

   }

   public KeyBindListEditor(KeyBindListSetting setting, Supplier<Float> animationSupplier) {
      this.field1663 = new Animation(150L, (double)1.0F, false, EasingCurve.field1477);
      this.field1695 = (new SearchFieldState()).method1001("Search...");
      this.field1739 = 1.0F;
      this.field0511 = setting;
      this.field0557 = animationSupplier;
      this.field1679 = new Animation(350L, (double)1.0F, false, EasingCurve.field1477);
   }

   public void method1973() {
      this.field1695.method1570(false);
   }

   public void method0665(float alpha) {
      this.field1739 = class_3532.method_15363(alpha, 0.0F, 1.0F);
   }

   private Color method0960(Color c) {
      return this.field1739 >= 0.99F ? c : new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, (int)((float)c.getAlpha() * this.field1739))));
   }

   public float method2047() {
      return 110.0F;
   }

   public float method1762() {
      return 119.0F;
   }

   public float method0413() {
      return this.field1679.method0002();
   }

   public boolean method0376() {
      return this.field1679.method0376();
   }

   public boolean method0499() {
      return this.field1679.method0346(false);
   }

   public void method1570(boolean opening) {
      this.field1679.method1570(opening);
      if (!opening) {
         this.field1695.method1570(false);
         this.field1770 = null;
      }

   }

   public void method2100(float x, float y) {
      this.field1601 = x;
      this.field1753 = y;
   }

   public float method2213() {
      return this.field1601;
   }

   public float method2182() {
      return this.field1753;
   }

   private List<KeyBindListSetting.KeyBindEntry> method1914() {
      String f = this.field1695.method1792().toString().toLowerCase(Locale.ROOT);
      List<KeyBindListSetting.KeyBindEntry> result = new ArrayList();

      for(KeyBindListSetting.KeyBindEntry entry : this.field0511.method1889()) {
         if (entry.method2079()) {
            if (!f.isEmpty()) {
               String name = entry.method0546().method2067().toLowerCase(Locale.ROOT);
               if (!name.contains(f)) {
                  continue;
               }
            }

            result.add(entry);
         }
      }

      return result;
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      method2266();
      this.field1577 = class_3532.method_16439(0.1F, this.field1577, this.field1590);
      float x = this.method0530();
      float y = this.method0002();
      float w = 110.0F;
      this.method1406(context, x, y, w, mouseX, mouseY);
      float searchY = y + 10.0F + 3.0F;
      this.method2168(context, x, searchY, w, mouseX, mouseY);
      List<KeyBindListSetting.KeyBindEntry> shown = this.method1914();
      float contentY = searchY + 15.0F + 3.0F;
      float contentH = 84.0F;
      GuiRenderHelper.method1404(context, x, contentY, 106.8F, contentH);
      float drawY = contentY + this.field1577;
      this.method1429(context, shown, x, drawY, 106.8F, mouseX, mouseY, contentY, contentY + contentH);
      GuiRenderHelper.method1400(context);
      float totalHeight = (float)shown.size() * 14.0F;
      this.field1590 = Math.clamp(this.field1590, Math.min(0.0F, contentH - totalHeight), 0.0F);
      this.method1404(context, x + 106.8F + 2.0F, contentY, contentH, totalHeight);
   }

   private void method1404(class_332 context, float sx, float sy, float visibleH, float totalH) {
      Color trackColor = this.method0960(new Color(183957503, true));
      GuiRenderHelper.method0326(context.method_51448(), sx, sy, 1.2F, visibleH, 0.6F, trackColor);
      if (!(totalH <= visibleH)) {
         float thumbH = Math.max(8.0F, visibleH * (visibleH / totalH));
         float scrollableSpace = visibleH - thumbH;
         float scrollRange = totalH - visibleH;
         float t = scrollRange <= 1.0E-4F ? 0.0F : -this.field1577 / scrollRange;
         t = class_3532.method_15363(t, 0.0F, 1.0F);
         float thumbY = sy + t * scrollableSpace;
         Color thumbColor = this.method0960(new Color(1039595519, true));
         GuiRenderHelper.method0326(context.method_51448(), sx, thumbY, 1.2F, thumbH, 0.6F, thumbColor);
      }
   }

   private void method1406(class_332 context, float x, float y, float w, int mouseX, int mouseY) {
      ThemeColorManager tm = ThemeColorManager.method1908();
      Color headerIconColor = this.method0960(new Color(tm.method2063().getRed(), tm.method2063().getGreen(), tm.method2063().getBlue(), 255));
      String moduleIcon = this.field0511.method1911() != null ? this.field0511.method1911().method1935() : null;
      FontSize headerIconFont = moduleIcon != null ? field0428 : field0358;
      String headerIconChar = moduleIcon != null ? moduleIcon : "e";
      float titleIconW = headerIconFont.method0998(headerIconChar);
      float titleIconY = y + (10.0F - headerIconFont.method0530()) / 2.0F - 0.5F;
      GuiRenderHelper.method1491(context.method_51448(), headerIconFont, headerIconChar, x, titleIconY, headerIconColor);
      float closeFw = field0232.method0998("F");
      float closeX = x + w - closeFw - 2.0F;
      float closeY = y + (10.0F - field0232.method0530()) / 2.0F - 1.5F;
      this.method0314(context, closeX, closeY, closeFw, mouseX, mouseY);
      float titleNameX = x + titleIconW + 2.0F;
      float titleNameMaxW = closeX - titleNameX - 3.0F;
      String clipped = TextTruncator.method0831(field0392, this.field0511.method2067(), titleNameMaxW);
      float titleNameY = y + (10.0F - field0392.method0530()) / 2.0F;
      Color titleNameColor = this.method0960(new Color(-1208551425, true));
      GuiRenderHelper.method1491(context.method_51448(), field0392, clipped, titleNameX, titleNameY, titleNameColor);
   }

   private void method0314(class_332 context, float closeX, float closeY, float closeFw, int mouseX, int mouseY) {
      float closeFh = field0232.method0530();
      boolean hovered = this.field1679.method0002() > 0.5F && MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeFw + 6.0F, closeFh + 6.0F, (float)mouseX, (float)mouseY);
      if (this.field1663.method0376() != hovered) {
         this.field1663.method1570(hovered);
      }

      float hv = this.field1663.method0002();
      int cR = (int)(170.0F + 70.0F * hv);
      int cG = (int)(170.0F + 70.0F * hv);
      int cB = (int)(170.0F + 80.0F * hv);
      int cA = (int)(2.55F * (52.0F + 90.0F * hv));
      Color closeColor = this.method0960(new Color(Math.min(255, cR), Math.min(255, cG), Math.min(255, cB), Math.min(255, cA)));
      float closeScale = 1.0F + 0.18F * hv;
      float closeCx = closeX + closeFw / 2.0F;
      float closeCy = closeY + closeFh / 2.0F;
      context.method_51448().method_22903();
      context.method_51448().method_46416(closeCx, closeCy, 0.0F);
      context.method_51448().method_22905(closeScale, closeScale, 1.0F);
      context.method_51448().method_46416(-closeCx, -closeCy, 0.0F);
      GuiRenderHelper.method1491(context.method_51448(), field0232, "F", closeX, closeY, closeColor);
      context.method_51448().method_22909();
   }

   private void method2168(class_332 context, float x, float y, float w, int mouseX, int mouseY) {
      Color bg = this.method0960(new Color(183957503, true));
      GuiRenderHelper.method1463(context.method_51448(), x, y, w, 15.0F, 3.0F, bg);
      boolean hasText = !this.field1695.method1792().isEmpty();
      boolean active = this.field1695.method0579();
      boolean showClear = hasText || active;
      String text = this.field1695.method1792().toString();
      String displayText = hasText ? text : (active ? "" : "Search...");
      Color textColor = this.method0960(hasText ? ThemePalette.field1268 : ThemePalette.field0486);
      float textX = x + 5.0F;
      float textY = y + (15.0F - field1375.method0530()) / 2.0F;
      float clearReserve = showClear ? field0261.method0998("t") + 6.0F : 0.0F;
      GuiRenderHelper.method1404(context, x + 4.0F, y, w - 8.0F - clearReserve, 15.0F);
      if (active && this.field1695.method0026() && hasText) {
         Color themeBase = (Color)ThemePalette.field1514.get();
         float textW = field1375.method0998(text);
         float textH = field1375.method0530();
         float selX = textX - 1.0F;
         float selY = textY - 1.0F;
         float selW = textW + 2.0F;
         float selH = textH + 2.0F;
         Color selFill = this.method0960(new Color(themeBase.getRed(), themeBase.getGreen(), themeBase.getBlue(), 90));
         GuiRenderHelper.method0326(context.method_51448(), selX, selY, selW, selH, 1.5F, selFill);
      }

      GuiRenderHelper.method1491(context.method_51448(), field1375, displayText, textX, textY, textColor);
      if (active && !this.field1695.method0026()) {
         float cursorX = textX + field1375.method0998(text) + 0.5F;
         float t = (float)((double)0.5F + (double)0.5F * Math.sin((double)System.currentTimeMillis() / (double)150.0F));
         Color cursorColor = this.method0960(new Color(255, 255, 255, (int)(255.0F * t)));
         float cursorH = 6.8181815F;
         float cursorYpos = y + (15.0F - cursorH) / 2.0F;
         GuiRenderHelper.method0326(context.method_51448(), cursorX, cursorYpos, 0.6F, cursorH, 0.3F, cursorColor);
      }

      GuiRenderHelper.method1400(context);
      if (showClear) {
         String clearGlyph = "t";
         float clearW = field0261.method0998(clearGlyph);
         float clearX = x + w - clearW - 4.0F;
         float clearY = y + (15.0F - field0261.method0530()) / 2.0F;
         boolean clearHovered = MathHelper.method0689(clearX - 2.0F, clearY - 1.0F, clearW + 4.0F, field0261.method0530() + 2.0F, (float)mouseX, (float)mouseY);
         int clearAlpha = clearHovered ? 72 : 48;
         Color clearColor = this.method0960(new Color((int)(2.55F * (float)clearAlpha) << 24 | 11184810, true));
         GuiRenderHelper.method1491(context.method_51448(), field0261, clearGlyph, clearX, clearY, clearColor);
      }

   }

   private boolean method0616(double mouseX, double mouseY) {
      float closeFw = field0232.method0998("F");
      float closeFh = field0232.method0530();
      float closeX = this.method0530() + 110.0F - closeFw - 2.0F;
      float closeY = this.method0002() + (10.0F - closeFh) / 2.0F - 1.5F;
      return MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeFw + 6.0F, closeFh + 6.0F, (float)mouseX, (float)mouseY);
   }

   private void method1429(class_332 context, List<KeyBindListSetting.KeyBindEntry> entries, float startX, float startY, float width, int mouseX, int mouseY, float visibleTop, float visibleBottom) {
      int totalRows = entries.size();
      if (totalRows != 0) {
         int firstVisible = Math.max(0, (int)((visibleTop - startY) / 14.0F));
         int lastVisible = Math.min(totalRows - 1, (int)((visibleBottom - startY) / 14.0F));
         if (firstVisible <= lastVisible) {
            Color accent = (Color)ThemePalette.field1514.get();
            Color neutralBg = this.method0960(new Color(255, 255, 255, 8));
            Color rowText = this.method0960(ThemePalette.field1268);
            Color descColor = this.method0960(ThemePalette.field0207);
            float rowW = width;
            float rowH = 13.5F;

            for(int i = firstVisible; i <= lastVisible; ++i) {
               KeyBindListSetting.KeyBindEntry entry = (KeyBindListSetting.KeyBindEntry)entries.get(i);
               KeyBindSetting bs = entry.method0546();
               KeyBind bind = (KeyBind)bs.method0492();
               boolean isSelecting = this.field1770 == bs;
               boolean hasKey = bind.method2048() != -1;
               String keyText = isSelecting ? "..." : bind.toString().replace("_", " ");
               float rowY = startY + (float)i * 14.0F;
               GuiRenderHelper.method1463(context.method_51448(), startX, rowY, rowW, rowH, 2.0F, neutralBg);
               if (this.field1739 > 0.85F) {
                  class_1799 stack = new class_1799(entry.method0021());
                  context.method_51448().method_22903();
                  float itemX = startX + 4.0F;
                  float itemY = rowY + (rowH - 10.0F) / 2.0F;
                  context.method_51448().method_46416(itemX, itemY, 0.0F);
                  context.method_51448().method_22905(0.625F, 0.625F, 1.0F);
                  context.method_51427(stack, 0, 0);
                  context.method_51448().method_22909();
               }

               float minKeyWidth = field0294.method0998("W");
               float keyBoxW = 4.0F + Math.max(field0294.method0998(keyText), minKeyWidth);
               float keyBoxX = startX + rowW - 4.0F - keyBoxW;
               float pillY = rowY + (rowH - 8.0F) / 2.0F;
               float nameX = startX + 4.0F + 10.0F + 4.0F;
               float nameMaxW = keyBoxX - nameX - 2.0F;
               String displayName = bs.method2067();
               String clippedName = TextTruncator.method0831(field1300, displayName, nameMaxW);
               float nameY = rowY + (rowH - field1300.method0530()) / 2.0F;
               GuiRenderHelper.method1491(context.method_51448(), field1300, clippedName, nameX, nameY, rowText);
               Color keyBg;
               Color keyFg;
               if (hasKey && !isSelecting) {
                  keyBg = this.method0960(accent);
                  keyFg = this.method0960(Color.WHITE);
               } else if (isSelecting) {
                  keyBg = this.method0960(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 96));
                  keyFg = this.method0960(Color.WHITE);
               } else {
                  keyBg = this.method0960(new Color(255, 255, 255, 24));
                  keyFg = descColor;
               }

               GuiRenderHelper.method0326(context.method_51448(), keyBoxX, pillY, keyBoxW, 8.0F, 1.0F, keyBg);
               float keyTextW = field0294.method0998(keyText);
               float keyTextX = keyBoxX + (keyBoxW - keyTextW) / 2.0F;
               GuiRenderHelper.method1491(context.method_51448(), field0294, keyText, keyTextX, pillY + (8.0F - field0294.method0530()) / 2.0F, keyFg);
            }

         }
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      method2266();
      float x = this.method0530();
      float y = this.method0002();
      if (!MathHelper.method0689(x, y, 110.0F, 119.0F, (float)mouseX, (float)mouseY)) {
         if (this.field1770 != null) {
            this.field1770 = null;
         }

         return false;
      } else if (button == 0 && this.method0616(mouseX, mouseY)) {
         KeyBindListSettingWidget.method1973();
         return true;
      } else {
         float searchY = y + 10.0F + 3.0F;
         if (this.field1770 != null) {
            this.field1770.method0206(new KeyBind(button, true, false));
            this.field1770 = null;
            return true;
         } else {
            boolean showClear = !this.field1695.method1792().isEmpty() || this.field1695.method0579();
            if (showClear) {
               String clearGlyph = "t";
               float clearW = field0261.method0998(clearGlyph);
               float clearX = x + 110.0F - clearW - 4.0F;
               float clearY = searchY + (15.0F - field0261.method0530()) / 2.0F;
               if (MathHelper.method0689(clearX - 2.0F, clearY - 1.0F, clearW + 4.0F, field0261.method0530() + 2.0F, (float)mouseX, (float)mouseY)) {
                  if (!this.field1695.method1792().isEmpty()) {
                     this.field1695.method1792().setLength(0);
                     this.field1695.method2078();
                     this.field1590 = 0.0F;
                  } else {
                     this.field1695.method1570(false);
                  }

                  return true;
               }
            }

            if (MathHelper.method0689(x, searchY, 110.0F, 15.0F, (float)mouseX, (float)mouseY)) {
               this.field1695.method1570(true);
               this.field1695.method2078();
               ClickGuiScreen menu = ClickGuiScreen.method1904();
               if (menu != null && menu.method1775() != null) {
                  menu.method1775().method1951().method1570(false);
               }

               return true;
            } else {
               this.field1695.method1570(false);
               this.field1695.method2078();
               float contentY = searchY + 15.0F + 3.0F;
               float contentH = 84.0F;
               if (!(mouseY < (double)contentY) && !(mouseY > (double)(contentY + contentH))) {
                  List<KeyBindListSetting.KeyBindEntry> shown = this.method1914();
                  float drawY = contentY + this.field1577;
                  int rowIdx = (int)Math.floor((mouseY - (double)drawY) / (double)14.0F);
                  if (rowIdx >= 0 && rowIdx < shown.size()) {
                     KeyBindListSetting.KeyBindEntry entry = (KeyBindListSetting.KeyBindEntry)shown.get(rowIdx);
                     this.field1770 = entry.method0546();
                     return true;
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            }
         }
      }
   }

   public boolean method0623(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (MathHelper.method0689(this.method0530(), this.method0002(), 110.0F, 119.0F, (float)mouseX, (float)mouseY)) {
         this.field1590 += (float)verticalAmount * 15.0F;
         return true;
      } else {
         return false;
      }
   }

   public boolean method0746(int keyCode, int scanCode, int modifiers) {
      if (this.field1770 != null) {
         this.field1770.method0206(new KeyBind(keyCode == 256 ? -1 : keyCode, false, false));
         this.field1770 = null;
         ClickGuiScreen menu = ClickGuiScreen.method1904();
         if (menu != null) {
            menu.method0578();
         }

         return true;
      } else if (!this.field1695.method0579()) {
         return false;
      } else {
         boolean handled = this.field1695.method0746(keyCode, scanCode, modifiers);
         if (handled) {
            this.field1590 = 0.0F;
         }

         return handled;
      }
   }

   public boolean method0607(char chr, int modifiers) {
      if (!this.field1695.method0579()) {
         return false;
      } else {
         boolean handled = this.field1695.method0607(chr, modifiers);
         if (handled) {
            this.field1590 = 0.0F;
         }

         return handled;
      }
   }
}
