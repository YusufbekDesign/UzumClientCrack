package aethereal;

public class SpeedMine extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("speedmine.ultrafast", false)).method1007("Tezkor").method0210("Instantly break blocks").method2130("Bloklarni darhol sindirish");

   public SpeedMine() {
      super("SpeedMine", ModuleCategory.field1470, "Blok qazishni tezlashtiradi");
      this.method1013("Blok qazishni tezlashtiradi");
   }

   public static SpeedMine method1719() {
      ArbuzClient var0 = ArbuzClient.method2004();
      return var0 != null && var0.method1783() != null ? (SpeedMine)var0.method1783().method0976(SpeedMine.class) : null;
   }

   public boolean method1692() {
      return this.method2195() && (Boolean)this.field0034.method0492();
   }
}
