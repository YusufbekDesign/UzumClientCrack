package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1836;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_9635;
import org.patch.arbuzhack.api.mixins.accessors.IHandledScreen;

public class AuctionHelper extends Module {
   private static final Pattern field0145 = Pattern.compile("(\\d{1,3}(?:[\\s,._]\\d{3})+|\\d+)");
   private static final long field1412 = 900L;
   private static final float field0957 = 0.35F;
   private static final float field0177 = 1.0F;
   private static final int field0459 = 104;
   private final MultiSelectSetting field1637 = (MultiSelectSetting)(new MultiSelectSetting("auctionhelper.armorfilters", Arrays.asList("No Thorns", "Protection 5"), false, () -> true)).method1007("Armor Filters").method0210("Filters applied only to armor; other items pass through untouched").method2130("Фильтры для брони");
   private final MultiSelectSetting field1562 = (MultiSelectSetting)(new MultiSelectSetting("auctionhelper.swordfilters", Arrays.asList("Sharpness 7", "No Knockback"), false, () -> true)).method1007("Sword Filters").method0210("Filters applied only to swords; other items pass through untouched").method2130("Фильтры только для мечей");
   private final ColorSetting field1711 = (ColorSetting)(new ColorSetting("auctionhelper.cheapest", 75, 255, 75, 180)).method1007("Cheapest Color").method0210("Highlight color for the cheapest item").method2130("Цвет подсветки самого дешёвого предмета");
   private final ColorSetting field1143 = (ColorSetting)(new ColorSetting("auctionhelper.effective", 255, 75, 75, 180)).method1007("Best Per-Item Color").method0210("Highlight color for the lowest price per unit").method2130("Цвет подсветки лучшей цены за штуку");

   public AuctionHelper() {
      super("AuctionHelper", ModuleCategory.field1004, "Highlights the cheapest items in auction-style containers");
      this.method1013("Подсвечивает самые дешёвые предметы на аукционе");
   }

   @EventHandler
   public void onScreenRender(Event001 e) {
      if (!method1974()) {
         class_465<?> screen = e.method1810();
         if (screen != null) {
            class_332 ctx = e.method1628();
            IHandledScreen acc = (IHandledScreen)screen;
            int guiLeft = acc.arbuz$getX();
            int guiTop = acc.arbuz$getY();
            List<class_1735> slots = field0796.field_1724.field_7512.field_7761;
            class_1735 bestCheap = null;
            int bestCheapPrice = Integer.MAX_VALUE;

            for(class_1735 s : slots) {
               if (this.method1207(s)) {
                  class_1799 st = s.method_7677();
                  if (!st.method_7960() && this.method1241(st)) {
                     int price = this.method0268(st);
                     if (price >= 0 && price < bestCheapPrice) {
                        bestCheapPrice = price;
                        bestCheap = s;
                     }
                  }
               }
            }

            class_1735 bestEffective = null;
            double bestPpi = Double.POSITIVE_INFINITY;
            int bestPpiTotal = Integer.MAX_VALUE;

            for(class_1735 s : slots) {
               if (this.method1207(s) && s != bestCheap) {
                  class_1799 st = s.method_7677();
                  if (!st.method_7960() && this.method1241(st)) {
                     int price = this.method0268(st);
                     if (price >= 0) {
                        int count = Math.max(1, st.method_7947());
                        double ppi = (double)price / (double)count;
                        boolean better = ppi < bestPpi - 9.999995561963904E-10;
                        boolean equal = Math.abs(ppi - bestPpi) <= 9.999995561963904E-10;
                        if (better || equal && price < bestPpiTotal) {
                           bestPpi = ppi;
                           bestPpiTotal = price;
                           bestEffective = s;
                        }
                     }
                  }
               }
            }

            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(0.0F, 0.0F, 250.0F);
            if (bestCheap != null) {
               this.method1416(ctx, guiLeft, guiTop, bestCheap, method0956(this.field1711.method1726()));
            }

            if (bestEffective != null) {
               this.method1416(ctx, guiLeft, guiTop, bestEffective, method0956(this.field1143.method1726()));
            }

            ctx.method_51448().method_22909();
         }
      }
   }

   private boolean method1207(class_1735 s) {
      if (field0796.field_1724 != null && s != null) {
         if (s.field_7871 == field0796.field_1724.method_31548()) {
            return false;
         } else {
            return s.field_7872 < 104;
         }
      } else {
         return false;
      }
   }

   private boolean method1241(class_1799 stack) {
      class_1792 item = stack.method_7909();
      if (item instanceof class_1738) {
         if (this.field1637.method0387("No Thorns") && this.method1244(stack, class_1893.field_9097) > 0) {
            return false;
         }

         if (this.field1637.method0387("Protection 5") && this.method1244(stack, class_1893.field_9111) < 5) {
            return false;
         }
      } else if (item instanceof class_1829) {
         if (this.field1562.method0387("Sharpness 7") && this.method1244(stack, class_1893.field_9118) < 7) {
            return false;
         }

         if (this.field1562.method0387("No Knockback") && this.method1244(stack, class_1893.field_9121) > 0) {
            return false;
         }
      }

      return true;
   }

   private int method1244(class_1799 stack, class_5321<class_1887> key) {
      if (field0796.field_1687 == null) {
         return 0;
      } else {
         class_2378<class_1887> registry = field0796.field_1687.method_30349().method_30530(class_7924.field_41265);
         class_6880<class_1887> entry = (class_6880)registry.method_10223(key.method_29177()).orElse((Object)null);
         return entry == null ? 0 : class_1890.method_8225(entry, stack);
      }
   }

   private void method1416(class_332 ctx, int guiLeft, int guiTop, class_1735 slot, int argb) {
      int x = guiLeft + slot.field_7873;
      int y = guiTop + slot.field_7872;
      ctx.method_25294(x, y, x + 16, y + 16, argb);
   }

   private static int method0956(Color c) {
      long now = System.currentTimeMillis();
      float t = (float)(now % 900L) / 900.0F;
      float wave = 0.5F - 0.5F * class_3532.method_15362(t * ((float)Math.PI * 2F));
      float alphaMul = class_3532.method_15363(0.35F + 0.65F * wave, 0.0F, 1.0F);
      int a = (int)((float)c.getAlpha() * alphaMul);
      return a << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }

   private int method0268(class_1799 stack) {
      List<String> lines = this.method2156(stack);
      int count = Math.max(1, stack.method_7947());
      long headline = -1L;
      long perUnit = -1L;

      for(String raw : lines) {
         String line = method2131(raw);
         if (!line.isEmpty()) {
            String lower = line.toLowerCase();
            if (this.method1847(lower) && !lower.contains("истек") && !lower.contains("expir") && !lower.contains("осталось")) {
               boolean per = lower.contains("за шт") || lower.contains("/шт") || lower.contains("шт.") || lower.contains(" per ") || lower.contains(" each ") || lower.contains("за 1 ед");
               long num = this.method1043(line, lower);
               if (num > 0L) {
                  if (per) {
                     if (num > perUnit) {
                        perUnit = num;
                     }
                  } else if (num > headline) {
                     headline = num;
                  }
               }
            }
         }
      }

      long chosen;
      if (headline > 0L) {
         chosen = headline;
      } else {
         if (perUnit <= 0L) {
            return -1;
         }

         chosen = perUnit * (long)count;
      }

      if (chosen > 2147483647L) {
         return Integer.MAX_VALUE;
      } else {
         return (int)chosen;
      }
   }

   private List<String> method2156(class_1799 stack) {
      ArrayList<String> out = new ArrayList();
      List<class_2561> tooltip = this.method1860(stack);
      if (tooltip != null) {
         for(class_2561 t : tooltip) {
            out.add(t.getString());
         }
      }

      class_9290 lore = (class_9290)stack.method_57824(class_9334.field_49632);
      if (lore != null) {
         for(class_2561 t : lore.comp_2400()) {
            out.add(t.getString());
         }
      }

      try {
         out.add(stack.method_7964().getString());
      } catch (Throwable var7) {
      }

      return out;
   }

   private long method1043(String original, String lower) {
      Matcher m = field0145.matcher(original);
      long best = -1L;

      while(m.find()) {
         long val = this.method1653(m.group(1));
         if (val > 0L) {
            long mul = this.method1022(lower, m.end(1));
            if (mul != 1L) {
               val *= mul;
            }

            if (val > best) {
               best = val;
            }
         }
      }

      return best;
   }

   private List<class_2561> method1860(class_1799 stack) {
      try {
         return stack.method_7950(class_9635.field_51353, field0796.field_1724, class_1836.field_41070);
      } catch (Throwable var3) {
         return null;
      }
   }

   private static String method2131(String s) {
      if (s == null) {
         return "";
      } else {
         StringBuilder out = new StringBuilder(s.length());

         for(int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            if (!Character.isSpaceChar(c) && c != '\t' && c != '\n' && c != '\r') {
               out.append(c);
            } else {
               out.append(' ');
            }
         }

         return out.toString();
      }
   }

   private boolean method1847(String c) {
      return c.contains("цена") || c.contains("price") || c.contains("стоим") || c.contains("монет") || c.contains("coins") || c.contains("коин") || c.contains("$") || c.contains("₽") || c.contains("¤");
   }

   private long method1022(String lower, int end) {
      if (end >= lower.length()) {
         return 1L;
      } else {
         char c0 = lower.charAt(end);
         char c1 = end + 1 < lower.length() ? lower.charAt(end + 1) : 0;
         if (c0 != 'k' && c0 != 1082) {
            if (c0 != 'm' && c0 != 1084) {
               return 1L;
            } else {
               return method0606(c1) ? 1L : 1000000L;
            }
         } else if (c1 != 'k' && c1 != 1082) {
            return method0606(c1) ? 1L : 1000L;
         } else {
            char c2 = end + 2 < lower.length() ? lower.charAt(end + 2) : 0;
            return method0606(c2) ? 1L : 1000000L;
         }
      }
   }

   private static boolean method0606(char c) {
      return Character.isLetterOrDigit(c);
   }

   private long method1653(String raw) {
      long v = 0L;

      for(int i = 0; i < raw.length(); ++i) {
         char c = raw.charAt(i);
         if (c >= '0' && c <= '9') {
            v = v * 10L + (long)(c - 48);
         }
      }

      return v;
   }
}
