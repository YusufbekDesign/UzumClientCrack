package aethereal;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_2596;
import net.minecraft.class_2703;
import net.minecraft.class_640;
import net.minecraft.class_7828;

public class AntiBot extends Module {
   private final Set<UUID> field1511 = new HashSet();
   static Set<UUID> field0142 = new HashSet();
   private final EnumSetting<Mode> field0984;

   public AntiBot() {
      super("AntiBot", ModuleCategory.field0661, "Filters out fake players and bots");
      this.field0984 = (EnumSetting)(new EnumSetting("antibot.mode", AntiBot.Mode.field0009)).method1007("Mode").method0210("Bot detection algorithm").method2130("Метод обнаружения");
      this.method1013("Удаляет ботов от античита");
   }

   public static AntiBot method1700() {
      ArbuzClient arbuz = ArbuzClient.method2004();
      return arbuz != null && arbuz.method1783() != null ? (AntiBot)arbuz.method1783().method0976(AntiBot.class) : null;
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound event) {
      class_2596 var10000 = event.method1970();
      Objects.requireNonNull(var10000);
      class_2596 var2 = var10000;
      byte var3 = 0;
      //$FF: var3->value
      //0->net/minecraft/class_2703
      //1->net/minecraft/class_7828
      switch (var2.typeSwitch<invokedynamic>(var2, var3)) {
         case 0:
            class_2703 list = (class_2703)var2;
            this.method1368(list);
            break;
         case 1:
            class_7828 remove = (class_7828)var2;
            this.method1544(remove);
      }

   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (field0796.field_1687 != null && field0796.field_1724 != null) {
         if (!this.field1511.isEmpty()) {
            field0796.field_1687.method_18456().stream().filter((p) -> this.field1511.contains(p.method_5667())).forEach(this::method2150);
         }

         if (this.field0984.method0492() == AntiBot.Mode.field0572) {
            this.method1754();
         } else {
            this.method2029();
         }

      }
   }

   private void method1368(class_2703 packet) {
      packet.method_46330().forEach((entry) -> {
         GameProfile profile = entry.comp_1107();
         if (profile != null && !this.method1367(entry, profile)) {
            if (this.method0946(profile)) {
               field0142.add(profile.getId());
            } else {
               this.field1511.add(profile.getId());
            }

         }
      });
   }

   private void method1544(class_7828 packet) {
      packet.comp_1105().forEach((uuid) -> {
         this.field1511.remove(uuid);
         field0142.remove(uuid);
      });
   }

   private boolean method1367(class_2703.class_2705 entry, GameProfile profile) {
      return entry.comp_1109() < 2 && profile.getProperties() != null && !profile.getProperties().isEmpty();
   }

   private void method2150(class_1657 player) {
      if (this.method1183(player)) {
         field0142.add(player.method_5667());
      }

      this.field1511.remove(player.method_5667());
   }

   private void method1754() {
      if (field0796.field_1687 != null && field0796.field_1724 != null) {
         for(Iterator<UUID> iterator = this.field1511.iterator(); iterator.hasNext(); iterator.remove()) {
            UUID suspect = (UUID)iterator.next();
            class_1657 entity = field0796.field_1687.method_18470(suspect);
            if (entity != null) {
               String playerName = entity.method_5477().getString();
               boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.contains("[ZNPC]");
               int armorCount = 0;

               for(class_1799 item : entity.method_5661()) {
                  if (!item.method_7960()) {
                     ++armorCount;
                  }
               }

               boolean isFullArmor = armorCount == 4;
               boolean isFakeUUID = !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes()));
               if (isFullArmor || isNameBot || isFakeUUID) {
                  field0142.add(suspect);
               }
            }
         }

         if (field0796.field_1724.field_6012 % 100 == 0) {
            field0142.removeIf((uuid) -> field0796.field_1687.method_18470(uuid) == null);
         }

      }
   }

   private void method2029() {
      if (field0796.field_1687 != null) {
         for(class_1657 entity : field0796.field_1687.method_18456()) {
            if (entity != field0796.field_1724 && !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes())) && entity.method_5767() && !field0142.contains(entity.method_5667()) && !entity.method_5477().getString().contains("NPC") && !entity.method_5477().getString().startsWith("[ZNPC]")) {
               field0142.add(entity.method_5667());
            }
         }

      }
   }

   public boolean method0946(GameProfile profile) {
      if (field0796.method_1562() == null) {
         return false;
      } else {
         List<class_640> playerListCopy;
         try {
            playerListCopy = new ArrayList(field0796.method_1562().method_2880());
         } catch (Exception var4) {
            return false;
         }

         return playerListCopy.stream().filter((player) -> player.method_2966().getName().equals(profile.getName()) && !player.method_2966().getId().equals(profile.getId())).count() == 1L;
      }
   }

   public boolean method1183(class_1657 entity) {
      IntStream var10000 = IntStream.rangeClosed(0, 3);
      class_1661 var10001 = entity.method_31548();
      Objects.requireNonNull(var10001);
      return var10000.mapToObj(var10001::method_7372).allMatch((stack) -> stack.method_7909() instanceof class_1738 && !stack.method_7942());
   }

   public boolean method1196(class_1657 entity, Iterable<class_1799> prevArmor) {
      if (prevArmor == null) {
         return true;
      } else {
         List<class_1799> currentArmorList = StreamSupport.stream(entity.method_5661().spliterator(), false).toList();
         List<class_1799> prevArmorList = StreamSupport.stream(prevArmor.spliterator(), false).toList();
         return !IntStream.range(0, Math.min(currentArmorList.size(), prevArmorList.size())).allMatch((i) -> ((class_1799)currentArmorList.get(i)).equals(prevArmorList.get(i))) || currentArmorList.size() != prevArmorList.size();
      }
   }

   public boolean method0250(class_1657 entity) {
      String playerName = entity.method_5477().getString();
      boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.startsWith("[ZNPC]");
      boolean isMarkedBot = field0142.contains(entity.method_5667());
      return isNameBot || isMarkedBot || this.method1129(entity);
   }

   public boolean method1095(UUID uuid) {
      return field0142.contains(uuid);
   }

   public boolean method1129(class_1297 entity) {
      return !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes())) && entity.method_5767() && !entity.method_5477().getString().contains("NPC") && !entity.method_5477().getString().startsWith("[ZNPC]");
   }

   public void method1691() {
      this.field1511.clear();
      field0142.clear();
   }

   public void method2078() {
      this.method1691();
      super.method2078();
   }

   public static enum Mode implements DisplayNamed {
      field0572("Matrix"),
      field0009("ReallyWorld");

      private final String field1504;

      private Mode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static Mode[] method0028() {
         return new Mode[]{field0572, field0009};
      }
   }
}
