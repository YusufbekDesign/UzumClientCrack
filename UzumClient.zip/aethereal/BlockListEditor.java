package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7923;

public final class BlockListEditor extends GuiElement {
   private static final float field0566 = 104.0F;
   private static final float field0003 = 2.0F;
   private static final float field1410 = 100.0F;
   private static final float field0957 = 8.0F;
   private static final float field0177 = 4.0F;
   private static final float field0458 = 15.0F;
   private static final float field1614 = 3.0F;
   private static final float field1538 = 13.0F;
   private static final float field1704 = 2.0F;
   private static final float field1136 = 4.0F;
   private static final int field1088 = 4;
   private static final int field1197 = 4;
   private static final float field0871 = 1.8F;
   private static final float field0826 = 1.2F;
   private static final float field0910 = 2.0F;
   private static final float field1331 = 96.8F;
   private static final float field1292 = 22.85F;
   private static final float field1369 = 2.5F;
   private static final float field0385 = 12.7960005F;
   private static final float field0351 = 0.79975003F;
   private static final float field0423 = 4.0F;
   private static final float field0255 = 96.8F;
   private static final float field0226 = 147.8F;
   private static final float field0289 = 3.0F;
   private static FontSize field0528;
   private static FontSize field0505;
   private static FontSize field0551;
   private static FontSize field1674;
   private static FontSize field1660;
   private static FontSize field1692;
   private static FontSize field1592;
   private static FontSize field1582;
   private static FontSize field1605;
   private static boolean field1762 = false;
   private final BlockListSetting field1742;
   private final Animation field1769;
   private final Animation field1178;
   private final SearchFieldState field1168;
   private float field1186;
   private float field1119;
   private float field1112;
   private float field1129;
   private float field1227;
   private List<class_2248> field1224;
   private List<class_2248> field1238;
   private String field0901;
   private int field0893;
   private FilterMode field0905;
   private FilterMode field0858;
   private final Animation field0850;
   private static final long field0865 = 220L;
   private final List<BlockEntry> field0943;
   private static final List<class_2248> field0937 = new ArrayList();
   private static final Map<class_2248, String> field0952 = new HashMap();
   private static final Map<class_2248, String> field1360 = new HashMap();
   private static final Map<class_2248, String> field1354 = new HashMap();
   private static final Map<class_2248, class_1799> field1364 = new HashMap();

   private static void method2266() {
      if (!field1762) {
         field0528 = Fonts.field0075.method0654(5.5F);
         field0505 = Fonts.field0075.method0654(5.0F);
         field0551 = Fonts.field0075.method0654(5.5F);
         field1674 = Fonts.field0075.method0654(5.0F);
         field1660 = Fonts.field0774.method0654(4.0F);
         field1692 = Fonts.field1718.method0654(5.5F);
         field1592 = Fonts.field0774.method0654(3.0F);
         field1582 = Fonts.field0774.method0654(4.5F);
         field1605 = Fonts.field0774.method0654(4.0F);
         field1762 = true;
      }

   }

   public BlockListEditor(BlockListSetting setting, Supplier<Float> animationSupplier) {
      this.field1178 = new Animation(150L, (double)1.0F, false, EasingCurve.field1477);
      this.field1168 = (new SearchFieldState()).method1001("Search...");
      this.field1227 = 1.0F;
      this.field1224 = new ArrayList();
      this.field1238 = new ArrayList();
      this.field0901 = null;
      this.field0893 = -1;
      this.field0905 = BlockListEditor.FilterMode.field0066;
      this.field0858 = BlockListEditor.FilterMode.field0066;
      this.field0850 = new Animation(280L, (double)1.0F, false, EasingCurve.field1011);
      this.field0943 = new ArrayList();
      this.field1742 = setting;
      this.field1769 = new Animation(350L, (double)1.0F, false, EasingCurve.field1477);
   }

   public float method2047() {
      return 104.0F;
   }

   public float method1762() {
      return 147.8F;
   }

   public boolean method1974() {
      return this.field1769.method0376();
   }

   public boolean method0431() {
      return this.field1769.method0346(false);
   }

   public float method0355() {
      return this.field1769.method0002();
   }

   public void method1570(boolean opening) {
      this.field1769.method1570(opening);
      if (!opening) {
         this.field1168.method1570(false);
      }

   }

   public void method0665(float alpha) {
      this.field1227 = class_3532.method_15363(alpha, 0.0F, 1.0F);
   }

   public void method0498() {
      this.field1168.method1570(false);
   }

   public void method2100(float x, float y) {
      this.field1112 = x;
      this.field1129 = y;
   }

   public float method2213() {
      return this.field1112;
   }

   public float method2182() {
      return this.field1129;
   }

   private Color method0960(Color c) {
      return this.field1227 >= 0.99F ? c : new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, (int)((float)c.getAlpha() * this.field1227))));
   }

   private void method1915() {
      String f = this.field1168.method1792().toString().toLowerCase(Locale.ROOT);
      int ver = this.field1742.method1879();
      if (this.field0901 == null || !f.equals(this.field0901) || ver != this.field0893) {
         this.field1224.clear();
         this.field1238.clear();

         for(class_2248 block : field0937) {
            if (f.isEmpty() || ((String)field0952.get(block)).contains(f) || ((String)field1360.get(block)).contains(f)) {
               if (this.field1742.method1253(block)) {
                  this.field1224.add(block);
               } else {
                  this.field1238.add(block);
               }
            }
         }

         this.field0901 = f;
         this.field0893 = ver;
      }
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      method2266();
      this.field1119 = class_3532.method_16439(0.1F, this.field1119, this.field1186);
      float x = this.method0530() + 2.0F;
      float y = this.method0002();
      this.method1915();
      int activeCount = ((List)this.field1742.method0492()).size();
      int totalCount = field0937.size();
      this.method1407(context, x, y, 100.0F, activeCount, totalCount, mouseX, mouseY);
      float searchY = y + 8.0F + 4.0F;
      this.method0314(context, x, searchY, 100.0F, mouseX, mouseY);
      float tabsY = searchY + 15.0F + 3.0F;
      this.method1403(context, x, tabsY, 100.0F);
      float gridY = tabsY + 13.0F + 4.0F;
      this.method1402(context, x, gridY);
   }

   private void method1407(class_332 context, float x, float y, float w, int activeCount, int totalCount, int mouseX, int mouseY) {
      Color themeColor = (Color)ThemePalette.field1514.get();
      Color iconColor = this.method0960(new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), 255));
      String moduleIcon = this.field1742.method1911() != null ? this.field1742.method1911().method1935() : null;
      FontSize headerIconFont = moduleIcon != null ? field1692 : field1660;
      String headerIconChar = moduleIcon != null ? moduleIcon : "h";
      float iconW = headerIconFont.method0998(headerIconChar);
      float iconY = y + (8.0F - headerIconFont.method0530()) / 2.0F - 0.5F;
      GuiRenderHelper.method1491(context.method_51448(), headerIconFont, headerIconChar, x, iconY, iconColor);
      float closeW = field1605.method0998("F");
      float closeX = x + w - closeW;
      float closeY = y + (8.0F - field1605.method0530()) / 2.0F - 0.5F;
      this.method1406(context, closeX, closeY, closeW, mouseX, mouseY);
      String counter = activeCount + " / " + totalCount;
      float counterW = field1674.method0998(counter);
      float counterX = closeX - counterW - 4.0F;
      float counterY = y + (8.0F - field1674.method0530()) / 2.0F;
      Color counterColor = this.method0960(new Color(1157627903, true));
      GuiRenderHelper.method1491(context.method_51448(), field1674, counter, counterX, counterY, counterColor);
      float titleX = x + iconW + 2.0F;
      float titleMaxW = counterX - titleX - 3.0F;
      String displayName = this.field1742.method2067();
      String clipped = TextTruncator.method0831(field0551, displayName, titleMaxW);
      float titleY = y + (8.0F - field0551.method0530()) / 2.0F;
      Color titleColor = this.method0960(new Color(-591873, true));
      GuiRenderHelper.method1491(context.method_51448(), field0551, clipped, titleX, titleY, titleColor);
   }

   private void method1406(class_332 context, float closeX, float closeY, float closeW, int mouseX, int mouseY) {
      float closeH = field1605.method0530();
      boolean hovered = this.field1769.method0002() > 0.5F && MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeW + 6.0F, closeH + 6.0F, (float)mouseX, (float)mouseY);
      if (this.field1178.method0376() != hovered) {
         this.field1178.method1570(hovered);
      }

      float hv = this.field1178.method0002();
      int cR = (int)(170.0F + 70.0F * hv);
      int cG = (int)(170.0F + 70.0F * hv);
      int cB = (int)(170.0F + 80.0F * hv);
      int cA = (int)(2.55F * (52.0F + 90.0F * hv));
      Color closeColor = this.method0960(new Color(Math.min(255, cR), Math.min(255, cG), Math.min(255, cB), Math.min(255, cA)));
      float closeScale = 1.0F + 0.18F * hv;
      float closeCx = closeX + closeW / 2.0F;
      float closeCy = closeY + closeH / 2.0F;
      context.method_51448().method_22903();
      context.method_51448().method_46416(closeCx, closeCy, 0.0F);
      context.method_51448().method_22905(closeScale, closeScale, 1.0F);
      context.method_51448().method_46416(-closeCx, -closeCy, 0.0F);
      GuiRenderHelper.method1491(context.method_51448(), field1605, "F", closeX, closeY, closeColor);
      context.method_51448().method_22909();
   }

   private boolean method0616(double mouseX, double mouseY) {
      float closeW = field1605.method0998("F");
      float closeH = field1605.method0530();
      float closeX = this.method0530() + 2.0F + 100.0F - closeW;
      float closeY = this.method0002() + (8.0F - closeH) / 2.0F - 0.5F;
      return MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeW + 6.0F, closeH + 6.0F, (float)mouseX, (float)mouseY);
   }

   private void method0314(class_332 context, float x, float y, float w, int mouseX, int mouseY) {
      Color bg = this.method0960(new Color(183957503, true));
      GuiRenderHelper.method1463(context.method_51448(), x, y, w, 15.0F, 3.0F, bg);
      boolean hasText = !this.field1168.method1792().isEmpty();
      boolean active = this.field1168.method0579();
      boolean showClear = hasText || active;
      String text = this.field1168.method1792().toString();
      String displayText = hasText ? text : (active ? "" : "Search...");
      Color textColor = this.method0960(hasText ? ThemePalette.field1268 : ThemePalette.field0486);
      float textX = x + 5.0F;
      float textY = y + (15.0F - field0505.method0530()) / 2.0F;
      float clearReserve = showClear ? field1592.method0998("t") + 6.0F : 0.0F;
      GuiRenderHelper.method1404(context, x + 4.0F, y, w - 8.0F - clearReserve, 15.0F);
      if (active && this.field1168.method0026() && hasText) {
         Color themeBase = (Color)ThemePalette.field1514.get();
         float textW = field0505.method0998(text);
         float textH = field0505.method0530();
         float selX = textX - 1.0F;
         float selY = textY - 1.0F;
         float selW = textW + 2.0F;
         float selH = textH + 2.0F;
         Color selFill = this.method0960(new Color(themeBase.getRed(), themeBase.getGreen(), themeBase.getBlue(), 90));
         GuiRenderHelper.method0326(context.method_51448(), selX, selY, selW, selH, 1.5F, selFill);
      }

      GuiRenderHelper.method1491(context.method_51448(), field0505, displayText, textX, textY, textColor);
      if (active && !this.field1168.method0026()) {
         float cursorX = textX + field0505.method0998(text) + 0.5F;
         float t = (float)((double)0.5F + (double)0.5F * Math.sin((double)System.currentTimeMillis() / (double)150.0F));
         Color cursorColor = this.method0960(new Color(255, 255, 255, (int)(255.0F * t)));
         float cursorH = 6.8181815F;
         float cursorYpos = y + (15.0F - cursorH) / 2.0F;
         GuiRenderHelper.method0326(context.method_51448(), cursorX, cursorYpos, 0.6F, cursorH, 0.3F, cursorColor);
      }

      GuiRenderHelper.method1400(context);
      if (showClear) {
         String clearGlyph = "t";
         float clearW = field1592.method0998(clearGlyph);
         float clearX = x + w - clearW - 4.0F;
         float clearY = y + (15.0F - field1592.method0530()) / 2.0F;
         boolean clearHovered = MathHelper.method0689(clearX - 2.0F, clearY - 1.0F, clearW + 4.0F, field1592.method0530() + 2.0F, (float)mouseX, (float)mouseY);
         int clearAlpha = clearHovered ? 72 : 48;
         Color clearColor = this.method0960(new Color((int)(2.55F * (float)clearAlpha) << 24 | 11184810, true));
         GuiRenderHelper.method1491(context.method_51448(), field1592, clearGlyph, clearX, clearY, clearColor);
      }

   }

   private void method1403(class_332 context, float x, float y, float w) {
      float tabW = (w - 2.0F) / 2.0F;
      this.method1410(context, x, y, tabW, "Active", this.field0905 == BlockListEditor.FilterMode.field0632);
      this.method1410(context, x + tabW + 2.0F, y, tabW, "All", this.field0905 == BlockListEditor.FilterMode.field0066);
   }

   private void method1410(class_332 context, float tx, float ty, float tw, String label, boolean selected) {
      Color accent = (Color)ThemePalette.field1514.get();
      Color bg;
      if (selected) {
         bg = this.method0960(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 255));
      } else {
         bg = this.method0960(new Color(183957503, true));
      }

      GuiRenderHelper.method1463(context.method_51448(), tx, ty, tw, 13.0F, 3.0F, bg);
      Color labelColor = selected ? this.method0960(new Color(255, 255, 255, 255)) : this.method0960(ThemePalette.field0207);
      float labelW = field0505.method0998(label);
      if (selected) {
         float checkW = field1582.method0998("q");
         float gap = 2.5F;
         float totalW = checkW + gap + labelW;
         float startX = tx + (tw - totalW) / 2.0F;
         float checkY = ty + (13.0F - field1582.method0530()) / 2.0F - 0.3F;
         GuiRenderHelper.method1491(context.method_51448(), field1582, "q", startX, checkY, labelColor);
         float labelY = ty + (13.0F - field0505.method0530()) / 2.0F;
         GuiRenderHelper.method1491(context.method_51448(), field0505, label, startX + checkW + gap, labelY, labelColor);
      } else {
         float labelX = tx + (tw - labelW) / 2.0F;
         float labelY = ty + (13.0F - field0505.method0530()) / 2.0F;
         GuiRenderHelper.method1491(context.method_51448(), field0505, label, labelX, labelY, labelColor);
      }

   }

   private void method1402(class_332 context, float x, float y) {
      List<class_2248> shown = this.field0905 == BlockListEditor.FilterMode.field0632 ? this.field1224 : this.field1238;
      int totalRows = (shown.size() + 4 - 1) / 4;
      float totalH = totalRows == 0 ? 0.0F : (float)totalRows * 22.85F + (float)(totalRows - 1) * 1.8F;
      float clampMin = Math.min(0.0F, 96.8F - totalH);
      this.field1186 = class_3532.method_15363(this.field1186, clampMin, 0.0F);
      GuiRenderHelper.method1404(context, x, y, 96.8F, 96.8F);
      float tabAnim = this.field0850.method0002();
      boolean tabSwitching = this.field0850.method0376() && tabAnim < 0.999F;
      if (tabSwitching) {
         boolean toRight = this.field0905 == BlockListEditor.FilterMode.field0066 && this.field0858 == BlockListEditor.FilterMode.field0632;
         float dir = toRight ? 1.0F : -1.0F;
         float currentOffset = dir * 96.8F * (1.0F - tabAnim);
         float prevOffset = -dir * 96.8F * tabAnim;
         List<class_2248> prevList = this.field0858 == BlockListEditor.FilterMode.field0632 ? this.field1224 : this.field1238;
         this.method1430(context, prevList, x + prevOffset, y, true);
         this.method1430(context, shown, x + currentOffset, y, false);
      } else {
         this.method1430(context, shown, x, y, false);
      }

      if (!this.field0943.isEmpty()) {
         Color accentPulse = (Color)ThemePalette.field1514.get();

         for(int i = this.field0943.size() - 1; i >= 0; --i) {
            BlockEntry p = (BlockEntry)this.field0943.get(i);
            float v = p.field0775.method0002();
            if (v <= 0.01F) {
               this.field0943.remove(i);
            } else {
               int alpha = (int)(160.0F * v);
               Color c = this.method0960(new Color(accentPulse.getRed(), accentPulse.getGreen(), accentPulse.getBlue(), alpha));
               GuiRenderHelper.method1463(context.method_51448(), p.field0566, p.field0003, p.field1410, p.field0957, 2.5F, c);
            }
         }
      }

      GuiRenderHelper.method1400(context);
      this.method0311(context, x + 96.8F + 2.0F, y, totalH);
   }

   private void method1430(class_332 context, List<class_2248> shown, float x, float y, boolean isPrevious) {
      if (!shown.isEmpty()) {
         int totalRows = (shown.size() + 4 - 1) / 4;
         float drawY = y + (isPrevious ? 0.0F : this.field1119);
         int firstRow = Math.max(0, (int)((y - drawY) / 24.65F));
         int lastRow = Math.min(totalRows - 1, (int)((y + 96.8F - drawY) / 24.65F));
         Color bgLight = this.method0960(new Color(100663295, true));
         Color bgDark = this.method0960(new Color(268435455, true));
         Color accent = (Color)ThemePalette.field1514.get();
         Color selectedBorder = this.method0960(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200));

         for(int row = firstRow; row <= lastRow; ++row) {
            for(int col = 0; col < 4; ++col) {
               int idx = row * 4 + col;
               if (idx >= shown.size()) {
                  break;
               }

               class_2248 block = (class_2248)shown.get(idx);
               float cellX = x + (float)col * 24.65F;
               float cellY = drawY + (float)row * 24.65F;
               Color cellBg = (row + col & 1) == 0 ? bgLight : bgDark;
               GuiRenderHelper.method1463(context.method_51448(), cellX, cellY, 22.85F, 22.85F, 2.5F, cellBg);
               boolean isActiveBlock = this.field1742.method1253(block);
               if (isActiveBlock) {
                  GuiRenderHelper.method1461(context.method_51448(), cellX, cellY, 22.85F, 22.85F, 2.5F, 0.5F, 0.5F, selectedBorder);
               }

               class_1799 stack = (class_1799)field1364.get(block);
               if (stack != null && this.field1227 > 0.85F) {
                  context.method_51448().method_22903();
                  float itemX = cellX + 5.027F;
                  float itemY = cellY + 5.027F;
                  context.method_51448().method_46416(itemX, itemY, 0.0F);
                  context.method_51448().method_22905(0.79975003F, 0.79975003F, 1.0F);
                  context.method_51427(stack, 0, 0);
                  context.method_51448().method_22909();
               }
            }
         }

      }
   }

   private void method0311(class_332 context, float sx, float sy, float totalH) {
      Color trackColor = this.method0960(new Color(183957503, true));
      GuiRenderHelper.method0326(context.method_51448(), sx, sy, 1.2F, 96.8F, 0.6F, trackColor);
      if (!(totalH <= 96.8F)) {
         float thumbH = Math.max(8.0F, 96.8F * (96.8F / totalH));
         float scrollableSpace = 96.8F - thumbH;
         float scrollRange = totalH - 96.8F;
         float t = scrollRange <= 1.0E-4F ? 0.0F : -this.field1119 / scrollRange;
         t = class_3532.method_15363(t, 0.0F, 1.0F);
         float thumbY = sy + t * scrollableSpace;
         Color thumbColor = this.method0960(new Color(1039595519, true));
         GuiRenderHelper.method0326(context.method_51448(), sx, thumbY, 1.2F, thumbH, 0.6F, thumbColor);
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      float panelX = this.method0530();
      float y = this.method0002();
      if (!MathHelper.method0689(panelX, y, 104.0F, 147.8F, (float)mouseX, (float)mouseY)) {
         return false;
      } else if (button == 0 && this.method0616(mouseX, mouseY)) {
         BlockListSettingWidget.method1973();
         return true;
      } else {
         float x = panelX + 2.0F;
         float searchY = y + 8.0F + 4.0F;
         boolean showClear = !this.field1168.method1792().isEmpty() || this.field1168.method0579();
         if (showClear) {
            String clearGlyph = "t";
            float clearW = field1592.method0998(clearGlyph);
            float clearX = x + 100.0F - clearW - 4.0F;
            float clearY = searchY + (15.0F - field1592.method0530()) / 2.0F;
            if (MathHelper.method0689(clearX - 2.0F, clearY - 1.0F, clearW + 4.0F, field1592.method0530() + 2.0F, (float)mouseX, (float)mouseY)) {
               if (!this.field1168.method1792().isEmpty()) {
                  this.field1168.method1792().setLength(0);
                  this.field1168.method2078();
                  this.field1186 = 0.0F;
               } else {
                  this.field1168.method1570(false);
               }

               return true;
            }
         }

         if (MathHelper.method0689(x, searchY, 100.0F, 15.0F, (float)mouseX, (float)mouseY)) {
            this.field1168.method1570(true);
            this.field1168.method2078();
            ClickGuiScreen menu = ClickGuiScreen.method1904();
            if (menu != null && menu.method1775() != null) {
               menu.method1775().method1951().method1570(false);
            }

            return true;
         } else {
            this.field1168.method1570(false);
            this.field1168.method2078();
            float tabsY = searchY + 15.0F + 3.0F;
            float tabW = 49.0F;
            if (MathHelper.method0689(x, tabsY, tabW, 13.0F, (float)mouseX, (float)mouseY)) {
               this.method0842(BlockListEditor.FilterMode.field0632);
               return true;
            } else if (MathHelper.method0689(x + tabW + 2.0F, tabsY, tabW, 13.0F, (float)mouseX, (float)mouseY)) {
               this.method0842(BlockListEditor.FilterMode.field0066);
               return true;
            } else {
               float gridY = tabsY + 13.0F + 4.0F;
               if (!(mouseY < (double)gridY) && !(mouseY > (double)(gridY + 96.8F))) {
                  if (!(mouseX < (double)x) && !(mouseX > (double)(x + 96.8F))) {
                     this.method1915();
                     List<class_2248> shown = this.field0905 == BlockListEditor.FilterMode.field0632 ? this.field1224 : this.field1238;
                     float drawY = gridY + this.field1119;
                     int row = (int)Math.floor((mouseY - (double)drawY) / (double)24.65F);
                     int col = (int)Math.floor((mouseX - (double)x) / (double)24.65F);
                     if (row >= 0 && col >= 0 && col < 4) {
                        float cellX = x + (float)col * 24.65F;
                        float cellY = drawY + (float)row * 24.65F;
                        if (mouseX > (double)(cellX + 22.85F)) {
                           return true;
                        } else if (mouseY > (double)(cellY + 22.85F)) {
                           return true;
                        } else {
                           int idx = row * 4 + col;
                           if (idx >= shown.size()) {
                              return true;
                           } else {
                              class_2248 clicked = (class_2248)shown.get(idx);
                              this.method0686(cellX, cellY, 22.85F, 22.85F);
                              this.field1742.method1861(clicked);
                              return true;
                           }
                        }
                     } else {
                        return true;
                     }
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            }
         }
      }
   }

   private void method0842(FilterMode newTab) {
      if (this.field0905 != newTab) {
         this.field0858 = this.field0905;
         this.field0905 = newTab;
         this.field0850.method1570(false);
         this.field0850.method1634();
         this.field0850.method1570(true);
         this.field1186 = 0.0F;
         this.field1119 = 0.0F;
      }
   }

   private void method0686(float px, float py, float pw, float ph) {
      Animation a = new Animation(220L, (double)1.0F, false, EasingCurve.field0203);
      a.method1634();
      this.field0943.add(new BlockEntry(px, py, pw, ph, a));
   }

   public boolean method0623(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (MathHelper.method0689(this.method0530(), this.method0002(), 104.0F, 147.8F, (float)mouseX, (float)mouseY)) {
         this.field1186 += (float)verticalAmount * 14.0F;
         return true;
      } else {
         return false;
      }
   }

   public boolean method0746(int keyCode, int scanCode, int modifiers) {
      if (!this.field1168.method0579()) {
         return false;
      } else {
         boolean handled = this.field1168.method0746(keyCode, scanCode, modifiers);
         if (handled) {
            this.field1186 = 0.0F;
         }

         return handled;
      }
   }

   public boolean method0607(char chr, int modifiers) {
      if (!this.field1168.method0579()) {
         return false;
      } else {
         boolean handled = this.field1168.method0607(chr, modifiers);
         if (handled) {
            this.field1186 = 0.0F;
         }

         return handled;
      }
   }

   static {
      for(class_2248 block : class_7923.field_41175) {
         class_1799 stack = new class_1799(block);
         if (!stack.method_7960() && block != class_2246.field_10124) {
            String displayName = block.method_9518().getString();
            field0937.add(block);
            field1354.put(block, displayName);
            field0952.put(block, displayName.toLowerCase(Locale.ROOT));
            field1360.put(block, class_7923.field_41175.method_10221(block).toString().toLowerCase(Locale.ROOT));
            field1364.put(block, stack);
         }
      }

   }

   private static enum FilterMode {
      field0632,
      field0066;

      // $FF: synthetic method
      private static FilterMode[] method0589() {
         return new FilterMode[]{field0632, field0066};
      }
   }

   private static final class BlockEntry {
      final float field0566;
      final float field0003;
      final float field1410;
      final float field0957;
      final Animation field0775;

      BlockEntry(float x, float y, float w, float h, Animation anim) {
         this.field0566 = x;
         this.field0003 = y;
         this.field1410 = w;
         this.field0957 = h;
         this.field0775 = anim;
      }
   }
}
