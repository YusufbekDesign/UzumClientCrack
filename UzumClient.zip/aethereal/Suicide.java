package aethereal;

public class Suicide extends Module {
   public Suicide() {
      super("Suicide", ModuleCategory.field0661, "Targets yourself with crystals");
      this.method1013("O'ziga qarshi kristallarga hujum qiladi");
   }

   public static Suicide method1721() {
      ArbuzClient var0 = ArbuzClient.method2004();
      return var0 != null && var0.method1783() != null ? (Suicide)var0.method1783().method0976(Suicide.class) : null;
   }
}
