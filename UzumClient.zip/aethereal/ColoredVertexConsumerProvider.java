package aethereal;

import java.util.Optional;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4720;
import net.minecraft.class_9799;
import net.minecraft.class_9848;

public class ColoredVertexConsumerProvider implements class_4597 {
   private final class_4597.class_4598 field0744;
   private final class_4597.class_4598 field0164 = class_4597.method_22991(new class_9799(1536));
   private int field1411 = 255;
   private int field0958 = 255;
   private int field0759 = 255;
   private int field1243 = 255;

   public ColoredVertexConsumerProvider(class_4597.class_4598 parent) {
      this.field0744 = parent;
   }

   public class_4588 getBuffer(class_1921 renderLayer) {
      if (renderLayer.method_24295()) {
         class_4588 vertexConsumer = this.field0164.getBuffer(renderLayer);
         return new ColoredVertexConsumer(vertexConsumer, this.field1411, this.field0958, this.field0759, this.field1243);
      } else {
         class_4588 vertexConsumer = this.field0744.getBuffer(renderLayer);
         Optional<class_1921> optional = renderLayer.method_23289();
         if (optional.isPresent()) {
            class_4588 vertexConsumer2 = this.field0164.getBuffer((class_1921)optional.get());
            ColoredVertexConsumer outlineVertexConsumer = new ColoredVertexConsumer(vertexConsumer2, this.field1411, this.field0958, this.field0759, this.field1243);
            return class_4720.method_24037(outlineVertexConsumer, vertexConsumer);
         } else {
            return vertexConsumer;
         }
      }
   }

   public void method0749(int red, int green, int blue, int alpha) {
      this.field1411 = red;
      this.field0958 = green;
      this.field0759 = blue;
      this.field1243 = alpha;
   }

   public void method0578() {
      this.field0164.method_22993();
   }

   public static record ColoredVertexConsumer(class_4588 delegate, int color) implements class_4588 {
      public ColoredVertexConsumer(class_4588 delegate, int red, int green, int blue, int alpha) {
         this(delegate, class_9848.method_61324(alpha, red, green, blue));
      }

      public class_4588 method_22912(float x, float y, float z) {
         this.delegate.method_22912(x, y, z).method_39415(this.color);
         return this;
      }

      public class_4588 method_1336(int red, int green, int blue, int alpha) {
         return this;
      }

      public class_4588 method_22913(float u, float v) {
         this.delegate.method_22913(u, v);
         return this;
      }

      public class_4588 method_60796(int u, int v) {
         return this;
      }

      public class_4588 method_22921(int u, int v) {
         return this;
      }

      public class_4588 method_22914(float x, float y, float z) {
         return this;
      }

      public class_4588 method0574() {
         return this.delegate;
      }

      public int method0003() {
         return this.color;
      }
   }
}
