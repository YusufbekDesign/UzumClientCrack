package aethereal;

import java.util.Arrays;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2561;

public class AutoLeave extends Module {
   private final EnumSetting<TriggerType> field0058;
   private final MultiSelectSetting field1471;
   private final FloatSetting field0985;

   public AutoLeave() {
      super(" AutoLeave", ModuleCategory.field0776, "Automatically disconnects");
      this.field0058 = (EnumSetting)(new EnumSetting("autoleave.type", AutoLeave.TriggerType.field0026)).method1007("Leave Type").method0210("How to disconnect from the server").method2130("Способ отключения от сервера");
      this.field1471 = (MultiSelectSetting)(new MultiSelectSetting("autoleave.triggers", Arrays.asList("Players", "Staff"), false, () -> true)).method1007("Triggers").method0210("Conditions that trigger automatic disconnect").method2130("Условия для отключения");
      this.field0985 = (FloatSetting)(new FloatSetting("autoleave.maxdistance", 10.0F, 5.0F, 40.0F, 1.0F, () -> this.method2135("Players"))).method1007("Max Distance").method0210("Maximum distance for player detection trigger").method2130("Максимальная дистанция обнаружения игроков");
      this.method1013("Автоматически выполняет действие при определённых условиях");
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         if (this.method2135("Players")) {
            field0796.field_1687.method_18456().stream().filter((player) -> player != field0796.field_1724).filter((player) -> field0796.field_1724.method_5739(player) < (Float)this.field0985.method0492()).filter((player) -> {
               ArbuzClient arbuz = ArbuzClient.method2004();
               return arbuz == null || arbuz.method1608() == null || !arbuz.method1608().method2135(player.method_7334().getName());
            }).findFirst().ifPresent((player) -> {
               String var10001 = player.method_5477().getString();
               this.method1347(class_2561.method_43470(var10001 + " appeared at " + String.format("%.1f", field0796.field_1724.method_5739(player)) + "m"));
            });
         }

         if (this.method2135("Staff")) {
            List<String> staff = NewHUD.method1397(field0796);
            if (!staff.isEmpty()) {
               this.method1347(class_2561.method_43470("Сотрудник на сервере: " + String.join(", ", staff)));
            }
         }

      }
   }

   private void method1347(class_2561 reason) {
      if (field0796.method_1562() != null) {
         if (this.field0058.method0492() == AutoLeave.TriggerType.field0591) {
            field0796.method_1562().method_45730("hub");
         } else {
            field0796.method_1562().method_48296().method_10747(class_2561.method_43470("[AutoLeave]\n").method_27661().method_10852(reason));
         }

         this.method0345(false);
      }
   }

   private boolean method2135(String name) {
      BooleanSetting setting = this.field1471.method0439(name);
      return setting != null && (Boolean)setting.method0492();
   }

   public static enum TriggerType implements DisplayNamed {
      field0591("Hub"),
      field0026("Main Menu");

      private final String field1504;

      private TriggerType(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static TriggerType[] method0045() {
         return new TriggerType[]{field0591, field0026};
      }
   }
}
