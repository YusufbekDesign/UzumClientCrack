package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class GeometricShapes extends Module {
   private final MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("geometricshapes.shapetype", Arrays.asList("Cube", "Pyramid", "Octahedron", "Tetrahedron", "Star", "Snowflake", "Icosahedron", "Dodecahedron", "Torus"))).method1007("Shape Type").method0210("Types of shapes to render").method2130("Типы фигур");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("geometricshapes.amount", 79.0F, 5.0F, 700.0F, 1.0F)).method1007("Amount").method0210("Number of shapes to spawn").method2130("Количество фигур");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("geometricshapes.size", 0.05F, 0.05F, 0.25F, 0.01F)).method1007("Size").method0210("Size of each shape").method2130("Размер");
   private final FloatSetting field0190 = (FloatSetting)(new FloatSetting("geometricshapes.spawnradius", 7.0F, 3.0F, 50.0F, 1.0F)).method1007("Spawn Radius").method0210("Radius around player to spawn shapes").method2130("Радиус вокруг игрока");
   private final BooleanSetting field0464 = (BooleanSetting)(new BooleanSetting("geometricshapes.filled", false)).method1007("Filled").method0210("Render shapes with filled faces").method2130("Отрисовка фигур с заполненными гранями");
   private final ColorSetting field1623 = (ColorSetting)(new ColorSetting("geometricshapes.color", 255, 99, 204, 113)).method1882().method1007("Color").method0210("Shape color").method2130("Цвет фигур");
   private final BooleanSetting field1544 = (BooleanSetting)(new BooleanSetting("geometricshapes.glow", false)).method1007("Glow").method0210("Render a soft glow halo behind each shape").method2130("Рисовать свечение");
   private static final class_2960 field1733 = ArbuzClient.method1012("textures/glow.png");
   private static final float field1136 = 4.0F;
   private static final float field1087 = 0.06F;
   private static final float field1196 = 20.0F;
   private static final float field0871 = 0.05F;
   private final List<ShapeInstance> field0843 = new ArrayList();
   private final Random field0929 = new Random();
   private int field1332 = 0;
   private class_243 field1311;
   private final List<ColoredLine> field1384;
   private final List<ShapeMesh> field0400;
   private final double[] field0370;

   public GeometricShapes() {
      super("GeometricShapes", ModuleCategory.field1004, "Renders geometric shape effects");
      this.field1311 = class_243.field_1353;
      this.field1384 = new ArrayList();
      this.field0400 = new ArrayList();
      this.field0370 = new double[3];
      this.method1013("Рисует эффекты геометрических фигур");
      this.field0089.method0439("Pyramid").method0206(false);
      this.field0089.method0439("Octahedron").method0206(false);
      this.field0089.method0439("Tetrahedron").method0206(false);
      this.field0089.method0439("Star").method0206(false);
      this.field0089.method0439("Torus").method0206(false);
   }

   public void method0025() {
      super.method0025();
      if (!method1974()) {
         this.method1735();
      }

   }

   public void method2078() {
      super.method2078();
      this.field0843.clear();
      this.field1384.clear();
      this.field0400.clear();
      this.field1311 = class_243.field_1353;
   }

   private void method1735() {
      int amount = ((Float)this.field1450.method0492()).intValue();

      for(int i = 0; i < amount; ++i) {
         this.method1691();
      }

   }

   private void method1691() {
      if (!method1974()) {
         List<BooleanSetting> enabledShapes = this.field0089.method1889();
         if (!enabledShapes.isEmpty()) {
            BooleanSetting selected = (BooleanSetting)enabledShapes.get(this.field0929.nextInt(enabledShapes.size()));
            String shapeName = selected.method1888() != null ? selected.method1888() : selected.method0423();
            ShapeType type = GeometricShapes.ShapeType.method1000(shapeName);
            class_243 playerPos = field0796.field_1724.method_19538();
            double radius = (double)(Float)this.field0190.method0492();
            double vertSpread = (double)20.0F;
            double speed = (double)0.059999976F;
            double angle = this.field0929.nextDouble() * 3.141593782352789 * (double)2.0F;
            double distance = radius * ((double)0.5F + this.field0929.nextDouble() * (double)0.5F);
            double x = playerPos.field_1352 + Math.cos(angle) * distance;
            double z = playerPos.field_1350 + Math.sin(angle) * distance;
            double y = playerPos.field_1351 + (double)2.0F + this.field0929.nextDouble() * vertSpread;

            for(class_2338 spawnPos = class_2338.method_49637(x, y, z); !field0796.field_1687.method_8320(spawnPos).method_26215() && y < playerPos.field_1351 + (double)20.0F; spawnPos = class_2338.method_49637(x, y, z)) {
               ++y;
            }

            class_243 velocity = new class_243((this.field0929.nextDouble() - (double)0.5F) * speed, (this.field0929.nextDouble() - 0.7000000447150796) * speed * 0.30000014541235215, (this.field0929.nextDouble() - (double)0.5F) * speed);
            double rotation = this.field0929.nextDouble() * 3.141593782352789 * (double)2.0F;
            this.field0843.add(new ShapeInstance(type, new class_243(x, y, z), velocity, rotation));
         }
      }
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         Set<ShapeType> enabledTypes = this.method1752();
         this.method1090(enabledTypes);
         if (!enabledTypes.isEmpty()) {
            ++this.field1332;
            class_243 playerPos = field0796.field_1724.method_19538();
            double spawnRadiusValue = (double)(Float)this.field0190.method0492();
            double deleteDistSq = spawnRadiusValue * 1.8000000388027193 * spawnRadiusValue * 1.8000000388027193;
            double fadeDistSq = spawnRadiusValue * 1.3000000019595366 * spawnRadiusValue * 1.3000000019595366;
            double spawnRadiusSq = spawnRadiusValue * spawnRadiusValue;
            int targetAmount = ((Float)this.field1450.method0492()).intValue();
            int nearbyCount = 0;
            int size = this.field0843.size();

            for(int i = size - 1; i >= 0; --i) {
               ShapeInstance shape = (ShapeInstance)this.field0843.get(i);
               shape.method0578();
               double distSq = shape.field0795.method_1025(playerPos);
               if (distSq > deleteDistSq) {
                  int last = this.field0843.size() - 1;
                  if (i != last) {
                     this.field0843.set(i, (ShapeInstance)this.field0843.get(last));
                  }

                  this.field0843.remove(last);
               } else {
                  shape.field0169 = distSq > fadeDistSq;
                  if (shape.field0566 <= 0.0F && shape.field0169) {
                     int last = this.field0843.size() - 1;
                     if (i != last) {
                        this.field0843.set(i, (ShapeInstance)this.field0843.get(last));
                     }

                     this.field0843.remove(last);
                  } else if (distSq <= spawnRadiusSq) {
                     ++nearbyCount;
                  }
               }
            }

            if (nearbyCount < targetAmount) {
               int missing = targetAmount - nearbyCount;
               int toAdd = Math.min(50, missing);

               for(int i = 0; i < toAdd; ++i) {
                  this.method1691();
               }
            }

            if (this.field1311.method_1025(playerPos) > (double)100.0F) {
               this.field1311 = playerPos;
               int toSpawn = Math.min(100, targetAmount / 4);

               for(int i = 0; i < toSpawn; ++i) {
                  this.method1691();
               }
            }

         }
      }
   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent event) {
      if (!method1974()) {
         this.method1090(this.method1752());
         float partialTicks = event.method1603();
         class_243 camera = field0796.field_1773.method_19418().method_19326();
         this.field1384.clear();
         this.field0400.clear();
         event.method1808().method_22903();
         event.method1808().method_23760().method_23761().identity();
         int shapeCount = this.field0843.size();
         float size = (Float)this.field0985.method0492();

         for(int i = 0; i < shapeCount; ++i) {
            ShapeInstance shape = (ShapeInstance)this.field0843.get(i);
            shape.method0840(event, 0.0F, size, partialTicks, this.field1384, this.field0400);
         }

         event.method1808().method_22909();
         this.method1079(this.field1384, this.field0400);
         if ((Boolean)this.field1544.method0492()) {
            this.method0665(partialTicks);
         }

      }
   }

   private Set<ShapeType> method1752() {
      EnumSet<ShapeType> enabled = EnumSet.noneOf(ShapeType.class);

      for(BooleanSetting setting : this.field0089.method1889()) {
         String name = setting.method1888() != null ? setting.method1888() : setting.method0423();
         enabled.add(GeometricShapes.ShapeType.method1000(name));
      }

      return enabled;
   }

   private void method1090(Set<ShapeType> enabledTypes) {
      if (!this.field0843.isEmpty()) {
         if (enabledTypes.isEmpty()) {
            this.field0843.clear();
         } else {
            this.field0843.removeIf((shape) -> !enabledTypes.contains(shape.field0986));
         }
      }
   }

   private void method0665(float partialTicks) {
      if (!this.field0843.isEmpty()) {
         class_243 camPos = field0796.field_1773.method_19418().method_19326();
         Color baseColor = this.field1623.method1726();
         int baseRgb = baseColor.getRGB() & 16777215;
         int baseAlpha = baseColor.getAlpha();
         float halfSize = (Float)this.field0985.method0492() * 3.0F;
         Matrix4f matrix = new Matrix4f();
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(770, 32772);
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.disableCull();
         RenderSystem.setShaderTexture(0, field1733);
         RenderSystem.setShader(class_10142.field_53880);
         class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
         boolean hasVertices = false;

         for(ShapeInstance shape : this.field0843) {
            if (!(shape.field0566 <= 0.001F)) {
               class_243 renderPos = shape.field1273.method_35590(shape.field0795, (double)partialTicks);
               float x = (float)(renderPos.field_1352 - camPos.field_1352);
               float y = (float)(renderPos.field_1351 - camPos.field_1351);
               float z = (float)(renderPos.field_1350 - camPos.field_1350);
               double dx = renderPos.field_1352 - camPos.field_1352;
               double dz = renderPos.field_1350 - camPos.field_1350;
               double dist = Math.sqrt(dx * dx + dz * dz);
               float rightX;
               float rightZ;
               if (dist > 0.001000000009275471) {
                  rightX = (float)(-dz / dist);
                  rightZ = (float)(dx / dist);
               } else {
                  rightX = 1.0F;
                  rightZ = 0.0F;
               }

               int alpha = Math.max(0, Math.min(255, (int)((float)baseAlpha * shape.field0566)));
               int rgba = alpha << 24 | baseRgb;
               buffer.method_22918(matrix, x - rightX * halfSize, y - halfSize, z - rightZ * halfSize).method_22913(0.0F, 0.0F).method_39415(rgba);
               buffer.method_22918(matrix, x + rightX * halfSize, y - halfSize, z + rightZ * halfSize).method_22913(1.0F, 0.0F).method_39415(rgba);
               buffer.method_22918(matrix, x + rightX * halfSize, y + halfSize, z + rightZ * halfSize).method_22913(1.0F, 1.0F).method_39415(rgba);
               buffer.method_22918(matrix, x - rightX * halfSize, y + halfSize, z - rightZ * halfSize).method_22913(0.0F, 1.0F).method_39415(rgba);
               hasVertices = true;
            }
         }

         if (hasVertices) {
            class_286.method_43433(buffer.method_60800());
         }

         RenderSystem.setShaderTexture(0, 0);
         RenderSystem.enableCull();
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
      }
   }

   private void method1079(List<ColoredLine> lines, List<ShapeMesh> quads) {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 32772);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      if (!lines.isEmpty()) {
         class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);

         for(ColoredLine line : lines) {
            buffer.method_22918(line.matrix, line.x1, line.y1, line.z1).method_39415(line.color);
            buffer.method_22918(line.matrix, line.x2, line.y2, line.z2).method_39415(line.color);
         }

         RenderSystem.setShader(class_10142.field_53876);
         GL11.glHint(3154, 4354);
         GL11.glEnable(2848);
         class_286.method_43433(buffer.method_60800());
         GL11.glDisable(2848);
      }

      if (!quads.isEmpty() && (Boolean)this.field0464.method0492()) {
         class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);

         for(ShapeMesh quad : quads) {
            buffer.method_22918(quad.matrix, quad.x1, quad.y1, quad.z1).method_39415(quad.color);
            buffer.method_22918(quad.matrix, quad.x2, quad.y2, quad.z2).method_39415(quad.color);
            buffer.method_22918(quad.matrix, quad.x3, quad.y3, quad.z3).method_39415(quad.color);
            buffer.method_22918(quad.matrix, quad.x4, quad.y4, quad.z4).method_39415(quad.color);
         }

         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.disableCull();
         class_286.method_43433(buffer.method_60800());
         RenderSystem.enableCull();
      }

      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
   }

   private static record ColoredLine(Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, int color) {
      public Matrix4f method0577() {
         return this.matrix;
      }

      public float method0002() {
         return this.x1;
      }

      public float method2047() {
         return this.y1;
      }

      public float method1762() {
         return this.z1;
      }

      public float method1603() {
         return this.x2;
      }

      public float method1946() {
         return this.y2;
      }

      public float method0413() {
         return this.z2;
      }

      public int method0356() {
         return this.color;
      }
   }

   private static record ShapeMesh(Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, int color) {
      public Matrix4f method0577() {
         return this.matrix;
      }

      public float method0002() {
         return this.x1;
      }

      public float method2047() {
         return this.y1;
      }

      public float method1762() {
         return this.z1;
      }

      public float method1603() {
         return this.x2;
      }

      public float method1946() {
         return this.y2;
      }

      public float method0413() {
         return this.z2;
      }

      public float method0355() {
         return this.x3;
      }

      public float method0483() {
         return this.y3;
      }

      public float method2213() {
         return this.z3;
      }

      public float method2182() {
         return this.x4;
      }

      public float method2253() {
         return this.y4;
      }

      public float method1901() {
         return this.z4;
      }

      public int method1879() {
         return this.color;
      }
   }

   private class ShapeInstance {
      private final ShapeType field0986;
      private class_243 field0795;
      private class_243 field1273;
      private class_243 field0338;
      private double field0176;
      private double field0457;
      private double field1613;
      private double field1537;
      private double field1703;
      private double field1135;
      public float field0566;
      public boolean field0169;
      private double field1086;
      private double field1195;
      private double field0870;
      private double field0825;
      private double field0909;
      private double field1330;
      private double field1291 = Double.NaN;
      private double field1368 = Double.NaN;
      private double field0384 = Double.NaN;

      public ShapeInstance(ShapeType type, class_243 position, class_243 velocity, double initialRotation) {
         this.field0986 = type;
         this.field0795 = position;
         this.field1273 = position;
         this.field0338 = velocity;
         this.field0176 = initialRotation;
         this.field0457 = initialRotation;
         this.field1613 = GeometricShapes.this.field0929.nextDouble() * 3.141593439626053 * (double)2.0F;
         this.field1537 = this.field1613;
         this.field1703 = GeometricShapes.this.field0929.nextDouble() * 3.141593439626053 * (double)2.0F;
         this.field1135 = this.field1703;
         this.field0566 = 0.0F;
         this.field0169 = false;
      }

      public void method0578() {
         float fadeSpeedValue = 0.1F;
         if (this.field0169) {
            this.field0566 = Math.max(0.0F, this.field0566 - fadeSpeedValue);
         } else {
            this.field0566 = Math.min(1.0F, this.field0566 + fadeSpeedValue);
         }

         this.field1273 = this.field0795;
         this.field0457 = this.field0176;
         this.field1537 = this.field1613;
         this.field1135 = this.field1703;
         double speed = (double)0.06F;
         if (GeometricShapes.this.field0929.nextInt(5) == 0) {
            class_243 randomImpulse = new class_243((GeometricShapes.this.field0929.nextDouble() - (double)0.5F) * speed * 0.20000004508207708, (GeometricShapes.this.field0929.nextDouble() - (double)0.5F) * speed * 0.15000007922541733, (GeometricShapes.this.field0929.nextDouble() - (double)0.5F) * speed * 0.20000004508207708);
            this.field0338 = this.field0338.method_1019(randomImpulse);
         }

         this.field0338 = this.field0338.method_18805(0.9849997920843107, 0.9849997920843107, 0.9849997920843107);
         class_238 playerBox = MinecraftAccess.field0796.field_1724.method_5829().method_1014((double)0.5F);
         class_238 shapeBox = new class_238(this.field0795.field_1352 - 0.20000004508207708, this.field0795.field_1351 - 0.20000004508207708, this.field0795.field_1350 - 0.20000004508207708, this.field0795.field_1352 + 0.20000004508207708, this.field0795.field_1351 + 0.20000004508207708, this.field0795.field_1350 + 0.20000004508207708);
         if (playerBox.method_994(shapeBox)) {
            class_243 playerCenter = MinecraftAccess.field0796.field_1724.method_19538().method_1031((double)0.0F, (double)(MinecraftAccess.field0796.field_1724.method_17682() / 2.0F), (double)0.0F);
            class_243 pushDir = this.field0795.method_1020(playerCenter).method_1029();
            double pushStrength = 0.15000007922541733;
            this.field0338 = this.field0338.method_1019(pushDir.method_1021(pushStrength));
         }

         double size = (double)(Float)GeometricShapes.this.field0985.method0492() * (double)0.5F;
         class_238 currentBox = new class_238(this.field0795.field_1352 - size, this.field0795.field_1351 - size, this.field0795.field_1350 - size, this.field0795.field_1352 + size, this.field0795.field_1351 + size, this.field0795.field_1350 + size);
         class_243 movement = this.field0338;
         class_238 testBoxY = currentBox.method_989((double)0.0F, movement.field_1351, (double)0.0F);
         class_2338.class_2339 mutablePos = new class_2338.class_2339();
         boolean collisionY = false;

         for(int x = (int)Math.floor(testBoxY.field_1323); (double)x <= Math.floor(testBoxY.field_1320); ++x) {
            for(int y = (int)Math.floor(testBoxY.field_1322); (double)y <= Math.floor(testBoxY.field_1325); ++y) {
               for(int z = (int)Math.floor(testBoxY.field_1321); (double)z <= Math.floor(testBoxY.field_1324); ++z) {
                  mutablePos.method_10103(x, y, z);
                  if (!MinecraftAccess.field0796.field_1687.method_8320(mutablePos).method_26215()) {
                     collisionY = true;
                     break;
                  }
               }

               if (collisionY) {
                  break;
               }
            }

            if (collisionY) {
               break;
            }
         }

         if (collisionY) {
            if (this.field0338.field_1351 < (double)0.0F) {
               this.field0338 = new class_243(this.field0338.field_1352 * 0.7000001065509516, -this.field0338.field_1351 * 0.6000000039872756, this.field0338.field_1350 * 0.7000001065509516);
            } else {
               this.field0338 = new class_243(this.field0338.field_1352, (double)0.0F, this.field0338.field_1350);
            }

            movement = new class_243(movement.field_1352, (double)0.0F, movement.field_1350);
         }

         class_238 testBoxX = currentBox.method_989(movement.field_1352, movement.field_1351, (double)0.0F);
         boolean collisionX = false;

         for(int x = (int)Math.floor(testBoxX.field_1323); (double)x <= Math.floor(testBoxX.field_1320); ++x) {
            for(int y = (int)Math.floor(testBoxX.field_1322); (double)y <= Math.floor(testBoxX.field_1325); ++y) {
               for(int z = (int)Math.floor(testBoxX.field_1321); (double)z <= Math.floor(testBoxX.field_1324); ++z) {
                  mutablePos.method_10103(x, y, z);
                  if (!MinecraftAccess.field0796.field_1687.method_8320(mutablePos).method_26215()) {
                     collisionX = true;
                     break;
                  }
               }

               if (collisionX) {
                  break;
               }
            }

            if (collisionX) {
               break;
            }
         }

         if (collisionX) {
            this.field0338 = new class_243(-this.field0338.field_1352 * (double)0.5F, this.field0338.field_1351, this.field0338.field_1350);
            movement = new class_243((double)0.0F, movement.field_1351, movement.field_1350);
         }

         class_238 testBoxZ = currentBox.method_989(movement.field_1352, movement.field_1351, movement.field_1350);
         boolean collisionZ = false;

         for(int x = (int)Math.floor(testBoxZ.field_1323); (double)x <= Math.floor(testBoxZ.field_1320); ++x) {
            for(int y = (int)Math.floor(testBoxZ.field_1322); (double)y <= Math.floor(testBoxZ.field_1325); ++y) {
               for(int z = (int)Math.floor(testBoxZ.field_1321); (double)z <= Math.floor(testBoxZ.field_1324); ++z) {
                  mutablePos.method_10103(x, y, z);
                  if (!MinecraftAccess.field0796.field_1687.method_8320(mutablePos).method_26215()) {
                     collisionZ = true;
                     break;
                  }
               }

               if (collisionZ) {
                  break;
               }
            }

            if (collisionZ) {
               break;
            }
         }

         if (collisionZ) {
            this.field0338 = new class_243(this.field0338.field_1352, this.field0338.field_1351, -this.field0338.field_1350 * (double)0.5F);
            movement = new class_243(movement.field_1352, movement.field_1351, (double)0.0F);
         }

         this.field0795 = this.field0795.method_1019(movement);
         double rotSpeed = Math.toRadians((double)4.0F) * (double)0.5F;
         this.field0176 += rotSpeed;
         this.field1613 += rotSpeed * 0.7000001065509516;
         this.field1703 += rotSpeed * (double)0.5F;
         if (this.field0176 >= 6.283187713717119) {
            this.field0176 -= 6.283187713717119;
         }

         if (this.field1613 >= 6.283187713717119) {
            this.field1613 -= 6.283187713717119;
         }

         if (this.field1703 >= 6.283187713717119) {
            this.field1703 -= 6.283187713717119;
         }

      }

      public void method0840(GlowRenderEvent event, float hue, float size, float partialTicks, List<ColoredLine> lines, List<ShapeMesh> quads) {
         if (!(this.field0566 <= 0.001F)) {
            class_243 renderPos = this.field1273.method_35590(this.field0795, (double)partialTicks);
            double renderRotation = this.method0625(this.field0457, this.field0176, partialTicks);
            double renderRotationY = this.method0625(this.field1537, this.field1613, partialTicks);
            double renderRotationZ = this.method0625(this.field1135, this.field1703, partialTicks);
            class_243 camera = MinecraftAccess.field0796.field_1773.method_19418().method_19326();
            Matrix4f matrix = event.method1808().method_23760().method_23761();
            Color baseColor = GeometricShapes.this.field1623.method1726();
            int alpha = Math.max(0, Math.min(255, (int)((float)baseColor.getAlpha() * this.field0566)));
            int shapeRgb = (alpha & 255) << 24 | baseColor.getRGB() & 16777215;
            switch (this.field0986.ordinal()) {
               case 0 -> this.method1342(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 1 -> this.method0294(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 2 -> this.method2164(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 3 -> this.method1866(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 4 -> this.method1669(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 5 -> this.method1996(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 6 -> this.method0447(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 7 -> this.method0390(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
               case 8 -> this.method0509(renderPos, camera, matrix, shapeRgb, size, renderRotation, renderRotationY, renderRotationZ, lines, quads);
            }

         }
      }

      private double method0625(double start, double end, float t) {
         double diff = end - start;
         if (diff > 3.141593439626053) {
            diff -= 6.283187713717119;
         } else if (diff < -3.1415933127849662) {
            diff += 6.283187713717119;
         }

         return start + diff * (double)t;
      }

      private void method1342(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         class_243[] vertices = new class_243[]{this.method1305(new class_243((double)(-size), (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)size, (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)size, (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)(-size), (double)size), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)(-size), (double)size), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)size, (double)size), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)size, (double)size), rot, rotY, rotZ)};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] faces = new int[][]{{0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 3, 7, 4}, {1, 2, 6, 5}};

            for(int[] face : faces) {
               this.method2180(vertices, face, x, y, z, matrix, rgb, quads);
            }
         }

         int[][] edges = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            this.method1597(vertices, x, y, z, matrix, rgb, lines);
         }

      }

      private void method0294(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         class_243[] vertices = new class_243[]{this.method1305(new class_243((double)0.0F, (double)size, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)(-size), (double)size), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)(-size), (double)size), rot, rotY, rotZ)};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] faces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 4}, {0, 4, 1}, {1, 2, 3, 4}};

            for(int[] face : faces) {
               if (face.length == 3) {
                  this.method0353(vertices, face, x, y, z, matrix, rgb, quads);
               } else {
                  this.method2180(vertices, face, x, y, z, matrix, rgb, quads);
               }
            }
         }

         int[][] edges = new int[][]{{0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 2}, {2, 3}, {3, 4}, {4, 1}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] triangleFaces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 4}, {0, 4, 1}};

            for(int[] face : triangleFaces) {
               this.method1877(vertices, face, x, y, z, matrix, rgb, lines);
            }
         }

      }

      private void method2164(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         class_243[] vertices = new class_243[]{this.method1305(new class_243((double)0.0F, (double)size, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)0.0F, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, (double)0.0F, (double)size), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)0.0F, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, (double)0.0F, (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, (double)(-size), (double)0.0F), rot, rotY, rotZ)};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] faces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 4}, {0, 4, 1}, {5, 2, 1}, {5, 3, 2}, {5, 4, 3}, {5, 1, 4}};

            for(int[] face : faces) {
               this.method0353(vertices, face, x, y, z, matrix, rgb, quads);
            }
         }

         int[][] edges = new int[][]{{0, 1}, {0, 2}, {0, 3}, {0, 4}, {5, 1}, {5, 2}, {5, 3}, {5, 4}, {1, 2}, {2, 3}, {3, 4}, {4, 1}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] triangleFaces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 4}, {0, 4, 1}, {5, 2, 1}, {5, 3, 2}, {5, 4, 3}, {5, 1, 4}};

            for(int[] face : triangleFaces) {
               this.method1877(vertices, face, x, y, z, matrix, rgb, lines);
            }
         }

      }

      private void method1866(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         class_243[] vertices = new class_243[]{this.method1305(new class_243((double)0.0F, (double)size, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)(-size), (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)size, (double)(-size), (double)(-size)), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, (double)(-size), (double)size), rot, rotY, rotZ)};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] faces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 1}, {1, 3, 2}};

            for(int[] face : faces) {
               this.method0353(vertices, face, x, y, z, matrix, rgb, quads);
            }
         }

         int[][] edges = new int[][]{{0, 1}, {0, 2}, {0, 3}, {1, 2}, {2, 3}, {3, 1}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] triangleFaces = new int[][]{{0, 1, 2}, {0, 2, 3}, {0, 3, 1}, {1, 3, 2}};

            for(int[] face : triangleFaces) {
               this.method1877(vertices, face, x, y, z, matrix, rgb, lines);
            }
         }

      }

      private void method1598(class_243[] vertices, int[] edge, float x, float y, float z, Matrix4f matrix, int rgb, List<ColoredLine> lines) {
         class_243 v1 = vertices[edge[0]];
         class_243 v2 = vertices[edge[1]];
         lines.add(new ColoredLine(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)v2.field_1352, y + (float)v2.field_1351, z + (float)v2.field_1350, rgb));
      }

      private static int method0716(int rgb) {
         int a = rgb >>> 24 & 255;
         return rgb & 16777215 | a >> 1 << 24;
      }

      private void method0353(class_243[] vertices, int[] face, float x, float y, float z, Matrix4f matrix, int rgb, List<ShapeMesh> quads) {
         class_243 v1 = vertices[face[0]];
         class_243 v2 = vertices[face[1]];
         class_243 v3 = vertices[face[2]];
         int fadedRgb = method0716(rgb);
         quads.add(new ShapeMesh(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)v2.field_1352, y + (float)v2.field_1351, z + (float)v2.field_1350, x + (float)v3.field_1352, y + (float)v3.field_1351, z + (float)v3.field_1350, x + (float)v3.field_1352, y + (float)v3.field_1351, z + (float)v3.field_1350, fadedRgb));
         quads.add(new ShapeMesh(matrix, x + (float)(v1.field_1352 * (double)0.5F), y + (float)(v1.field_1351 * (double)0.5F), z + (float)(v1.field_1350 * (double)0.5F), x + (float)(v2.field_1352 * (double)0.5F), y + (float)(v2.field_1351 * (double)0.5F), z + (float)(v2.field_1350 * (double)0.5F), x + (float)(v3.field_1352 * (double)0.5F), y + (float)(v3.field_1351 * (double)0.5F), z + (float)(v3.field_1350 * (double)0.5F), x + (float)(v3.field_1352 * (double)0.5F), y + (float)(v3.field_1351 * (double)0.5F), z + (float)(v3.field_1350 * (double)0.5F), fadedRgb));
      }

      private void method2180(class_243[] vertices, int[] face, float x, float y, float z, Matrix4f matrix, int rgb, List<ShapeMesh> quads) {
         class_243 v1 = vertices[face[0]];
         class_243 v2 = vertices[face[1]];
         class_243 v3 = vertices[face[2]];
         class_243 v4 = vertices[face[3]];
         int fadedRgb = method0716(rgb);
         quads.add(new ShapeMesh(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)v2.field_1352, y + (float)v2.field_1351, z + (float)v2.field_1350, x + (float)v3.field_1352, y + (float)v3.field_1351, z + (float)v3.field_1350, x + (float)v4.field_1352, y + (float)v4.field_1351, z + (float)v4.field_1350, fadedRgb));
         quads.add(new ShapeMesh(matrix, x + (float)(v1.field_1352 * (double)0.5F), y + (float)(v1.field_1351 * (double)0.5F), z + (float)(v1.field_1350 * (double)0.5F), x + (float)(v2.field_1352 * (double)0.5F), y + (float)(v2.field_1351 * (double)0.5F), z + (float)(v2.field_1350 * (double)0.5F), x + (float)(v3.field_1352 * (double)0.5F), y + (float)(v3.field_1351 * (double)0.5F), z + (float)(v3.field_1350 * (double)0.5F), x + (float)(v4.field_1352 * (double)0.5F), y + (float)(v4.field_1351 * (double)0.5F), z + (float)(v4.field_1350 * (double)0.5F), fadedRgb));
      }

      private void method1597(class_243[] vertices, float x, float y, float z, Matrix4f matrix, int rgb, List<ColoredLine> lines) {
         int[][] faces = new int[][]{{0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 3, 7, 4}, {1, 2, 6, 5}};

         for(int[] face : faces) {
            class_243 v0 = vertices[face[0]];
            class_243 v1 = vertices[face[1]];
            class_243 v2 = vertices[face[2]];
            class_243 v3 = vertices[face[3]];

            for(int i = 1; i < 3; ++i) {
               float t = (float)i / 3.0F;
               class_243 h1 = v0.method_35590(v3, (double)t);
               class_243 h2 = v1.method_35590(v2, (double)t);
               lines.add(new ColoredLine(matrix, x + (float)h1.field_1352, y + (float)h1.field_1351, z + (float)h1.field_1350, x + (float)h2.field_1352, y + (float)h2.field_1351, z + (float)h2.field_1350, rgb));
               class_243 v1_lerp = v0.method_35590(v1, (double)t);
               class_243 v2_lerp = v3.method_35590(v2, (double)t);
               lines.add(new ColoredLine(matrix, x + (float)v1_lerp.field_1352, y + (float)v1_lerp.field_1351, z + (float)v1_lerp.field_1350, x + (float)v2_lerp.field_1352, y + (float)v2_lerp.field_1351, z + (float)v2_lerp.field_1350, rgb));
            }
         }

      }

      private void method1877(class_243[] vertices, int[] face, float x, float y, float z, Matrix4f matrix, int rgb, List<ColoredLine> lines) {
         class_243 v0 = vertices[face[0]];
         class_243 v1 = vertices[face[1]];
         class_243 v2 = vertices[face[2]];
         class_243 center = new class_243((v0.field_1352 + v1.field_1352 + v2.field_1352) / (double)3.0F, (v0.field_1351 + v1.field_1351 + v2.field_1351) / (double)3.0F, (v0.field_1350 + v1.field_1350 + v2.field_1350) / (double)3.0F);
         lines.add(new ColoredLine(matrix, x + (float)v0.field_1352, y + (float)v0.field_1351, z + (float)v0.field_1350, x + (float)center.field_1352, y + (float)center.field_1351, z + (float)center.field_1350, rgb));
         lines.add(new ColoredLine(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)center.field_1352, y + (float)center.field_1351, z + (float)center.field_1350, rgb));
         lines.add(new ColoredLine(matrix, x + (float)v2.field_1352, y + (float)v2.field_1351, z + (float)v2.field_1350, x + (float)center.field_1352, y + (float)center.field_1351, z + (float)center.field_1350, rgb));
      }

      private void method1669(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         class_243[] vertices = new class_243[12];
         int points = 5;
         float outerRadius = size * 1.2F;
         float innerRadius = size * 0.5F;

         for(int i = 0; i < points; ++i) {
            double angle = 6.283187713717119 * (double)i / (double)points - 1.57079665648706;
            vertices[i] = this.method1305(new class_243(Math.cos(angle) * (double)outerRadius, (double)0.0F, Math.sin(angle) * (double)outerRadius), rot, rotY, rotZ);
            double angleInner = 6.283187713717119 * ((double)i + (double)0.5F) / (double)points - 1.57079665648706;
            vertices[i + points] = this.method1305(new class_243(Math.cos(angleInner) * (double)innerRadius, (double)0.0F, Math.sin(angleInner) * (double)innerRadius), rot, rotY, rotZ);
         }

         vertices[10] = this.method1305(new class_243((double)0.0F, (double)size * 0.6000000039872756, (double)0.0F), rot, rotY, rotZ);
         vertices[11] = this.method1305(new class_243((double)0.0F, (double)(-size) * 0.6000000039872756, (double)0.0F), rot, rotY, rotZ);
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            for(int i = 0; i < points; ++i) {
               int next = (i + 1) % points;
               this.method0353(vertices, new int[]{i, i + points, 10}, x, y, z, matrix, rgb, quads);
               this.method0353(vertices, new int[]{next, i + points, 10}, x, y, z, matrix, rgb, quads);
               this.method0353(vertices, new int[]{i, i + points, 11}, x, y, z, matrix, rgb, quads);
               this.method0353(vertices, new int[]{next, i + points, 11}, x, y, z, matrix, rgb, quads);
            }
         }

         for(int i = 0; i < points; ++i) {
            int next = (i + 1) % points;
            this.method1598(vertices, new int[]{i, i + points}, x, y, z, matrix, rgb, lines);
            this.method1598(vertices, new int[]{i + points, next}, x, y, z, matrix, rgb, lines);
            this.method1598(vertices, new int[]{i, 10}, x, y, z, matrix, rgb, lines);
            this.method1598(vertices, new int[]{i, 11}, x, y, z, matrix, rgb, lines);
         }

      }

      private void method1996(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         int arms = 6;
         double snowflakeSize = (double)size * 1.4000004889625575;
         double thickness = (double)size * 0.20000004508207708;
         class_243 centerTop = this.method1305(new class_243((double)0.0F, thickness, (double)0.0F), rot, rotY, rotZ);
         class_243 centerBottom = this.method1305(new class_243((double)0.0F, -thickness, (double)0.0F), rot, rotY, rotZ);

         for(int i = 0; i < arms; ++i) {
            double angle = 6.283187713717119 * (double)i / (double)arms;
            class_243 tipTop = this.method1305(new class_243(Math.cos(angle) * snowflakeSize, thickness, Math.sin(angle) * snowflakeSize), rot, rotY, rotZ);
            class_243 tipBottom = this.method1305(new class_243(Math.cos(angle) * snowflakeSize, -thickness, Math.sin(angle) * snowflakeSize), rot, rotY, rotZ);
            if ((Boolean)GeometricShapes.this.field0464.method0492()) {
               class_243[] verts = new class_243[]{centerTop, centerBottom, tipBottom, tipTop};
               this.method2180(verts, new int[]{0, 1, 2, 3}, x, y, z, matrix, rgb, quads);
            }

            this.method1598(new class_243[]{centerTop, tipTop}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
            this.method1598(new class_243[]{centerBottom, tipBottom}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
            this.method1598(new class_243[]{tipTop, tipBottom}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);

            for(int j = 1; j <= 2; ++j) {
               double branchDist = snowflakeSize * 0.30000003411622683 * (double)j;
               class_243 branchBaseTop = this.method1305(new class_243(Math.cos(angle) * branchDist, thickness, Math.sin(angle) * branchDist), rot, rotY, rotZ);
               class_243 branchBaseBottom = this.method1305(new class_243(Math.cos(angle) * branchDist, -thickness, Math.sin(angle) * branchDist), rot, rotY, rotZ);
               double leftAngle = angle + 0.7853984019917979;
               class_243 leftTipTop = this.method1305(new class_243(Math.cos(angle) * branchDist + Math.cos(leftAngle) * snowflakeSize * 0.20000004508207708, thickness, Math.sin(angle) * branchDist + Math.sin(leftAngle) * snowflakeSize * 0.20000004508207708), rot, rotY, rotZ);
               class_243 leftTipBottom = this.method1305(new class_243(Math.cos(angle) * branchDist + Math.cos(leftAngle) * snowflakeSize * 0.20000004508207708, -thickness, Math.sin(angle) * branchDist + Math.sin(leftAngle) * snowflakeSize * 0.20000004508207708), rot, rotY, rotZ);
               if ((Boolean)GeometricShapes.this.field0464.method0492()) {
                  this.method2180(new class_243[]{branchBaseTop, branchBaseBottom, leftTipBottom, leftTipTop}, new int[]{0, 1, 2, 3}, x, y, z, matrix, rgb, quads);
               }

               this.method1598(new class_243[]{branchBaseTop, leftTipTop}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
               this.method1598(new class_243[]{leftTipTop, leftTipBottom}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
               double rightAngle = angle - 0.7853984019917979;
               class_243 rightTipTop = this.method1305(new class_243(Math.cos(angle) * branchDist + Math.cos(rightAngle) * snowflakeSize * 0.20000004508207708, thickness, Math.sin(angle) * branchDist + Math.sin(rightAngle) * snowflakeSize * 0.20000004508207708), rot, rotY, rotZ);
               class_243 rightTipBottom = this.method1305(new class_243(Math.cos(angle) * branchDist + Math.cos(rightAngle) * snowflakeSize * 0.20000004508207708, -thickness, Math.sin(angle) * branchDist + Math.sin(rightAngle) * snowflakeSize * 0.20000004508207708), rot, rotY, rotZ);
               if ((Boolean)GeometricShapes.this.field0464.method0492()) {
                  this.method2180(new class_243[]{branchBaseTop, branchBaseBottom, rightTipBottom, rightTipTop}, new int[]{0, 1, 2, 3}, x, y, z, matrix, rgb, quads);
               }

               this.method1598(new class_243[]{branchBaseTop, rightTipTop}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
               this.method1598(new class_243[]{rightTipTop, rightTipBottom}, new int[]{0, 1}, x, y, z, matrix, rgb, lines);
            }
         }

      }

      private void method0447(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         double phi = ((double)1.0F + Math.sqrt((double)5.0F)) / (double)2.0F;
         double a = (double)size;
         double b = (double)size / phi;
         class_243[] vertices = new class_243[]{this.method1305(new class_243((double)0.0F, b, -a), rot, rotY, rotZ), this.method1305(new class_243(b, a, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243(-b, a, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, b, a), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, -b, a), rot, rotY, rotZ), this.method1305(new class_243(-a, (double)0.0F, b), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, -b, -a), rot, rotY, rotZ), this.method1305(new class_243(a, (double)0.0F, -b), rot, rotY, rotZ), this.method1305(new class_243(a, (double)0.0F, b), rot, rotY, rotZ), this.method1305(new class_243(-a, (double)0.0F, -b), rot, rotY, rotZ), this.method1305(new class_243(b, -a, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243(-b, -a, (double)0.0F), rot, rotY, rotZ)};
         int[][] faces = new int[][]{{0, 1, 2}, {3, 2, 1}, {3, 1, 8}, {3, 8, 4}, {3, 4, 5}, {2, 3, 5}, {4, 10, 11}, {4, 11, 5}, {5, 11, 9}, {5, 9, 2}, {2, 9, 0}, {9, 7, 0}, {0, 7, 1}, {6, 9, 11}, {6, 11, 10}, {6, 10, 7}, {7, 10, 1}, {8, 1, 10}, {4, 8, 10}, {6, 7, 9}};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            for(int[] face : faces) {
               this.method0353(vertices, face, x, y, z, matrix, rgb, quads);
            }
         }

         int[][] edges = new int[][]{{0, 1}, {0, 2}, {0, 7}, {0, 9}, {1, 2}, {1, 3}, {1, 7}, {1, 8}, {1, 10}, {2, 3}, {2, 5}, {2, 9}, {3, 4}, {3, 5}, {3, 8}, {4, 5}, {4, 8}, {4, 10}, {4, 11}, {5, 9}, {5, 11}, {6, 7}, {6, 9}, {6, 10}, {6, 11}, {7, 9}, {7, 10}, {8, 10}, {9, 11}, {10, 11}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

      }

      private void method0390(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         double phi = ((double)1.0F + Math.sqrt((double)5.0F)) / (double)2.0F;
         double a = (double)size;
         double b = (double)size / phi;
         double c = (double)size * ((double)2.0F - phi);
         class_243[] vertices = new class_243[]{this.method1305(new class_243(a, a, a), rot, rotY, rotZ), this.method1305(new class_243(a, a, -a), rot, rotY, rotZ), this.method1305(new class_243(a, -a, a), rot, rotY, rotZ), this.method1305(new class_243(a, -a, -a), rot, rotY, rotZ), this.method1305(new class_243(-a, a, a), rot, rotY, rotZ), this.method1305(new class_243(-a, a, -a), rot, rotY, rotZ), this.method1305(new class_243(-a, -a, a), rot, rotY, rotZ), this.method1305(new class_243(-a, -a, -a), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, b, c), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, b, -c), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, -b, c), rot, rotY, rotZ), this.method1305(new class_243((double)0.0F, -b, -c), rot, rotY, rotZ), this.method1305(new class_243(c, (double)0.0F, b), rot, rotY, rotZ), this.method1305(new class_243(c, (double)0.0F, -b), rot, rotY, rotZ), this.method1305(new class_243(-c, (double)0.0F, b), rot, rotY, rotZ), this.method1305(new class_243(-c, (double)0.0F, -b), rot, rotY, rotZ), this.method1305(new class_243(b, c, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243(b, -c, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243(-b, c, (double)0.0F), rot, rotY, rotZ), this.method1305(new class_243(-b, -c, (double)0.0F), rot, rotY, rotZ)};
         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            int[][] faces = new int[][]{{0, 8, 4, 14, 12}, {0, 12, 2, 17, 13}, {0, 13, 1, 16, 8}, {1, 9, 5, 18, 16}, {1, 13, 3, 11, 9}, {2, 10, 6, 14, 12}, {2, 12, 0, 16, 17}, {3, 17, 2, 10, 11}, {3, 13, 0, 8, 9}, {4, 8, 16, 18, 14}, {5, 15, 7, 19, 18}, {6, 10, 11, 7, 19}};

            for(int[] face : faces) {
               this.method0353(vertices, new int[]{face[0], face[1], face[2]}, x, y, z, matrix, rgb, quads);
               this.method0353(vertices, new int[]{face[0], face[2], face[3]}, x, y, z, matrix, rgb, quads);
               this.method0353(vertices, new int[]{face[0], face[3], face[4]}, x, y, z, matrix, rgb, quads);
            }
         }

         int[][] edges = new int[][]{{0, 8}, {0, 12}, {0, 16}, {1, 9}, {1, 13}, {1, 16}, {2, 10}, {2, 12}, {2, 17}, {3, 11}, {3, 13}, {3, 17}, {4, 8}, {4, 14}, {4, 18}, {5, 9}, {5, 15}, {5, 18}, {6, 10}, {6, 14}, {6, 19}, {7, 11}, {7, 15}, {7, 19}, {8, 9}, {10, 11}, {12, 13}, {14, 15}, {16, 18}, {17, 19}};

         for(int[] edge : edges) {
            this.method1598(vertices, edge, x, y, z, matrix, rgb, lines);
         }

      }

      private void method0509(class_243 pos, class_243 camera, Matrix4f matrix, int rgb, float size, double rot, double rotY, double rotZ, List<ColoredLine> lines, List<ShapeMesh> quads) {
         float x = (float)(pos.field_1352 - camera.field_1352);
         float y = (float)(pos.field_1351 - camera.field_1351);
         float z = (float)(pos.field_1350 - camera.field_1350);
         double majorRadius = (double)size * (double)1.0F;
         double minorRadius = (double)size * 0.3999999535514235;
         int majorSegments = 16;
         int minorSegments = 8;
         class_243[][] vertices = new class_243[majorSegments][minorSegments];

         for(int i = 0; i < majorSegments; ++i) {
            double u = 6.283187713717119 * (double)i / (double)majorSegments;

            for(int j = 0; j < minorSegments; ++j) {
               double v = 6.283187713717119 * (double)j / (double)minorSegments;
               double px = (majorRadius + minorRadius * Math.cos(v)) * Math.cos(u);
               double py = minorRadius * Math.sin(v);
               double pz = (majorRadius + minorRadius * Math.cos(v)) * Math.sin(u);
               vertices[i][j] = this.method1305(new class_243(px, py, pz), rot, rotY, rotZ);
            }
         }

         if ((Boolean)GeometricShapes.this.field0464.method0492()) {
            for(int i = 0; i < majorSegments; ++i) {
               int nextI = (i + 1) % majorSegments;

               for(int j = 0; j < minorSegments; ++j) {
                  int nextJ = (j + 1) % minorSegments;
                  class_243 v1 = vertices[i][j];
                  class_243 v2 = vertices[nextI][j];
                  class_243 v3 = vertices[nextI][nextJ];
                  class_243 v4 = vertices[i][nextJ];
                  class_243[] quadVerts = new class_243[]{v1, v2, v3, v4};
                  this.method2180(quadVerts, new int[]{0, 1, 2, 3}, x, y, z, matrix, rgb, quads);
               }
            }
         }

         for(int i = 0; i < majorSegments; ++i) {
            int nextI = (i + 1) % majorSegments;

            for(int j = 0; j < minorSegments; ++j) {
               int nextJ = (j + 1) % minorSegments;
               class_243 v1 = vertices[i][j];
               class_243 v2 = vertices[nextI][j];
               class_243 v3 = vertices[i][nextJ];
               lines.add(new ColoredLine(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)v2.field_1352, y + (float)v2.field_1351, z + (float)v2.field_1350, rgb));
               lines.add(new ColoredLine(matrix, x + (float)v1.field_1352, y + (float)v1.field_1351, z + (float)v1.field_1350, x + (float)v3.field_1352, y + (float)v3.field_1351, z + (float)v3.field_1350, rgb));
            }
         }

      }

      private void method0619(double rotX, double rotY, double rotZ) {
         if (rotX != this.field1291 || rotY != this.field1368 || rotZ != this.field0384) {
            this.field1086 = Math.sin(rotX);
            this.field1195 = Math.cos(rotX);
            this.field0870 = Math.sin(rotY);
            this.field0825 = Math.cos(rotY);
            this.field0909 = Math.sin(rotZ);
            this.field1330 = Math.cos(rotZ);
            this.field1291 = rotX;
            this.field1368 = rotY;
            this.field0384 = rotZ;
         }

      }

      private class_243 method1305(class_243 vertex, double rotX, double rotY, double rotZ) {
         this.method0619(rotX, rotY, rotZ);
         this.method0108(vertex.field_1352, vertex.field_1351, vertex.field_1350);
         return new class_243(GeometricShapes.this.field0370[0], GeometricShapes.this.field0370[1], GeometricShapes.this.field0370[2]);
      }

      private void method0108(double vx, double vy, double vz) {
         double y1 = vy * this.field1195 - vz * this.field1086;
         double z1 = vy * this.field1086 + vz * this.field1195;
         double x2 = vx * this.field0825 + z1 * this.field0870;
         double z2 = -vx * this.field0870 + z1 * this.field0825;
         GeometricShapes.this.field0370[0] = x2 * this.field1330 - y1 * this.field0909;
         GeometricShapes.this.field0370[1] = x2 * this.field0909 + y1 * this.field1330;
         GeometricShapes.this.field0370[2] = z2;
      }
   }

   public static enum ShapeType implements DisplayNamed {
      field0630("Cube"),
      field0063("Pyramid"),
      field1451("Octahedron"),
      field0986("Tetrahedron"),
      field0769("Star"),
      field1254("Snowflake"),
      field0321("Icosahedron"),
      field0192("Dodecahedron"),
      field0472("Torus");

      private final String field1643;

      private ShapeType(String name) {
         this.field1643 = name;
      }

      public String method0557() {
         return this.field1643;
      }

      public static ShapeType method1000(String name) {
         for(ShapeType type : values()) {
            if (type.method0557().equalsIgnoreCase(name)) {
               return type;
            }
         }

         return field0630;
      }

      // $FF: synthetic method
      private static ShapeType[] method0066() {
         return new ShapeType[]{field0630, field0063, field1451, field0986, field0769, field1254, field0321, field0192, field0472};
      }
   }
}
