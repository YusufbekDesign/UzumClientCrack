package aethereal;

import java.awt.Color;
import java.util.Objects;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2828;
import net.minecraft.class_5498;
import org.joml.Vector2d;

public class FreeCam extends Module {
   public static FreeCam field0061;
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("freecam.speed", 2.0F, 0.5F, 5.0F, 0.1F)).method1007("Tezlik").method0210("Camera fly speed").method2130("Kamera parvoz tezligi");
   private final BooleanSetting field0970 = (BooleanSetting)(new BooleanSetting("freecam.freeze", false)).method1007("Muzlatish").method0210("Freeze player in place while camera flies").method2130("Kamera uchib ketganda o'yinchini joyida muzlatadi");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("freecam.showmodel", true)).method1007("Modelni ko'rsatish").method0210("Render a static ghost of your player at the locked position").method2130("O'yinchi modelini bloklangan joyda ko'rsatish");
   private final BooleanSetting field0464;
   private final ColorSetting field1623;
   private final BooleanSetting field1544;
   private final ColorSetting field1711;
   private class_243 field1158;
   private class_243 field1107;
   private StaticPlayerEntity field1202;
   private class_243 field0889;

   public FreeCam() {
      super("FreeCam", ModuleCategory.field0776, "O'yinchidan ajralgan erkin parvoz kamerasi");
      Boolean var10004 = true;
      BooleanSetting var10005 = this.field0184;
      Objects.requireNonNull(var10005);
      this.field0464 = (BooleanSetting)(new BooleanSetting("freecam.modelfill", var10004, var10005::method0492)).method1007("To'ldirish").method0210("Render filled model").method2130("To'ldirilgan model");
      this.field1623 = (ColorSetting)(new ColorSetting("freecam.modelfillcolor", 255, 156, 228, 100, () -> (Boolean)this.field0184.method0492() && (Boolean)this.field0464.method0492())).method1882().method1007("To'ldirish rangi").method0210("Color of the filled ghost model").method2130("To'ldirilgan model rangi");
      var10004 = true;
      var10005 = this.field0184;
      Objects.requireNonNull(var10005);
      this.field1544 = (BooleanSetting)(new BooleanSetting("freecam.modeloutline", var10004, var10005::method0492)).method1007("Kontur").method0210("Render outline around ghost model").method2130("Model atrofida kontur chizish");
      this.field1711 = (ColorSetting)(new ColorSetting("freecam.modeloutlinecolor", 255, 156, 228, 255, () -> (Boolean)this.field0184.method0492() && (Boolean)this.field1544.method0492())).method1882().method1007("Kontur rangi").method0210("Color of the ghost model outline").method2130("Model kontur rangi");
      this.method1013("Erkin parvoz kamerasi");
      field0061 = this;
   }

   public void method0025() {
      super.method0025();
      if (field0796.field_1724 != null && field0796.field_1687 != null && field0796.field_1773 != null && field0796.field_1773.method_19418() != null) {
         field0796.field_1730 = false;
         this.field1107 = this.field1158 = field0796.field_1773.method_19418().method_19326();
         this.field1202 = new StaticPlayerEntity(field0796.field_1724);
         this.field0889 = field0796.field_1724.method_19538();
      } else {
         this.method0345(false);
      }

   }

   public void method2078() {
      super.method2078();
      if (field0796.field_1687 != null) {
         field0796.field_1730 = true;
      }

      this.field1202 = null;
      this.field0889 = null;
   }

   @EventHandler
   public void onPacketSend(PacketEvent.Outbound var1) {
      if ((Boolean)this.field0970.method0492() && var1.method1970() instanceof class_2828) {
         var1.method0578();
      }

   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Inbound var1) {
      if (var1.method1970() instanceof class_2724 || var1.method1970() instanceof class_2678) {
         this.method0345(false);
      }

   }

   @EventHandler
   public void onMove(MovementEvent var1) {
      if ((Boolean)this.field0970.method0492()) {
         var1.method1300(class_243.field_1353);
      }

   }

   @EventHandler
   public void onMoveInput(MoveInputEvent var1) {
      if (!method1974() && this.field1158 != null) {
         double var2 = ((Float)this.field1450.method0492()).doubleValue();
         Vector2d var4 = this.method0635(var2, var1.method1603(), var1.method1946());
         double var5 = (double)0.0F;
         if (var1.method1797() != null) {
            if (var1.method1797().comp_3163()) {
               var5 = var2;
            } else if (var1.method1797().comp_3164()) {
               var5 = -var2;
            }
         }

         this.field1107 = this.field1158;
         this.field1158 = this.field1158.method_1031(var4.x, var5, var4.y);
         var1.method0665(0.0F);
         var1.method0124(0.0F);
      }

   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent var1) {
      if ((Boolean)this.field0184.method0492() && this.field1202 != null && this.field0889 != null && field0796.field_1687 != null) {
         this.field1202.method1300(this.field0889);
         Color var2 = new Color(this.field1623.method1742(), this.field1623.method2019(), this.field1623.method2002(), this.field1623.method2036());
         Color var3 = new Color(this.field1711.method1742(), this.field1711.method2019(), this.field1711.method2002(), this.field1711.method2036());

         try {
            this.field1202.method0713(var1.method1603(), (Boolean)this.field0464.method0492(), var2, (Boolean)this.field1544.method0492(), var3, false);
         } catch (Exception var5) {
         }
      }

   }

   @EventHandler
   public void onCamera(CameraEvent var1) {
      if (this.method2195() && this.field1158 != null && this.field1107 != null) {
         class_243 var2 = MathHelper.method1328(this.field1107, this.field1158);
         var1.method0611(var2.field_1352);
         var1.method0103(var2.field_1351);
         var1.method2086(var2.field_1350);
         if (field0796.field_1690 != null && field0796.field_1690.method_31044() != class_5498.field_26664) {
            field0796.field_1690.method_31043(class_5498.field_26664);
         }
      }

   }

   private Vector2d method0635(double var1, float var3, float var4) {
      if (field0796.field_1724 == null) {
         return new Vector2d((double)0.0F, (double)0.0F);
      } else {
         float var5 = field0796.field_1724.method_36454();
         float var6 = var3;
         float var7 = var4;
         if (var3 == 0.0F && var4 == 0.0F) {
            return new Vector2d((double)0.0F, (double)0.0F);
         } else {
            if (var3 != 0.0F) {
               if (var4 >= 1.0F) {
                  var5 += var3 > 0.0F ? -45.0F : 45.0F;
                  var7 = 0.0F;
               } else if (var4 <= -1.0F) {
                  var5 += var3 > 0.0F ? 45.0F : -45.0F;
                  var7 = 0.0F;
               }

               var6 = var3 > 0.0F ? 1.0F : -1.0F;
            }

            double var8 = Math.cos(Math.toRadians((double)(var5 + 90.0F)));
            double var10 = Math.sin(Math.toRadians((double)(var5 + 90.0F)));
            return new Vector2d((double)var6 * var1 * var8 + (double)var7 * var1 * var10, (double)var6 * var1 * var10 - (double)var7 * var1 * var8);
         }
      }
   }

   @Generated
   public FloatSetting method1711() {
      return this.field1450;
   }

   @Generated
   public BooleanSetting method1682() {
      return this.field0970;
   }

   @Generated
   public BooleanSetting method1743() {
      return this.field0184;
   }

   @Generated
   public BooleanSetting method2021() {
      return this.field0464;
   }

   @Generated
   public ColorSetting method2006() {
      return this.field1623;
   }

   @Generated
   public BooleanSetting method2037() {
      return this.field1544;
   }

   @Generated
   public ColorSetting method0465() {
      return this.field1711;
   }

   @Generated
   public class_243 method0456() {
      return this.field1158;
   }

   @Generated
   public class_243 method0478() {
      return this.field1107;
   }

   @Generated
   public StaticPlayerEntity method0401() {
      return this.field1202;
   }

   @Generated
   public class_243 method0397() {
      return this.field0889;
   }
}
