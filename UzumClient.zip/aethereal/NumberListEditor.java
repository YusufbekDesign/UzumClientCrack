package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class NumberListEditor extends GuiElement {
   private static final float field0566 = 165.0F;
   private static final float field0003 = 12.0F;
   private static final float field1410 = 10.0F;
   private static final float field0957 = 3.0F;
   private static final int field0178 = 7;
   private static final float field0458 = 16.0F;
   private static final float field1614 = 5.0F;
   private static final float field1538 = 0.5F;
   private static final float field1704 = 88.0F;
   private static final float field1136 = 22.0F;
   private static final float field1087 = 4.0F;
   private static final float field1196 = 1.5F;
   private static final float field0871 = 144.0F;
   private static FontSize field0834;
   private static FontSize field0917;
   private static FontSize field1339;
   private static FontSize field1300;
   private static FontSize field1375;
   private static FontSize field0392;
   private static FontSize field0358;
   private static boolean field0442 = false;
   private final NumberListSetting field0267;
   private final Supplier<Float> field0240;
   private final Animation field0297;
   private final StringBuilder field0535 = new StringBuilder();
   private float field0501;
   private float field0547;
   private float field1671;
   private float field1657;
   private boolean field1699;
   private FloatSetting field1593;
   private float field1577;
   private float field1601;
   private final Map<FloatSetting, Float> field1760 = new HashMap();

   private static void method2228() {
      if (!field0442) {
         field0834 = Fonts.field0075.method0654(5.5F);
         field0917 = Fonts.field0075.method0654(5.0F);
         field1339 = Fonts.field0075.method0654(5.5F);
         field1300 = Fonts.field0774.method0654(4.0F);
         field1375 = Fonts.field0774.method0654(4.5F);
         field0392 = Fonts.field0075.method0654(5.0F);
         field0358 = Fonts.field0075.method0654(5.0F);
         field0442 = true;
      }

   }

   private static String method2191() {
      try {
         return ClickGuiDashboard.field0984.method0492() == ClickGuiDashboard.Language.field0631 ? "Сбросить" : "Reset";
      } catch (Exception var1) {
         return "Reset";
      }
   }

   public NumberListEditor(NumberListSetting setting, Supplier<Float> animationSupplier) {
      this.field0267 = setting;
      this.field0240 = animationSupplier;
      this.field0297 = new Animation(200L, (double)1.0F, false, EasingCurve.field1011);
   }

   public float method2047() {
      return 165.0F;
   }

   public float method1762() {
      return 144.0F;
   }

   public float method1946() {
      return this.field0297.method0002();
   }

   public boolean method0431() {
      return !this.field0297.method0376() && this.field0297.method0002() < 0.01F;
   }

   public void method1570(boolean opening) {
      this.field0297.method1570(opening);
      this.field0297.method1634();
      if (!opening) {
         this.field1699 = false;
         this.field1593 = null;
      }

   }

   public void method2100(float x, float y) {
      this.field1671 = x;
      this.field1657 = y;
   }

   public float method0355() {
      return this.field1671;
   }

   public float method0483() {
      return this.field1657;
   }

   private List<NumberListSetting.NumberEntry> method2263() {
      String f = this.field0535.toString().toLowerCase(Locale.ROOT);
      List<NumberListSetting.NumberEntry> result = new ArrayList();

      for(NumberListSetting.NumberEntry entry : this.field0267.method1889()) {
         if (entry.method0026()) {
            if (!f.isEmpty()) {
               String name = entry.method0537().method2067().toLowerCase(Locale.ROOT);
               if (!name.contains(f)) {
                  continue;
               }
            }

            result.add(entry);
         }
      }

      return result;
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      method2228();
      this.field0547 = class_3532.method_16439(0.1F, this.field0547, this.field0501);
      float x = this.method0530();
      float y = this.method0002();
      float w = 165.0F;
      ThemeColorManager tm = ThemeColorManager.method1908();
      Color headerIconColor = new Color(tm.method2063().getRed(), tm.method2063().getGreen(), tm.method2063().getBlue(), 255);
      float titleIconW = field1300.method0998("h");
      float titleIconY = y + (10.0F - field1300.method0530()) / 2.0F - 0.5F;
      GuiRenderHelper.method1491(context.method_51448(), field1300, "h", x, titleIconY, headerIconColor);
      String resetText = method2191();
      float resetTextW = field0358.method0998(resetText);
      float resetBtnW = resetTextW + 8.0F;
      float resetBtnH = 12.0F;
      float resetBtnX = x + w - resetBtnW;
      float resetBtnY = y + (10.0F - resetBtnH) / 2.0F;
      Color resetBtnBg = new Color(255, 255, 255, 18);
      Color resetBtnBorder = new Color(255, 255, 255, 28);
      GuiRenderHelper.method1463(context.method_51448(), resetBtnX, resetBtnY, resetBtnW, resetBtnH, 2.5F, resetBtnBg);
      GuiRenderHelper.method1461(context.method_51448(), resetBtnX, resetBtnY, resetBtnW, resetBtnH, 2.5F, 0.5F, 0.5F, resetBtnBorder);
      float resetTextX = resetBtnX + 4.0F;
      float resetTextY = resetBtnY + (resetBtnH - field0358.method0530()) / 2.0F;
      GuiRenderHelper.method1491(context.method_51448(), field0358, resetText, resetTextX, resetTextY, ThemePalette.field1268);
      float titleNameX = x + titleIconW + 2.0F;
      float titleNameMaxW = resetBtnX - 3.0F - titleNameX;
      String clipped = TextTruncator.method0831(field1339, this.field0267.method2067(), titleNameMaxW);
      float titleNameY = y + (10.0F - field1339.method0530()) / 2.0F;
      Color titleNameColor = new Color(-1208551425, true);
      GuiRenderHelper.method1491(context.method_51448(), field1339, clipped, titleNameX, titleNameY, titleNameColor);
      float searchY = y + 10.0F + 3.0F;
      Color searchBg = new Color(255, 255, 255, 15);
      Color searchBorder = this.field1699 ? (Color)ThemePalette.field1514.get() : new Color(255, 255, 255, 20);
      GuiRenderHelper.method1463(context.method_51448(), x, searchY, w, 12.0F, 3.0F, searchBg);
      GuiRenderHelper.method1461(context.method_51448(), x, searchY, w, 12.0F, 3.0F, 0.5F, 0.5F, searchBorder);
      float textInputX = x + 4.0F;
      boolean hasText = this.field0535.length() > 0;
      String displayText = hasText ? this.field0535.toString() : "Search...";
      Color textColor = hasText ? ThemePalette.field1268 : ThemePalette.field0486;
      GuiRenderHelper.method1491(context.method_51448(), field0917, displayText, textInputX, searchY + (12.0F - field0917.method0530()) / 2.0F, textColor);
      if (this.field1699) {
         float cursorX = textInputX + field0917.method0998(this.field0535.toString());
         boolean blink = System.currentTimeMillis() / 500L % 2L == 0L;
         if (blink) {
            GuiRenderHelper.method1463(context.method_51448(), cursorX, searchY + 2.5F, 0.5F, 7.0F, 0.0F, ThemePalette.field0334);
         }
      }

      if (hasText) {
         String clearGlyph = "t";
         float clearW = field1375.method0998(clearGlyph);
         float clearX = x + w - clearW - 4.0F;
         float clearY = searchY + (12.0F - field1375.method0530()) / 2.0F;
         GuiRenderHelper.method1491(context.method_51448(), field1375, clearGlyph, clearX, clearY, ThemePalette.field0334);
      }

      List<NumberListSetting.NumberEntry> shown = this.method2263();
      float contentY = searchY + 12.0F + 3.0F;
      float contentH = 112.0F;
      GuiRenderHelper.method1404(context, x, contentY, w, contentH);
      float drawY = contentY + this.field0547;
      this.method1428(context, shown, x, drawY, w, mouseX, contentY, contentY + contentH);
      GuiRenderHelper.method1400(context);
      float totalHeight = (float)shown.size() * 16.0F;
      this.field0501 = Math.clamp(this.field0501, Math.min(0.0F, contentH - totalHeight), 0.0F);
      if (this.field1593 != null) {
         this.method0611((double)mouseX);
      }

   }

   private void method1428(class_332 context, List<NumberListSetting.NumberEntry> entries, float startX, float startY, float width, int mouseX, float visibleTop, float visibleBottom) {
      int totalRows = entries.size();
      if (totalRows != 0) {
         int firstVisible = Math.max(0, (int)((visibleTop - startY) / 16.0F));
         int lastVisible = Math.min(totalRows - 1, (int)((visibleBottom - startY) / 16.0F));
         if (firstVisible <= lastVisible) {
            Color accent = (Color)ThemePalette.field1514.get();
            Color neutralBg = new Color(255, 255, 255, 8);
            Color rowText = ThemePalette.field1268;
            Color sliderBg = new Color(255, 255, 255, 24);
            Color thumbColor = new Color(255, 255, 255, 230);
            float rowW = width;
            float rowH = 15.5F;

            for(int i = firstVisible; i <= lastVisible; ++i) {
               NumberListSetting.NumberEntry entry = (NumberListSetting.NumberEntry)entries.get(i);
               FloatSetting ns = entry.method0537();
               float rowY = startY + (float)i * 16.0F;
               GuiRenderHelper.method1463(context.method_51448(), startX, rowY, rowW, rowH, 2.0F, neutralBg);
               float sliderEndX = startX + rowW - 5.0F - 22.0F - 2.0F;
               float sliderStartX = sliderEndX - 88.0F;
               float sliderY = rowY + (rowH - 3.0F) / 2.0F;
               float nameX = startX + 5.0F;
               float nameMaxW = sliderStartX - nameX - 4.0F;
               String displayName = ns.method2067();
               String clippedName = TextTruncator.method0831(field0834, displayName, nameMaxW);
               float nameY = rowY + (rowH - field0834.method0530()) / 2.0F;
               GuiRenderHelper.method1491(context.method_51448(), field0834, clippedName, nameX, nameY, rowText);
               float realValue = (Float)ns.method0492();
               float animVal = (Float)this.field1760.getOrDefault(ns, realValue);
               animVal = class_3532.method_16439(0.3F, animVal, realValue);
               this.field1760.put(ns, animVal);
               float ratio = (animVal - ns.method1878()) / (ns.method1928() - ns.method1878());
               ratio = Math.clamp(ratio, 0.0F, 1.0F);
               float fillW = 88.0F * ratio;
               GuiRenderHelper.method0326(context.method_51448(), sliderStartX, sliderY, 88.0F, 3.0F, 0.5F, sliderBg);
               GuiRenderHelper.method0326(context.method_51448(), sliderStartX, sliderY, fillW, 3.0F, 0.5F, accent);
               GuiRenderHelper.method0326(context.method_51448(), sliderStartX + fillW - 2.0F, sliderY - 0.5F, 4.0F, 4.0F, 1.0F, thumbColor);
               int decimals = Math.max(1, (int)Math.ceil(-Math.log10((double)ns.method1697())));
               String valueStr = String.format(Locale.US, "%." + decimals + "f", animVal);
               float valueX = startX + rowW - 5.0F - field0392.method0998(valueStr);
               float valueY = rowY + (rowH - field0392.method0530()) / 2.0F;
               GuiRenderHelper.method1491(context.method_51448(), field0392, valueStr, valueX, valueY, rowText);
            }

         }
      }
   }

   private void method0611(double mouseX) {
      if (this.field1593 != null) {
         float startX = this.field1577;
         float endX = this.field1601;
         if (!(endX <= startX)) {
            float clamped = (float)class_3532.method_15350(mouseX, (double)startX, (double)endX);
            float ratio = (clamped - startX) / (endX - startX);
            float newValue = this.field1593.method1878() + ratio * (this.field1593.method1928() - this.field1593.method1878());
            newValue = (float)Math.round(newValue / this.field1593.method1697()) * this.field1593.method1697();
            newValue = Math.clamp(newValue, this.field1593.method1878(), this.field1593.method1928());
            this.field1593.method0206(newValue);
         }
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      method2228();
      float x = this.method0530();
      float y = this.method0002();
      if (!MathHelper.method0689(x, y, 165.0F, 144.0F, (float)mouseX, (float)mouseY)) {
         return false;
      } else {
         String resetText = method2191();
         float resetTextW = field0358.method0998(resetText);
         float resetBtnW = resetTextW + 8.0F;
         float resetBtnH = 12.0F;
         float resetBtnX = x + 165.0F - resetBtnW;
         float resetBtnY = y + (10.0F - resetBtnH) / 2.0F;
         if (!MathHelper.method0689(resetBtnX, resetBtnY, resetBtnW, resetBtnH, (float)mouseX, (float)mouseY)) {
            float searchY = y + 10.0F + 3.0F;
            if (this.field0535.length() > 0) {
               String clearGlyph = "t";
               float clearW = field1375.method0998(clearGlyph);
               float clearX = x + 165.0F - clearW - 4.0F;
               float clearY = searchY + (12.0F - field1375.method0530()) / 2.0F;
               if (MathHelper.method0689(clearX - 2.0F, clearY - 1.0F, clearW + 4.0F, field1375.method0530() + 2.0F, (float)mouseX, (float)mouseY)) {
                  this.field0535.setLength(0);
                  this.field0501 = 0.0F;
                  this.field1699 = true;
                  return true;
               }
            }

            if (MathHelper.method0689(x, searchY, 165.0F, 12.0F, (float)mouseX, (float)mouseY)) {
               this.field1699 = true;
               return true;
            } else {
               this.field1699 = false;
               float contentY = searchY + 12.0F + 3.0F;
               float contentH = 112.0F;
               if (!(mouseY < (double)contentY) && !(mouseY > (double)(contentY + contentH))) {
                  List<NumberListSetting.NumberEntry> shown = this.method2263();
                  float drawY = contentY + this.field0547;
                  int rowIdx = (int)Math.floor((mouseY - (double)drawY) / (double)16.0F);
                  if (rowIdx >= 0 && rowIdx < shown.size()) {
                     NumberListSetting.NumberEntry entry = (NumberListSetting.NumberEntry)shown.get(rowIdx);
                     FloatSetting ns = entry.method0537();
                     float sliderEndX = x + 165.0F - 5.0F - 22.0F - 2.0F;
                     float sliderStartX = sliderEndX - 88.0F;
                     if (mouseX >= (double)(sliderStartX - 4.0F) && mouseX <= (double)(sliderEndX + 4.0F)) {
                        this.field1593 = ns;
                        this.field1577 = sliderStartX;
                        this.field1601 = sliderEndX;
                        this.method0611(mouseX);
                     }

                     return true;
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            }
         } else {
            for(NumberListSetting.NumberEntry entry : this.field0267.method1889()) {
               FloatSetting ns = entry.method0537();
               ns.method0578();
               ns.method1973();
            }

            return true;
         }
      }
   }

   public boolean method0112(double mouseX, double mouseY, int button) {
      if (this.field1593 != null) {
         this.field1593 = null;
         return true;
      } else {
         return false;
      }
   }

   public boolean method0623(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      float x = this.method0530();
      float y = this.method0002();
      if (!MathHelper.method0689(x, y, 165.0F, 144.0F, (float)mouseX, (float)mouseY)) {
         return false;
      } else {
         float searchY = y + 10.0F + 3.0F;
         float contentY = searchY + 12.0F + 3.0F;
         float contentH = 112.0F;
         if (mouseY >= (double)contentY && mouseY <= (double)(contentY + contentH)) {
            List<NumberListSetting.NumberEntry> shown = this.method2263();
            float drawY = contentY + this.field0547;
            int rowIdx = (int)Math.floor((mouseY - (double)drawY) / (double)16.0F);
            if (rowIdx >= 0 && rowIdx < shown.size()) {
               FloatSetting ns = ((NumberListSetting.NumberEntry)shown.get(rowIdx)).method0537();
               float sliderEndX = x + 165.0F - 5.0F - 22.0F - 2.0F;
               float sliderStartX = sliderEndX - 88.0F;
               if (mouseX >= (double)(sliderStartX - 4.0F) && mouseX <= (double)(sliderEndX + 22.0F + 4.0F)) {
                  float step = ns.method1697() * (float)verticalAmount;
                  float newValue = (Float)ns.method0492() + step;
                  newValue = (float)Math.round(newValue / ns.method1697()) * ns.method1697();
                  newValue = Math.clamp(newValue, ns.method1878(), ns.method1928());
                  ns.method0206(newValue);
                  return true;
               }
            }
         }

         this.field0501 += (float)verticalAmount * 15.0F;
         return true;
      }
   }

   public boolean method0746(int keyCode, int scanCode, int modifiers) {
      if (!this.field1699) {
         return false;
      } else if (keyCode == 259 && this.field0535.length() > 0) {
         this.field0535.deleteCharAt(this.field0535.length() - 1);
         this.field0501 = 0.0F;
         return true;
      } else {
         return false;
      }
   }

   public boolean method0607(char chr, int modifiers) {
      if (!this.field1699) {
         return false;
      } else if (!Character.isLetterOrDigit(chr) && chr != '_' && chr != ':' && chr != ' ' && !method0606(chr)) {
         return false;
      } else {
         this.field0535.append(chr);
         this.field0501 = 0.0F;
         return true;
      }
   }

   private static boolean method0606(char c) {
      return c >= 1024 && c <= 1279 || c >= 1280 && c <= 1327;
   }
}
