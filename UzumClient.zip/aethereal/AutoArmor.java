package aethereal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10192;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5134;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_1304.class_1305;

public class AutoArmor extends Module {
   public AutoArmor() {
      super("AutoArmor", ModuleCategory.field0661, "Automatically equips the best armor from inventory");
      this.method1013("Автоматически надевает лучшую броню из инвентаря");
   }

   @EventHandler
   public void onTick(PreTickEvent e) {
      if (!method1974()) {
         if (!InventorySearch.method0026()) {
            if (InventoryActionScheduler.field0649.method0026()) {
               List<Runnable> actions = new ArrayList();

               for(class_1304 equipment : class_1304.values()) {
                  if (equipment.method_5925() == class_1305.field_6178) {
                     class_1799 equipStack = field0796.field_1724.method_31548().method_7372(equipment.method_5927());
                     if (equipment != class_1304.field_6174 || equipStack.method_7909() != class_1802.field_8833) {
                        int armorSlotId = 8 - equipment.method_5927();
                        class_1735 best = InventorySearch.method1107((s) -> {
                           class_1799 stack = s.method_7677();
                           if (stack.method_7960()) {
                              return false;
                           } else if (s.field_7874 == armorSlotId) {
                              return false;
                           } else if (this.method0269(stack)) {
                              return false;
                           } else {
                              return this.method1241(stack) ? false : this.method1242(stack, equipment);
                           }
                        }, Comparator.comparingDouble((s) -> (double)this.method0270(s.method_7677(), equipment)));
                        if (best != null && this.method1243(best.method_7677(), equipStack, equipment)) {
                           actions.add((Runnable)() -> InventorySearch.method1208(best, armorSlotId));
                        } else if (this.method0269(equipStack)) {
                           if (best != null) {
                              actions.add((Runnable)() -> InventorySearch.method1208(best, armorSlotId));
                              this.method1060("Заменил - ", equipment, equipStack);
                           } else if (InventorySearch.method1230(class_1802.field_8162, (s) -> s.field_7874 >= 9) != null) {
                              actions.add((Runnable)() -> InventorySearch.method0754(armorSlotId, 0, class_1713.field_7794, false));
                              this.method2157(equipStack);
                           }
                        }
                     }
                  }
               }

               if (!actions.isEmpty()) {
                  InventoryActionScheduler.method0991(() -> actions.forEach(Runnable::run));
               }

            }
         }
      }
   }

   private boolean method1242(class_1799 stack, class_1304 target) {
      if (!(stack.method_7909() instanceof class_1738)) {
         return false;
      } else {
         class_10192 equippable = (class_10192)stack.method_57824(class_9334.field_54196);
         return equippable != null && equippable.comp_3174() == target;
      }
   }

   private float method0270(class_1799 stack, class_1304 slot) {
      if (stack.method_7960()) {
         return 0.0F;
      } else {
         class_9285 modifiers = (class_9285)stack.method_57824(class_9334.field_49636);
         float[] armorValue = new float[]{0.0F};
         if (modifiers != null) {
            modifiers.method_57482(slot, (attribute, modifier) -> {
               if (attribute.comp_349() == class_5134.field_23724.comp_349() || attribute.comp_349() == class_5134.field_23725.comp_349()) {
                  armorValue[0] += (float)modifier.comp_2449();
               }

            });
         }

         float protection = armorValue[0] + (float)this.method1244(stack, class_1893.field_9111);
         float unbreaking = (float)this.method1244(stack, class_1893.field_9119);
         float mending = (float)this.method1244(stack, class_1893.field_9101);
         return protection + unbreaking * 0.1F + mending * 0.2F;
      }
   }

   private int method1244(class_1799 stack, class_5321<class_1887> key) {
      if (field0796.field_1687 == null) {
         return 0;
      } else {
         class_2378<class_1887> registry = field0796.field_1687.method_30349().method_30530(class_7924.field_41265);
         class_6880<class_1887> entry = (class_6880)registry.method_10223(key.method_29177()).orElse((Object)null);
         return entry == null ? 0 : class_1890.method_8225(entry, stack);
      }
   }

   private boolean method1241(class_1799 stack) {
      return this.method1244(stack, class_1893.field_9113) > 0;
   }

   private boolean method0269(class_1799 stack) {
      if (!stack.method_7960() && stack.method_7963()) {
         return (double)stack.method_7919() / (double)stack.method_7936() > 0.9799995641474735;
      } else {
         return false;
      }
   }

   private boolean method1243(class_1799 newArmor, class_1799 currentArmor, class_1304 slot) {
      if (currentArmor.method_7960()) {
         return true;
      } else if (this.method1242(newArmor, slot) && this.method1242(currentArmor, slot)) {
         return this.method0270(newArmor, slot) > this.method0270(currentArmor, slot);
      } else {
         return false;
      }
   }

   private String method1150(class_1304 slot) {
      String var10000;
      switch (slot) {
         case field_6166 -> var10000 = "Ботинки";
         case field_6172 -> var10000 = "Поножи";
         case field_6174 -> var10000 = "Нагрудник";
         case field_6169 -> var10000 = "Шлем";
         default -> var10000 = "Броня";
      }

      return var10000;
   }

   private void method1060(String prefix, class_1304 slot, class_1799 replaced) {
      class_5250 text = class_2561.method_43470(prefix + String.valueOf(class_124.field_1060) + this.method1150(slot) + String.valueOf(class_124.field_1070) + " на ").method_10852(replaced.method_7964());
      NewHUD.method1350(text, ModuleCategory.field0661.method0017(), true);
   }

   private void method2157(class_1799 oldStack) {
      class_5250 text = class_2561.method_43470("Засейвил - ").method_10852(oldStack.method_7964());
      NewHUD.method1350(text, ModuleCategory.field0661.method0017(), true);
   }
}
