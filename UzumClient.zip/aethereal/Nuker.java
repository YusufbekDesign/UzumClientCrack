package aethereal;

import java.util.Comparator;
import java.util.Objects;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_638;

public class Nuker extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("nuker.rotate", true)).method1007("Aylanish").method0210("Rotate towards the block being broken").method2130("Sindirilayotgan blokka qarab aylanish");
   private final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("nuker.down", true)).method1007("Pastga").method0210("Also break blocks below you").method2130("Ostidagi bloklarni ham sindirish");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("nuker.radius", 3.0F, 1.0F, 6.0F, 1.0F)).method1007("Radius").method0210("Block breaking radius around the player").method2130("Blok sindirish radiusi");
   private class_2338 field0213;
   private class_265 field0493;

   public Nuker() {
      super("Nuker", ModuleCategory.field1470, "Atrofdagi bloklarni avtomatik sindiradi");
      this.method1013("Atrofdagi bloklarni avtomatik sindiradi");
   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (!method1974()) {
         int var2 = ((Float)this.field0985.method0492()).intValue();
         this.field0213 = (class_2338)BlockAreaScanner.method1268(field0796.field_1724.method_24515(), var2, var2, (Boolean)this.field1432.method0492()).stream().filter(this::method0279).min(Comparator.comparingDouble(this::method1256)).orElse((Object)null);
         if (this.field0213 == null) {
            this.field0493 = null;
         } else {
            this.field0493 = field0796.field_1687.method_8320(this.field0213).method_26218(field0796.field_1687, this.field0213);
            field0796.field_1761.method_2902(this.field0213, class_2350.field_11036);
            field0796.field_1724.method_6104(class_1268.field_5808);
         }
      }

   }

   @EventHandler
   public void onRender(WorldRenderEvent.WorldPass var1) {
      if (!method1974() && this.field0213 != null && this.field0493 != null && !this.field0493.method_1110()) {
         WorldRenderHelper.method0334(new class_4587(), this.field0493.method_1107().method_996(this.field0213), BlockHighlightColor.method0553(), BlockHighlightColor.method0553());
      }

   }

   private double method1256(class_2338 var1) {
      double var10000;
      switch (field0796.field_1687.method_8320(var1).method_26204().method_63499().replace("block.minecraft.", "")) {
         case "ancient_debris" -> var10000 = (double)0.0F;
         case "diamond_ore" -> var10000 = (double)1.0F;
         case "emerald_ore" -> var10000 = (double)2.0F;
         case "gold_ore" -> var10000 = (double)3.0F;
         case "iron_ore" -> var10000 = (double)4.0F;
         case "lapis_ore" -> var10000 = (double)5.0F;
         case "redstone_ore" -> var10000 = (double)6.0F;
         default -> var10000 = field0796.field_1724.method_5707(var1.method_46558());
      }

      return var10000;
   }

   private boolean method0279(class_2338 var1) {
      class_2680 var2 = ((class_638)Objects.requireNonNull(field0796.field_1687)).method_8320(var1);
      return !var2.method_26215() && var2.method_26204() != class_2246.field_10382 && var2.method_26204() != class_2246.field_10164 && var2.method_26204() != class_2246.field_9987 && var2.method_26204() != class_2246.field_10499;
   }
}
