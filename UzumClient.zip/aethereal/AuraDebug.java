package aethereal;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2661;
import net.minecraft.class_2663;
import net.minecraft.class_2743;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_4587;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7439;
import net.minecraft.class_8043;
import net.minecraft.class_8143;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_2848.class_2849;

public class AuraDebug extends Module {
   private static final Color field0134 = new Color(12, 12, 18, 220);
   private static final Color field1500 = new Color(160, 160, 180);
   private static final Color field1026 = new Color(235, 235, 240);
   private static final Color field0207 = new Color(120, 220, 130);
   private static final Color field0486 = new Color(220, 110, 110);
   private static final Color field1641 = new Color(230, 200, 90);
   private static final Color field1564 = new Color(220, 120, 220);
   private static final Color field1726 = new Color(120, 200, 230);
   private static final Color field1153 = new Color(255, 255, 255);
   private static final String[] field1111 = new String[]{"античит", "anticheat", "бан", "забанен", "ban", "кик", "kick", "мут", "mute", "подозрит", "suspect", "читы", "cheat", "флаг", "flag", "детект", "detect", "blocked", "заблок"};
   private final BooleanSetting field1201 = new BooleanSetting("HUD", true);
   private final BooleanSetting field0875 = new BooleanSetting("Log File", true);
   private final BooleanSetting field0830 = new BooleanSetting("Aura Only", true);
   private final BooleanSetting field0914 = new BooleanSetting("Capture Chat", true);
   private final BooleanSetting field1335 = new BooleanSetting("Rotation Trail", true);
   private final BooleanSetting field1296 = new BooleanSetting("Packet Trail", true);
   private final BooleanSetting field1372 = new BooleanSetting("Damage Timeline", true);
   private final BooleanSetting field0389 = new BooleanSetting("Tick Snapshots", false);
   private final FloatSetting field0360 = new FloatSetting("Miss Timeout (ms)", 500.0F, 100.0F, 2000.0F, 50.0F);
   private final FloatSetting field0430 = new FloatSetting("Snap Threshold", 30.0F, 5.0F, 90.0F, 1.0F);
   private final FloatSetting field0262 = new FloatSetting("HUD Events", 6.0F, 3.0F, 15.0F, 1.0F);
   private final FloatSetting field0234 = new FloatSetting("Trail Ticks", 20.0F, 5.0F, 60.0F, 1.0F);
   private final FloatSetting field0295 = new FloatSetting("Damage Trace Ticks", 20.0F, 5.0F, 60.0F, 1.0F);
   private final FloatSetting field0529 = new FloatSetting("Packet History", 20.0F, 5.0F, 50.0F, 1.0F);
   private final FloatSetting field0506 = new FloatSetting("Tick Snapshot Interval", 10.0F, 1.0F, 40.0F, 1.0F);
   private final FloatSetting field0552 = new FloatSetting("Cut Ratio", 0.7F, 0.3F, 0.95F, 0.05F);
   private final Deque<DebugText> field1682 = new ArrayDeque();
   private final Deque<DebugLine> field1664 = new ArrayDeque();
   private final Deque<DebugLine> field1697 = new ArrayDeque();
   private final List<DebugBox> field1595 = new ArrayList();
   private final Deque<DebugBox> field1584 = new ArrayDeque();
   private final Deque<Long> field1607 = new ArrayDeque();
   private final Deque<Long> field1759 = new ArrayDeque();
   private final Deque<Long> field1745 = new ArrayDeque();
   private final Deque<Long> field1771 = new ArrayDeque();
   private final Deque<Long> field1179 = new ArrayDeque();
   private BufferedWriter field1169;
   private Path field1190;
   private long field1120;
   private long field1113;
   private long field1130;
   private long field1228 = -1L;
   private long field1220 = -1L;

   public static AuraDebug method1702() {
      ArbuzClient arbuz = ArbuzClient.method2004();
      return arbuz != null && arbuz.method1783() != null ? (AuraDebug)arbuz.method1783().method0976(AuraDebug.class) : null;
   }

   public AuraDebug() {
      super("AuraDebug", ModuleCategory.field1004, "Forensic Aura logger v2: hit outcomes, packet trails, damage timelines");
      this.method1013("Forensic Aura v2: исход хитов, трейлы пакетов, таймлайны урона");
   }

   public void method0025() {
      super.method0025();
      this.field1120 = System.currentTimeMillis();
      this.field1113 = 0L;
      this.field1130 = 0L;
      this.field1228 = -1L;
      this.field1220 = -1L;
      this.field1682.clear();
      this.field1664.clear();
      this.field1697.clear();
      this.field1595.clear();
      this.field1584.clear();
      this.field1607.clear();
      this.field1759.clear();
      this.field1745.clear();
      this.field1771.clear();
      this.field1179.clear();
      this.method1691();
   }

   public void method2078() {
      this.method1754();
      super.method2078();
   }

   private void method1691() {
      if (this.field0875.method1938()) {
         try {
            Path baseDir = field0796.field_1697.toPath().resolve("arbuzhack").resolve("debug");
            Files.createDirectories(baseDir);
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            this.field1190 = baseDir.resolve("aura-" + ts + ".jsonl");
            this.field1169 = Files.newBufferedWriter(this.field1190, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            JsonObject header = new JsonObject();
            header.addProperty("type", "session_start");
            header.addProperty("ts", this.field1120);
            header.addProperty("user", field0796.field_1724 != null ? field0796.field_1724.method_5477().getString() : "unknown");
            header.addProperty("server", field0796.method_1558() != null ? field0796.method_1558().field_3761 : "singleplayer");
            header.addProperty("schemaVersion", 2);
            this.method0943(header);
         } catch (IOException var4) {
            this.field1169 = null;
         }

      }
   }

   private void method1754() {
      if (this.field1169 != null) {
         try {
            for(DebugBox r : this.field1595) {
               if (r.field0287.equals("PENDING")) {
                  r.field0287 = "DISABLED";
               }

               this.method0943(this.method1833(r));
            }

            JsonObject footer = new JsonObject();
            footer.addProperty("type", "session_end");
            footer.addProperty("ts", System.currentTimeMillis());
            footer.addProperty("totalAttacks", this.field1113);
            this.method0943(footer);
            this.field1169.flush();
            this.field1169.close();
         } catch (IOException var3) {
         }

         this.field1169 = null;
         this.field1595.clear();
      }
   }

   private void method0943(JsonObject obj) {
      if (this.field1169 != null) {
         try {
            this.field1169.write(obj.toString());
            this.field1169.newLine();
            this.field1169.flush();
         } catch (IOException var3) {
         }

      }
   }

   private boolean method2030() {
      if (field0796.field_1724 != null && field0796.field_1687 != null) {
         if (!this.field0830.method1938()) {
            return true;
         } else {
            Aura aura = Aura.method1701();
            return aura != null && aura.method2195();
         }
      } else {
         return false;
      }
   }

   @EventHandler
   public void onTick(PlayerTickEvent e) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null) {
         ++this.field1130;
         if (this.method2030()) {
            this.method2015();
         }

         this.method0457();
         this.method0405();
         this.method0471();
         if (this.field0389.method1938() && this.method2030() && (Float)this.field0506.method0492() > 0.0F && this.field1130 % ((Float)this.field0506.method0492()).longValue() == 0L) {
            this.method2043();
         }

      }
   }

   private void method2015() {
      DebugText snap = new DebugText();
      snap.field0568 = System.currentTimeMillis();
      snap.field0005 = this.field1130;
      Rotation cam = RotationHelper.method0545();
      Rotation cur = RotationManager.field0618.method0545();
      Rotation srv = RotationManager.field0618.method2258();
      snap.field1410 = cam.method2047();
      snap.field0957 = cam.method1762();
      snap.field0758 = cur.method2047();
      snap.field1242 = cur.method1762();
      snap.field0314 = srv.method2047();
      snap.field0177 = srv.method1762();
      snap.field0497 = field0796.field_1724.method_24828();
      snap.field1614 = field0796.field_1724.field_6017;
      snap.field1574 = field0796.field_1724.method_5624();
      snap.field1735 = field0796.field_1724.method_6115();
      snap.field1161 = field0796.field_1724.method_5715();
      class_243 v = field0796.field_1724.method_18798();
      snap.field1086 = v.field_1352;
      snap.field1195 = v.field_1351;
      snap.field0870 = v.field_1350;
      snap.field0826 = field0796.field_1724.field_6251;
      snap.field0931 = field0796.field_1724.field_6252;
      this.field1682.addLast(snap);
   }

   private void method2043() {
      JsonObject o = new JsonObject();
      o.addProperty("type", "tick_state");
      o.addProperty("ts", System.currentTimeMillis());
      o.addProperty("absTick", this.field1130);
      o.addProperty("gameTime", field0796.field_1687.method_8510());
      Rotation cam = RotationHelper.method0545();
      Rotation cur = RotationManager.field0618.method0545();
      Rotation srv = RotationManager.field0618.method2258();
      o.addProperty("cameraYaw", cam.method2047());
      o.addProperty("cameraPitch", cam.method1762());
      o.addProperty("currentYaw", cur.method2047());
      o.addProperty("currentPitch", cur.method1762());
      o.addProperty("serverYaw", srv.method2047());
      o.addProperty("serverPitch", srv.method1762());
      class_243 v = field0796.field_1724.method_18798();
      o.addProperty("velX", v.field_1352);
      o.addProperty("velY", v.field_1351);
      o.addProperty("velZ", v.field_1350);
      o.addProperty("sprinting", field0796.field_1724.method_5624());
      o.addProperty("sneaking", field0796.field_1724.method_5715());
      o.addProperty("onGround", field0796.field_1724.method_24828());
      o.addProperty("fallDistance", field0796.field_1724.field_6017);
      o.addProperty("usingItem", field0796.field_1724.method_6115());
      o.addProperty("handSwinging", field0796.field_1724.field_6252);
      o.addProperty("swingProgress", field0796.field_1724.field_6251);
      o.addProperty("hotbarSlot", field0796.field_1724.method_31548().field_7545);
      this.method0943(o);
   }

   private void method0471() {
      int max = Math.max(((Float)this.field0234.method0492()).intValue() * 3, 80);

      while(this.field1682.size() > max) {
         this.field1682.removeFirst();
      }

      int pktMax = ((Float)this.field0529.method0492()).intValue();

      while(this.field1664.size() > pktMax) {
         this.field1664.removeFirst();
      }

      while(this.field1697.size() > pktMax) {
         this.field1697.removeFirst();
      }

      long cutoff = System.currentTimeMillis() - 1000L;
      method1070(this.field1607, cutoff);
      method1070(this.field1759, cutoff);
      method1070(this.field1745, cutoff);
      method1070(this.field1771, cutoff);
      method1070(this.field1179, cutoff);
   }

   private static void method1070(Deque<Long> q, long cutoff) {
      while(!q.isEmpty() && (Long)q.peekFirst() < cutoff) {
         q.removeFirst();
      }

   }

   @EventHandler
   public void onPacketSend(PacketEvent.Outbound e) {
      if (this.method2195() && field0796.field_1724 != null) {
         class_2596<?> p = e.method1970();
         long now = System.currentTimeMillis();
         DebugLine pe = new DebugLine();
         pe.field0568 = now;
         pe.field0005 = this.field1130;
         pe.field1527 = true;
         pe.field1030 = p.getClass().getSimpleName();
         pe.field0791 = this.method1353(p);
         this.field1664.addLast(pe);
         if (p instanceof class_2879) {
            this.field1759.addLast(now);
         } else {
            label44: {
               if (p instanceof class_2828) {
                  class_2828 move = (class_2828)p;
                  if (move.method_36172()) {
                     this.field1771.addLast(now);
                     break label44;
                  }
               }

               if (p instanceof class_2848) {
                  class_2848 cc = (class_2848)p;
                  class_2848.class_2849 m = cc.method_12365();
                  if (m == class_2849.field_12981 || m == class_2849.field_12985) {
                     this.field1745.addLast(now);
                  }
               } else if (p instanceof class_2868) {
                  this.field1179.addLast(now);
               }
            }
         }

         if (p instanceof class_2824) {
            class_2824 pkt = (class_2824)p;
            if (method1376(pkt)) {
               this.field1607.addLast(now);
               if (this.method2030()) {
                  Aura aura = Aura.method1701();
                  class_1309 target = aura != null ? aura.method0409() : null;
                  if (target != null) {
                     this.method1166(target, now);
                  }
               }
            }
         }

      }
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Inbound e) {
      if (this.method2195()) {
         class_2596<?> p = e.method1970();
         long now = System.currentTimeMillis();
         DebugLine pe = new DebugLine();
         pe.field0568 = now;
         pe.field0005 = this.field1130;
         pe.field1527 = false;
         pe.field1030 = p.getClass().getSimpleName();
         pe.field0791 = this.method0299(p);
         this.field1697.addLast(pe);
         if (p instanceof class_8143) {
            class_8143 dmg = (class_8143)p;
            this.method1546(dmg, now);
         } else if (p instanceof class_8043) {
            class_8043 tilt = (class_8043)p;
            this.method1545(tilt, now);
         } else if (p instanceof class_2743) {
            class_2743 vel = (class_2743)p;
            this.method1370(vel, now);
         } else if (p instanceof class_2663) {
            class_2663 st = (class_2663)p;
            this.method1359(st, now);
         } else if (p instanceof class_7439) {
            class_7439 gm = (class_7439)p;
            if (!this.field0914.method1938()) {
               return;
            }

            String msg = gm.comp_763().getString();
            String lower = msg.toLowerCase();

            for(String kw : field1111) {
               if (lower.contains(kw)) {
                  this.method2134(msg);
                  return;
               }
            }
         } else if (p instanceof class_2661) {
            class_2661 dc = (class_2661)p;
            String reason = dc.comp_2325() != null ? dc.comp_2325().getString() : "unknown";
            this.method1846(reason);
         }

      }
   }

   private void method1546(class_8143 pkt, long now) {
      int eid = pkt.comp_1267();
      boolean fromUs = field0796.field_1724 != null && (pkt.comp_1269() == field0796.field_1724.method_5628() || pkt.comp_1270() == field0796.field_1724.method_5628());
      String typeId = null;

      try {
         typeId = pkt.comp_1268().method_55840();
      } catch (Throwable var11) {
      }

      for(DebugBox r : this.field1595) {
         if (r.field0759 == eid) {
            DebugFrame ev = new DebugFrame();
            ev.field0715 = "damage";
            ev.field0005 = now;
            ev.field1411 = (int)(this.field1130 - r.field1412);
            JsonObject d = new JsonObject();
            d.addProperty("sourceCauseId", pkt.comp_1269());
            d.addProperty("sourceDirectId", pkt.comp_1270());
            if (typeId != null) {
               d.addProperty("damageType", typeId);
            }

            pkt.comp_1271().ifPresent((v) -> {
               d.addProperty("sourceX", v.field_1352);
               d.addProperty("sourceY", v.field_1351);
               d.addProperty("sourceZ", v.field_1350);
            });
            d.addProperty("attackerIsUs", fromUs);
            ev.field1025 = d;
            r.field0276.add(ev);
            if (fromUs && !r.field1367) {
               r.field1367 = true;
               r.field1322 = typeId;
            }
         }
      }

   }

   private void method1545(class_8043 pkt, long now) {
      int eid = pkt.comp_1202();

      for(DebugBox r : this.field1595) {
         if (r.field0759 == eid) {
            DebugFrame ev = new DebugFrame();
            ev.field0715 = "tilt";
            ev.field0005 = now;
            ev.field1411 = (int)(this.field1130 - r.field1412);
            JsonObject d = new JsonObject();
            d.addProperty("tiltYaw", pkt.comp_1203());
            d.addProperty("idealYaw", r.field0423);
            d.addProperty("serverYaw", r.field0385);
            ev.field1025 = d;
            r.field0276.add(ev);
         }
      }

   }

   private void method1370(class_2743 pkt, long now) {
      int eid = pkt.method_11818();

      for(DebugBox r : this.field1595) {
         if (r.field0759 == eid) {
            DebugFrame ev = new DebugFrame();
            ev.field0715 = "knockback";
            ev.field0005 = now;
            ev.field1411 = (int)(this.field1130 - r.field1412);
            JsonObject d = new JsonObject();
            d.addProperty("vx", pkt.method_11815());
            d.addProperty("vy", pkt.method_11816());
            d.addProperty("vz", pkt.method_11819());
            d.addProperty("magnitude", Math.sqrt(pkt.method_11815() * pkt.method_11815() + pkt.method_11816() * pkt.method_11816() + pkt.method_11819() * pkt.method_11819()));
            ev.field1025 = d;
            r.field0276.add(ev);
         }
      }

   }

   private void method1359(class_2663 pkt, long now) {
      if (field0796.field_1687 != null) {
         class_1297 ent;
         try {
            ent = pkt.method_11469(field0796.field_1687);
         } catch (Throwable var11) {
            return;
         }

         if (ent != null) {
            int eid = ent.method_5628();
            byte st = pkt.method_11470();

            for(DebugBox r : this.field1595) {
               if (r.field0759 == eid) {
                  DebugFrame ev = new DebugFrame();
                  ev.field0715 = "status";
                  ev.field0005 = now;
                  ev.field1411 = (int)(this.field1130 - r.field1412);
                  JsonObject d = new JsonObject();
                  d.addProperty("status", st);
                  ev.field1025 = d;
                  r.field0276.add(ev);
               }
            }

         }
      }
   }

   private String method1353(class_2596<?> p) {
      try {
         if (p instanceof class_2828 m) {
            return String.format("look=%s pos=%s yaw=%.2f pitch=%.2f og=%b", m.method_36172(), m.method_36171(), m.method_12271(0.0F), m.method_12270(0.0F), m.method_12273());
         }

         if (p instanceof class_2824 pkt) {
            return method1376(pkt) ? "ATTACK" : "interact";
         }

         if (p instanceof class_2879 sw) {
            return "hand=" + sw.method_12512().name();
         }

         if (p instanceof class_2848 cc) {
            return "mode=" + cc.method_12365().name();
         }

         if (p instanceof class_2868 sl) {
            return "slot=" + sl.method_12442();
         }
      } catch (Throwable var3) {
      }

      return "";
   }

   private String method0299(class_2596<?> p) {
      try {
         if (p instanceof class_8143 d) {
            return "eid=" + d.comp_1267();
         }

         if (p instanceof class_8043 t) {
            return String.format("eid=%d yaw=%.2f", t.comp_1202(), t.comp_1203());
         }

         if (p instanceof class_2743 v) {
            return String.format("eid=%d v=%.2f,%.2f,%.2f", v.method_11818(), v.method_11815(), v.method_11816(), v.method_11819());
         }

         if (p instanceof class_2663 st) {
            return "status=" + st.method_11470();
         }

         if (p instanceof class_7439 gm) {
            String s = gm.comp_763().getString();
            return s.length() > 60 ? s.substring(0, 60) : s;
         }
      } catch (Throwable var4) {
      }

      return "";
   }

   private void method2134(String msg) {
      for(DebugBox r : this.field1595) {
         if (r.field0306 == null) {
            r.field0306 = new ArrayList();
         }

         r.field0306.add(msg);
      }

      DebugBox last = (DebugBox)this.field1584.peekLast();
      if (last != null && last.field0311 == null) {
         last.field0311 = method1024(msg, 40);
      }

      if (this.field0875.method1938()) {
         JsonObject obj = new JsonObject();
         obj.addProperty("type", "chat_flag");
         obj.addProperty("ts", System.currentTimeMillis());
         obj.addProperty("absTick", this.field1130);
         obj.addProperty("msg", msg);
         this.method0943(obj);
      }

      DebugBox ghost = new DebugBox();
      ghost.field0568 = ++this.field1113;
      ghost.field0005 = System.currentTimeMillis();
      ghost.field0287 = "CHAT_FLAG";
      ghost.field1269 = "—";
      ghost.field0311 = method1024(msg, 40);
      this.method2110(ghost);
   }

   private void method1846(String reason) {
      if (this.field0875.method1938()) {
         JsonObject obj = new JsonObject();
         obj.addProperty("type", "disconnect");
         obj.addProperty("ts", System.currentTimeMillis());
         obj.addProperty("absTick", this.field1130);
         obj.addProperty("reason", reason);
         this.method0943(obj);

         for(DebugBox r : this.field1595) {
            r.field0287 = "DISCONNECT";
            r.field0244 = System.currentTimeMillis() - r.field0005;
            this.method0943(this.method1833(r));
         }
      }

      this.field1595.clear();
      DebugBox ghost = new DebugBox();
      ghost.field0568 = ++this.field1113;
      ghost.field0005 = System.currentTimeMillis();
      ghost.field0287 = "DISCONNECT";
      ghost.field1269 = "—";
      ghost.field0311 = method1024(reason, 40);
      this.method2110(ghost);

      try {
         if (this.field1169 != null) {
            this.field1169.flush();
         }
      } catch (IOException var5) {
      }

   }

   private void method1166(class_1309 target, long now) {
      DebugBox rec = new DebugBox();
      rec.field0568 = ++this.field1113;
      rec.field0005 = now;
      rec.field1412 = this.field1130;
      rec.field0959 = field0796.field_1687.method_8510();
      rec.field0759 = target.method_5628();
      rec.field1269 = target.method_5477().getString();
      class_243 tp = target.method_19538();
      rec.field0313 = tp.field_1352;
      rec.field0176 = tp.field_1351;
      rec.field0457 = tp.field_1350;
      class_243 tv = target.method_18798();
      rec.field1613 = tv.field_1352;
      rec.field1537 = tv.field_1351;
      rec.field1703 = tv.field_1350;
      rec.field1135 = (double)field0796.field_1724.method_5739(target);
      rec.field1087 = target.method_6032();
      rec.field1196 = target.method_6067();
      rec.field0872 = target.field_6235;
      rec.field0826 = target.field_6283;
      Rotation cam = RotationHelper.method0545();
      Rotation cur = RotationManager.field0618.method0545();
      Rotation srv = RotationManager.field0618.method2258();
      Rotation ideal = RotationHelper.method1296(target.method_33571().method_1020(field0796.field_1724.method_33571()));
      rec.field0910 = cam.method2047();
      rec.field1331 = cam.method1762();
      rec.field1292 = cur.method2047();
      rec.field1369 = cur.method1762();
      rec.field0385 = srv.method2047();
      rec.field0351 = srv.method1762();
      rec.field0423 = ideal.method2047();
      rec.field0255 = ideal.method1762();
      Rotation delta = RotationHelper.method0872(srv, ideal);
      rec.field0226 = delta.method2047();
      rec.field0289 = delta.method1762();
      if (!this.field1682.isEmpty()) {
         DebugText prev = (DebugText)this.field1682.peekLast();
         float dy = RotationHelper.method0667(srv.method2047(), prev.field0314);
         float dp = srv.method1762() - prev.field0177;
         rec.field0523 = dy;
         rec.field0501 = dp;
         float threshold = (Float)this.field0430.method0492();
         rec.field0558 = Math.abs(dy) > threshold || Math.abs(dp) > threshold * 0.6F;
      }

      rec.field1683 = field0796.field_1724.method_24828();
      rec.field1665 = field0796.field_1724.method_5624();
      rec.field1699 = field0796.field_1724.method_5715();
      rec.field1597 = field0796.field_1724.field_6017 > 0.0F;
      rec.field1601 = field0796.field_1724.field_6017;
      rec.field1586 = field0796.field_1724.method_6115();
      rec.field0899 = field0796.field_1724.method_7261(0.5F);
      rec.field1754 = field0796.field_1724.field_6235;
      rec.field1749 = field0796.field_1724.field_6252;
      rec.field1766 = field0796.field_1724.field_6251;
      rec.field1175 = field0796.field_1724.method_31548().field_7545;
      class_243 v = field0796.field_1724.method_18798();
      rec.field1163 = v.field_1352;
      rec.field1185 = v.field_1351;
      rec.field1118 = v.field_1350;

      try {
         rec.field1112 = field0796.field_1724.field_3913 != null ? field0796.field_1724.field_3913.field_3905 : 0.0F;
         rec.field1129 = field0796.field_1724.field_3913 != null ? field0796.field_1724.field_3913.field_3907 : 0.0F;
         rec.field1233 = field0796.field_1690.field_1903.method_1434();
         rec.field1225 = field0796.field_1690.field_1867.method_1434();
         rec.field1239 = field0796.field_1690.field_1832.method_1434();
      } catch (Throwable var21) {
      }

      class_1799 hand = field0796.field_1724.method_6047();
      rec.field0906 = hand.method_7909().toString();
      rec.field0897 = this.method0480();
      rec.field0863 = this.method0793(rec);
      rec.field1391 = this.field1220 > 0L ? now - this.field1220 : -1L;
      rec.field1404 = this.field1228 >= 0L ? this.field1130 - this.field1228 : -1L;
      this.field1220 = now;
      this.field1228 = this.field1130;
      long cutoff = now - 1000L;
      method1070(this.field1607, cutoff);
      method1070(this.field1759, cutoff);
      method1070(this.field1745, cutoff);
      method1070(this.field1771, cutoff);
      method1070(this.field1179, cutoff);
      rec.field0413 = this.field1607.size();
      rec.field0408 = this.field1759.size();
      rec.field0419 = this.field1745.size();
      rec.field0375 = this.field1771.size();
      rec.field0371 = this.field1179.size();

      try {
         Aura aura = Aura.method1701();
         if (aura != null) {
            rec.field0859 = String.valueOf(aura.method0524().method0492());
            if (aura.method0464() != null) {
               rec.field0851 = aura.method0464().method2067();
            }
         }
      } catch (Throwable var20) {
      }

      int trailN = ((Float)this.field0234.method0492()).intValue();
      Iterator<DebugText> it = this.field1682.descendingIterator();
      rec.field0381 = new ArrayList();

      for(int i = 0; it.hasNext() && i < trailN; ++i) {
         DebugText s = (DebugText)it.next();
         rec.field0381.add(0, new float[]{s.field0758, s.field1242, s.field0314, s.field0177, s.field1410, s.field0957, (float)(s.field0568 - rec.field0005), (float)s.field1086, (float)s.field1195, (float)s.field0870, s.field0826, s.field0931 ? 1.0F : 0.0F, s.field1574 ? 1.0F : 0.0F, s.field0497 ? 1.0F : 0.0F, s.field1161 ? 1.0F : 0.0F});
      }

      if (this.field1296.method1938()) {
         rec.field0451 = new ArrayList(this.field1664);
         rec.field0446 = new ArrayList(this.field1697);
      }

      if (this.field1372.method1938()) {
         rec.field0455 = new ArrayList();
         this.method0794(rec, target, 0);
         rec.field0280 = this.field1130 + ((Float)this.field0295.method0492()).longValue();
      }

      rec.field0276 = new ArrayList();
      rec.field0287 = "PENDING";
      this.field1595.add(rec);
   }

   private void method0457() {
      if (this.field1372.method1938()) {
         for(DebugBox r : this.field1595) {
            if (this.field1130 <= r.field0280 && field0796.field_1687 != null) {
               class_1297 raw = field0796.field_1687.method_8469(r.field0759);
               if (raw instanceof class_1309) {
                  class_1309 le = (class_1309)raw;
                  this.method0794(r, le, (int)(this.field1130 - r.field1412));
               }
            }
         }

      }
   }

   private void method0794(DebugBox r, class_1309 le, int tickOff) {
      class_243 v = le.method_18798();
      r.field0455.add(new float[]{(float)tickOff, le.method_6032(), le.method_6067(), (float)le.field_6235, (float)v.field_1352, (float)v.field_1351, (float)v.field_1350, le.field_6283, le.method_36454(), le.method_36455()});
   }

   private boolean method0480() {
      try {
         return field0796.field_1724.method_7261(0.5F) > 0.9F && field0796.field_1724.field_6017 > 0.0F && !field0796.field_1724.method_24828() && !field0796.field_1724.method_6101() && !field0796.field_1724.method_5799() && !field0796.field_1724.method_6059(class_1294.field_5919) && !field0796.field_1724.method_5765() && !field0796.field_1724.method_5624();
      } catch (Throwable var2) {
         return false;
      }
   }

   private float method0793(DebugBox rec) {
      try {
         float playerBase = (float)field0796.field_1724.method_45325(class_5134.field_23721);
         class_1799 stack = field0796.field_1724.method_6047();
         float weaponBonus = this.method1238(stack);
         int sharpLevel = this.method0268(stack);
         float sharpBonus = sharpLevel > 0 ? 0.5F * (float)sharpLevel + 0.5F : 0.0F;
         float baseTotal = playerBase + weaponBonus;
         float cd = rec.field0899;
         float scaled = baseTotal * (0.2F + cd * cd * 0.8F);
         if (rec.field0897) {
            scaled *= 1.5F;
         }

         float enchantScaled = sharpBonus * cd;
         rec.field0941 = playerBase;
         rec.field0933 = weaponBonus;
         rec.field0949 = sharpLevel;
         rec.field1356 = enchantScaled;
         rec.field1351 = rec.field0897 ? 1.5F : 1.0F;
         return scaled + enchantScaled;
      } catch (Throwable var11) {
         return 0.0F;
      }
   }

   private float method1238(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         class_9285 comp = (class_9285)stack.method_57824(class_9334.field_49636);
         if (comp == null) {
            return 0.0F;
         } else {
            float[] total = new float[]{0.0F};

            try {
               comp.method_57482(class_1304.field_6173, (attribute, modifier) -> {
                  if (attribute.comp_349() == class_5134.field_23721.comp_349()) {
                     total[0] += (float)modifier.comp_2449();
                  }

               });
            } catch (Throwable var5) {
            }

            return total[0];
         }
      } else {
         return 0.0F;
      }
   }

   private int method0268(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         try {
            class_9304 ench = class_1890.method_57532(stack);

            for(class_6880<class_1887> e : ench.method_57534()) {
               if ("minecraft:sharpness".equals(e.method_55840())) {
                  return ench.method_57536(e);
               }
            }
         } catch (Throwable var5) {
         }

         return 0;
      } else {
         return 0;
      }
   }

   private void method0405() {
      long now = System.currentTimeMillis();
      long timeout = ((Float)this.field0360.method0492()).longValue();
      float cut = (Float)this.field0552.method0492();
      Iterator<DebugBox> it = this.field1595.iterator();

      while(it.hasNext()) {
         DebugBox r = (DebugBox)it.next();
         class_1297 raw = field0796.field_1687.method_8469(r.field0759);
         class_1309 var10000;
         if (raw instanceof class_1309 le) {
            var10000 = le;
         } else {
            var10000 = null;
         }

         class_1309 target = var10000;
         if (target != null) {
            int currentHurt = target.field_6235;
            if (!r.field1328 && currentHurt >= 10 && r.field1315 < 10) {
               r.field1328 = true;
               r.field1397 = this.field1130;
            }

            r.field1315 = currentHurt;
            if (r.field1328 && this.field1130 >= r.field1397 + 1L && r.field0287.equals("PENDING")) {
               float total = target.method_6032() + target.method_6067();
               float before = r.field1087 + r.field1196;
               float taken = before - total;
               r.field0244 = now - r.field0005;
               r.field0252 = (int)(this.field1130 - r.field1412);
               if (taken < -0.5F) {
                  r.field0246 = 0.0F;
                  r.field0287 = r.field1367 ? "HIT_HEALED" : "HEALED";
               } else if (taken <= 0.05F) {
                  r.field0246 = 0.0F;
                  r.field0287 = r.field1367 ? "CUT" : "CANCELLED";
               } else {
                  r.field0246 = taken;
                  boolean confirmed = r.field1367;
                  if (r.field0863 > 0.0F && taken < r.field0863 * cut) {
                     r.field0287 = confirmed ? "CUT" : "CUT_UNCONFIRMED";
                  } else {
                     r.field0287 = confirmed ? "HIT" : "HIT_UNCONFIRMED";
                  }
               }

               if (this.field1372.method1938() && this.field1130 <= r.field0280) {
                  r.field0280 = this.field1130 + Math.min(8L, ((Float)this.field0295.method0492()).longValue());
               } else {
                  this.method0165(r);
                  it.remove();
               }
               continue;
            }
         } else {
            r.field0309 = true;
         }

         if ((!this.field1372.method1938() || this.field1130 > r.field0280 || now - r.field0005 > timeout * 2L) && now - r.field0005 > timeout) {
            if (r.field0287.equals("PENDING")) {
               r.field0287 = r.field0309 ? "TARGET_GONE" : "CANCELLED";
               r.field0244 = now - r.field0005;
               r.field0252 = (int)(this.field1130 - r.field1412);
            }

            if (!this.field1372.method1938() || this.field1130 > r.field0280) {
               this.method0165(r);
               it.remove();
            }
         }
      }

   }

   private void method0165(DebugBox r) {
      this.method2110(r);
      if (this.field0875.method1938()) {
         this.method0943(this.method1833(r));
      }

   }

   private void method2110(DebugBox r) {
      this.field1584.addLast(r);
      int max = ((Float)this.field0262.method0492()).intValue();

      while(this.field1584.size() > max) {
         this.field1584.removeFirst();
      }

   }

   private JsonObject method1833(DebugBox r) {
      JsonObject o = new JsonObject();
      o.addProperty("type", "attack");
      o.addProperty("seq", r.field0568);
      o.addProperty("sendMs", r.field0005);
      o.addProperty("sendTickAbs", r.field1412);
      o.addProperty("gameTime", r.field0959);
      o.addProperty("outcome", r.field0287);
      o.addProperty("latencyMs", r.field0244);
      o.addProperty("latencyTicks", r.field0252);
      o.addProperty("msSinceLastAttack", r.field1391);
      o.addProperty("ticksSinceLastAttack", r.field1404);
      o.addProperty("attacksLastSec", r.field0413);
      o.addProperty("swingsLastSec", r.field0408);
      o.addProperty("sprintCmdsLastSec", r.field0419);
      o.addProperty("lookChangesLastSec", r.field0375);
      o.addProperty("slotChangesLastSec", r.field0371);
      o.addProperty("targetId", r.field0759);
      o.addProperty("target", r.field1269);
      o.addProperty("targetX", r.field0313);
      o.addProperty("targetY", r.field0176);
      o.addProperty("targetZ", r.field0457);
      o.addProperty("targetVelX", r.field1613);
      o.addProperty("targetVelY", r.field1537);
      o.addProperty("targetVelZ", r.field1703);
      o.addProperty("distance", r.field1135);
      o.addProperty("healthBefore", r.field1087);
      o.addProperty("absorptionBefore", r.field1196);
      o.addProperty("targetHurtTimeBefore", r.field0872);
      o.addProperty("targetBodyYawBefore", r.field0826);
      o.addProperty("expectedDamage", r.field0863);
      o.addProperty("actualDamage", r.field0246);
      o.addProperty("playerBaseDamage", r.field0941);
      o.addProperty("weaponBonusDamage", r.field0933);
      o.addProperty("sharpnessLevel", r.field0949);
      o.addProperty("enchantDamage", r.field1356);
      o.addProperty("critMultiplier", r.field1351);
      o.addProperty("damageConfirmedByEvent", r.field1367);
      if (r.field1322 != null) {
         o.addProperty("damageType", r.field1322);
      }

      o.addProperty("cameraYaw", r.field0910);
      o.addProperty("cameraPitch", r.field1331);
      o.addProperty("currentYaw", r.field1292);
      o.addProperty("currentPitch", r.field1369);
      o.addProperty("serverYaw", r.field0385);
      o.addProperty("serverPitch", r.field0351);
      o.addProperty("idealYaw", r.field0423);
      o.addProperty("idealPitch", r.field0255);
      o.addProperty("deltaYaw", r.field0226);
      o.addProperty("deltaPitch", r.field0289);
      o.addProperty("prevTickServerYawDelta", r.field0523);
      o.addProperty("prevTickServerPitchDelta", r.field0501);
      o.addProperty("snapDetected", r.field0558);
      o.addProperty("onGround", r.field1683);
      o.addProperty("sprinting", r.field1665);
      o.addProperty("sneaking", r.field1699);
      o.addProperty("fallActive", r.field1597);
      o.addProperty("fallDistance", r.field1601);
      o.addProperty("usingItem", r.field1586);
      o.addProperty("hurtTime", r.field1754);
      o.addProperty("handSwinging", r.field1749);
      o.addProperty("swingProgress", r.field1766);
      o.addProperty("hotbarSlot", r.field1175);
      o.addProperty("velX", r.field1163);
      o.addProperty("velY", r.field1185);
      o.addProperty("velZ", r.field1118);
      o.addProperty("inputForward", r.field1112);
      o.addProperty("inputSide", r.field1129);
      o.addProperty("jumpKey", r.field1233);
      o.addProperty("sprintKey", r.field1225);
      o.addProperty("sneakKey", r.field1239);
      o.addProperty("cooldownProgress", r.field0899);
      o.addProperty("canCrit", r.field0897);
      o.addProperty("weapon", r.field0906);
      if (r.field0859 != null) {
         o.addProperty("auraAimMode", r.field0859);
      }

      if (r.field0851 != null) {
         o.addProperty("smoother", r.field0851);
      }

      if (this.field1335.method1938() && r.field0381 != null) {
         JsonArray arr = new JsonArray();

         for(float[] s : r.field0381) {
            JsonArray row = new JsonArray();

            for(float v : s) {
               row.add(v);
            }

            arr.add(row);
         }

         o.add("trail", arr);
      }

      if (this.field1296.method1938() && r.field0451 != null) {
         JsonArray arr = new JsonArray();

         for(DebugLine pe : r.field0451) {
            JsonObject pj = new JsonObject();
            pj.addProperty("ts", pe.field0568);
            pj.addProperty("absTick", pe.field0005);
            pj.addProperty("name", pe.field1030);
            pj.addProperty("summary", pe.field0791);
            arr.add(pj);
         }

         o.add("packetOut", arr);
      }

      if (this.field1296.method1938() && r.field0446 != null) {
         JsonArray arr = new JsonArray();

         for(DebugLine pe : r.field0446) {
            JsonObject pj = new JsonObject();
            pj.addProperty("ts", pe.field0568);
            pj.addProperty("absTick", pe.field0005);
            pj.addProperty("name", pe.field1030);
            pj.addProperty("summary", pe.field0791);
            arr.add(pj);
         }

         o.add("packetIn", arr);
      }

      if (this.field1372.method1938() && r.field0455 != null && !r.field0455.isEmpty()) {
         JsonArray arr = new JsonArray();

         for(float[] s : r.field0455) {
            JsonArray row = new JsonArray();

            for(float v : s) {
               row.add(v);
            }

            arr.add(row);
         }

         o.add("damageTimeline", arr);
      }

      if (r.field0276 != null && !r.field0276.isEmpty()) {
         JsonArray arr = new JsonArray();

         for(DebugFrame ev : r.field0276) {
            JsonObject ej = new JsonObject();
            ej.addProperty("kind", ev.field0715);
            ej.addProperty("ts", ev.field0005);
            ej.addProperty("tickOffset", ev.field1411);
            if (ev.field1025 != null) {
               ej.add("data", ev.field1025);
            }

            arr.add(ej);
         }

         o.add("targetEvents", arr);
      }

      if (r.field0306 != null && !r.field0306.isEmpty()) {
         JsonArray flags = new JsonArray();

         for(String f : r.field0306) {
            flags.add(f);
         }

         o.add("chatFlags", flags);
      }

      if (r.field0311 != null) {
         o.addProperty("chatFlag", r.field0311);
      }

      return o;
   }

   private static boolean method1376(class_2824 packet) {
      final boolean[] result = new boolean[]{false};
      packet.method_34209(new class_2824.class_5908() {
         public void method_34219(class_1268 hand) {
         }

         public void method_34220(class_1268 hand, class_243 pos) {
         }

         public void method_34218() {
            result[0] = true;
         }
      });
      return result[0];
   }

   @EventHandler
   public void onRender2D(HudRenderEvent event) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null) {
         if (this.field1201.method1938()) {
            class_4587 stack = event.method1806().method_51448();
            FontSize titleFont = Fonts.field0075.method0654(7.0F);
            FontSize lineFont = Fonts.field0075.method0654(6.0F);
            Aura aura = Aura.method1701();
            List<String[]> stateLines = this.method0792(aura);
            List<DebugPoint> events = this.method0396();
            float pad = 6.0F;
            float titleH = 12.0F;
            float lineH = 9.0F;
            float labelW = 96.0F;
            float panelW = 270.0F;
            float panelH = pad + titleH + (float)stateLines.size() * lineH + 8.0F + (float)(events.size() + 1) * lineH + pad;
            float px = 4.0F;
            float py = 80.0F;
            GuiRenderHelper.method1463(stack, px, py, panelW, panelH, 4.0F, field0134);
            GuiRenderHelper.method1491(stack, titleFont, "aura debug v2", px + pad, py + pad, field1153);
            float ly = py + pad + titleH;

            for(String[] kv : stateLines) {
               GuiRenderHelper.method1491(stack, lineFont, kv[0], px + pad, ly, field1500);
               GuiRenderHelper.method1491(stack, lineFont, kv[1], px + pad + labelW, ly, method1983(kv[1]));
               ly += lineH;
            }

            ly += 5.0F;
            GuiRenderHelper.method1491(stack, lineFont, "events:", px + pad, ly, field1726);
            ly += lineH;

            for(DebugPoint ev : events) {
               GuiRenderHelper.method1491(stack, lineFont, ev.field0715, px + pad, ly, ev.field0134);
               GuiRenderHelper.method1491(stack, lineFont, ev.field1504, px + pad + 56.0F, ly, field1026);
               ly += lineH;
            }

         }
      }
   }

   private List<String[]> method0792(Aura aura) {
      List<String[]> lines = new ArrayList();
      boolean auraOn = aura != null && aura.method2195();
      lines.add(new String[]{"aura", auraOn ? "ON" : "OFF"});
      lines.add(new String[]{"collecting", this.method2030() ? "yes" : "no"});
      lines.add(new String[]{"pending", String.valueOf(this.field1595.size())});
      lines.add(new String[]{"session #", String.valueOf(this.field1113)});
      lines.add(new String[]{"tick", String.valueOf(this.field1130)});
      if (aura != null && aura.method0409() != null) {
         class_1309 t = aura.method0409();
         String name = method1024(t.method_5477().getString(), 14);
         lines.add(new String[]{"target", name + " " + String.format("%.2fm", field0796.field_1724.method_5739(t))});
         lines.add(new String[]{"target hp", String.format("%.1f/%.1f", t.method_6032(), t.method_6063())});
         Rotation srv = RotationManager.field0618.method2258();
         Rotation ideal = RotationHelper.method1296(t.method_33571().method_1020(field0796.field_1724.method_33571()));
         Rotation delta = RotationHelper.method0872(srv, ideal);
         lines.add(new String[]{"srv->ideal", String.format("%.1f / %.1f", delta.method2047(), delta.method1762())});
         double desync = RotationManager.method0871(srv, RotationHelper.method0545());
         lines.add(new String[]{"cam desync", String.format("%.2f", desync)});
      } else {
         lines.add(new String[]{"target", "none"});
      }

      try {
         AttackController ah = ArbuzClient.method2004().method1881().method2051();
         if (ah != null) {
            lines.add(new String[]{"hit count", String.valueOf(ah.method0414())});
            lines.add(new String[]{"since hit", ah.method2057().method0004() + "ms"});
         }
      } catch (Throwable var11) {
      }

      long cutoff = System.currentTimeMillis() - 1000L;
      method1070(this.field1607, cutoff);
      method1070(this.field1759, cutoff);
      String[] var10001 = new String[]{"atk/s · sw/s", null};
      int var10004 = this.field1607.size();
      var10001[1] = var10004 + " · " + this.field1759.size();
      lines.add(var10001);
      lines.add(new String[]{"cooldown", String.format("%.0f%%", field0796.field_1724.method_7261(0.5F) * 100.0F)});
      lines.add(new String[]{"crit ready", this.method0480() ? "yes" : "no"});
      if (this.field1190 != null) {
         lines.add(new String[]{"log", this.field1190.getFileName().toString()});
      }

      return lines;
   }

   private List<DebugPoint> method0396() {
      List<DebugPoint> out = new ArrayList();
      Iterator<DebugBox> it = this.field1584.descendingIterator();

      while(it.hasNext()) {
         DebugBox r = (DebugBox)it.next();
         DebugPoint ev = new DebugPoint();
         ev.field0715 = "[" + r.field0287 + "]";
         ev.field0134 = method1654(r.field0287);
         ev.field1504 = method1647(r);
         out.add(ev);
      }

      return out;
   }

   private static String method1647(DebugBox r) {
      StringBuilder sb = new StringBuilder();
      sb.append('#').append(r.field0568).append(' ');
      if (r.field1269 != null) {
         sb.append(method1024(r.field1269, 8)).append(' ');
      }

      if (r.field1135 > (double)0.0F) {
         sb.append(String.format("d=%.1fm ", r.field1135));
      }

      switch (r.field0287) {
         case "HIT":
         case "CUT":
         case "HIT_UNCONFIRMED":
         case "CUT_UNCONFIRMED":
            sb.append(String.format("%.1f/%.1f (%dms)", r.field0246, r.field0863, r.field0244));
            break;
         case "HIT_HEALED":
         case "HEALED":
            sb.append(String.format("hit ok, healed (exp %.1f)", r.field0863));
            break;
         case "CANCELLED":
         case "TARGET_GONE":
         case "DISCONNECT":
         case "DISABLED":
            sb.append(String.format("exp %.1f", r.field0863));
            break;
         case "PENDING":
            sb.append(String.format("exp %.1f wait", r.field0863));
         case "CHAT_FLAG":
            break;
         default:
            sb.append('?');
      }

      if (r.field0558) {
         sb.append(" SNAP");
      }

      if (r.field0311 != null) {
         sb.append(" \"").append(r.field0311).append('"');
      }

      return sb.toString();
   }

   private static String method1024(String s, int max) {
      if (s == null) {
         return "?";
      } else {
         return s.length() > max ? s.substring(0, max) : s;
      }
   }

   private static Color method1654(String outcome) {
      Color var10000;
      switch (outcome) {
         case "HIT":
         case "HIT_UNCONFIRMED":
            var10000 = field0207;
            break;
         case "HIT_HEALED":
         case "HEALED":
            var10000 = field1726;
            break;
         case "CUT":
         case "CUT_UNCONFIRMED":
            var10000 = field1641;
            break;
         case "CANCELLED":
         case "TARGET_GONE":
            var10000 = field0486;
            break;
         case "DISCONNECT":
         case "DISABLED":
            var10000 = field1564;
            break;
         case "CHAT_FLAG":
            var10000 = field1564;
            break;
         case "PENDING":
            var10000 = field1500;
            break;
         default:
            var10000 = field1026;
      }

      return var10000;
   }

   private static Color method1983(String v) {
      if (v == null) {
         return field1026;
      } else if (!v.equals("ON") && !v.equals("yes")) {
         if (!v.equals("OFF") && !v.equals("no") && !v.equals("none")) {
            if (v.endsWith("%")) {
               try {
                  float p = Float.parseFloat(v.substring(0, v.length() - 1).trim());
                  if (p >= 90.0F) {
                     return field0207;
                  }

                  if (p >= 50.0F) {
                     return field1641;
                  }

                  return field0486;
               } catch (NumberFormatException var2) {
               }
            }

            return field1026;
         } else {
            return field0486;
         }
      } else {
         return field0207;
      }
   }

   private static class DebugText {
      long field0568;
      long field0005;
      float field1410;
      float field0957;
      float field0758;
      float field1242;
      float field0314;
      float field0177;
      boolean field0497;
      float field1614;
      boolean field1574;
      boolean field1735;
      boolean field1161;
      double field1086;
      double field1195;
      double field0870;
      float field0826;
      boolean field0931;
   }

   private static class DebugLine {
      long field0568;
      long field0005;
      boolean field1527;
      String field1030;
      String field0791;
   }

   private static class DebugFrame {
      String field0715;
      long field0005;
      int field1411;
      JsonObject field1025;
   }

   private static class DebugBox {
      long field0568;
      long field0005;
      long field1412;
      long field0959;
      int field0759;
      String field1269;
      double field0313;
      double field0176;
      double field0457;
      double field1613;
      double field1537;
      double field1703;
      double field1135;
      float field1087;
      float field1196;
      int field0872;
      float field0826;
      float field0910;
      float field1331;
      float field1292;
      float field1369;
      float field0385;
      float field0351;
      float field0423;
      float field0255;
      float field0226;
      float field0289;
      float field0523;
      float field0501;
      boolean field0558;
      boolean field1683;
      boolean field1665;
      boolean field1699;
      boolean field1597;
      boolean field1586;
      float field1601;
      int field1754;
      boolean field1749;
      float field1766;
      int field1175;
      double field1163;
      double field1185;
      double field1118;
      float field1112;
      float field1129;
      boolean field1233;
      boolean field1225;
      boolean field1239;
      float field0899;
      boolean field0897;
      String field0906;
      String field0859;
      String field0851;
      float field0863;
      float field0941;
      float field0933;
      int field0949;
      float field1356;
      float field1351;
      boolean field1367;
      String field1322;
      int field1315;
      boolean field1328;
      long field1397;
      long field1391;
      long field1404;
      int field0413;
      int field0408;
      int field0419;
      int field0375;
      int field0371;
      List<float[]> field0381;
      List<DebugLine> field0451;
      List<DebugLine> field0446;
      List<float[]> field0455;
      long field0280;
      List<DebugFrame> field0276;
      String field0287;
      float field0246;
      long field0244;
      int field0252;
      boolean field0309;
      List<String> field0306;
      String field0311;
   }

   private static class DebugPoint {
      String field0715;
      Color field0134;
      String field1504;
   }
}
