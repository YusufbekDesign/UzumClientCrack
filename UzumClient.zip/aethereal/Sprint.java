package aethereal;

import meteordevelopment.orbit.EventHandler;

public class Sprint extends Module {
   public static int field0004;
   private final EnumSetting<Mode> field1448;

   public Sprint() {
      super("Sprint", ModuleCategory.field0088, "Avtomatik yugurishni yoqadi");
      this.field1448 = (EnumSetting)(new EnumSetting("sprint.mode", Sprint.Mode.field0690)).method1007("Rejim").method0210("Sprint faollashtirish usuli").method2130("Sprint faollashtirish usuli");
      this.method1013("Avtomatik yugurishni yoqadi");
   }

   public static Sprint method1720() {
      ArbuzClient var0 = ArbuzClient.method2004();
      return var0 != null && var0.method1783() != null ? (Sprint)var0.method1783().method0976(Sprint.class) : null;
   }

   @EventHandler
   public void onPlayerTick(PlayerTickEvent var1) {
      if (!method1974()) {
         boolean var2 = field0796.field_1724.field_5976;
         boolean var3 = field0796.field_1724.method_5715() && !field0796.field_1724.method_5681();
         boolean var4 = field0796.field_1724.method_5799() && !field0796.field_1724.method_5869() && !field0796.field_1724.method_5681();
         if (field0004 <= 0 && !var3 && !var2 && !var4) {
            if (!field0796.field_1724.method_6115()) {
               switch (((Mode)this.field1448.method0492()).ordinal()) {
                  case 0:
                     if (field0796.field_1724.field_3913.field_3905 > 0.0F) {
                        field0796.field_1724.method_5728(true);
                     }
                     break;
                  case 1:
                     if (field0796.field_1724.field_3913.field_3905 > 0.0F && !field0796.field_1690.field_1867.method_1434()) {
                        field0796.field_1724.method_5728(true);
                     }
               }
            }
         } else {
            field0796.field_1724.method_5728(false);
         }

         if (field0004 > 0) {
            --field0004;
         }
      }

   }

   public static enum Mode implements DisplayNamed {
      field0690("Normal"),
      field0114("Legit");

      private final String field1504;

      private Mode(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0690, field0114};
      }
   }
}
