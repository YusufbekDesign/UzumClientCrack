package aethereal;

import lombok.Generated;

public enum RotationPriority {
   field0671(60),
   field0099(40),
   field1476(35),
   field1010(30),
   field0778(20),
   field1261(0),
   field0329(-20);

   private final int field0178;

   @Generated
   public int method0531() {
      return this.field0178;
   }

   @Generated
   private RotationPriority(int var3) {
      this.field0178 = var3;
   }

   // $FF: synthetic method
   private static RotationPriority[] $values() {
      return new RotationPriority[]{field0671, field0099, field1476, field1010, field0778, field1261, field0329};
   }
}
