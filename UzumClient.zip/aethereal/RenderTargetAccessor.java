package aethereal;

import net.minecraft.class_4668;

public interface RenderTargetAccessor {
   class_4668.class_4678 arbuz$getTarget();
}
