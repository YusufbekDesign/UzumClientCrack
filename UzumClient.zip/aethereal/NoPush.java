package aethereal;

import java.util.Arrays;

public class NoPush extends Module {
   public MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("nopush.targets", Arrays.asList("Players", "Blocks", "Water"), true, () -> true)).method1007("Maqsadlar").method0210("Sources to ignore push from").method2130("Itarish manbalarini e'tiborsiz qoldirish");

   public NoPush() {
      super("NoPush", ModuleCategory.field1470, "Itarishni o'chiradi");
      this.method1013("Itarishni o'chiradi");
   }

   public boolean method1736() {
      return this.field0089.method0387("Players");
   }

   public boolean method1692() {
      return this.field0089.method0387("Blocks");
   }

   public boolean method1755() {
      return this.field0089.method0387("Water");
   }
}
