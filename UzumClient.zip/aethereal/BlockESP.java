package aethereal;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2666;
import net.minecraft.class_2672;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_4587;

public class BlockESP extends Module {
   private final BlockListSetting field0032 = (BlockListSetting)(new BlockListSetting("blockesp.blocks")).method1007("Blocks").method0210("Blocks to highlight").method2130("Блоки для подсветки");
   private final ColorSetting field1443 = (ColorSetting)(new ColorSetting("blockesp.outline", 74, 214, 160, 255)).method1882().method1007("Outline").method0210("Outline color").method2130("Цвет обводки");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("blockesp.range", 48.0F, 16.0F, 128.0F, 8.0F)).method1007("Range").method0210("Max render distance (blocks)").method2130("Максимальная дистанция обнаружения");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("blockesp.notify", false)).method1007("Notify").method0210("Show HUD notification when a target block is found").method2130("Показывать уведомление при нахождении блока");
   private static final int field0459 = 4096;
   private static final int field1615 = 8;
   private final Long2ObjectOpenHashMap<class_2248> field1563 = new Long2ObjectOpenHashMap();
   private final LongOpenHashSet field1725 = new LongOpenHashSet();
   private int field1137 = -1;
   private float field1087 = -1.0F;
   private class_2338 field1216;
   private class_1937 field0888;

   public BlockESP() {
      super("BlockESP", ModuleCategory.field1004, "Outlines selected blocks through walls");
      this.method1013("Подсвечивает выбранные блоки сквозь стены");
      this.method0213("C");
   }

   public void method0025() {
      super.method0025();
      this.field1563.clear();
      this.field1725.clear();
      this.field1137 = this.field0032.method1879();
      this.field0888 = field0796.field_1687;
      this.method1735();
   }

   public void method2078() {
      super.method2078();
      this.field1563.clear();
      this.field1725.clear();
      this.field0888 = null;
      this.field1216 = null;
   }

   private void method1735() {
      this.field1563.clear();
      if (field0796.field_1687 != null && field0796.field_1724 != null) {
         class_2338 eye = field0796.field_1724.method_24515();
         this.field1216 = eye;
         this.field1087 = (Float)this.field0985.method0492();
         if (((List)this.field0032.method0492()).isEmpty()) {
            this.field1725.clear();
         } else {
            int r = (int)Math.ceil((double)(Float)this.field0985.method0492());
            int chunkR = (r >> 4) + 1;
            int cx = eye.method_10263() >> 4;
            int cz = eye.method_10260() >> 4;

            label41:
            for(int dx = -chunkR; dx <= chunkR; ++dx) {
               for(int dz = -chunkR; dz <= chunkR; ++dz) {
                  if (field0796.field_1687.method_2935().method_12123(cx + dx, cz + dz)) {
                     class_2818 chunk = field0796.field_1687.method_8497(cx + dx, cz + dz);
                     if (chunk != null) {
                        this.method1375(chunk, eye, r);
                        if (this.field1563.size() >= 4096) {
                           break label41;
                        }
                     }
                  }
               }
            }

            if (this.field0184.method1938() && !this.field1563.isEmpty()) {
               this.method0729(this.field1563.size());
            }

         }
      }
   }

   private void method1375(class_2818 chunk, class_2338 eye, int r) {
      class_1923 cp = chunk.method_12004();
      int minY = field0796.field_1687.method_31607();
      int maxY = field0796.field_1687.method_31600() + 1;
      int rSq = r * r;
      class_2338.class_2339 mp = new class_2338.class_2339();

      for(int x = 0; x < 16; ++x) {
         for(int z = 0; z < 16; ++z) {
            int wx = cp.method_8326() + x;
            int wz = cp.method_8328() + z;
            int dxz = (wx - eye.method_10263()) * (wx - eye.method_10263()) + (wz - eye.method_10260()) * (wz - eye.method_10260());
            if (dxz <= rSq) {
               for(int y = minY; y < maxY; ++y) {
                  int dy = y - eye.method_10264();
                  if (dxz + dy * dy <= rSq) {
                     mp.method_10103(wx, y, wz);
                     class_2680 state = chunk.method_8320(mp);
                     if (this.field0032.method1253(state.method_26204())) {
                        this.field1563.put(mp.method_10063(), state.method_26204());
                        if (this.field1563.size() >= 4096) {
                           return;
                        }
                     }
                  }
               }
            }
         }
      }

   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         if (field0796.field_1687 != this.field0888) {
            this.field0888 = field0796.field_1687;
            this.field1137 = this.field0032.method1879();
            this.field1725.clear();
            this.method1735();
         } else {
            int cur = this.field0032.method1879();
            if (cur != this.field1137) {
               this.field1137 = cur;
               this.method1735();
            } else if (!(Math.abs((Float)this.field0985.method0492() - this.field1087) > 0.001F) && !this.method1692()) {
               this.method1754();
            } else {
               this.method1735();
            }
         }
      }
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound event) {
      class_2596 var10000 = event.method1970();
      Objects.requireNonNull(var10000);
      class_2596 var2 = var10000;
      byte var3 = 0;
      //$FF: var3->value
      //0->net/minecraft/class_2626
      //1->net/minecraft/class_2672
      //2->net/minecraft/class_2666
      //3->net/minecraft/class_2637
      switch (var2.typeSwitch<invokedynamic>(var2, var3)) {
         case 0:
            class_2626 p = (class_2626)var2;
            field0796.execute(() -> this.method1276(p.method_11309(), p.method_11308()));
            break;
         case 1:
            class_2672 p = (class_2672)var2;
            field0796.execute(() -> this.method0738(p.method_11523(), p.method_11524()));
            break;
         case 2:
            class_2666 p = (class_2666)var2;
            field0796.execute(() -> this.method1644(p.comp_1726().field_9181, p.comp_1726().field_9180));
            break;
         case 3:
            class_2637 p = (class_2637)var2;
            field0796.execute(() -> this.method1357(p));
      }

   }

   private void method1276(class_2338 pos, class_2680 state) {
      if (field0796.field_1724 != null) {
         long key = pos.method_10063();
         if (this.field0032.method1253(state.method_26204())) {
            if (this.field1563.size() >= 4096 && !this.field1563.containsKey(key)) {
               return;
            }

            boolean wasNew = !this.field1563.containsKey(key);
            this.field1563.put(key, state.method_26204());
            if (wasNew && this.field0184.method1938()) {
               this.method1254(state.method_26204(), pos);
            }
         } else {
            this.field1563.remove(key);
         }

      }
   }

   private void method1254(class_2248 block, class_2338 pos) {
      String name = block.method_9518().getString();
      String message = name + " " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
      class_1799 stack = new class_1799(block.method_8389());
      NewHUD.method1053("BlockESP", message, stack, true);
   }

   private void method0729(int count) {
      boolean ru = NewHUD.HudEntry.method0026();
      String message;
      if (ru) {
         int mod100 = count % 100;
         int mod10 = count % 10;
         String suffix;
         if (mod100 >= 11 && mod100 <= 14) {
            suffix = "блоков";
         } else if (mod10 == 1) {
            suffix = "блок";
         } else if (mod10 >= 2 && mod10 <= 4) {
            suffix = "блока";
         } else {
            suffix = "блоков";
         }

         message = "Найдено " + count + " " + suffix;
      } else {
         message = "Found " + count + (count == 1 ? " block" : " blocks");
      }

      Set<class_2248> unique = new LinkedHashSet(this.field1563.values());
      List<class_1799> cycle = new ArrayList(unique.size());

      for(class_2248 b : unique) {
         class_1799 s = new class_1799(b.method_8389());
         if (!s.method_7960()) {
            cycle.add(s);
         }
      }

      if (cycle.isEmpty()) {
         NewHUD.method1050("BlockESP", message, "", true);
      } else if (cycle.size() == 1) {
         NewHUD.method1053("BlockESP", message, (class_1799)cycle.get(0), true);
      } else {
         NewHUD.method1051("BlockESP", message, cycle, true);
      }

   }

   private void method1357(class_2637 packet) {
      packet.method_30621((pos, state) -> this.method1276(new class_2338(pos), state));
   }

   private boolean method1692() {
      if (this.field1216 == null) {
         return true;
      } else {
         class_2338 current = field0796.field_1724.method_24515();
         int dx = current.method_10263() - this.field1216.method_10263();
         int dy = current.method_10264() - this.field1216.method_10264();
         int dz = current.method_10260() - this.field1216.method_10260();
         return dx * dx + dy * dy + dz * dz >= 64;
      }
   }

   private void method0738(int cx, int cz) {
      this.field1725.add(this.method1830(cx, cz));
   }

   private void method1754() {
      if (!this.field1725.isEmpty()) {
         if (field0796.field_1687 != null && field0796.field_1724 != null && !((List)this.field0032.method0492()).isEmpty()) {
            LongIterator iterator = this.field1725.iterator();

            while(iterator.hasNext()) {
               long key = iterator.nextLong();
               int cx = this.method0775(key);
               int cz = this.method0158(key);
               if (!this.method2106(cx, cz)) {
                  iterator.remove();
               } else if (field0796.field_1687.method_2935().method_12123(cx, cz)) {
                  this.method0148(cx, cz);
                  iterator.remove();
               }
            }

         } else {
            this.field1725.clear();
         }
      }
   }

   private void method0148(int cx, int cz) {
      if (field0796.field_1687 != null && field0796.field_1724 != null) {
         if (!((List)this.field0032.method0492()).isEmpty()) {
            if (this.method2106(cx, cz)) {
               if (field0796.field_1687.method_2935().method_12123(cx, cz)) {
                  class_2818 chunk = field0796.field_1687.method_8497(cx, cz);
                  if (chunk != null) {
                     this.method1644(cx, cz);
                     int before = this.field1563.size();
                     this.method1375(chunk, field0796.field_1724.method_24515(), (int)Math.ceil((double)(Float)this.field0985.method0492()));
                     int added = this.field1563.size() - before;
                     if (added > 0 && this.field0184.method1938()) {
                        this.method0729(added);
                     }

                  }
               }
            }
         }
      }
   }

   private boolean method2106(int cx, int cz) {
      class_2338 eye = field0796.field_1724.method_24515();
      int r = (int)Math.ceil((double)(Float)this.field0985.method0492());
      int chunkR = (r >> 4) + 1;
      if (Math.abs(cx - (eye.method_10263() >> 4)) > chunkR) {
         return false;
      } else {
         return Math.abs(cz - (eye.method_10260() >> 4)) <= chunkR;
      }
   }

   private long method1830(int cx, int cz) {
      return (long)cx & 4294967295L | ((long)cz & 4294967295L) << 32;
   }

   private int method0775(long key) {
      return (int)key;
   }

   private int method0158(long key) {
      return (int)(key >> 32);
   }

   private void method1644(int cx, int cz) {
      long minX = (long)cx << 4;
      long minZ = (long)cz << 4;
      long maxX = minX + 15L;
      long maxZ = minZ + 15L;
      ObjectIterator<Long2ObjectMap.Entry<class_2248>> it = this.field1563.long2ObjectEntrySet().fastIterator();

      while(it.hasNext()) {
         Long2ObjectMap.Entry<class_2248> entry = (Long2ObjectMap.Entry)it.next();
         class_2338 pos = class_2338.method_10092(entry.getLongKey());
         if ((long)pos.method_10263() >= minX && (long)pos.method_10263() <= maxX && (long)pos.method_10260() >= minZ && (long)pos.method_10260() <= maxZ) {
            it.remove();
         }
      }

   }

   @EventHandler
   public void onRender3D(WorldRenderEvent.WorldPass event) {
      if (!method1974()) {
         if (!this.field1563.isEmpty()) {
            class_243 eye = field0796.field_1724.method_19538();
            float r = (Float)this.field0985.method0492();
            double rSq = (double)(r * r);
            Color color = this.field1443.method1726();
            class_4587 matrices = new class_4587();
            ObjectIterator<Long2ObjectMap.Entry<class_2248>> it = this.field1563.long2ObjectEntrySet().fastIterator();

            while(it.hasNext()) {
               Long2ObjectMap.Entry<class_2248> entry = (Long2ObjectMap.Entry)it.next();
               class_2338 pos = class_2338.method_10092(entry.getLongKey());
               if (!(pos.method_19770(eye) > rSq)) {
                  WorldRenderHelper.method2173(matrices, new class_238(pos), color);
               }
            }

         }
      }
   }
}
