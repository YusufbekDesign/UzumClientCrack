package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public final class SwordTrailTransform {
   private SwordTrailTransform() {
   }

   public static void method1452(class_4587 matrices) {
      SwordTrail module = (SwordTrail)ArbuzClient.method2004().method1783().method0976(SwordTrail.class);
      if (module != null && module.method0480()) {
         List<SwordTrailSample> snapshots = new ArrayList();

         for(SwordTrailSample s : module.method1712().method2065()) {
            snapshots.add(s);
         }

         int maxLen = module.method0400();
         if (snapshots.size() > maxLen) {
            snapshots = snapshots.subList(snapshots.size() - maxLen, snapshots.size());
         }

         if (snapshots.size() >= 2) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1773 != null && mc.field_1773.method_19418() != null) {
               class_4184 cam = mc.field_1773.method_19418();
               class_243 camPos = cam.method_19326();
               float width = module.method0393();
               Color start = module.method0407();
               Color end = module.method0518();
               SwordTrail.GradientMode gradient = module.method0514();
               SwordTrail.FadeMode fadeCurve = module.method0525();
               long now = System.currentTimeMillis();
               Matrix4f matrix = (new class_4587()).method_23760().method_23761();
               int n = snapshots.size();

               for(int i = 0; i < n - 1; ++i) {
                  SwordTrailSample a = (SwordTrailSample)snapshots.get(i);
                  SwordTrailSample b = (SwordTrailSample)snapshots.get(i + 1);
                  class_243 pa = a.method0569().method_1020(camPos);
                  class_243 pb = b.method0569().method_1020(camPos);
                  class_243 tangent = pb.method_1020(pa);
                  if (!(tangent.method_1027() < 9.999997729060978E-7)) {
                     tangent = tangent.method_1029();
                     class_243 viewDir = pa.method_1029();
                     class_243 side = tangent.method_1036(viewDir);
                     if (side.method_1027() < 9.999997729060978E-7) {
                        side = new class_243((double)0.0F, (double)1.0F, (double)0.0F);
                     }

                     side = side.method_1029();
                     float tA = 1.0F - (float)i / (float)(n - 1);
                     float tB = 1.0F - (float)(i + 1) / (float)(n - 1);
                     if (fadeCurve == SwordTrail.FadeMode.field0119) {
                        tA *= tA;
                        tB *= tB;
                     }

                     int colorA = method0939(gradient, start, end, tA, now, i, n);
                     int colorB = method0939(gradient, start, end, tB, now, i + 1, n);
                     int aA = method0733(colorA, tA);
                     int aB = method0733(colorB, tB);
                     float halfW = width * 0.5F;
                     class_243 a1 = pa.method_1019(side.method_1021((double)halfW));
                     class_243 a2 = pa.method_1020(side.method_1021((double)halfW));
                     class_243 b1 = pb.method_1019(side.method_1021((double)halfW));
                     class_243 b2 = pb.method_1020(side.method_1021((double)halfW));
                     WorldGeometryRenderer.field0139.add(new WorldGeometryRenderer.VertexBatch(new WorldGeometryRenderer.ColoredVertex[]{new WorldGeometryRenderer.ColoredVertex(matrix, (float)a1.field_1352, (float)a1.field_1351, (float)a1.field_1350, aA), new WorldGeometryRenderer.ColoredVertex(matrix, (float)a2.field_1352, (float)a2.field_1351, (float)a2.field_1350, aA), new WorldGeometryRenderer.ColoredVertex(matrix, (float)b2.field_1352, (float)b2.field_1351, (float)b2.field_1350, aB), new WorldGeometryRenderer.ColoredVertex(matrix, (float)b1.field_1352, (float)b1.field_1351, (float)b1.field_1350, aB)}));
                  }
               }

            }
         }
      }
   }

   private static int method0939(SwordTrail.GradientMode mode, Color start, Color end, float t, long now, int index, int total) {
      int var10000;
      switch (mode) {
         case field0696 -> var10000 = start.getRGB();
         case field0120 -> var10000 = method0968(end, start, t);
         case field1490 -> var10000 = method0781(now, index, total);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static int method0968(Color from, Color to, float t) {
      int r = (int)((float)from.getRed() + (float)(to.getRed() - from.getRed()) * t);
      int g = (int)((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * t);
      int b = (int)((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * t);
      int a = (int)((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * t);
      return (new Color(method0716(r), method0716(g), method0716(b), method0716(a))).getRGB();
   }

   private static int method0781(long now, int index, int total) {
      float hue = ((float)(now % 2000L) / 2000.0F + (float)index / (float)total) % 1.0F;
      return Color.HSBtoRGB(hue, 1.0F, 1.0F) | -16777216;
   }

   private static int method0733(int argb, float alphaScale) {
      int a = Math.round((float)(argb >> 24 & 255) * alphaScale);
      return method0716(a) << 24 | argb & 16777215;
   }

   private static int method0716(int x) {
      return Math.max(0, Math.min(255, x));
   }
}
