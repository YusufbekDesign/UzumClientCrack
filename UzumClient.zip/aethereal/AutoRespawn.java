package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;
import net.minecraft.class_437;
import net.minecraft.class_5892;

public class AutoRespawn extends Module {
   private final EnumSetting<Mode> field0058;

   public AutoRespawn() {
      super("AutoRespawn", ModuleCategory.field1470, "O'limdan keyin avtomatik respawn");
      this.field0058 = (EnumSetting)(new EnumSetting("autorespawn.mode", AutoRespawn.Mode.field0592)).method1007("Rejim").method0210("Respawn method to use").method2130("Respawn usuli");
      this.method1013("O'limdan keyin avtomatik respawn");
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound var1) {
      if (!method1974() && var1.method1970() instanceof class_5892 && this.field0058.method0492() == AutoRespawn.Mode.field0592) {
         field0796.field_1724.field_3944.method_52787(new class_2828.class_2829((double)1448.0F, (double)1337.0F, (double)228.0F, false, false));
         field0796.field_1724.method_7331();
         field0796.field_1724.method_7346();
      }

   }

   @EventHandler
   public void onDeathScreen(DeathScreenEvent var1) {
      if (!method1974() && this.field0058.method0492() == AutoRespawn.Mode.field0027) {
         field0796.field_1724.method_7331();
         field0796.method_1507((class_437)null);
      }

   }

   public static enum Mode implements DisplayNamed {
      field0592("FunTime Back"),
      field0027("Default");

      private final String field1504;

      private Mode(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0592, field0027};
      }
   }
}
