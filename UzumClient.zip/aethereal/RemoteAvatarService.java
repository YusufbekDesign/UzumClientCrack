package aethereal;

import net.minecraft.class_2960;

public final class RemoteAvatarService {
   private RemoteAvatarService() {
   }

   public static class_2960 method0571() {
      return null;
   }

   public static void method0025() {
   }

   public static void method2078() {
   }
}
