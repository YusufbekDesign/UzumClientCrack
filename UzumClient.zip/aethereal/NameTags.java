package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5251;
import net.minecraft.class_742;

public class NameTags extends Module {
   private final MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("nametags.targets", new BooleanSetting[]{method1056("nametags.target.self", "Self", false, "Render your own nametag in third person", "Отображать себя"), method1056("nametags.target.monsters", "Monsters", false, "Render nametags on hostile mobs", "Отображать враждебных мобов"), method1056("nametags.target.animals", "Animals", false, "Render nametags on passive mobs", "Отображать мирных мобов"), method1056("nametags.target.players", "Players", true, "Render nametags on other players", "Отображать игроков"), method1056("nametags.target.items", "Items", false, "Render nametags on dropped items", "Отображать предметы на земле")})).method1007("Targets").method0210("Entity types to render nametags on").method2130("Типы сущностей");
   private final MultiSelectSetting field1471 = (MultiSelectSetting)(new MultiSelectSetting("nametags.playeroptions", () -> this.field0089.method0387("Players"), Arrays.asList(method1056("nametags.player.ping", "Show Ping", true, "Display player ping on nametag", "Отображать пинг"), method1056("nametags.player.health", "Show Health", true, "Display player health on nametag", "Отображать здоровье"), method1056("nametags.player.armor", "Show Armor", true, "Display armor items on nametag", "Отображать броню"), method1056("nametags.player.items", "Show Items", true, "Display held items on nametag", "Отображать предметы в руках"), method1056("nametags.player.self", "Show Self", true, "Show your own nametag (combined with Self target)", "Отображать себя"), method1056("nametags.player.invisible", "Show Invisible", false, "Show nametags for invisible players", "Отображать невидимых игроков"), method1056("nametags.player.prefix", "Show Prefix", true, "Display donation/rank prefix from scoreboard team", "Отображать привилегию")))).method1007("Players Settings").method0210("Player nametag display options").method2130("Опции таблички игроков");
   private final EnumSetting<ScaleMode> field0984;
   private final BooleanSetting field0184;
   private final BooleanSetting field0464;
   private final FloatSetting field1627;
   private final FloatSetting field1553;
   private static final float field1704 = 6.0F;
   private static final float field1136 = 3.0F;
   private static final float field1087 = 6.0F;
   private static final float field1196 = 12.0F;
   private static final float field0871 = 2.0F;
   private static final float field0826 = 30.0F;
   private static final float field0910 = 32.0F;
   private static final float field1331 = 0.08F;
   private final Map<String, float[]> field1309;
   private final Map<UUID, Float> field1385;
   private static final Color field0399 = new Color(255, 255, 255, 55);
   private static final Color field0364 = new Color(255, 255, 255, 80);
   private static final Color field0436 = new Color(227, 227, 227);
   private static final Color field0269 = new Color(255, 255, 255, 184);
   private static final Color field0236 = new Color(74, 214, 160);
   private static final Color field0298 = new Color(255, 80, 90);
   private static final Color field0533 = new Color(66, 245, 149);

   private static BooleanSetting method1056(String key, String displayName, boolean enabled, String desc, String descRu) {
      BooleanSetting s = new BooleanSetting(key, enabled);
      s.method0442(displayName);
      s.method1846(displayName);
      s.method1656(desc);
      s.method1985(descRu);
      return s;
   }

   public Map<String, float[]> method1730() {
      return this.field1309;
   }

   public NameTags() {
      super("NameTags", ModuleCategory.field1004, "Enhanced nametag rendering with extra info");
      this.field0984 = (EnumSetting)(new EnumSetting("nametags.scalemode", NameTags.ScaleMode.field0662)).method1007("Scale Mode").method0210("").method2130("HUD - масштаб с ограничением, World - во всём мире");
      this.field0184 = (BooleanSetting)(new BooleanSetting("nametags.friendcolor", true)).method1007("Friend Color").method0210("Highlight friends with green color").method2130("Подсвечивать друзей зелёным цветом");
      this.field0464 = (BooleanSetting)(new BooleanSetting("nametags.distancehideitems", true)).method1007("Hide Items By Distance").method0210("Hide armor/items when players are far away").method2130("Скрывать броню и предметы вдали");
      this.field1627 = (FloatSetting)(new FloatSetting("nametags.scale", 1.0F, 0.3F, 2.0F, 0.05F)).method1007("Scale").method0210("Nametag size multiplier").method2130("Размер");
      this.field1553 = (FloatSetting)(new FloatSetting("nametags.range", 64.0F, 8.0F, 128.0F, 1.0F, () -> this.field0984.method0492() == NameTags.ScaleMode.field0662)).method1007("Max Range").method0210("Maximum render distance").method2130("Максимальная дальность");
      this.field1309 = new ConcurrentHashMap();
      this.field1385 = new HashMap();
      this.method1013("Отображение информации над сущностями");
   }

   @EventHandler
   public void onRender2D(Render2DEvent e) {
      if (field0796.field_1687 != null && field0796.field_1724 != null) {
         if (this.field0984.method0492() == NameTags.ScaleMode.field0662) {
            this.method0918(e);
         } else {
            this.method0186(e);
         }

      }
   }

   private void method0918(Render2DEvent e) {
      boolean doSelf = this.field0089.method0387("Self") && this.field1471.method0387("Show Self");
      boolean doPlayers = this.field0089.method0387("Players");
      boolean doMonsters = this.field0089.method0387("Monsters");
      boolean doAnimals = this.field0089.method0387("Animals");
      boolean doItems = this.field0089.method0387("Items");
      boolean showInvisible = this.field1471.method0387("Show Invisible");
      if (doSelf || doPlayers || doMonsters || doAnimals || doItems) {
         float tickDelta = e.method1632().method_60637(true);
         class_332 ctx = e.method1806();
         class_4587 stack = ctx.method_51448();
         class_243 camPos = field0796.field_1773.method_19418().method_19326();
         boolean firstPerson = field0796.field_1690.method_31044().method_31034();
         double range = ((Float)this.field1553.method0492()).doubleValue();
         List<class_1297> queue = new ArrayList();
         if (doSelf || doPlayers) {
            for(class_1657 p : field0796.field_1687.method_18456()) {
               if (p == field0796.field_1724) {
                  if (!doSelf || firstPerson) {
                     continue;
                  }
               } else if (!doPlayers || !showInvisible && p.method_5767()) {
                  continue;
               }

               if (!p.method_29504() && ProjectionHelper.method1185(p, range)) {
                  queue.add(p);
               }
            }
         }

         if (doMonsters || doAnimals || doItems) {
            for(class_1297 entity : field0796.field_1687.method_18112()) {
               if (!(entity instanceof class_1657) && !entity.method_31481() && !((double)field0796.field_1724.method_5739(entity) > range)) {
                  if (entity instanceof class_1542) {
                     if (doItems) {
                        queue.add(entity);
                     }
                  } else if (entity instanceof class_1309) {
                     class_1309 living = (class_1309)entity;
                     if (!living.method_29504()) {
                        class_1311 group = entity.method_5864().method_5891();
                        if (doMonsters && group == class_1311.field_6302) {
                           queue.add(entity);
                        } else if (doAnimals && method1173(group)) {
                           queue.add(entity);
                        }
                     }
                  }
               }
            }
         }

         queue.sort(Comparator.comparingDouble((enx) -> camPos.method_1022(method1132(enx, tickDelta))).reversed());
         this.field1309.clear();
         GuiRenderHelper.method0578();

         try {
            for(class_1297 en : queue) {
               class_243 worldPos = en instanceof class_1657 ? ProjectionHelper.method1188((class_1657)en, tickDelta) : method1132(en, tickDelta);
               class_243 screenPos = ProjectionHelper.method1299(worldPos);
               if (ProjectionHelper.method0289(screenPos)) {
                  double distance = Math.max(camPos.method_1022(worldPos), (double)0.5F);
                  float distScale = (float)Math.max(0.550000157981654, (double)5.0F / distance);
                  if (en instanceof class_1657) {
                     class_1657 p = (class_1657)en;
                     this.method1440(ctx, stack, p, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale, distance);
                  } else if (en instanceof class_1542) {
                     class_1542 item = (class_1542)en;
                     this.method1439(ctx, stack, item, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale);
                  } else if (en instanceof class_1309) {
                     class_1309 living = (class_1309)en;
                     this.method1438(ctx, stack, living, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale);
                  }
               }
            }
         } finally {
            GuiRenderHelper.method0025();
         }

      }
   }

   private void method0186(Render2DEvent e) {
      boolean doSelf = this.field0089.method0387("Self") && this.field1471.method0387("Show Self");
      boolean doPlayers = this.field0089.method0387("Players");
      boolean doMonsters = this.field0089.method0387("Monsters");
      boolean doAnimals = this.field0089.method0387("Animals");
      boolean doItems = this.field0089.method0387("Items");
      boolean showInvisible = this.field1471.method0387("Show Invisible");
      if (doSelf || doPlayers || doMonsters || doAnimals || doItems) {
         float tickDelta = e.method1632().method_60637(true);
         class_332 ctx = e.method1806();
         class_4587 stack = ctx.method_51448();
         class_243 camPos = field0796.field_1773.method_19418().method_19326();
         boolean firstPerson = field0796.field_1690.method_31044().method_31034();
         List<class_1297> queue = new ArrayList();
         if (doSelf || doPlayers) {
            for(class_1657 p : field0796.field_1687.method_18456()) {
               if (p == field0796.field_1724) {
                  if (!doSelf || firstPerson) {
                     continue;
                  }
               } else if (!doPlayers || !showInvisible && p.method_5767()) {
                  continue;
               }

               if (!p.method_29504()) {
                  queue.add(p);
               }
            }
         }

         if (doMonsters || doAnimals || doItems) {
            for(class_1297 entity : field0796.field_1687.method_18112()) {
               if (!(entity instanceof class_1657) && !entity.method_31481()) {
                  if (entity instanceof class_1542) {
                     if (doItems) {
                        queue.add(entity);
                     }
                  } else if (entity instanceof class_1309) {
                     class_1309 living = (class_1309)entity;
                     if (!living.method_29504()) {
                        class_1311 group = entity.method_5864().method_5891();
                        if (doMonsters && group == class_1311.field_6302) {
                           queue.add(entity);
                        } else if (doAnimals && method1173(group)) {
                           queue.add(entity);
                        }
                     }
                  }
               }
            }
         }

         queue.sort(Comparator.comparingDouble((enx) -> camPos.method_1022(method1132(enx, tickDelta))).reversed());
         this.field1309.clear();
         GuiRenderHelper.method0578();

         try {
            for(class_1297 en : queue) {
               class_243 worldPos = method1132(en, tickDelta);
               class_243 screenPos = ProjectionHelper.method1299(worldPos);
               if (ProjectionHelper.method0289(screenPos)) {
                  double distance = Math.max(camPos.method_1022(worldPos), (double)0.5F);
                  float distScale = (float)(0.9799997653140244 / ((double)1.0F + distance * 0.0149999937451505));
                  if (en instanceof class_1657) {
                     class_1657 p = (class_1657)en;
                     this.method1440(ctx, stack, p, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale, distance);
                  } else if (en instanceof class_1542) {
                     class_1542 item = (class_1542)en;
                     this.method1439(ctx, stack, item, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale);
                  } else if (en instanceof class_1309) {
                     class_1309 living = (class_1309)en;
                     this.method1438(ctx, stack, living, (float)screenPos.field_1352, (float)screenPos.field_1351, distScale);
                  }
               }
            }
         } finally {
            GuiRenderHelper.method0025();
         }

      }
   }

   private static boolean method1173(class_1311 group) {
      return group == class_1311.field_6294 || group == class_1311.field_6300 || group == class_1311.field_24460 || group == class_1311.field_30092 || group == class_1311.field_34447;
   }

   private static class_243 method1132(class_1297 entity, float tickDelta) {
      double x = class_3532.method_16436((double)tickDelta, entity.field_6014, entity.method_23317());
      double y = class_3532.method_16436((double)tickDelta, entity.field_6036, entity.method_23318());
      double z = class_3532.method_16436((double)tickDelta, entity.field_5969, entity.method_23321());
      return new class_243(x, y + (double)entity.method_17682() + 0.30000014319085483, z);
   }

   private void method1440(class_332 ctx, class_4587 stack, class_1657 player, float x, float y, float distScale, double distance) {
      boolean showHealth = this.field1471.method0387("Show Health");
      boolean showPing = this.field1471.method0387("Show Ping");
      boolean showArmor = this.field1471.method0387("Show Armor");
      boolean showHandItems = this.field1471.method0387("Show Items");
      boolean showPrefix = this.field1471.method0387("Show Prefix");
      float sc = (Float)this.field1627.method0492();
      float targetItemAlpha = !(Boolean)this.field0464.method0492() ? 1.0F : (distance < (double)32.0F ? 1.0F : 0.0F);
      float currentAlpha = (Float)this.field1385.getOrDefault(player.method_5667(), targetItemAlpha);
      currentAlpha += (targetItemAlpha - currentAlpha) * 0.08F;
      currentAlpha = class_3532.method_15363(currentAlpha, 0.0F, 1.0F);
      this.field1385.put(player.method_5667(), currentAlpha);
      boolean showItemsAtDist = currentAlpha > 0.01F;
      boolean showIconsAtDist = true;
      FontSize font = Fonts.field0075.method0654(6.0F * sc);
      FontSize secondaryFont = Fonts.field0075.method0654(6.0F * sc);
      FontSize iconFont = Fonts.field0774.method0654(6.0F * sc * 1.15F);
      String name = NameProtect.method2131(player.method_5477().getString());
      String prefix = "";
      Color prefixColor = field0269;
      if (showPrefix && field0796.field_1687 != null) {
         class_268 team = field0796.field_1687.method_8428().method_1164(name);
         if (team != null) {
            class_2561 prefixText = team.method_1144();
            String rawPrefix = prefixText.getString();
            if (rawPrefix != null && !rawPrefix.isEmpty()) {
               String sanitized = NameDecorator.method1010(rawPrefix);
               String cleaned = sanitized.replaceAll("§.", "").trim();
               if (!cleaned.isEmpty()) {
                  prefix = cleaned;
                  class_5251 tc = null;
                  if (prefixText.method_10866() != null && prefixText.method_10866().method_10973() != null) {
                     tc = prefixText.method_10866().method_10973();
                  } else {
                     for(class_2561 sibling : prefixText.method_10855()) {
                        if (sibling.method_10866() != null && sibling.method_10866().method_10973() != null) {
                           tc = sibling.method_10866().method_10973();
                           break;
                        }
                     }
                  }

                  if (tc != null) {
                     int rgb = tc.method_27716();
                     prefixColor = new Color(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255);
                  }
               }
            }
         }
      }

      float hp = ProjectionHelper.method1178(player);
      float absorption = ProjectionHelper.method1854(player);
      int ping = ProjectionHelper.method1663(player);
      float hpPercent = ProjectionHelper.method2149(player);
      String hpText = showHealth ? ProjectionHelper.method0673(hp, absorption) : "";
      String pingText = showPing ? ping + "ms" : "";
      List<class_1799> armorList = this.method1180(player);
      List<class_1799> handItems = this.method0249(player);
      float scaledItemSize = 12.0F * sc;
      float armorWidthFull = showArmor && showItemsAtDist ? this.method1075(armorList, sc) : 0.0F;
      float handsWidthFull = showHandItems && showItemsAtDist ? this.method1075(handItems, sc) : 0.0F;
      float armorWidth = armorWidthFull * currentAlpha;
      float handsWidth = handsWidthFull * currentAlpha;
      float sepGap = 5.0F * sc;
      float iconGap = 3.0F * sc;
      float innerPad = 4.0F * sc;
      float smallSepH = 7.0F * sc;
      float prefixGap = prefix.isEmpty() ? 0.0F : 3.0F * sc;
      float prefixWidth = prefix.isEmpty() ? 0.0F : secondaryFont.method0998(prefix);
      float nameWidth = font.method0998(name);
      float hpWidth = font.method0998(hpText);
      float pingWidth = font.method0998(pingText);
      float heartIconW = iconFont.method0998("J");
      float pingIconW = iconFont.method0998("a");
      float totalW = innerPad + scaledItemSize;
      totalW += sepGap + 1.0F + sepGap;
      totalW += prefixWidth + prefixGap + nameWidth;
      if (showHealth && hpWidth > 0.0F) {
         totalW += sepGap + 1.0F + sepGap;
         totalW += (showIconsAtDist ? heartIconW + iconGap : 0.0F) + hpWidth;
      }

      if (showPing && pingWidth > 0.0F) {
         totalW += sepGap + 1.0F + sepGap;
         totalW += (showIconsAtDist ? pingIconW + iconGap : 0.0F) + pingWidth;
      }

      boolean hasItems = showArmor && armorWidth > 0.0F || showHandItems && handsWidth > 0.0F;
      if (hasItems) {
         totalW += sepGap + 1.0F + sepGap;
         if (showArmor && armorWidth > 0.0F) {
            totalW += armorWidth;
            if (showHandItems && handsWidth > 0.0F) {
               totalW += 3.0F * sc;
            }
         }

         if (showHandItems && handsWidth > 0.0F) {
            totalW += handsWidth;
         }
      }

      totalW += innerPad;
      float contentH = class_3532.method_16439(currentAlpha, font.method0530(), scaledItemSize);
      float bgHeight = contentH + 7.5F * sc;
      float bgX = -totalW / 2.0F;
      float bgY = -bgHeight;
      float screenBgX = x + bgX * distScale;
      float screenBgY = y - 4.0F + bgY * distScale;
      float screenBgW = totalW * distScale;
      float screenBgH = bgHeight * distScale;
      this.field1309.put(name, new float[]{screenBgX, screenBgY, screenBgW, screenBgH});
      float scaledBlur = (Float)ThemePalette.field0367.get() * Math.min(distScale, 1.0F);
      stack.method_22903();
      stack.method_46416(x, y - 4.0F, 0.0F);
      stack.method_22905(distScale, distScale, 1.0F);
      boolean isFriend = (Boolean)this.field0184.method0492() && ArbuzClient.method2004().method1608().method1129(player);
      Color bgColor = (Color)ThemePalette.field0930.get();
      Color borderColor = ThemePalette.field1564;
      if (isFriend) {
         bgColor = method0964(bgColor, 0.1F);
         borderColor = method0964(borderColor, 0.3F);
      }

      GuiRenderHelper.method1462(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, scaledBlur, ThemePalette.field0134);
      GuiRenderHelper.method1463(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, bgColor);
      GuiRenderHelper.method1461(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, 0.5F, 0.5F, borderColor);
      float centerY = bgY + bgHeight / 2.0F;
      float textY = centerY - font.method0530() / 2.0F;
      float iconY = centerY - iconFont.method0530() / 2.0F;
      float smallSepY = centerY - smallSepH / 2.0F;
      float currentX = bgX + innerPad;
      class_2960 skinTexture = ((class_742)player).method_52814().comp_1626();
      float headRadius = 3.0F * sc;
      GuiRenderHelper.method1459(stack, currentX, centerY - scaledItemSize / 2.0F, scaledItemSize, scaledItemSize, headRadius, 0.125F, 0.125F, 0.125F, 0.125F, skinTexture, field0436);
      currentX += scaledItemSize;
      currentX += sepGap;
      GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field0364);
      currentX += 1.0F + sepGap;
      if (!prefix.isEmpty()) {
         currentX = this.method1490(stack, secondaryFont, prefix, currentX, textY, prefixColor);
         currentX += prefixGap;
      }

      Color nameColor = isFriend ? field0533 : field0436;
      GuiRenderHelper.method1491(stack, font, name, currentX, textY, nameColor);
      currentX += nameWidth;
      Color iconColor = isFriend ? field0533 : ThemeColorManager.method1908().method2063();
      if (showHealth && hpWidth > 0.0F) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field0364);
         currentX += 1.0F + sepGap;
         if (showIconsAtDist) {
            GuiRenderHelper.method1491(stack, iconFont, "J", currentX, iconY - 0.7F * sc, iconColor);
            currentX += heartIconW + iconGap;
         }

         GuiRenderHelper.method1491(stack, font, hpText, currentX, textY, field0436);
         currentX += hpWidth;
      }

      if (showPing && pingWidth > 0.0F) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field0364);
         currentX += 1.0F + sepGap;
         if (showIconsAtDist) {
            GuiRenderHelper.method1491(stack, iconFont, "a", currentX, iconY - 0.6F * sc, iconColor);
            currentX += pingIconW + iconGap;
         }

         GuiRenderHelper.method1491(stack, font, pingText, currentX, textY, field0436);
         currentX += pingWidth;
      }

      if (hasItems && showItemsAtDist) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field0364);
         currentX += 1.0F + sepGap;
         if (showArmor && armorWidth > 0.0F) {
            this.method1437(ctx, stack, armorList, currentX, centerY - scaledItemSize / 2.0F, sc, currentAlpha);
            currentX += armorWidth;
            if (showHandItems && handsWidth > 0.0F) {
               currentX += 3.0F * sc;
            }
         }

         if (showHandItems && handsWidth > 0.0F) {
            this.method1437(ctx, stack, handItems, currentX, centerY - scaledItemSize / 2.0F, sc, currentAlpha);
         }
      }

      stack.method_22909();
   }

   private void method1438(class_332 ctx, class_4587 stack, class_1309 entity, float x, float y, float distScale) {
      float sc = (Float)this.field1627.method0492();
      FontSize font = Fonts.field0075.method0654(6.0F * sc);
      FontSize iconFont = Fonts.field0774.method0654(6.0F * sc * 1.15F);
      String name = entity.method_5476().getString();
      String hpText = ProjectionHelper.method0673(entity.method_6032(), entity.method_6067());
      float sepGap = 5.0F * sc;
      float iconGap = 3.0F * sc;
      float innerPad = 4.0F * sc;
      float smallSepH = 7.0F * sc;
      float nameWidth = font.method0998(name);
      float hpWidth = font.method0998(hpText);
      float heartIconW = iconFont.method0998("J");
      float totalW = innerPad + nameWidth + sepGap + 1.0F + sepGap + heartIconW + iconGap + hpWidth + innerPad;
      float bgHeight = font.method0530() + 7.5F * sc;
      float bgX = -totalW / 2.0F;
      float bgY = -bgHeight;
      float scaledBlur = (Float)ThemePalette.field0367.get() * Math.min(distScale, 1.0F);
      stack.method_22903();
      stack.method_46416(x, y - 4.0F, 0.0F);
      stack.method_22905(distScale, distScale, 1.0F);
      Color bgColor = (Color)ThemePalette.field0930.get();
      Color borderColor = ThemePalette.field1564;
      GuiRenderHelper.method1462(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, scaledBlur, ThemePalette.field0134);
      GuiRenderHelper.method1463(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, bgColor);
      GuiRenderHelper.method1461(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, 0.5F, 0.5F, borderColor);
      float centerY = bgY + bgHeight / 2.0F;
      float textY = centerY - font.method0530() / 2.0F;
      float iconY = centerY - iconFont.method0530() / 2.0F;
      float smallSepY = centerY - smallSepH / 2.0F;
      float currentX = bgX + innerPad;
      GuiRenderHelper.method1491(stack, font, name, currentX, textY, field0436);
      currentX += nameWidth;
      currentX += sepGap;
      GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field0364);
      currentX += 1.0F + sepGap;
      Color iconColor = ThemeColorManager.method1908().method2063();
      GuiRenderHelper.method1491(stack, iconFont, "J", currentX, iconY - 0.7F * sc, iconColor);
      currentX += heartIconW + iconGap;
      GuiRenderHelper.method1491(stack, font, hpText, currentX, textY, field0436);
      stack.method_22909();
   }

   private void method1439(class_332 ctx, class_4587 stack, class_1542 entity, float x, float y, float distScale) {
      float sc = (Float)this.field1627.method0492();
      FontSize font = Fonts.field0075.method0654(6.0F * sc);
      class_1799 stackItem = entity.method_6983();
      if (!stackItem.method_7960()) {
         String name = stackItem.method_7964().getString();
         int count = stackItem.method_7947();
         String countText = count > 1 ? " x" + count : "";
         float scaledItemSize = 12.0F * sc;
         float innerPad = 4.0F * sc;
         float iconGap = 3.0F * sc;
         float nameWidth = font.method0998(name);
         float countWidth = countText.isEmpty() ? 0.0F : font.method0998(countText);
         float totalW = innerPad + scaledItemSize + iconGap + nameWidth + countWidth + innerPad;
         float contentH = Math.max(font.method0530(), scaledItemSize);
         float bgHeight = contentH + 7.5F * sc;
         float bgX = -totalW / 2.0F;
         float bgY = -bgHeight;
         float scaledBlur = (Float)ThemePalette.field0367.get() * Math.min(distScale, 1.0F);
         stack.method_22903();
         stack.method_46416(x, y - 4.0F, 0.0F);
         stack.method_22905(distScale, distScale, 1.0F);
         Color bgColor = (Color)ThemePalette.field0930.get();
         Color borderColor = ThemePalette.field1564;
         GuiRenderHelper.method1462(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, scaledBlur, ThemePalette.field0134);
         GuiRenderHelper.method1463(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, bgColor);
         GuiRenderHelper.method1461(stack, bgX, bgY, totalW, bgHeight, 6.0F * sc, 0.5F, 0.5F, borderColor);
         float centerY = bgY + bgHeight / 2.0F;
         float textY = centerY - font.method0530() / 2.0F;
         float currentX = bgX + innerPad;
         this.method1441(ctx, stack, stackItem, currentX, centerY - scaledItemSize / 2.0F, sc, 1.0F);
         currentX += scaledItemSize + iconGap;
         GuiRenderHelper.method1491(stack, font, name, currentX, textY, field0436);
         currentX += nameWidth;
         if (!countText.isEmpty()) {
            GuiRenderHelper.method1491(stack, font, countText, currentX, textY, field0269);
         }

         stack.method_22909();
      }
   }

   private static Color method0964(Color base, float t) {
      int r = (int)((float)base.getRed() * (1.0F - t) + 66.0F * t);
      int g = (int)((float)base.getGreen() * (1.0F - t) + 245.0F * t);
      int b = (int)((float)base.getBlue() * (1.0F - t) + 149.0F * t);
      return new Color(r, g, b, base.getAlpha());
   }

   private float method1490(class_4587 stack, FontSize font, String prefix, float x, float y, Color fallback) {
      float cx = x;
      int i = 0;

      while(i < prefix.length()) {
         RankColorResolver.RankStyle grad = RankColorResolver.method1023(prefix, i);
         if (grad != null) {
            for(int j = 0; j < grad.field0004; ++j) {
               String ch = String.valueOf(prefix.charAt(i + j));
               Color c = grad.method0737(j, fallback.getAlpha());
               GuiRenderHelper.method1491(stack, font, ch, cx, y, c);
               cx += font.method0998(ch);
            }

            i += grad.field0004;
         } else {
            String ch = String.valueOf(prefix.charAt(i));
            GuiRenderHelper.method1491(stack, font, ch, cx, y, fallback);
            cx += font.method0998(ch);
            ++i;
         }
      }

      return cx;
   }

   private List<class_1799> method1180(class_1657 player) {
      List<class_1799> items = new ArrayList();
      items.add((class_1799)player.method_31548().field_7548.get(3));
      items.add((class_1799)player.method_31548().field_7548.get(2));
      items.add((class_1799)player.method_31548().field_7548.get(1));
      items.add((class_1799)player.method_31548().field_7548.get(0));
      items.removeIf(class_1799::method_7960);
      return items;
   }

   private List<class_1799> method0249(class_1657 player) {
      List<class_1799> items = new ArrayList();
      class_1799 main = player.method_6047();
      class_1799 off = player.method_6079();
      if (!off.method_7960()) {
         items.add(off);
      }

      if (!main.method_7960()) {
         items.add(main);
      }

      return items;
   }

   private float method1075(List<class_1799> items, float sc) {
      if (items.isEmpty()) {
         return 0.0F;
      } else {
         float scaledSize = 12.0F * sc;
         return (float)items.size() * scaledSize + (float)(items.size() - 1) * 2.0F * sc;
      }
   }

   private void method1437(class_332 ctx, class_4587 stack, List<class_1799> items, float startX, float y, float sc, float alpha) {
      float scaledSize = 12.0F * sc;
      float currentX = startX;

      for(class_1799 item : items) {
         this.method1441(ctx, stack, item, currentX, y, sc, alpha);
         currentX += scaledSize + 2.0F * sc;
      }

   }

   private void method1441(class_332 ctx, class_4587 stack, class_1799 item, float x, float y, float sc, float alpha) {
      if (!item.method_7960() && !(alpha <= 0.01F)) {
         float scaledSize = 12.0F * sc;
         float renderScale = scaledSize / 16.0F;
         stack.method_22903();
         stack.method_46416(x, y, 200.0F);
         stack.method_22905(renderScale, renderScale, 1.0F);
         RenderSystem.enableBlend();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
         ctx.method_51427(item, 0, 0);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         if (item.method_7947() > 1) {
            String countText = String.valueOf(item.method_7947());
            FontSize countFont = Fonts.field0075.method0654(5.0F);
            float tx = 16.0F - countFont.method0998(countText);
            float ty = 16.0F - countFont.method0530();
            Color countColor = new Color(255, 255, 255, (int)(255.0F * alpha));
            GuiRenderHelper.method1491(stack, countFont, countText, tx, ty, countColor);
         }

         stack.method_22909();
      }
   }

   public static enum ScaleMode implements DisplayNamed {
      field0662("HUD"),
      field0091("World");

      private final String field1504;

      private ScaleMode(String n) {
         this.field1504 = n;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static ScaleMode[] method0071() {
         return new ScaleMode[]{field0662, field0091};
      }
   }
}
