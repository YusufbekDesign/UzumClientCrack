package aethereal;

import meteordevelopment.orbit.EventHandler;

public class ChromaticDistortion extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("chromdist.aberration", 0.012F, 0.0F, 0.05F, 0.001F)).method1007("Aberratsiya").method2130("Chrom aberratsiya");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("chromdist.falloff", 2.0F, 0.5F, 5.0F, 0.1F)).method1007("Pasayish").method2130("Markazdan pasayish");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("chromdist.motion", 1.5F, 0.0F, 5.0F, 0.1F)).method1007("Harakat").method2130("Kamera harakatidan kuchi");
   private final FloatSetting field0190 = (FloatSetting)(new FloatSetting("chromdist.smooth", 0.2F, 0.02F, 0.5F, 0.01F)).method1007("Harakat sillqligi").method2130("Harakat sillqligi");
   private final FloatSetting field0470 = (FloatSetting)(new FloatSetting("chromdist.bloomThr", 0.65F, 0.2F, 1.0F, 0.02F)).method1007("Bloom chegarasi").method2130("Bloom chegarasi");
   private final FloatSetting field1627 = (FloatSetting)(new FloatSetting("chromdist.bloomInt", 0.8F, 0.0F, 3.0F, 0.05F)).method1007("Bloom").method2130("Bloom kuchi");
   private final FloatSetting field1553 = (FloatSetting)(new FloatSetting("chromdist.bloomRad", 3.0F, 0.5F, 8.0F, 0.25F)).method1007("Bloom radiusi").method2130("Bloom radiusi");
   private final FloatSetting field1716 = (FloatSetting)(new FloatSetting("chromdist.vignette", 0.5F, 0.0F, 1.0F, 0.05F)).method1007("Vinjetka").method2130("Vinjetka");
   private final ChromaticDistortionRenderer field1142 = new ChromaticDistortionRenderer();
   private float field1087;
   private float field1196;
   private float field0871;
   private float field0826;
   private boolean field0931 = true;

   public ChromaticDistortion() {
      super("ChromaticDistortion", ModuleCategory.field1004, "Kino post-effekti: aberratsiya, harakat distorsiyasi, bloom, vinjetka");
      this.method1013("Kino post-effekti: aberratsiya, harakat distorsiyasi, bloom, vinjetka");
   }

   public void method2078() {
      super.method2078();
      this.field0931 = true;
      this.field0871 = 0.0F;
      this.field0826 = 0.0F;
   }

   @EventHandler
   public void onRender(Render2DEvent var1) {
      if (!method1974()) {
         float var2 = field0796.field_1724.method_36454();
         float var3 = field0796.field_1724.method_36455();
         if (this.field0931) {
            this.field1087 = var2;
            this.field1196 = var3;
            this.field0931 = false;
         }

         float var4;
         for(var4 = var2 - this.field1087; var4 > 180.0F; var4 -= 360.0F) {
         }

         while(var4 < -180.0F) {
            var4 += 360.0F;
         }

         float var5 = var3 - this.field1196;
         this.field1087 = var2;
         this.field1196 = var3;
         float var6 = (Float)this.field0190.method0492();
         this.field0871 += (var4 * 0.04F - this.field0871) * var6;
         this.field0826 += (var5 * 0.04F - this.field0826) * var6;
         this.field1142.method0675((Float)this.field0060.method0492(), (Float)this.field1450.method0492());
         this.field1142.method0684(this.field0871, this.field0826, (Float)this.field0985.method0492());
         this.field1142.method0131((Float)this.field0470.method0492(), (Float)this.field1627.method0492(), (Float)this.field1553.method0492());
         this.field1142.method0665((Float)this.field1716.method0492());
         this.field1142.method0578();
      }

   }
}
