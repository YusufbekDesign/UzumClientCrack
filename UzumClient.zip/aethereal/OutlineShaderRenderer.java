package aethereal;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import lombok.Generated;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_4720;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_9799;
import net.minecraft.class_9960;
import net.minecraft.class_1921.class_4688;
import net.minecraft.class_1921.class_4750;
import net.minecraft.class_293.class_5596;
import org.patch.arbuzhack.api.mixins.accessors.GameRendererAccessor;
import org.patch.arbuzhack.api.mixins.accessors.PostEffectProcessorAccessor;
import org.patch.arbuzhack.api.mixins.accessors.RenderLayerMultiPhaseAccessor;
import org.patch.arbuzhack.api.mixins.accessors.RenderLayerMultiPhaseParametersAccessor;
import org.patch.arbuzhack.api.mixins.accessors.RenderPhaseTextureBaseAccessor;

public class OutlineShaderRenderer implements MinecraftAccess {
   private final ColoredVertexConsumerProvider field0650;
   private class_276 field0159;
   private class_4668.class_4678 field1523;
   private Function<class_4668.class_5939, class_1921> field1035;
   private boolean field0219;
   private class_279 field0495;
   private class_279 field1649;
   private class_279 field1571;
   private final int field1705;

   public OutlineShaderRenderer() {
      this(1);
   }

   public OutlineShaderRenderer(int downscale) {
      this.field0650 = new ColoredVertexConsumerProvider(class_4597.method_22991(new class_9799(256)));
      this.field0219 = false;
      this.field1705 = Math.max(1, downscale);
      ShaderCache.method0550().method0811(this);
   }

   private void method2266() {
      if (!this.field0219 && field0796.method_22683() != null) {
         int fbWidth = Math.max(1, field0796.method_22683().method_4489() / this.field1705);
         int fbHeight = Math.max(1, field0796.method_22683().method_4506() / this.field1705);
         this.field0159 = new class_6367(fbWidth, fbHeight, true);
         this.field0159.method_1236(0.0F, 0.0F, 0.0F, 0.0F);
         this.field1523 = new class_4668.class_4678("shader_target", () -> this.field0159.method_1235(true), () -> field0796.method_1522().method_1235(true));
         this.field1035 = this.method1101((texture) -> class_1921.method_24048("sydney_overlay", class_290.field_1575, class_5596.field_27382, 1536, class_4688.method_23598().method_34578(class_4668.field_29418).method_34577(texture).method_23604(class_4668.field_21346).method_23610(this.field1523).method_24297(class_4750.field_21854)));
         this.field0219 = true;
      }

   }

   public void method0578() {
      this.method2266();
      if (this.field0219) {
         this.field0159.method_1236(0.0F, 0.0F, 0.0F, 0.0F);
         this.field0159.method_1230();
         field0796.method_1522().method_1235(true);
      }
   }

   public void method0764(int renderMode, Color mainColor, boolean shine, boolean glintEnabled, float glintSpeed, float glintWidth, float glintGrad, Color glintColor, boolean noiseEnabled, float noiseSpeed, float noiseAngle, float noiseScale, Color noiseColor, boolean circuitEnabled, float circuitSpeed, float circuitIntensity, Color circuitColor) {
      this.method2266();
      if (this.field0219) {
         try {
            if (this.field0495 == null) {
               this.field0495 = field0796.method_62887().method_62941(class_2960.method_60655("arbuzhack", "outline"), class_9960.field_53902);
            }

            class_279 shader = this.field0495;
            if (shader == null) {
               System.err.println("Shader is null!");
               return;
            }

            class_5944 program = ((class_283)((PostEffectProcessorAccessor)shader).getPasses().getFirst()).method_62922();
            if (program == null) {
               System.err.println("Program is null!");
               return;
            }

            program.method_62899("DiffuseSampler", this.field0159.method_30277());
            program.method_34582("RenderMode").method_35649(renderMode);
            program.method_34582("MainColor").method_35657((float)mainColor.getRed() / 255.0F, (float)mainColor.getGreen() / 255.0F, (float)mainColor.getBlue() / 255.0F, (float)mainColor.getAlpha() / 255.0F);
            program.method_34582("GlintEnabled").method_1251(glintEnabled ? 1.0F : 0.0F);
            program.method_34582("GlintSpeed").method_1251(glintSpeed);
            program.method_34582("GlintWidth").method_1251(glintWidth);
            program.method_34582("GlintGrad").method_1251(glintGrad);
            program.method_34582("GlintColor").method_35657((float)glintColor.getRed() / 255.0F, (float)glintColor.getGreen() / 255.0F, (float)glintColor.getBlue() / 255.0F, (float)glintColor.getAlpha() / 255.0F);
            program.method_34582("NoiseEnabled").method_1251(noiseEnabled ? 1.0F : 0.0F);
            program.method_34582("NoiseSpeed").method_1251(noiseSpeed);
            program.method_34582("NoiseAngle").method_1251(noiseAngle);
            program.method_34582("NoiseScale").method_1251(noiseScale);
            program.method_34582("NoiseColor").method_35657((float)noiseColor.getRed() / 255.0F, (float)noiseColor.getGreen() / 255.0F, (float)noiseColor.getBlue() / 255.0F, (float)noiseColor.getAlpha() / 255.0F);
            program.method_34582("CircuitEnabled").method_1251(circuitEnabled ? 1.0F : 0.0F);
            program.method_34582("CircuitSpeed").method_1251(circuitSpeed);
            program.method_34582("CircuitIntensity").method_1251(circuitIntensity);
            program.method_34582("CircuitColor").method_35657((float)circuitColor.getRed() / 255.0F, (float)circuitColor.getGreen() / 255.0F, (float)circuitColor.getBlue() / 255.0F, (float)circuitColor.getAlpha() / 255.0F);
            program.method_34582("Time").method_1251((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            shader.method_1258(this.field0159, ((GameRendererAccessor)field0796.field_1773).getPool());
            field0796.method_1522().method_1235(true);
            RenderSystem.enableBlend();
            if (shine) {
               RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
            } else {
               RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
            }

            this.field0159.method_1233(field0796.method_22683().method_4489(), field0796.method_22683().method_4506());
            RenderSystem.disableBlend();
         } catch (Exception e) {
            System.err.println("Error rendering shader: " + e.getMessage());
            e.printStackTrace();
            this.field0495 = null;
         }

      }
   }

   public void method0735(int shapeMode, float fillOpacity, int glintEnabled, float glintSpeed, float glintScale, float glintStrength, int glintCount) {
      this.method2266();
      if (this.field0219) {
         try {
            if (this.field1649 == null) {
               this.field1649 = field0796.method_62887().method_62941(class_2960.method_60655("arbuzhack", "itemchams_solid"), class_9960.field_53902);
            }

            class_279 shader = this.field1649;
            if (shader == null) {
               return;
            }

            class_5944 program = ((class_283)((PostEffectProcessorAccessor)shader).getPasses().getFirst()).method_62922();
            if (program == null) {
               return;
            }

            program.method_62899("DiffuseSampler", this.field0159.method_30277());
            program.method_34582("shapeMode").method_35649(shapeMode);
            program.method_34582("fillOpacity").method_1251(fillOpacity);
            program.method_34582("glintEnabled").method_35649(glintEnabled);
            program.method_34582("glintSpeed").method_1251(glintSpeed);
            program.method_34582("glintScale").method_1251(glintScale);
            program.method_34582("glintStrength").method_1251(glintStrength);
            program.method_34582("glintCount").method_35649(glintCount);
            program.method_34582("Time").method_1251((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            shader.method_1258(this.field0159, ((GameRendererAccessor)field0796.field_1773).getPool());
            field0796.method_1522().method_1235(true);
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
            this.field0159.method_1233(field0796.method_22683().method_4489(), field0796.method_22683().method_4506());
            RenderSystem.disableBlend();
         } catch (Exception e) {
            System.err.println("Error rendering itemchams_solid: " + e.getMessage());
            e.printStackTrace();
            this.field1649 = null;
         }

      }
   }

   public void method0743(int shapeMode, int glowStrength, float glowMultiplier, int glowQuality, float fillOpacity, int glintEnabled, float glintSpeed, float glintScale, float glintStrength, int glintCount, int optimize) {
      this.method2266();
      if (this.field0219) {
         try {
            if (this.field1571 == null) {
               this.field1571 = field0796.method_62887().method_62941(class_2960.method_60655("arbuzhack", "itemchams_glow"), class_9960.field_53902);
            }

            class_279 shader = this.field1571;
            if (shader == null) {
               return;
            }

            class_5944 program = ((class_283)((PostEffectProcessorAccessor)shader).getPasses().getFirst()).method_62922();
            if (program == null) {
               return;
            }

            program.method_62899("DiffuseSampler", this.field0159.method_30277());
            program.method_34582("shapeMode").method_35649(shapeMode);
            program.method_34582("glowStrength").method_35649(glowStrength);
            program.method_34582("glowMultiplier").method_1251(glowMultiplier);
            program.method_34582("glowQuality").method_35649(glowQuality);
            program.method_34582("fillOpacity").method_1251(fillOpacity);
            program.method_34582("glintEnabled").method_35649(glintEnabled);
            program.method_34582("glintSpeed").method_1251(glintSpeed);
            program.method_34582("glintScale").method_1251(glintScale);
            program.method_34582("glintStrength").method_1251(glintStrength);
            program.method_34582("glintCount").method_35649(glintCount);
            program.method_34582("optimize").method_35649(optimize);
            program.method_34582("Time").method_1251((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            shader.method_1258(this.field0159, ((GameRendererAccessor)field0796.field_1773).getPool());
            field0796.method_1522().method_1235(true);
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
            this.field0159.method_1233(field0796.method_22683().method_4489(), field0796.method_22683().method_4506());
            RenderSystem.disableBlend();
         } catch (Exception e) {
            System.err.println("Error rendering itemchams_glow: " + e.getMessage());
            e.printStackTrace();
            this.field1571 = null;
         }

      }
   }

   public void method0738(int width, int height) {
      if (this.field0159 != null) {
         this.field0159.method_1234(Math.max(1, width / this.field1705), Math.max(1, height / this.field1705));
      }

      this.field0495 = null;
      this.field1649 = null;
      this.field1571 = null;
   }

   public void method0025() {
      this.field0495 = null;
      this.field1649 = null;
      this.field1571 = null;
   }

   public class_4597 method1517(class_4597 parent, Color color) {
      return this.method1518(parent, color, 255);
   }

   public class_4597 method1518(class_4597 parent, Color color, int outlineAlpha) {
      this.method2266();
      if (!this.field0219) {
         return parent;
      } else {
         int clampedAlpha = Math.max(0, Math.min(255, outlineAlpha));
         return (layer) -> {
            class_4588 parentBuffer = parent.getBuffer(layer);
            if (layer instanceof class_1921.class_4687 && ((RenderLayerMultiPhaseParametersAccessor)((RenderLayerMultiPhaseAccessor)layer).invokeGetPhases()).getOutlineMode() != class_4750.field_21853) {
               this.field0650.method0749(color.getRed(), color.getGreen(), color.getBlue(), clampedAlpha);
               class_4588 outlineBuffer = this.field0650.getBuffer((class_1921)this.field1035.apply(((RenderLayerMultiPhaseParametersAccessor)((RenderLayerMultiPhaseAccessor)layer).invokeGetPhases()).getTexture()));
               return outlineBuffer != null ? class_4720.method_24037(outlineBuffer, parentBuffer) : parentBuffer;
            } else {
               return parentBuffer;
            }
         };
      }
   }

   private Function<class_4668.class_5939, class_1921> method1101(final Function<class_4668.class_5939, class_1921> function) {
      return new Function<class_4668.class_5939, class_1921>() {
         private final Map<class_2960, class_1921> field0140 = new HashMap();

         public class_1921 method1521(class_4668.class_5939 texture) {
            return (class_1921)this.field0140.computeIfAbsent((class_2960)((RenderPhaseTextureBaseAccessor)texture).invokeGetId().get(), (id) -> (class_1921)function.apply(texture));
         }

         // $FF: synthetic method
         public Object apply(Object var1) {
            return this.method1521((class_4668.class_5939)var1);
         }
      };
   }

   @Generated
   public ColoredVertexConsumerProvider method2058() {
      return this.field0650;
   }

   @Generated
   public class_276 method1805() {
      return this.field0159;
   }

   @Generated
   public class_4668.class_4678 method1631() {
      return this.field1523;
   }

   @Generated
   public Function<class_4668.class_5939, class_1921> method1964() {
      return this.field1035;
   }

   @Generated
   public boolean method0431() {
      return this.field0219;
   }

   @Generated
   public class_279 method0373() {
      return this.field0495;
   }

   @Generated
   public class_279 method0496() {
      return this.field1649;
   }

   @Generated
   public class_279 method2226() {
      return this.field1571;
   }

   @Generated
   public int method2183() {
      return this.field1705;
   }
}
