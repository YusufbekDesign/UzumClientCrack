package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_5498;

public class VisualSpin extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("visualspin.yawspeed", 60.0F, 5.0F, 360.0F, 5.0F)).method1007("Yaw tezligi").method0210("Yaw aylanish tezligi (darajalar/tik)").method2130("Yaw tezligi (darajalar/tik)");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("visualspin.pitchamp", 30.0F, 0.0F, 90.0F, 5.0F)).method1007("Pitch amplitudasi").method0210("Maksimal pitch siljishi darajalarda").method2130("Pitch siljish amplitudasi (darajalar)");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("visualspin.pitchspeed", 12.0F, 1.0F, 60.0F, 1.0F)).method1007("Pitch tezligi").method0210("Pitch tebranish tezligi").method2130("Pitch tebranish tezligi");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("visualspin.onlyf5", true)).method1007("Faqat F5 da").method0210("Faqat uchinchi shaxs ko'rishda aylantirish").method2130("Faqat uchinchi shaxsda (F5)");
   private final BooleanSetting field0464 = (BooleanSetting)(new BooleanSetting("visualspin.requireaura", false)).method1007("Aura faol talab qilish").method0210("Faqat Aura maqsad qilganda pitchni aylantirish (xavfsizroq)").method2130("Faqat Aura faol bo'lganda pitchni aylantirish (xavfsizroq)");
   private float field1614 = 0.0F;
   private float field1538 = 0.0F;

   public VisualSpin() {
      super("VisualSpin", ModuleCategory.field1004, "Faqat mahalliy vizual aylanish aylantirishi (server va boshqa o'yinchilar oddiy aylanishni ko'radi)");
      this.method1013("Mahalliy vizual spin (server va boshqa o'yinchilar oddiy aylanishni ko'radi)");
   }

   public void method2078() {
      super.method2078();
      this.field1614 = 0.0F;
      this.field1538 = 0.0F;
   }

   private boolean method1736() {
      return method1974() ? false : !(Boolean)this.field0184.method0492() || field0796.field_1690.method_31044() != class_5498.field_26664;
   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (this.method1736()) {
         this.field1614 = (this.field1614 + (Float)this.field0060.method0492()) % 360.0F;
         this.field1538 = (this.field1538 + (Float)this.field0985.method0492()) % 360.0F;
      }

   }

   @EventHandler
   public void onPostMovement(PostMovementTickEvent var1) {
      if (this.method1736()) {
         field0796.field_1724.method_5636(this.field1614);
         field0796.field_1724.method_5847(this.field1614);
         field0796.field_1724.field_6220 = this.field1614;
         field0796.field_1724.field_6259 = this.field1614;
         boolean var2 = RotationManager.field0618.method1606() != null;
         if ((!(Boolean)this.field0464.method0492() || var2) && var2) {
            float var3 = (float)Math.sin(Math.toRadians((double)this.field1538)) * (Float)this.field1450.method0492();
            field0796.field_1724.method_36457(var3);
         }
      }

   }
}
