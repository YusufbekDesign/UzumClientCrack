package aethereal;

import java.awt.Color;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class PopChams extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("popchams.duration", 1500.0F, 500.0F, 5000.0F, 100.0F)).method1007("Davomiylik").method0210("Arix modeli qancha vaqt ko'rinib turishi").method2130("Yashash vaqti");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("popchams.fadetime", 500.0F, 100.0F, 2000.0F, 50.0F)).method1007("Yo'qolish vaqti").method0210("Arix modelining yo'qolish vaqti").method2130("Yo'qolish vaqti");
   private final BooleanSetting field0970 = (BooleanSetting)(new BooleanSetting("popchams.fill", true)).method1007("To'ldirish").method0210("To'ldirilgan arix modelini ko'rsatish").method2130("To'ldirilgan modelni ko'rsatish");
   private final ColorSetting field0185;
   private final BooleanSetting field0464;
   private final ColorSetting field1623;
   private final BooleanSetting field1544;
   private final BooleanSetting field1709;
   private final BooleanSetting field1141;
   private final FloatSetting field1097;
   private final Map<Integer, GhostEntity> field1214;

   public PopChams() {
      super("PopChams", ModuleCategory.field1004, "Totem chiqganda arix modelini ko'rsatadi");
      BooleanSetting var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field0185 = (ColorSetting)(new ColorSetting("popchams.fillcolor", 255, 0, 0, 100, var10008::method0492)).method1882().method1007("To'ldirish rangi").method0210("To'ldirilgan arix modelining rangi").method2130("Rang");
      this.field0464 = (BooleanSetting)(new BooleanSetting("popchams.outline", true)).method1007("Kontur").method0210("Arix modeli atrofida konturni ko'rsatish").method2130("Arix atrofida kontur");
      var10008 = this.field0464;
      Objects.requireNonNull(var10008);
      this.field1623 = (ColorSetting)(new ColorSetting("popchams.outlinecolor", 255, 0, 0, 255, var10008::method0492)).method1882().method1007("Kontur rangi").method0210("Arix modeli konturining rangi").method2130("Kontur rangi");
      this.field1544 = (BooleanSetting)(new BooleanSetting("popchams.shine", false)).method1007("Yaltirash").method0210("Arix modeliga yaltirash effektini qo'shish").method2130("Yaltirash");
      this.field1709 = (BooleanSetting)(new BooleanSetting("popchams.self", false)).method1007("O'zim").method0210("O'zimda pop chamsni ko'rsatish").method2130("O'zimda pop chamsni ko'rsatish");
      this.field1141 = (BooleanSetting)(new BooleanSetting("popchams.rising", true)).method1007("Ko'tarilish").method0210("Arix modeli vaqt o'tishi bilan yuqoriga ko'tariladi").method2130("Arix modeli osmonga uchadi");
      var10008 = this.field1141;
      Objects.requireNonNull(var10008);
      this.field1097 = (FloatSetting)(new FloatSetting("popchams.risespeed", 0.5F, 0.1F, 2.0F, 0.1F, var10008::method0492)).method1007("Ko'tarilish tezligi").method0210("Ko'tarilish animatsiyasining tezligi").method2130("Ko'tarilish animatsiyasi tezligi");
      this.field1214 = new ConcurrentHashMap();
      this.method1013("Totem ishlaganda arixni chizadi");
   }

   public void method2078() {
      super.method2078();
      this.field1214.clear();
   }

   @EventHandler
   public void onPopTotem(TotemPopEvent var1) {
      if (!method1974()) {
         class_1657 var2 = var1.method1800();
         if (var2 != null && (var2 != field0796.field_1724 || (Boolean)this.field1709.method0492())) {
            StaticPlayerEntity var3 = new StaticPlayerEntity(var2);
            GhostEntity var4 = new GhostEntity(var3, var2.method_19538(), System.currentTimeMillis());
            this.field1214.put(var2.method_5628(), var4);
         }
      }

   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent var1) {
      if (!method1974()) {
         long var2 = System.currentTimeMillis();
         float var4 = (Float)this.field0060.method0492();
         float var5 = (Float)this.field1450.method0492();
         this.field1214.entrySet().removeIf((var6) -> {
            GhostEntity var7 = (GhostEntity)var6.getValue();
            long var8 = var2 - var7.field1412;
            if ((float)var8 > var4) {
               return true;
            } else {
               float var10 = 1.0F;
               if ((float)var8 > var4 - var5) {
                  var10 = 1.0F - ((float)var8 - (var4 - var5)) / var5;
               }

               var10 = Math.max(0.0F, Math.min(1.0F, var10));
               float var11 = 0.0F;
               if ((Boolean)this.field1141.method0492()) {
                  float var12 = (float)var8 / var4;
                  var11 = var12 * (Float)this.field1097.method0492();
               }

               this.method0904(var7, var10, var1.method1603(), var11);
               return false;
            }
         });
      }

   }

   private void method0904(GhostEntity var1, float var2, float var3, float var4) {
      class_243 var5 = var1.field0157.method_1031((double)0.0F, (double)var4, (double)0.0F);
      var1.field0608.method1300(var5);
      Color var6 = new Color(this.field0185.method1742(), this.field0185.method2019(), this.field0185.method2002(), (int)((float)this.field0185.method2036() * var2));
      Color var7 = new Color(this.field1623.method1742(), this.field1623.method2019(), this.field1623.method2002(), (int)((float)this.field1623.method2036() * var2));

      try {
         var1.field0608.method0713(var3, (Boolean)this.field0970.method0492(), var6, (Boolean)this.field0464.method0492(), var7, (Boolean)this.field1544.method0492());
      } catch (Exception var9) {
      }

   }

   private static class GhostEntity {
      private final StaticPlayerEntity field0608;
      private final class_243 field0157;
      private final long field1412;

      public GhostEntity(StaticPlayerEntity var1, class_243 var2, long var3) {
         this.field0608 = var1;
         this.field0157 = var2;
         this.field1412 = var3;
      }

      @Generated
      public StaticPlayerEntity method0534() {
         return this.field0608;
      }

      @Generated
      public class_243 method0024() {
         return this.field0157;
      }

      @Generated
      public long method2049() {
         return this.field1412;
      }
   }
}
