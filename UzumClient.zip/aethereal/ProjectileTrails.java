package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1682;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public class ProjectileTrails extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("projectiletrails.amount", 5.0F, 1.0F, 15.0F, 1.0F)).method1007("Amount").method0210("Particles spawned per tick per projectile").method2130("Количество");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("projectiletrails.size", 0.04F, 0.01F, 0.2F, 0.01F)).method1007("Size").method0210("Size of trail particles").method2130("Размер");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("projectiletrails.lifetime", 30.0F, 5.0F, 60.0F, 1.0F)).method1007("Lifetime").method0210("How long particles last in ticks").method2130("Длительность");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("projectiletrails.shine", true)).method1007("Shine").method0210("Additive blending for glow").method2130("Сияние");
   private final ColorSetting field0466 = (ColorSetting)(new ColorSetting("projectiletrails.color", 255, 156, 228, 180)).method1882().method1007("Color").method0210("Trail color").method2130("Цвет");
   private final List<TrailPoint> field1644 = new ArrayList();
   private final Map<Integer, class_243> field1566 = new HashMap();
   private final Random field1730 = new Random();

   public ProjectileTrails() {
      super("ProjectileTrails", ModuleCategory.field1004, "Adds particle trails to thrown projectiles");
      this.method1013("Добавляет следы частиц к предметам которые бросают игроки");
   }

   public void method0025() {
      super.method0025();
      this.field1644.clear();
      this.field1566.clear();
   }

   public void method2078() {
      super.method2078();
      this.field1644.clear();
      this.field1566.clear();
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         Set<Integer> alive = new HashSet();

         for(class_1297 entity : field0796.field_1687.method_18112()) {
            if (this.method1129(entity)) {
               alive.add(entity.method_5628());
               class_243 pos = entity.method_19538();
               class_243 prev = (class_243)this.field1566.get(entity.method_5628());
               if (prev != null && pos.method_1025(prev) > 9.999994329400472E-4) {
                  int count = ((Float)this.field0060.method0492()).intValue();

                  for(int i = 0; i < count; ++i) {
                     float t = (float)i / (float)count;
                     double sx = prev.field_1352 + (pos.field_1352 - prev.field_1352) * (double)t + (this.field1730.nextDouble() - (double)0.5F) * 0.09999998808295149;
                     double sy = prev.field_1351 + (pos.field_1351 - prev.field_1351) * (double)t + (this.field1730.nextDouble() - (double)0.5F) * 0.09999998808295149;
                     double sz = prev.field_1350 + (pos.field_1350 - prev.field_1350) * (double)t + (this.field1730.nextDouble() - (double)0.5F) * 0.09999998808295149;
                     double vx = (this.field1730.nextDouble() - (double)0.5F) * 0.010000003791233567;
                     double vy = (this.field1730.nextDouble() - (double)0.5F) * 0.010000003791233567;
                     double vz = (this.field1730.nextDouble() - (double)0.5F) * 0.010000003791233567;
                     this.field1644.add(new TrailPoint(sx, sy, sz, vx, vy, vz, ((Float)this.field0985.method0492()).intValue()));
                  }
               }

               this.field1566.put(entity.method_5628(), pos);
            }
         }

         this.field1566.keySet().retainAll(alive);
         Iterator<TrailPoint> it = this.field1644.iterator();

         while(it.hasNext()) {
            TrailPoint p = (TrailPoint)it.next();
            p.field0956 = p.field0565;
            p.field0757 = p.field0002;
            p.field1241 = p.field1409;
            p.field0565 += p.field0313;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            ++p.field1615;
            if (p.field1615 >= p.field1539) {
               it.remove();
            }
         }

      }
   }

   private boolean method1129(class_1297 entity) {
      return entity instanceof class_1682 || entity instanceof class_1665;
   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent event) {
      if (!method1974() && !this.field1644.isEmpty()) {
         class_243 camera = field0796.field_1773.method_19418().method_19326();
         Matrix4f matrix = (new class_4587()).method_23760().method_23761();
         float partialTick = event.method1603();
         Color baseColor = this.field0466.method1726();
         int baseRgb = baseColor.getRGB() & 16777215;

         for(TrailPoint p : this.field1644) {
            float life = 1.0F - (float)p.field1615 / (float)p.field1539;
            if (!(life <= 0.0F)) {
               int alpha = Math.max(0, Math.min(255, (int)((float)baseColor.getAlpha() * life)));
               int rgb = (alpha & 255) << 24 | baseRgb;
               float rx = (float)(method0625(p.field0956, p.field0565, partialTick) - camera.field_1352);
               float ry = (float)(method0625(p.field0757, p.field0002, partialTick) - camera.field_1351);
               float rz = (float)(method0625(p.field1241, p.field1409, partialTick) - camera.field_1350);
               float s = (Float)this.field1450.method0492() * life;
               List<WorldGeometryRenderer.VertexBatch> lines = new ArrayList();
               lines.add(this.method1556(matrix, rx - s, ry, rz, rx + s, ry, rz, rgb));
               lines.add(this.method1556(matrix, rx, ry - s, rz, rx, ry + s, rz, rgb));
               lines.add(this.method1556(matrix, rx, ry, rz - s, rx, ry, rz + s, rgb));
               if ((Boolean)this.field0184.method0492()) {
                  WorldGeometryRenderer.field0209.addAll(lines);
               } else {
                  WorldGeometryRenderer.field1508.addAll(lines);
               }
            }
         }

      }
   }

   private WorldGeometryRenderer.VertexBatch method1556(Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, int color) {
      return new WorldGeometryRenderer.VertexBatch(new WorldGeometryRenderer.ColoredVertex[]{new WorldGeometryRenderer.ColoredVertex(matrix, x1, y1, z1, color), new WorldGeometryRenderer.ColoredVertex(matrix, x2, y2, z2, color)});
   }

   private static double method0625(double a, double b, float t) {
      return a + (b - a) * (double)t;
   }

   private static class TrailPoint {
      double field0565;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      double field0313;
      double field0176;
      double field0457;
      int field1615;
      int field1539;

      TrailPoint(double x, double y, double z, double vx, double vy, double vz, int maxAge) {
         this.field0565 = x;
         this.field0002 = y;
         this.field1409 = z;
         this.field0956 = x;
         this.field0757 = y;
         this.field1241 = z;
         this.field0313 = vx;
         this.field0176 = vy;
         this.field0457 = vz;
         this.field1615 = 0;
         this.field1539 = maxAge;
      }
   }
}
