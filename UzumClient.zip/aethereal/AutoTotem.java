package aethereal;

import java.util.Arrays;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1685;
import net.minecraft.class_1701;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_408;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

public class AutoTotem extends Module {
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("autototem.health", 4.0F, 4.0F, 20.0F, 1.0F)).method1007("Health").method0210("Health threshold to equip totem").method2130("Уровень здоровья для свапа тотема");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("autototem.elytrahealth", 12.0F, 4.0F, 20.0F, 1.0F)).method1007("Elytra Health").method0210("Health threshold to equip totem while wearing elytra").method2130("Уровень здоровья для свапа тотема в элитре");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("autototem.swapback", true)).method1007("Swap Back").method0210("Restore previous offhand item when safe").method2130("Возвращать предмет");
   private final BooleanSetting field0464 = (BooleanSetting)(new BooleanSetting("autototem.noballswitch", false)).method1007("No Ball Switch").method0210("Keep player head in offhand").method2130("Не менять когда голова игрока в левой руке");
   private final BooleanSetting field1619 = (BooleanSetting)(new BooleanSetting("autototem.saveenchanted", true)).method1007("Save Talismans").method0210("Prefer totems without enchants and without attribute modifiers").method2130("Сначала использовать тотемы без чаров и атрибутов");
   private final MultiSelectSetting field1562 = (MultiSelectSetting)(new MultiSelectSetting("autototem.checks", Arrays.asList("GoldenHearts", "Crystals", "RespawnAnchor", "Fall", "TNT", "Trident"), false, () -> true)).method1007("Checks").method0210("Danger checks that trigger totem swap").method2130("Проверки опасности для смены на тотем");
   private final BooleanSetting field1709 = (BooleanSetting)(new BooleanSetting("autototem.bypass", true)).method1007("Bypass").method0210("Use inventory desync to swap while moving").method2130("Десинк инвентаря для смены на ходу");
   private int field1137;
   private int field1088 = -1;
   private int field1197 = 0;
   private boolean field0890;
   public boolean field0169;
   private final Stopwatch field0839 = new Stopwatch();
   private boolean field0931;

   public AutoTotem() {
      super("AutoTotem", ModuleCategory.field0661, "Automatically equips totem of undying in offhand");
      this.method1013("Автоматически берёт тотем в левую руку");
   }

   @EventHandler
   public void onTick(PlayerTickEvent event) {
      if (!method1974()) {
         this.field1197 = InventoryManager.method1217(class_1802.field_8288);
         this.field1137 = (int)field0796.field_1724.field_7512.field_7761.stream().filter((s) -> {
            class_1799 st = s.method_7677();
            return st.method_7909() == class_1802.field_8288 && !st.method_7958() && !method0269(st);
         }).count();
         class_1735 slot = (class_1735)field0796.field_1724.field_7512.field_7761.stream().filter((s) -> s.method_7677().method_7909() == class_1802.field_8288 && this.method1241(s.method_7677())).findFirst().orElse((Object)null);
         if (this.field0839.method0779(400L)) {
            if (this.method2030()) {
               if (slot != null && !this.method1755()) {
                  if (this.method1692()) {
                     this.field0931 = true;
                  } else {
                     if (!field0796.field_1724.method_6079().method_7960() && this.field1088 == -1) {
                        this.field1088 = slot.field_7874;
                     }

                     this.method0766(slot.field_7874, class_1268.field_5810, false);
                     this.field0839.method1812();
                  }
               }
            } else if (this.field1088 != -1 && (Boolean)this.field0184.method0492()) {
               this.method0766(this.field1088, class_1268.field_5810, false);
               this.field1088 = -1;
               this.field0839.method1812();
            }
         }

      }
   }

   public void method0766(int slotId, class_1268 hand, boolean packet) {
      if (slotId != -1) {
         int button = hand == class_1268.field_5808 ? field0796.field_1724.method_31548().field_7545 : 40;
         if ((Boolean)this.field1709.method0492() && MovementHelper.method1635()) {
            InventoryManager.method0996(() -> InventoryManager.method0753(slotId, button, class_1713.field_7791), 0);
         } else {
            InventoryManager.method0753(slotId, button, class_1713.field_7791);
         }

      }
   }

   @EventHandler
   public void onScreenClose(ScreenCloseEvent e) {
      if (!method1974()) {
         if (this.field0931) {
            this.field0931 = false;
            InventoryManager.method0996(() -> {
               class_1735 slot = (class_1735)field0796.field_1724.field_7512.field_7761.stream().filter((s) -> s.method_7677().method_7909() == class_1802.field_8288 && this.method1241(s.method_7677())).findFirst().orElse((Object)null);
               if (slot != null && !this.method1755()) {
                  if (!field0796.field_1724.method_6079().method_7960() && this.field1088 == -1) {
                     this.field1088 = slot.field_7874;
                  }

                  this.method0766(slot.field_7874, class_1268.field_5810, false);
                  this.field0839.method1812();
               }

            }, 0);
         }
      }
   }

   private boolean method1692() {
      if (field0796.field_1755 == null) {
         return false;
      } else if (field0796.field_1755 instanceof class_408) {
         return false;
      } else {
         return !(field0796.field_1755 instanceof ClickGuiScreen);
      }
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound e) {
      if (!method1974()) {
         class_2596 var3 = e.method1970();
         if (var3 instanceof class_2663) {
            class_2663 packet = (class_2663)var3;
            if (packet.method_11470() == 35 && packet.method_11469(field0796.field_1687) == field0796.field_1724) {
               this.field0890 = true;
            }
         }

      }
   }

   private boolean method1755() {
      for(class_1268 hand : class_1268.values()) {
         class_1799 heldItem = field0796.field_1724.method_5998(hand);
         if (heldItem.method_7909() == class_1802.field_8288 && this.method1241(heldItem)) {
            return true;
         }
      }

      return false;
   }

   private boolean method1241(class_1799 stack) {
      if (!(Boolean)this.field1619.method0492()) {
         return true;
      } else if (this.field1137 <= 0) {
         return true;
      } else {
         return !stack.method_7958() && !method0269(stack);
      }
   }

   private static boolean method0269(class_1799 stack) {
      class_9285 c = (class_9285)stack.method_57824(class_9334.field_49636);
      return c != null && !c.comp_2393().isEmpty();
   }

   private boolean method2030() {
      float absorptionAmount = field0796.field_1724.method_6059(class_1294.field_5898) ? field0796.field_1724.method_6067() : 0.0F;
      float currentHealth = field0796.field_1724.method_6032();
      if (this.field1562.method0730(0)) {
         currentHealth += absorptionAmount;
      }

      if (!this.method0399() && this.method2016()) {
         return true;
      } else {
         float threshold = field0796.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833 ? (Float)this.field0985.method0492() : (Float)this.field1450.method0492();
         return currentHealth <= threshold;
      }
   }

   private boolean method2016() {
      return this.method0458() || this.method0472() || this.method2044() || this.method0480() || this.method0406();
   }

   private boolean method2044() {
      if (!this.field1562.method0730(3)) {
         return false;
      } else if (field0796.field_1724.method_5799()) {
         return false;
      } else if (field0796.field_1724.method_6128()) {
         return false;
      } else {
         return field0796.field_1724.field_6017 > 10.0F;
      }
   }

   private boolean method0472() {
      if (!this.field1562.method0730(2)) {
         return false;
      } else {
         return BlockPlacementHelper.method0708(6.0F, class_2246.field_23152) != null;
      }
   }

   private boolean method0458() {
      if (!this.field1562.method0730(1)) {
         return false;
      } else {
         for(class_1297 entity : field0796.field_1687.method_18112()) {
            if (entity instanceof class_1511 && field0796.field_1724.method_5739(entity) <= 6.0F) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean method0480() {
      if (!this.field1562.method0730(4)) {
         return false;
      } else {
         for(class_1297 entity : field0796.field_1687.method_18112()) {
            if ((entity instanceof class_1541 || entity instanceof class_1701) && field0796.field_1724.method_5739(entity) <= 6.0F) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean method0406() {
      if (!this.field1562.method0730(5)) {
         return false;
      } else {
         for(class_1297 entity : field0796.field_1687.method_18112()) {
            if (entity instanceof class_1685) {
               class_1685 trident = (class_1685)entity;
               if (trident.method_24921() != field0796.field_1724 && !(trident.method_18798().method_1027() < 0.010000004307821686) && field0796.field_1724.method_5739(trident) <= 8.0F) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean method0399() {
      boolean isFallingConditionMet = this.field1562.method0730(3) && field0796.field_1724.field_6017 > 5.0F;
      if (isFallingConditionMet) {
         return false;
      } else {
         return (Boolean)this.field0464.method0492() && field0796.field_1724.method_6079().method_7909() == class_1802.field_8575;
      }
   }

   public void method1735() {
      this.field1088 = -1;
      this.field0931 = false;
   }

   public void method1812() {
      super.method1812();
      this.method1735();
   }
}
