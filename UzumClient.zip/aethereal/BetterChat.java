package aethereal;

import java.util.Objects;

public class BetterChat extends Module {
   public final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("betterchat.nobackground", false)).method1007("Fonsiz").method0210("Suhbat xabarlari ortidagi qorong'u foni olib tashlash").method2130("Suhbat fonini olib tashlash");
   public final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("betterchat.timestamp", false)).method1007("Vaqt belgisi").method0210("Har bir suhbat xabaridan oldin vaqtni ko'rsatish").method2130("Xabardan oldin vaqtni ko'rsatish");
   public final BooleanSetting field0970;
   public final BooleanSetting field0184;
   public final FloatSetting field0470;

   public BetterChat() {
      super("BetterChat", ModuleCategory.field1004, "Yaxshilangan suhbat");
      Boolean var10004 = false;
      BooleanSetting var10005 = this.field1432;
      Objects.requireNonNull(var10005);
      this.field0970 = (BooleanSetting)(new BooleanSetting("betterchat.showseconds", var10004, var10005::method0492)).method1007("Soniyalarni ko'rsatish").method0210("Vaqt belgisiga soniyalarni qo'shish").method2130("Soniyalarni chiqarish");
      this.field0184 = (BooleanSetting)(new BooleanSetting("betterchat.animation", false)).method1007("Animatsiya").method0210("Suhbat xabarlarini animatsiya qilish").method2130("Xabarlarning paydo bo'lish animatsiyasi");
      BooleanSetting var10008 = this.field0184;
      Objects.requireNonNull(var10008);
      this.field0470 = (FloatSetting)(new FloatSetting("betterchat.animspeed", 6.0F, 1.0F, 20.0F, 0.5F, var10008::method0492)).method1007("Animatsiya tezligi").method0210("Xabar sirg'alish animatsiyasi tezligi").method2130("Animatsiya tezligi");
      this.method1013("O'yin suhbati uchun turli yaxshilanishlar");
   }
}
