package aethereal;

import lombok.Generated;
import net.minecraft.class_332;

public class PopupManager extends GuiElement {
   private static PopupManager field0634;

   public PopupManager() {
      field0634 = this;
   }

   public void method1973() {
      for(GuiElement drawable : this.method1620()) {
         PopupPanel tooltip = (PopupPanel)drawable;
         if (!tooltip.method1891()) {
            tooltip.method1973();
         }
      }

   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.method1620().isEmpty()) {
         super.method1414(context, mouseX, mouseY, delta);
         this.method1620().removeIf((e) -> {
            PopupPanel tooltip = (PopupPanel)e;
            return tooltip.method1891() ? false : tooltip.method2267();
         });
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      boolean clickedOnTooltip = super.method0627(mouseX, mouseY, button);
      if (!clickedOnTooltip) {
         this.method1620().removeIf((e) -> {
            PopupPanel tooltip = (PopupPanel)e;
            return tooltip.method1891() && !tooltip.method1825((float)mouseX, (float)mouseY);
         });
      }

      return clickedOnTooltip;
   }

   public boolean method0112(double mouseX, double mouseY, int button) {
      boolean result = super.method0112(mouseX, mouseY, button);
      NumberSettingWidget.method1973();
      return result;
   }

   @Generated
   public static PopupManager method0416() {
      return field0634;
   }
}
