package aethereal;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class FriendCommand extends Command {
   public FriendCommand() {
      super("friend", "Manage friend list", "f", "friends");
      this.method1013("Do'stlar ro'yxatini boshqarish");
   }

   private FriendManager method1608() {
      return ArbuzClient.method2004().method1608();
   }

   public void method0800(CommandContext var1) {
      String[] var2 = var1.method1814();
      if (var2.length == 0) {
         this.method1834(var1);
      } else {
         switch (var2[0].toLowerCase()) {
            case "add":
               this.method0803(var1, var2);
               break;
            case "remove":
            case "del":
               this.method0168(var1, var2);
               break;
            case "list":
               this.method0167(var1);
               break;
            case "clear":
               this.method2112(var1);
               break;
            default:
               this.method1834(var1);
         }
      }

   }

   private void method0803(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         var1.method0213("Ishlatish: .friend add <nom>");
      } else {
         String var3 = var2[1];
         if (this.method1608().method2135(var3)) {
            var1.method0213(var3 + " allaqachon do'st");
         } else {
            this.method1608().method1013(var3);
            var1.method1013("Do'st qo'shildi: " + var3);
         }
      }

   }

   private void method0168(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         var1.method0213("Ishlatish: .friend remove <nom>");
      } else {
         String var3 = var2[1];
         if (!this.method1608().method2135(var3)) {
            var1.method0213(var3 + " do'st emas");
         } else {
            this.method1608().method0213(var3);
            var1.method1013("Do'st o'chirildi: " + var3);
         }
      }

   }

   private void method0167(CommandContext var1) {
      List var2 = this.method1608().method0424();
      if (var2.isEmpty()) {
         var1.method2134("Do'stlar ro'yxati bo'sh");
      } else {
         var1.method2134("Do'stlar (" + var2.size() + "):");
         var2.forEach((var1x) -> var1.method1846("- " + String.valueOf(var1x)));
      }

   }

   private void method2112(CommandContext var1) {
      int var2 = this.method1608().method0424().size();
      this.method1608().method2078();
      var1.method1013("Tozalandi " + var2 + " do'stlar");
   }

   public List<String> method1593(String[] var1) {
      if (var1.length <= 1) {
         String var5 = var1.length == 1 ? var1[0].toLowerCase() : "";
         return List.of("add", "remove", "list", "clear").stream().filter((var1x) -> var1x.startsWith(var5)).toList();
      } else if (var1.length == 2 && var1[0].equalsIgnoreCase("add")) {
         String var4 = var1[1].toLowerCase();
         class_310 var3 = class_310.method_1551();
         return var3.method_1562() != null ? var3.method_1562().method_2880().stream().map((var0) -> var0.method_2966().getName()).filter((var1x) -> var1x.toLowerCase().startsWith(var4)).filter((var1x) -> !this.method1608().method2135(var1x)).toList() : List.of();
      } else if (var1.length == 2 && (var1[0].equalsIgnoreCase("remove") || var1[0].equalsIgnoreCase("del"))) {
         String var2 = var1[1].toLowerCase();
         return this.method1608().method0424().stream().filter((var1x) -> var1x.toLowerCase().startsWith(var2)).toList();
      } else {
         return List.of();
      }
   }

   public String method2179(String[] var1) {
      if (var1.length == 2) {
         String var10000;
         switch (var1[0].toLowerCase()) {
            case "add":
            case "remove":
            case "del":
               var10000 = "<nom>";
               break;
            default:
               var10000 = "";
         }

         return var10000;
      } else {
         return "";
      }
   }

   public Map<String, String> method0351(String[] var1) {
      return var1.length <= 1 ? Map.of("add", "Do'st qo'shish", "remove", "Do'stni o'chirish", "list", "Do'stlarni ko'rsatish", "clear", "Barcha do'stlarni tozalash") : Map.of();
   }

   private void method1834(CommandContext var1) {
      String var2 = ArbuzClient.method2004().method2257().method2067();
      var1.method0297(class_2561.method_43470("Do'st buyruqlari:").method_27694((var0) -> var0.method_36139(8947848)));
      var1.method0297(class_2561.method_43470(var2 + "friend add <nom>").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Do'st qo'shish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(var2 + "friend remove <nom>").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Do'stni o'chirish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(var2 + "friend list").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Do'stlarni ko'rsatish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(var2 + "friend clear").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Barcha do'stlarni tozalash").method_27694((var0) -> var0.method_36139(7829367))));
   }
}
