package aethereal;

import lombok.Generated;

public enum ModuleCategory {
   field0661("v", "V"),
   field0088("b", "K"),
   field1470("o", "L"),
   field1004("p", "B"),
   field0776("n", "Z");

   private final String field1269;
   private final String field0336;

   @Generated
   private ModuleCategory(String var3, String var4) {
      this.field1269 = var3;
      this.field0336 = var4;
   }

   @Generated
   public String method0557() {
      return this.field1269;
   }

   @Generated
   public String method0017() {
      return this.field0336;
   }

   public String getDisplayName() {
      String var10000;
      switch (this.ordinal()) {
         case 0 -> var10000 = "Jang";
         case 1 -> var10000 = "Harakat";
         case 2 -> var10000 = "O'yinchi";
         case 3 -> var10000 = "Ko'rish";
         case 4 -> var10000 = "Boshqa";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   // $FF: synthetic method
   private static ModuleCategory[] $values() {
      return new ModuleCategory[]{field0661, field0088, field1470, field1004, field0776};
   }
}
