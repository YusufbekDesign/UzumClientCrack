package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public final class MsdfFontRenderer {
   private final String field0715;
   private final class_1044 field0147;
   private final MsdfFontMetadata.Metrics field1461;
   private final MsdfFontMetadata.KerningPair field0996;
   private final Map<Integer, MsdfGlyphRenderer> field0794;
   private final Map<Integer, Map<Integer, Float>> field1270;

   private MsdfFontRenderer(String name, class_1044 texture, MsdfFontMetadata.Metrics atlas, MsdfFontMetadata.KerningPair metrics, Map<Integer, MsdfGlyphRenderer> glyphs, Map<Integer, Map<Integer, Float>> kernings) {
      this.field0715 = name;
      this.field0147 = texture;
      this.field1461 = atlas;
      this.field0996 = metrics;
      this.field0794 = glyphs;
      this.field1270 = kernings;
   }

   public int method0531() {
      return this.field0147.method_4624();
   }

   public void method0025() {
      this.field0147.method_4527(true, false);
   }

   public void method1565(Matrix4f matrix, class_4588 consumer, String text, float size, float thickness, float spacing, float x, float y, float z, int color) {
      int prevChar = -1;

      for(int i = 0; i < text.length(); ++i) {
         int _char = text.charAt(i);
         MsdfGlyphRenderer glyph = (MsdfGlyphRenderer)this.field0794.get(_char);
         if (glyph != null) {
            Map<Integer, Float> kerning = (Map)this.field1270.get(prevChar);
            if (kerning != null) {
               x += (Float)kerning.getOrDefault(_char, 0.0F) * size;
            }

            x += glyph.method1564(matrix, consumer, size, x, y, z, color) + thickness + spacing;
            prevChar = _char;
         }
      }

   }

   public float method1016(String text, float size) {
      int prevChar = -1;
      float width = 0.0F;

      for(int i = 0; i < text.length(); ++i) {
         int _char = text.charAt(i);
         MsdfGlyphRenderer glyph = (MsdfGlyphRenderer)this.field0794.get(_char);
         if (glyph != null) {
            Map<Integer, Float> kerning = (Map)this.field1270.get(prevChar);
            if (kerning != null) {
               width += (Float)kerning.getOrDefault(_char, 0.0F) * size;
            }

            width += glyph.method0645(size) * 1.05F;
            prevChar = _char;
         }
      }

      return width;
   }

   public float method1017(String text, float size, float thickness) {
      int prevChar = -1;
      float width = 0.0F;

      for(int i = 0; i < text.length(); ++i) {
         int _char = text.charAt(i);
         MsdfGlyphRenderer glyph = (MsdfGlyphRenderer)this.field0794.get(_char);
         if (glyph != null) {
            Map<Integer, Float> kerning = (Map)this.field1270.get(prevChar);
            if (kerning != null) {
               width += (Float)kerning.getOrDefault(_char, 0.0F) * size;
            }

            width += glyph.method0645(size) + thickness * size;
            prevChar = _char;
         }
      }

      return width;
   }

   public float method0645(float size) {
      return (this.field0996.method0002() * size + Math.abs(this.field0996.method2047() * size)) * 1.05F;
   }

   public String method2067() {
      return this.field0715;
   }

   public MsdfFontMetadata.Metrics method1777() {
      return this.field1461;
   }

   public MsdfFontMetadata.KerningPair method1610() {
      return this.field0996;
   }

   public static TextBatch method1952() {
      return new TextBatch();
   }

   public static class TextBatch {
      private String field0715 = "?";
      private class_2960 field0160;
      private class_2960 field1522;

      private TextBatch() {
      }

      public TextBatch method1003(String name) {
         this.field0715 = name;
         return this;
      }

      public TextBatch method0209(String dataFileName) {
         this.field0160 = ArbuzClient.method1012("fonts/" + dataFileName + ".json");
         return this;
      }

      public TextBatch method2128(String atlasFileName) {
         this.field1522 = ArbuzClient.method1012("fonts/" + atlasFileName + ".png");
         return this;
      }

      public MsdfFontRenderer method0542() {
         MsdfFontMetadata data = (MsdfFontMetadata)ResourceHelper.method1392(this.field0160, MsdfFontMetadata.class);
         class_1044 texture = class_310.method_1551().method_1531().method_4619(this.field1522);
         if (data == null) {
            throw new RuntimeException("Failed to read font data file: " + this.field0160.toString() + "; Are you sure this is json file? Try to check the correctness of its syntax.");
         } else {
            RenderSystem.recordRenderCall(() -> texture.method_4527(true, false));
            float aWidth = data.method0541().method0002();
            float aHeight = data.method0541().method2047();
            Map<Integer, MsdfGlyphRenderer> glyphs = (Map)data.method2068().stream().collect(Collectors.toMap((glyphData) -> glyphData.method0531(), (glyphData) -> new MsdfGlyphRenderer(glyphData, aWidth, aHeight)));
            Map<Integer, Map<Integer, Float>> kernings = new HashMap();
            data.method1793().forEach((kerning) -> {
               Map<Integer, Float> map = (Map)kernings.get(kerning.method0531());
               if (map == null) {
                  map = new HashMap();
                  kernings.put(kerning.method0531(), map);
               }

               map.put(kerning.method0003(), kerning.method2047());
            });
            return new MsdfFontRenderer(this.field0715, texture, data.method0541(), data.method0009(), glyphs, kernings);
         }
      }
   }
}
