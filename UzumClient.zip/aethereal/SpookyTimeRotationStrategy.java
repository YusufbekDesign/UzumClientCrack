package aethereal;

import java.security.SecureRandom;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class SpookyTimeRotationStrategy extends RotationStrategy {
   private static final float EPSILON = 0.5F;
   private static final long RELEASE_HOLD_MS = 150L;
   private static final long RELEASE_SLOWDOWN_MS = 100L;
   private static final float SHAKE_INTENSITY = 0.5F;
   private static final float SHAKE_SPEED = 2.0F;
   private static final SecureRandom RANDOM = new SecureRandom();
   private boolean releaseHoldActive = false;
   private long releaseHoldUntil = 0L;
   private boolean releaseSlowdownActive = false;
   private long releaseSlowdownStart = 0L;
   private Rotation releaseFromAngle;
   private Rotation releaseToAngle;
   private boolean hadTargetLastTick = false;
   private boolean auraEnabledLastTick = false;
   private final Random random1 = new Random();

   public SpookyTimeRotationStrategy() {
      super("SpookyTime");
   }

   public Rotation method0874(Rotation var1, Rotation var2, class_243 var3, class_1297 var4) {
      boolean auraEnabled = var4 != null;
      long now = System.currentTimeMillis();
      if (!auraEnabled) {
         this.resetState();
         return var1.method0545();
      } else {
         boolean tightSpace = this.isInTightSpace();
         if (auraEnabled) {
            this.hadTargetLastTick = true;
            this.auraEnabledLastTick = true;
            this.resetReleaseState();
            float yawDelta = class_3532.method_15393(var2.method2047() - var1.method2047());
            float pitchDelta = var2.method1762() - var1.method1762();
            float totalDelta = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
            float spaceMultiplier = tightSpace ? 0.4F : 1.0F;
            float yawLimit = Math.min(Math.abs(yawDelta), (45.0F + this.randomBetween(0.0F, 0.5F)) * spaceMultiplier);
            float pitchLimit = Math.abs(pitchDelta) < 20.0F * spaceMultiplier ? Math.abs(pitchDelta) : 20.0F * spaceMultiplier;
            Rotation result = new Rotation(var1.method2047(), var1.method1762());
            if (totalDelta > 0.5F) {
               boolean pitchLimitReached = Math.abs(pitchDelta) >= pitchLimit;
               float baseSpeed = tightSpace ? this.randomBetween(3.0F, 5.0F) : this.randomBetween(6.0F, 9.0F);
               float fastSpeed = tightSpace ? this.randomBetween(12.0F, 18.0F) : this.randomBetween(25.0F, 35.0F);
               float pitchMaxStep = pitchLimitReached ? fastSpeed : baseSpeed;
               float pitchStep = Math.min(totalDelta, pitchMaxStep);
               float pitchScale = pitchStep / totalDelta;
               if (!pitchLimitReached) {
                  pitchScale = this.easeTowardsTarget(pitchScale);
               }

               float maxPitchChange = tightSpace ? 3.0F : 15.0F;
               float pitchChange = class_3532.method_15363(pitchDelta * pitchScale, -maxPitchChange, maxPitchChange);
               result.method1638(class_3532.method_15363(var1.method1762() + pitchChange, -89.0F, 90.0F));
            }

            if (totalDelta > 0.5F) {
               boolean yawLimitReached = Math.abs(yawDelta) >= yawLimit;
               float baseSpeed = tightSpace ? this.randomBetween(3.0F, 5.0F) : this.randomBetween(6.0F, 9.0F);
               float fastSpeed = tightSpace ? this.randomBetween(12.0F, 18.0F) : this.randomBetween(25.0F, 35.0F);
               float yawMaxStep = yawLimitReached ? fastSpeed : baseSpeed;
               float yawStep = Math.min(totalDelta, yawMaxStep);
               float yawScale = yawStep / totalDelta;
               if (!yawLimitReached) {
                  yawScale = this.easeTowardsTarget(yawScale);
               }

               result.method1822(var1.method2047() + yawDelta * yawScale);
            }

            if (totalDelta < 5.0F) {
               this.applyShake(result, tightSpace ? 0.3F : 1.0F);
            }

            return result.method0545();
         } else {
            boolean lostTargetThisTick = this.hadTargetLastTick;
            boolean auraDisabledThisTick = this.auraEnabledLastTick && !auraEnabled;
            if ((lostTargetThisTick || auraDisabledThisTick) && !this.releaseHoldActive && !this.releaseSlowdownActive) {
               this.releaseHoldActive = true;
               this.releaseHoldUntil = now + 150L;
               this.releaseSlowdownActive = false;
               this.releaseSlowdownStart = 0L;
               this.releaseFromAngle = new Rotation(var1.method2047(), var1.method1762());
               this.releaseToAngle = var2 != null ? new Rotation(var2.method2047(), var2.method1762()) : new Rotation(var1.method2047(), var1.method1762());
            }

            this.hadTargetLastTick = false;
            this.auraEnabledLastTick = auraEnabled;
            if (this.releaseHoldActive && now < this.releaseHoldUntil) {
               Rotation frozen = this.releaseFromAngle != null ? this.releaseFromAngle : new Rotation(var1.method2047(), var1.method1762());
               return (new Rotation(frozen.method2047(), frozen.method1762())).method0545();
            } else {
               if (this.releaseHoldActive && !this.releaseSlowdownActive) {
                  this.releaseSlowdownActive = true;
                  this.releaseSlowdownStart = now;
               }

               if (!this.releaseSlowdownActive) {
                  return var2 != null ? var2.method0545() : var1.method0545();
               } else {
                  float progress = class_3532.method_15363((float)(now - this.releaseSlowdownStart) / 100.0F, 0.0F, 1.0F);
                  float eased = this.easeTowardsTarget(progress);
                  Rotation from = this.releaseFromAngle != null ? this.releaseFromAngle : var1;
                  Rotation to = this.releaseToAngle != null ? this.releaseToAngle : (var2 != null ? var2 : var1);
                  Rotation interpolated = new Rotation(this.lerpAngle(eased, from.method2047(), to.method2047()), class_3532.method_15363(class_3532.method_16439(eased, from.method1762(), to.method1762()), -89.0F, 90.0F));
                  if (progress >= 1.0F) {
                     this.resetReleaseState();
                  }

                  return interpolated.method0545();
               }
            }
         }
      }
   }

   public class_243 method0569() {
      return new class_243(0.04, 0.06, 0.04);
   }

   private boolean isInTightSpace() {
      try {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            class_2338 pos = class_2338.method_49638(field0796.field_1724.method_19538());
            boolean blockAbove = !field0796.field_1687.method_8320(pos.method_10069(0, 1, 0)).method_26215();
            boolean blockLeft = !field0796.field_1687.method_8320(pos.method_10069(-1, 0, 0)).method_26215();
            boolean blockRight = !field0796.field_1687.method_8320(pos.method_10069(1, 0, 0)).method_26215();
            boolean blockFront = !field0796.field_1687.method_8320(pos.method_10069(0, 0, -1)).method_26215();
            boolean blockBack = !field0796.field_1687.method_8320(pos.method_10069(0, 0, 1)).method_26215();
            return blockAbove || blockLeft || blockRight || blockFront || blockBack;
         } else {
            return false;
         }
      } catch (Exception var7) {
         return false;
      }
   }

   private void applyShake(Rotation angle, float multiplier) {
      float time = (float)(System.currentTimeMillis() % 12000L) / 1200.0F;
      float swayPhase = time * 2.0F * ((float)Math.PI * 2F);
      float swayYaw = (float)(Math.sin((double)swayPhase) * (double)0.5F * (double)multiplier * ((double)0.5F + this.random1.nextDouble() * (double)0.5F));
      angle.method1822(angle.method2047() + swayYaw);
   }

   private float easeTowardsTarget(float t) {
      return t * (0.5F + 0.5F * t);
   }

   private float lerpAngle(float delta, float start, float end) {
      return start + class_3532.method_15393(end - start) * delta;
   }

   private void resetState() {
      this.releaseHoldActive = false;
      this.releaseHoldUntil = 0L;
      this.releaseSlowdownActive = false;
      this.releaseSlowdownStart = 0L;
      this.releaseFromAngle = null;
      this.releaseToAngle = null;
      this.hadTargetLastTick = false;
      this.auraEnabledLastTick = false;
   }

   private void resetReleaseState() {
      this.releaseHoldActive = false;
      this.releaseHoldUntil = 0L;
      this.releaseSlowdownActive = false;
      this.releaseSlowdownStart = 0L;
      this.releaseFromAngle = null;
      this.releaseToAngle = null;
   }

   private float randomBetween(float min, float max) {
      return class_3532.method_16439(RANDOM.nextFloat(), min, max);
   }
}
