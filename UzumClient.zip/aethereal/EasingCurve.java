package aethereal;

import java.util.function.Function;
import lombok.Generated;

public enum EasingCurve {
   field0672((var0) -> var0),
   field0100((var0) -> -(Math.cos(3.1415933129662683 * var0) - (double)1.0F) / (double)2.0F),
   field1477((var0) -> var0 < (double)0.5F ? ((double)1.0F - Math.sqrt((double)1.0F - Math.pow((double)2.0F * var0, (double)2.0F))) / (double)2.0F : (Math.sqrt((double)1.0F - Math.pow((double)-2.0F * var0 + (double)2.0F, (double)2.0F)) + (double)1.0F) / (double)2.0F),
   field1011((var0) -> var0 < (double)0.5F ? (double)4.0F * var0 * var0 * var0 : (double)1.0F - Math.pow((double)-2.0F * var0 + (double)2.0F, (double)3.0F) / (double)2.0F),
   field0779((var0) -> var0 < (double)0.5F ? (double)8.0F * var0 * var0 * var0 * var0 : (double)1.0F - Math.pow((double)-2.0F * var0 + (double)2.0F, (double)4.0F) / (double)2.0F),
   field1262((var0) -> (double)1.0F + 2.7015783687885104 * Math.pow(var0 - (double)1.0F, (double)3.0F) + 1.7015800377204118 * Math.pow(var0 - (double)1.0F, (double)2.0F)),
   field0330((var0) -> Math.sqrt((double)1.0F - Math.pow(var0 - (double)1.0F, (double)2.0F))),
   field0203((var0) -> (double)1.0F - Math.pow((double)1.0F - var0, (double)3.0F)),
   field0482((var0) -> (double)-2.0F * Math.pow(var0, (double)3.0F) + (double)3.0F * Math.pow(var0, (double)2.0F)),
   field1638((var0) -> (double)3.0F * Math.pow((double)1.0F - var0, (double)2.0F) * var0 * -0.19999997782436657 + (double)3.0F * ((double)1.0F - var0) * Math.pow(var0, (double)2.0F) * (double)1.5F + Math.pow(var0, (double)3.0F));

   private final Function<Double, Double> field1568;

   public double method0608(double var1) {
      return (Double)this.field1568.apply(var1);
   }

   @Generated
   private EasingCurve(Function<Double, Double> var3) {
      this.field1568 = var3;
   }

   // $FF: synthetic method
   private static EasingCurve[] $values() {
      return new EasingCurve[]{field0672, field0100, field1477, field1011, field0779, field1262, field0330, field0203, field0482, field1638};
   }
}
