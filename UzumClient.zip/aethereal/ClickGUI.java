package aethereal;

import lombok.Generated;

public class ClickGUI extends Module {
   private static ClickGUI field0041;
   private final EnumSetting<AnimationStyle> field1448;

   public ClickGUI() {
      super("ClickGUI", ModuleCategory.field0776, "Modul sozlash menyusini ochadi");
      this.field1448 = (EnumSetting)(new EnumSetting("clickgui.animationtype", ClickGUI.AnimationStyle.field0040)).method1007("Animatsiya turi").method0210("GUI open/close animation style").method2130("Menyu ochish/yopish animatsiya usuli");
      this.method1013("Modul sozlash menyusini ochadi");
      field0041 = this;
      this.method2178(false);
   }

   public AnimationStyle method1706() {
      return (AnimationStyle)this.field1448.method0492();
   }

   @Generated
   public static ClickGUI method1683() {
      return field0041;
   }

   public static enum AnimationStyle implements DisplayNamed {
      field0603("Default"),
      field0040("MacOS");

      private final String field1504;

      private AnimationStyle(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static AnimationStyle[] $values() {
         return new AnimationStyle[]{field0603, field0040};
      }
   }
}
