package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

public final class BetterF5 extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("betterf5.distance", 8.5F, 2.0F, 15.0F, 0.5F)).method1007("Masofa").method0210("Kamera o'yinchidan masofasi").method2130("Kamera o'yinchidan masofasi");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("betterf5.height", 0.1F, -2.0F, 3.0F, 0.1F)).method1007("Balandlik").method0210("Kamera balandlik siljishi").method2130("Kamera balandlik siljishi");
   private static final float field0957 = 0.08F;
   private static final float field0177 = 0.12F;
   private static final float field0458 = 0.05F;
   private static final float field1614 = 0.4F;
   private static final float field1538 = 0.8F;
   private static final float field1704 = 0.5F;
   private static final float field1136 = 100.0F;
   private static final float field1087 = 0.25F;
   private static final float field1196 = 40.0F;
   private static final float field0871 = 0.6F;
   private static final float field0826 = 0.06F;
   private double field0909;
   private double field1330;
   private double field1291;
   private double field1368;
   private double field0384;
   private float field0351;
   private double field0422;
   private double field0254;
   private float field0226;
   private long field0291;
   private class_5498 field0537;
   private boolean field0514;
   private long field0549;
   private boolean field1683;

   public BetterF5() {
      super("BetterF5", ModuleCategory.field1004, "Yaxshilangan uchinchi shaxs kamerasi boshqaruvi");
      this.field0537 = class_5498.field_26664;
      this.field0514 = true;
      this.field1683 = false;
      this.method1013("Uchinchi shaxs kamerasini yaxshilangan boshqaruv");
      ArbuzClient.method2004().method2072().subscribe(this);
   }

   public void method0025() {
      super.method0025();
      this.method1735();
   }

   public void method2078() {
      this.method1735();
      super.method2078();
   }

   @EventHandler
   public void onJump(JumpEvent var1) {
      if (this.field0751) {
         this.field0291 = System.currentTimeMillis();
      }

   }

   @EventHandler
   public void onCameraUpdate(CameraEvent var1) {
      if (!this.field0751) {
         this.method1735();
      } else {
         class_5498 var2 = field0796.field_1690.method_31044();
         if (var2 != this.field0537) {
            if (var2 != class_5498.field_26664) {
               this.field0514 = true;
            }

            this.field0537 = var2;
         }

         if (var2 != class_5498.field_26664) {
            long var3 = System.currentTimeMillis();
            float var5 = this.field0549 == 0L ? 0.016F : class_3532.method_15363((float)(var3 - this.field0549) / 1000.0F, 0.001F, 0.1F);
            this.field0549 = var3;
            class_1297 var71 = var1.method1807().method_19331();
            if (var71 instanceof class_1657) {
               class_1657 var7 = (class_1657)var71;
               if (this.field0514) {
                  this.method0797(var1);
                  this.field0514 = false;
               }

               this.method1182(var7);
               this.method0665(var5);
               this.method0798(var1, var7);
            }
         }
      }

   }

   private void method0797(CameraEvent var1) {
      float var2 = (Float)this.field0060.method0492();
      float var3 = (Float)this.field1450.method0492();
      this.field0909 = (double)var2;
      this.field1330 = (double)var3;
      this.field1291 = var1.method1945();
      this.field1368 = var1.method0412();
      this.field0384 = var1.method0354();
      this.field0351 = 0.0F;
      this.field0422 = (double)var2;
      this.field0254 = (double)var3;
      this.field0226 = 0.0F;
      this.field0291 = 0L;
      this.field0549 = System.currentTimeMillis();
   }

   private void method1182(class_1657 var1) {
      float var2 = (Float)this.field0060.method0492();
      float var3 = (Float)this.field1450.method0492();
      boolean var4 = field0796.field_1690.method_31044() == class_5498.field_26666;
      double var5 = (double)var2;
      double var7 = (double)var3;
      float var9 = 0.0F;
      double var10 = CameraMath.method1177(var1);
      if (CameraMath.method1855(var1)) {
         double var12 = class_3532.method_15350(var10 / 0.30000002483330174, (double)0.0F, (double)1.0F);
         if (var4) {
            var5 += 1.2000005543231964 * CameraMath.method0102(var12);
         } else {
            var5 += (double)0.7999999F * CameraMath.method0102(var12);
         }
      } else if (var10 > 0.010000003756227357) {
         double var18 = class_3532.method_15350(var10 / 0.1500000901677722, (double)0.0F, (double)1.0F);
         if (var4) {
            var5 += 0.47999983021081966 * CameraMath.method2085(var18);
         } else {
            var5 += (double)0.4F * CameraMath.method2085(var18);
         }
      }

      long var19 = System.currentTimeMillis() - this.field0291;
      if ((float)var19 > 100.0F && (float)var19 < 700.0F) {
         double var14 = (double)((float)var19 - 100.0F) / (double)600.0F;
         double var16 = CameraMath.method0102(var14) * ((double)1.0F - CameraMath.method0608(var14));
         var7 += (double)0.5F * var16 * (double)2.0F;
      }

      if (CameraMath.method1664(var1)) {
         double var20 = class_3532.method_15350(Math.abs(var1.method_18798().field_1351) / (double)0.5F, (double)0.0F, (double)1.0F);
         var7 += (double)0.25F * CameraMath.method0102(var20);
      }

      if (CameraMath.method1991(var1)) {
         double var21 = class_3532.method_15350(var1.method_18798().field_1351 / 0.39999996007461613, (double)0.0F, (double)1.0F);
         var7 += 0.1500000901677722 * var21;
      }

      this.field1683 = CameraMath.method0579();
      if (this.field1683) {
         class_2338 var22 = CameraMath.method0022();
         class_2350 var15 = CameraMath.method2076();
         if (var22 != null && var15 != null) {
            float var10000;
            switch (var15) {
               case field_11043:
               case field_11034:
                  var10000 = -40.0F;
                  break;
               case field_11035:
               case field_11039:
                  var10000 = 40.0F;
                  break;
               default:
                  var10000 = var1.field_6283 > var1.method_36454() ? -40.0F : 40.0F;
            }

            var9 = var10000;
            var5 += (double)0.60000026F;
            var7 += 0.1500000901677722;
         }
      }

      this.field0422 = var5;
      this.field0254 = var7;
      this.field0226 = var9;
   }

   private void method0665(float var1) {
      double var2 = this.field1683 ? (double)0.06F : (double)0.08000003F;
      double var4 = (double)1.0F / (var2 * (double)10.0F);
      double var6 = (double)2.0F;
      if (Math.abs(this.field0909 - this.field0422) > 9.99999425615245E-4) {
         this.field0909 = CameraMath.method2090(this.field0909, this.field0422, var6, (double)var1);
         if (Math.abs(this.field0909 - this.field0422) < 9.99999425615245E-4) {
            this.field0909 = this.field0422;
         }
      }

      if (Math.abs(this.field1330 - this.field0254) > 9.99999425615245E-4) {
         this.field1330 = CameraMath.method2090(this.field1330, this.field0254, var4, (double)var1);
         if (Math.abs(this.field1330 - this.field0254) < 9.99999425615245E-4) {
            this.field1330 = this.field0254;
         }
      }

      if ((double)Math.abs(this.field0351 - this.field0226) > 0.010000003756227357) {
         this.field0351 = (float)CameraMath.method2090((double)this.field0351, (double)this.field0226, var4, (double)var1);
         if ((double)Math.abs(this.field0351 - this.field0226) < 0.010000003756227357) {
            this.field0351 = this.field0226;
         }
      }

   }

   private void method0798(CameraEvent var1, class_1657 var2) {
      var1.method0665((float)this.field0909);
      double var3 = var1.method1945();
      double var5 = var1.method0412() + this.field1330;
      double var7 = var1.method0354();
      double var9 = 0.8333331447600631;
      if (Math.abs(var3 - this.field1291) > 9.99999425615245E-4 || Math.abs(var5 - this.field1368) > 9.99999425615245E-4 || Math.abs(var7 - this.field0384) > 9.99999425615245E-4) {
         this.field1291 = CameraMath.method2090(this.field1291, var3, var9, (double)0.01599999F);
         this.field1368 = CameraMath.method2090(this.field1368, var5, var9, (double)0.01599999F);
         this.field0384 = CameraMath.method2090(this.field0384, var7, var9, (double)0.01599999F);
         if (Math.abs(var3 - this.field1291) < 9.99999425615245E-4) {
            this.field1291 = var3;
         }

         if (Math.abs(var5 - this.field1368) < 9.99999425615245E-4) {
            this.field1368 = var5;
         }

         if (Math.abs(var7 - this.field0384) < 9.99999425615245E-4) {
            this.field0384 = var7;
         }
      }

      var1.method0611(this.field1291);
      var1.method0103(this.field1368);
      var1.method2086(this.field0384);
      if (Math.abs(this.field0351) > 0.5F) {
         var1.method0675(var1.method0483() + this.field0351, var1.method2213());
      }

   }

   private void method1735() {
      float var1 = (Float)this.field0060.method0492();
      float var2 = (Float)this.field1450.method0492();
      this.field0909 = (double)var1;
      this.field1330 = (double)var2;
      this.field1291 = (double)0.0F;
      this.field1368 = (double)0.0F;
      this.field0384 = (double)0.0F;
      this.field0351 = 0.0F;
      this.field0422 = (double)var1;
      this.field0254 = (double)var2;
      this.field0226 = 0.0F;
      this.field0291 = 0L;
      this.field0514 = true;
      this.field0549 = 0L;
      this.field1683 = false;
   }
}
