package aethereal;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_239.class_240;

public class BlockOverlay extends Module {
   private final EnumSetting<RenderMode> field0058;
   private final ColorSetting field1443;
   private final BooleanSetting field0970;
   private final FloatSetting field0190;
   private final EnumSetting<BlockShaderRenderer.ShaderType> field0469;
   private final FloatSetting field1627;
   private final BlockShaderRenderer field1546;
   private class_238 field1732;
   private long field1138;

   public BlockOverlay() {
      super("BlockOverlay", ModuleCategory.field1004, "Blok tanlash qoplamasini sozlaydi");
      this.field0058 = (EnumSetting)(new EnumSetting("blockoverlay.mode", BlockOverlay.RenderMode.field0597)).method1007("Rejim").method0210("Ko'rinish uslubi").method2130("Chizish uslubi");
      this.field1443 = (ColorSetting)(new ColorSetting("blockoverlay.color", 74, 214, 160, 180, () -> this.field0058.method0492() != BlockOverlay.RenderMode.field0969)).method1882().method1007("Rang").method0210("Asosiy qoplama rangi").method2130("Asosiy rang");
      this.field0970 = (BooleanSetting)(new BooleanSetting("blockoverlay.grid", false, () -> this.field0058.method0492() != BlockOverlay.RenderMode.field0969)).method1007("Setka").method0210("Blok yuzalariga setka chiziq chizish").method2130("Yuzalardagi setkalar");
      this.field0190 = (FloatSetting)(new FloatSetting("blockoverlay.gridStep", 4.0F, 2.0F, 16.0F, 1.0F, () -> (Boolean)this.field0970.method0492() && this.field0058.method0492() != BlockOverlay.RenderMode.field0969)).method1007("Setka kataklari").method0210("Har bir yuz uchun setka kataklari soni").method2130("Setka kataklari soni");
      this.field0469 = (EnumSetting)(new EnumSetting("blockoverlay.shadertype", BlockShaderRenderer.ShaderType.field0615, () -> this.field0058.method0492() == BlockOverlay.RenderMode.field0969)).method1007("Shader turi").method0210("Qaysi shader effektini ishlatish").method2130("Qaysi shader effektini ishlatish");
      this.field1627 = (FloatSetting)(new FloatSetting("blockoverlay.animspeed", 15.0F, 10.0F, 40.0F, 1.0F)).method1007("O'tish tezligi").method0210("Qoplama bloklar orasida qanchalik tez sirg'aladi").method2130("O'tish animatsiyasi tezligi");
      this.field1546 = new BlockShaderRenderer();
      this.method1013("Nişanlaganda blok konturining vizual ko'rinishini yaxshilaydi");
      this.method0213("B");
   }

   public void method2078() {
      super.method2078();
      this.field1732 = null;
      this.field1138 = 0L;
      this.field1546.method0578();
   }

   @EventHandler
   public void onRender3DWorld(WorldRenderEvent.WorldPass var1) {
      if (!method1974()) {
         class_238 var2 = this.method1733();
         class_238 var3 = this.method1282(var2);
         if (var3 != null) {
            RenderMode var4 = (RenderMode)this.field0058.method0492();
            if (var4 != BlockOverlay.RenderMode.field0969) {
               class_4587 var5 = new class_4587();
               Color var6 = this.field1443.method1726();
               if (var4 == BlockOverlay.RenderMode.field0033 || var4 == BlockOverlay.RenderMode.field1431) {
                  int var7 = Math.max(20, var6.getAlpha() / 3);
                  Color var8 = new Color(var6.getRed(), var6.getGreen(), var6.getBlue(), var7);
                  WorldRenderHelper.method1498(var5, var3, var8);
               }

               if (var4 == BlockOverlay.RenderMode.field0597 || var4 == BlockOverlay.RenderMode.field1431) {
                  WorldRenderHelper.method2173(var5, var3, var6);
               }

               if ((Boolean)this.field0970.method0492()) {
                  this.method1498(var5, var3, var6);
               }
            }
         }
      }

   }

   @EventHandler
   public void onRender3DGame(WorldRenderEvent.GamePass var1) {
      if (!method1974() && this.field0058.method0492() == BlockOverlay.RenderMode.field0969 && this.field1732 != null) {
         float var2 = (float)System.nanoTime() / 1.0E9F * 1.5F;
         Color var3 = ThemeColorManager.method1908().method2063();
         this.field1546.method1285(this.field1732, var3, var2, 2.0F, (BlockShaderRenderer.ShaderType)this.field0469.method0492());
      }

   }

   private class_238 method1733() {
      class_239 var2 = field0796.field_1765;
      if (var2 instanceof class_3965 var1) {
         if (var1.method_17783() != class_240.field_1332) {
            return null;
         } else {
            class_2338 var4 = var1.method_17777();
            class_265 var3 = field0796.field_1687.method_8320(var4).method_26218(field0796.field_1687, var4);
            return var3.method_1110() ? null : var3.method_1107().method_996(var4);
         }
      } else {
         return null;
      }
   }

   private class_238 method1282(class_238 var1) {
      long var2 = System.nanoTime();
      float var4 = this.field1138 == 0L ? 0.016666668F : Math.min(0.5F, (float)(var2 - this.field1138) / 1.0E9F);
      this.field1138 = var2;
      if (var1 == null) {
         this.field1732 = null;
         return null;
      } else if (this.field1732 == null) {
         this.field1732 = var1;
         return this.field1732;
      } else {
         float var5 = 1.0F - (float)Math.exp((double)(-(Float)this.field1627.method0492() * var4));
         var5 = class_3532.method_15363(var5, 0.0F, 1.0F);
         this.field1732 = new class_238(class_3532.method_16436((double)var5, this.field1732.field_1323, var1.field_1323), class_3532.method_16436((double)var5, this.field1732.field_1322, var1.field_1322), class_3532.method_16436((double)var5, this.field1732.field_1321, var1.field_1321), class_3532.method_16436((double)var5, this.field1732.field_1320, var1.field_1320), class_3532.method_16436((double)var5, this.field1732.field_1325, var1.field_1325), class_3532.method_16436((double)var5, this.field1732.field_1324, var1.field_1324));
         return this.field1732;
      }
   }

   private void method1498(class_4587 var1, class_238 var2, Color var3) {
      int var4 = ((Float)this.field0190.method0492()).intValue();
      if (var4 >= 2) {
         double var5 = (var2.field_1320 - var2.field_1323) / (double)var4;
         double var7 = (var2.field_1325 - var2.field_1322) / (double)var4;
         double var9 = (var2.field_1324 - var2.field_1321) / (double)var4;
         Color var11 = new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), Math.max(40, var3.getAlpha() / 2));

         for(int var12 = 1; var12 < var4; ++var12) {
            double var13 = var2.field_1323 + var5 * (double)var12;
            double var15 = var2.field_1322 + var7 * (double)var12;
            double var17 = var2.field_1321 + var9 * (double)var12;
            WorldRenderHelper.method1507(var1, new class_243(var13, var2.field_1325, var2.field_1321), new class_243(var13, var2.field_1325, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var2.field_1325, var17), new class_243(var2.field_1320, var2.field_1325, var17), var11);
            WorldRenderHelper.method1507(var1, new class_243(var13, var2.field_1322, var2.field_1321), new class_243(var13, var2.field_1322, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var2.field_1322, var17), new class_243(var2.field_1320, var2.field_1322, var17), var11);
            WorldRenderHelper.method1507(var1, new class_243(var13, var2.field_1322, var2.field_1321), new class_243(var13, var2.field_1325, var2.field_1321), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var15, var2.field_1321), new class_243(var2.field_1320, var15, var2.field_1321), var11);
            WorldRenderHelper.method1507(var1, new class_243(var13, var2.field_1322, var2.field_1324), new class_243(var13, var2.field_1325, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var15, var2.field_1324), new class_243(var2.field_1320, var15, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var15, var2.field_1321), new class_243(var2.field_1323, var15, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1323, var2.field_1322, var17), new class_243(var2.field_1323, var2.field_1325, var17), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1320, var15, var2.field_1321), new class_243(var2.field_1320, var15, var2.field_1324), var11);
            WorldRenderHelper.method1507(var1, new class_243(var2.field_1320, var2.field_1322, var17), new class_243(var2.field_1320, var2.field_1325, var17), var11);
         }
      }

   }

   public static enum RenderMode implements DisplayNamed {
      field0597("Kontur"),
      field0033("To'ldirish"),
      field1431("Ikkalasi"),
      field0969("Shader");

      private final String field0791;

      private RenderMode(String var3) {
         this.field0791 = var3;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static RenderMode[] $values() {
         return new RenderMode[]{field0597, field0033, field1431, field0969};
      }
   }
}
