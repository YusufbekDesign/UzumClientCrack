package aethereal;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1676;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3857;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_9278;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.patch.arbuzhack.api.mixins.accessors.GameRendererAccessor;

public class ProjectilePrediction extends Module {
   private static ProjectilePrediction field0103;
   private final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("projectileprediction.renderhand", true)).method1007("Render Hand").method0210("Show trajectory of your currently held item").method2130("Показывать траекторию предмета в руке");
   private final BooleanSetting field0970 = (BooleanSetting)(new BooleanSetting("projectileprediction.handline", true, () -> (Boolean)this.field1432.method0492())).method1007("Hand Line").method0210("Draw a fading line from your hand to the predicted landing spot").method2130("Линия от руки до точки приземления, с фейдом");
   private final BooleanSetting field0184 = (BooleanSetting)(new BooleanSetting("projectileprediction.itemmarker", true, () -> (Boolean)this.field1432.method0492())).method1007("3D Item Marker").method0210("Show a 3D outline of the predicted item at the landing spot instead of the ring").method2130("3D-контур предмета в точке приземления вместо кольца");
   private final OutlineShaderRenderer field0465 = new OutlineShaderRenderer();
   private static final class_4588 field1651 = new class_4588() {
      public class_4588 method_22912(float x, float y, float z) {
         return this;
      }

      public class_4588 method_1336(int r, int g, int b, int a) {
         return this;
      }

      public class_4588 method_22913(float u, float v) {
         return this;
      }

      public class_4588 method_60796(int u, int v) {
         return this;
      }

      public class_4588 method_22921(int u, int v) {
         return this;
      }

      public class_4588 method_22914(float x, float y, float z) {
         return this;
      }
   };
   private static final class_4597 field1572 = (layer) -> field1651;
   private final BooleanSetting field1709 = (BooleanSetting)(new BooleanSetting("projectileprediction.renderincoming", true)).method1007("Render Incoming").method0210("Show trajectories of incoming projectiles").method2130("Показывать траектории от игроков");
   private final BooleanSetting field1141 = (BooleanSetting)(new BooleanSetting("projectileprediction.render2d", true)).method1007("2D HUD").method0210("Show 2D HUD with item icon and time-to-impact").method2130("Отображать время до окончания перед выполнением");
   private final BooleanSetting field1093 = (BooleanSetting)(new BooleanSetting("projectileprediction.crosshair", true)).method1007("Crosshair Indicator").method0210("Show time-to-impact indicator near crosshair").method2130("Отображать время до окончания после выполнения");
   private final ColorSetting field1203 = (ColorSetting)(new ColorSetting("projectileprediction.linecolor", 255, 156, 228, 200)).method1882().method1007("Line Color").method0210("Trajectory line color").method2130("Цвет траектории");
   private final List<PathMesh> field0885 = new ArrayList();
   private final List<class_243> field0843 = new ArrayList();
   private final List<class_2350> field0928 = new ArrayList();
   private final List<Boolean> field1347 = new ArrayList();
   private final List<class_243> field1308 = new ArrayList();
   private final List<class_243> field1384 = new ArrayList();
   private boolean field0404 = false;
   private float field0351 = -1.0F;
   private class_1799 field0441;
   private float field0255;
   private float field0226;
   private float field0289;
   private String field0534;
   private String field0513;
   private long field0549;
   private long field1673;
   private static final int field1658 = 150;
   private class_1297 field1698;
   private final List<PathPoint> field1595;
   private static final long field1579 = 220L;
   private static final long field1603 = 200L;
   private class_1799 field1761;
   private float field1739;
   private long field1767;
   private static final class_2960 field1181 = class_2960.method_60655("arbuzhack", "textures/glow.png");

   public static ProjectilePrediction method1716() {
      return field0103;
   }

   public ProjectilePrediction() {
      super("ProjectilePrediction", ModuleCategory.field1004, "Predicts projectile trajectories (incoming + hand item)");
      this.field0441 = class_1799.field_8037;
      this.field0255 = -1.0F;
      this.field0226 = 0.0F;
      this.field0289 = 0.0F;
      this.field0534 = "";
      this.field0513 = "";
      this.field0549 = 0L;
      this.field1673 = 0L;
      this.field1698 = null;
      this.field1595 = new ArrayList();
      this.field1761 = class_1799.field_8037;
      this.field1739 = -1.0F;
      this.field1767 = 0L;
      this.method1013("Предсказывает траектории падающих предметов");
      field0103 = this;
   }

   private ProjectilePath method1747() {
      return field0796.field_1724 == null ? new ProjectilePath(0.0F, 0.0F) : new ProjectilePath(field0796.field_1724.method_36454(), field0796.field_1724.method_36455());
   }

   private Stream<class_1297> method2026() {
      return field0796.field_1687 == null ? Stream.empty() : StreamSupport.stream(field0796.field_1687.method_18112().spliterator(), false);
   }

   public List<class_239> method1199(class_1676 entity, double velocity, ProjectilePath angle) {
      return new ArrayList(Collections.singletonList(this.method1323(angle.method2077(), entity, velocity)));
   }

   public class_239 method1323(class_243 lookVec, class_1676 entity, double velocity) {
      float sqrt = class_3532.method_15355((float)lookVec.method_1027());
      class_243 motion;
      if (entity instanceof class_1667 arrow) {
         if (arrow.method_54759().method_7909().equals(class_1802.field_8399)) {
            motion = class_243.field_1353;
            return this.method1335(field0796.field_1724.method_33571().method_1019(MathHelper.method1127(field0796.field_1724).method_1020(field0796.field_1724.method_19538())), lookVec.method_1021(velocity / (double)sqrt).method_1019(motion), entity);
         }
      }

      motion = field0796.field_1724.method_18798();
      return this.method1335(field0796.field_1724.method_33571().method_1019(MathHelper.method1127(field0796.field_1724).method_1020(field0796.field_1724.method_19538())), lookVec.method_1021(velocity / (double)sqrt).method_1019(motion), entity);
   }

   public class_239 method1198(class_1676 entity) {
      return this.method1335(entity.method_19538(), entity.method_18798(), entity);
   }

   public class_239 method1335(class_243 pos, class_243 motion, class_1676 entity) {
      this.field1384.clear();
      this.field1384.add(pos);
      int i = 0;

      while(true) {
         if (i < 300) {
            class_243 prevPos = pos;
            pos = pos.method_1019(motion);
            motion = this.method1147(entity, prevPos, motion);
            class_239 result = field0796.field_1687.method_17742(new class_3959(prevPos, pos, class_3960.field_17558, class_242.field_1348, entity));
            if (!result.method_17783().equals(class_240.field_1333)) {
               this.field1384.add(result.method_17784());
               return result;
            }

            boolean entityHit = this.method2026().filter((ent) -> {
               boolean var10000;
               if (ent instanceof class_1309 living) {
                  if (living != entity.method_24921() && living.method_5805()) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }).anyMatch((ent) -> this.method1293(ent.method_5829().method_1014(0.3000001804584443), prevPos, pos));
            if (entityHit) {
               this.field1384.add(pos);
               return new class_239(pos) {
                  public class_239.class_240 method_17783() {
                     return class_240.field_1331;
                  }
               };
            }

            this.field1384.add(pos);
            if (!(pos.field_1351 < (double)-128.0F)) {
               ++i;
               continue;
            }
         }

         return null;
      }
   }

   private boolean method1293(class_238 box, class_243 from, class_243 to) {
      double minX = Math.min(from.field_1352, to.field_1352) - 0.010000003747132445;
      double minY = Math.min(from.field_1351, to.field_1351) - 0.010000003747132445;
      double minZ = Math.min(from.field_1350, to.field_1350) - 0.010000003747132445;
      double maxX = Math.max(from.field_1352, to.field_1352) + 0.010000003747132445;
      double maxY = Math.max(from.field_1351, to.field_1351) + 0.010000003747132445;
      double maxZ = Math.max(from.field_1350, to.field_1350) + 0.010000003747132445;
      return maxX >= box.field_1323 && minX <= box.field_1320 && maxY >= box.field_1322 && minY <= box.field_1325 && maxZ >= box.field_1321 && minZ <= box.field_1324;
   }

   private void method2015() {
      try {
         class_243 camPos = field0796.field_1773.method_19418().method_19326();
         Color col = this.field1203.method1726();
         this.field0465.method0578();
         class_4597 wrapped = this.field0465.method1517(field1572, col);
         float spin = (float)(System.currentTimeMillis() % 3600L) / 10.0F;

         for(int i = 0; i < this.field0843.size(); ++i) {
            class_243 p = (class_243)this.field0843.get(i);
            class_4587 ms = new class_4587();
            ms.method_22904(p.field_1352 - camPos.field_1352, p.field_1351 - camPos.field_1351 + 0.2800001835305881, p.field_1350 - camPos.field_1350);
            ms.method_22905(0.7F, 0.7F, 0.7F);
            ms.method_22907(class_7833.field_40716.rotationDegrees(spin));
            ((GameRendererAccessor)field0796.field_1773).getFirstPersonRenderer().method_3233(field0796.field_1724, this.field0441, class_811.field_4318, false, ms, wrapped, 15728880);
         }

         this.field0465.method2058().method0578();
         this.field0465.method0764(1, col, false, false, 0.0F, 0.0F, 0.0F, col, false, 0.0F, 0.0F, 0.0F, col, false, 0.0F, 0.0F, col);
      } catch (Exception var8) {
      }

   }

   @EventHandler
   public void onGlowPass(GlowRenderEvent.Pre event) {
      if (!method1974()) {
         if ((Boolean)this.field0184.method0492() && (Boolean)this.field1432.method0492() && !this.field0843.isEmpty() && !this.field0441.method_7960()) {
            this.method2015();
         }

         if (!this.field0843.isEmpty() || !this.field0885.isEmpty()) {
            class_243 camera = field0796.field_1773.method_19418().method_19326();
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(770, 32772);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            RenderSystem.setShaderTexture(0, field1181);
            RenderSystem.setShader(class_10142.field_53880);
            class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
            Matrix4f m = new Matrix4f();
            Color lineCol = this.field1203.method1726();
            int[] vertexCount = new int[]{0};
            class_4184 cam = field0796.field_1773.method_19418();
            float camYawRad = (float)Math.toRadians((double)(-cam.method_19330()));
            float camPitchRad = (float)Math.toRadians((double)cam.method_19329());
            float cy = (float)Math.cos((double)camYawRad);
            float sy = (float)Math.sin((double)camYawRad);
            float cp = (float)Math.cos((double)camPitchRad);
            float sp = (float)Math.sin((double)camPitchRad);
            float rightX = cy;
            float rightY = 0.0F;
            float rightZ = -sy;
            float upX = sy * sp;
            float upY = cp;
            float upZ = cy * sp;

            for(int i = 0; i < this.field0843.size(); ++i) {
               class_243 p = (class_243)this.field0843.get(i);
               class_2350 face = (class_2350)this.field0928.get(i);
               if (this.field0404) {
                  vertexCount[0] += this.method1386(buffer, m, p, face, camera, 2.0F, lineCol, 180, rightX, rightY, rightZ, upX, upY, upZ);
               }
            }

            for(PathMesh pt : this.field0885) {
               class_1297 var24 = pt.entity;
               class_1297 var10000;
               if (var24 instanceof class_1676) {
                  class_1676 pe = (class_1676)var24;
                  var10000 = pe.method_24921();
               } else {
                  var10000 = null;
               }

               class_1297 owner = var10000;
               boolean isOwn = owner == field0796.field_1724;
               if (!isOwn && pt.isPotion) {
                  vertexCount[0] += this.method1386(buffer, m, pt.pos, pt.facing, camera, 4.0F, lineCol, 180, rightX, rightY, rightZ, upX, upY, upZ);
               }
            }

            if (vertexCount[0] > 0) {
               class_286.method_43433(buffer.method_60800());
            } else {
               buffer.method_60794();
            }

            RenderSystem.setShaderTexture(0, 0);
            RenderSystem.enableCull();
            RenderSystem.depthMask(true);
            RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
            RenderSystem.disableBlend();
         }
      }
   }

   private void method1506(class_4587 matrix, class_243 pos, class_2350 surface, Color color) {
      class_243 axisU;
      class_243 axisV;
      switch (surface) {
         case field_11043:
         case field_11035:
            axisU = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
            axisV = new class_243((double)0.0F, (double)1.0F, (double)0.0F);
            break;
         case field_11039:
         case field_11034:
            axisU = new class_243((double)0.0F, (double)0.0F, (double)1.0F);
            axisV = new class_243((double)0.0F, (double)1.0F, (double)0.0F);
            break;
         default:
            axisU = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
            axisV = new class_243((double)0.0F, (double)0.0F, (double)1.0F);
      }

      double width = 0.3000001804584443;
      double offset = 0.015000000495704477;
      class_243 center = new class_243(pos.field_1352 + (double)surface.method_10148() * offset, pos.field_1351 + (double)surface.method_10164() * offset, pos.field_1350 + (double)surface.method_10165() * offset);
      int size = 90;

      for(int i = 0; i < size; ++i) {
         double a1 = 6.283185314844992 * (double)i / (double)size;
         double a2 = 6.283185314844992 * (double)(i + 1) / (double)size;
         class_243 p1 = center.method_1019(axisU.method_1021(Math.cos(a1) * width)).method_1019(axisV.method_1021(Math.sin(a1) * width));
         class_243 p2 = center.method_1019(axisU.method_1021(Math.cos(a2) * width)).method_1019(axisV.method_1021(Math.sin(a2) * width));
         WorldRenderHelper.method1507(matrix, p1, p2, color);
      }

      WorldRenderHelper.method1507(matrix, center.method_1020(axisU.method_1021(width)), center.method_1019(axisU.method_1021(width)), color);
      WorldRenderHelper.method1507(matrix, center.method_1020(axisV.method_1021(width)), center.method_1019(axisV.method_1021(width)), color);
   }

   private void method1382(class_287 buf, Matrix4f m, float cx, float cy, float cz, float halfSize, float rX, float rY, float rZ, float uX, float uY, float uZ, Color col, int alpha) {
      int r = col.getRed();
      int g = col.getGreen();
      int b = col.getBlue();
      float rX2 = rX * halfSize;
      float rY2 = rY * halfSize;
      float rZ2 = rZ * halfSize;
      float uX2 = uX * halfSize;
      float uY2 = uY * halfSize;
      float uZ2 = uZ * halfSize;
      buf.method_22918(m, cx - rX2 - uX2, cy - rY2 - uY2, cz - rZ2 - uZ2).method_22913(0.0F, 1.0F).method_1336(r, g, b, alpha);
      buf.method_22918(m, cx + rX2 - uX2, cy + rY2 - uY2, cz + rZ2 - uZ2).method_22913(1.0F, 1.0F).method_1336(r, g, b, alpha);
      buf.method_22918(m, cx + rX2 + uX2, cy + rY2 + uY2, cz + rZ2 + uZ2).method_22913(1.0F, 0.0F).method_1336(r, g, b, alpha);
      buf.method_22918(m, cx - rX2 + uX2, cy - rY2 + uY2, cz - rZ2 + uZ2).method_22913(0.0F, 0.0F).method_1336(r, g, b, alpha);
   }

   private int method1386(class_287 buf, Matrix4f m, class_243 pos, class_2350 surface, class_243 camera, float radius, Color color, int alpha, float rX, float rY, float rZ, float uX, float uY, float uZ) {
      float cx = (float)(pos.field_1352 - camera.field_1352);
      float cy = (float)(pos.field_1351 - camera.field_1351) + 1.0F;
      float cz = (float)(pos.field_1350 - camera.field_1350);
      int segments = 96;
      float spacing = (float)(6.283185314844992 * (double)radius / (double)segments);
      float dotHalf = spacing * 2.0F;

      for(int i = 0; i < segments; ++i) {
         double angle = 6.283185314844992 * (double)i / (double)segments;
         float px = cx + (float)Math.cos(angle) * radius;
         float pz = cz + (float)Math.sin(angle) * radius;
         this.method1382(buf, m, px, cy, pz, dotHalf, rX, rY, rZ, uX, uY, uZ, color, alpha);
      }

      return segments * 4;
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Inbound event) {
      if (event.method1970() instanceof class_2678) {
         this.method2043();
      }

   }

   private void method2043() {
      this.field0885.clear();
      this.field0843.clear();
      this.field0928.clear();
      this.field1347.clear();
      this.field0404 = false;
      this.field0351 = -1.0F;
      this.field0441 = class_1799.field_8037;
      this.field0255 = -1.0F;
      this.field1698 = null;
      this.field1595.clear();
      this.field1761 = class_1799.field_8037;
      this.field1739 = -1.0F;
      this.field1767 = 0L;
      this.field0226 = 0.0F;
      this.field0289 = 0.0F;
      this.field0534 = "";
      this.field0513 = "";
      this.field0549 = 0L;
      this.field1673 = 0L;
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent.GamePass e) {
      if (!method1974()) {
         this.field0885.clear();
         this.field0843.clear();
         this.field0928.clear();
         this.field1347.clear();
         this.field1308.clear();
         this.field0404 = false;
         this.field0351 = -1.0F;
         this.field0441 = class_1799.field_8037;
         this.field0255 = -1.0F;
         Color lineCol = this.field1203.method1726();
         int baseColor = lineCol.getRGB();
         if ((Boolean)this.field1432.method0492()) {
            this.method1495(e.method1629(), field0796.field_1724.method_5877(), this.method1747());
         }

         long nowMs = System.currentTimeMillis();

         for(PathPoint t : this.field1595) {
            if (t.field1244 == 0L && (t.field0730.method_31481() || !t.field0730.method_5805() || t.field0730.field_6012 > 200)) {
               t.method1634();
            }
         }

         this.field1595.removeIf((tx) -> tx.method0161(nowMs));

         for(class_1297 ent : this.method1689()) {
            if (ent instanceof class_1676) {
               class_1676 proj = (class_1676)ent;
               if (proj.method_24921() == field0796.field_1724 && ent.field_6012 < 40) {
                  boolean already = false;

                  for(PathPoint t : this.field1595) {
                     if (t.method0563() == ent) {
                        already = true;
                        break;
                     }
                  }

                  if (!already) {
                     HitResult tr = this.method0292(ent.method_19538(), ent.method_18798(), proj);
                     if (tr != null) {
                        class_1799 stk = class_1799.field_8037;
                        if (ent instanceof class_3857) {
                           class_3857 ti = (class_3857)ent;
                           stk = ti.method_7495();
                        } else if (ent instanceof class_1665) {
                           class_1665 pp = (class_1665)ent;
                           stk = pp.method_54759();
                        } else if (ent instanceof class_1542) {
                           class_1542 ie = (class_1542)ent;
                           stk = ie.method_6983();
                        }

                        if (!stk.method_7960()) {
                           this.field1595.add(new PathPoint(ent, tr.method0568().method_17784(), tr.method0003(), stk));
                        }
                     }
                  }
               }
            }
         }

         this.field1698 = this.field1595.isEmpty() ? null : ((PathPoint)this.field1595.get(0)).method0563();
         if ((Boolean)this.field1709.method0492()) {
            for(class_1297 entity : this.method1689()) {
               class_243 motion = entity.method_18798();
               class_243 pos = entity.method_19538();

               for(int i = 0; i < 300; ++i) {
                  class_243 prevPos = pos;
                  pos = pos.method_1019(motion);
                  motion = this.method1147(entity, prevPos, motion);
                  class_239 result = field0796.field_1687.method_17742(new class_3959(prevPos, pos, class_3960.field_17558, class_242.field_1348, entity));
                  if (!result.method_17783().equals(class_240.field_1333)) {
                     pos = result.method_17784();
                  }

                  int fadeAlpha = (int)(255.0F * class_3532.method_15363((float)i / 25.0F, 0.0F, 1.0F));
                  int lineRgb = ColorMath.method1828(baseColor, (float)fadeAlpha / 255.0F);
                  WorldRenderHelper.method1507(e.method1629(), prevPos, pos, new Color(lineRgb, true));
                  if (!result.method_17783().equals(class_240.field_1333) || pos.field_1351 < (double)-128.0F) {
                     this.method1146(entity, pos, i, result);
                     break;
                  }
               }
            }
         }

         Color clientCol = this.field1203.method1726();
         Color entityCol = Color.RED;
         if (!(Boolean)this.field0184.method0492()) {
            for(int i = 0; i < this.field0843.size(); ++i) {
               boolean entHit = i < this.field1347.size() && (Boolean)this.field1347.get(i);
               this.method1506(e.method1629(), (class_243)this.field0843.get(i), (class_2350)this.field0928.get(i), entHit ? entityCol : clientCol);
            }
         }

         if ((Boolean)this.field1432.method0492() && (Boolean)this.field0970.method0492() && this.field1308.size() >= 2) {
            boolean entHit = !this.field1347.isEmpty() && (Boolean)this.field1347.get(this.field1347.size() - 1);
            this.method1503(e.method1629(), this.method0470(), this.field1308, entHit ? entityCol : clientCol);
         }

         for(PathMesh pt : this.field0885) {
            class_1297 var35 = pt.entity;
            class_1297 var10000;
            if (var35 instanceof class_1676) {
               class_1676 pe = (class_1676)var35;
               var10000 = pe.method_24921();
            } else {
               var10000 = null;
            }

            class_1297 owner = var10000;
            if (owner != field0796.field_1724) {
               this.method1506(e.method1629(), pt.pos, pt.facing, pt.isEntityHit ? entityCol : clientCol);
            }
         }

      }
   }

   private class_243 method0470() {
      class_4184 cam = field0796.field_1773.method_19418();
      class_243 base = cam.method_19326();
      double yawR = Math.toRadians((double)cam.method_19330());
      double pitchR = Math.toRadians((double)cam.method_19329());
      class_243 look = new class_243(-Math.sin(yawR) * Math.cos(pitchR), -Math.sin(pitchR), Math.cos(yawR) * Math.cos(pitchR));
      class_243 right = new class_243(-look.field_1350, (double)0.0F, look.field_1352);
      if (right.method_1027() < 1.0000000010018248E-6) {
         right = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
      } else {
         right = right.method_1029();
      }

      class_243 up = right.method_1036(look).method_1029();
      double side = field0796.field_1690.method_42552().method_41753() == class_1306.field_6182 ? (double)-1.0F : (double)1.0F;
      return base.method_1019(right.method_1021(0.32000000096362474 * side)).method_1019(up.method_1021(-0.16000005268583464)).method_1019(look.method_1021(0.44999991806726064));
   }

   private void method1503(class_4587 matrix, class_243 origin, List<class_243> path, Color baseColor) {
      int n = path.size();
      if (n >= 2) {
         int rgb = baseColor.getRGB();
         float baseFrac = (float)baseColor.getAlpha() / 255.0F;
         class_243 off = origin.method_1020((class_243)path.get(0));
         int blend = Math.max(2, (int)((double)n * 0.44999991806726064));
         class_243 prev = null;

         for(int i = 0; i < n; ++i) {
            float w = i >= blend ? 0.0F : 1.0F - (float)i / (float)blend;
            float ws = w * w * (3.0F - 2.0F * w);
            class_243 pt = ((class_243)path.get(i)).method_1019(off.method_1021((double)ws));
            if (prev != null) {
               float t = (float)i / (float)(n - 1);
               float fadeIn = class_3532.method_15363(t / 0.3F, 0.0F, 1.0F);
               int col = ColorMath.method1828(rgb, baseFrac * fadeIn);
               WorldRenderHelper.method1507(matrix, prev, pt, new Color(col, true));
            }

            prev = pt;
         }

      }
   }

   private void method1495(class_4587 matrix, Iterable<class_1799> stacks, ProjectilePath angle) {
      if (field0796.field_1724 != null) {
         class_1792 activeItem = field0796.field_1724.method_6030().method_7909();
         Iterator var5 = stacks.iterator();
         if (var5.hasNext()) {
            class_1799 stack = (class_1799)var5.next();
            List<class_239> results = null;
            class_1792 item = stack.method_7909();
            if (item instanceof class_1779) {
               results = this.method1199(new class_1683(field0796.field_1687, field0796.field_1724, stack), 0.7999999493743812, angle);
            } else if (item instanceof class_1828) {
               results = this.method1199(new class_1686(field0796.field_1687, field0796.field_1724, stack), 0.5500000601931105, angle);
            } else if (item instanceof class_1835 && item.equals(activeItem) && field0796.field_1724.method_6048() >= 10) {
               results = this.method1199(new class_1685(field0796.field_1687, field0796.field_1724, stack), (double)2.5F, angle);
            } else if (item instanceof class_1823) {
               results = this.method1199(new class_1680(field0796.field_1687, field0796.field_1724, stack), (double)1.5F, angle);
            } else if (item instanceof class_1771) {
               results = this.method1199(new class_1681(field0796.field_1687, field0796.field_1724, stack), (double)1.5F, angle);
            } else if (item instanceof class_1776) {
               results = this.method1199(new class_1684(field0796.field_1687, field0796.field_1724, stack), (double)1.5F, angle);
            } else if (item instanceof class_1753 && item.equals(activeItem) && field0796.field_1724.method_6115()) {
               float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
               float velocity = 3.0F * class_3532.method_15363(((float)field0796.field_1724.method_6048() + tickDelta) / 20.0F, 0.0F, 1.0F);
               results = this.method1199(new class_1667(field0796.field_1687, field0796.field_1724, stack, stack), (double)velocity, angle);
            } else if (item instanceof class_1764 && class_1764.method_7781(stack)) {
               class_9278 component = (class_9278)stack.method_57824(class_9334.field_49649);
               List<class_239> list = new ArrayList();
               if (component != null && !component.method_57437().isEmpty()) {
                  float velocity = ((class_1799)component.method_57437().getFirst()).method_31574(class_1802.field_8639) ? 100.0F : 3.0F;
                  list.add(this.method1323(angle.method2077(), new class_1667(field0796.field_1687, field0796.field_1724, stack, stack), (double)velocity));
                  if (component.method_57437().size() > 2) {
                     float pitchAbs = angle.method0002() / 90.0F;
                     float delta = pitchAbs * pitchAbs * pitchAbs * pitchAbs * pitchAbs;
                     float yawSpread = (float)class_3532.method_48781(Math.abs(delta), 10, 90);
                     float pitchSpread = (float)class_3532.method_48781(delta, 0, 10);
                     list.add(this.method1323(angle.method0659(-yawSpread).method0123(-pitchSpread).method2077(), new class_1667(field0796.field_1687, field0796.field_1724, stack, stack), (double)velocity));
                     list.add(this.method1323(angle.method0659(yawSpread).method0123(-pitchSpread).method2077(), new class_1667(field0796.field_1687, field0796.field_1724, stack, stack), (double)velocity));
                  }
               }

               results = list;
            }

            if (results != null) {
               List<class_239> var17 = results.stream().filter(Objects::nonNull).toList();
               if (!var17.isEmpty()) {
                  this.method1496(matrix, var17);
                  this.field1308.clear();
                  this.field1308.addAll(this.field1384);
                  if (item instanceof class_1828) {
                     this.field0404 = true;
                  }

                  this.field0441 = stack;
                  class_243 lookVec = angle.method2077();
                  double vel = this.method1234(item, stack, activeItem);
                  if (vel > (double)0.0F) {
                     float sqrt = class_3532.method_15355((float)lookVec.method_1027());
                     class_243 motion = lookVec.method_1021(vel / (double)sqrt).method_1019(field0796.field_1724.method_18798());
                     class_1676 dummy = this.method1232(item, stack);
                     if (dummy != null) {
                        HitResult tr = this.method0292(field0796.field_1724.method_33571().method_1019(MathHelper.method1127(field0796.field_1724).method_1020(field0796.field_1724.method_19538())), motion, dummy);
                        if (tr != null) {
                           this.field0441 = stack;
                           float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
                           this.field0255 = Math.max(0.0F, ((float)tr.ticks - tickDelta) * 0.05F);
                           this.field0351 = this.field0255;
                        }
                     }
                  }
               }
            }

         }
      }
   }

   private void method1496(class_4587 matrix, List<class_239> results) {
      for(class_239 result : results) {
         class_2350 direction = this.method1294(result);
         this.field0843.add(result.method_17784());
         this.field0928.add(direction);
         this.field1347.add(result.method_17783() == class_240.field_1331);
      }

   }

   private void method0336(class_4587 matrix, class_243 pos, class_2350 surface, Color color) {
      float offset = 0.015F;
      class_243 lifted = pos.method_1031((double)((float)surface.method_10148() * offset), (double)((float)surface.method_10164() * offset), (double)((float)surface.method_10165() * offset));
      Quaternionf var10000;
      switch (surface) {
         case field_11043:
         case field_11035:
            var10000 = class_7833.field_40714.rotationDegrees(90.0F);
            break;
         case field_11039:
         case field_11034:
            var10000 = class_7833.field_40718.rotationDegrees(90.0F);
            break;
         default:
            var10000 = new Quaternionf();
      }

      Quaternionf quat = var10000;
      float size = 0.15F;
      float gap = 0.18F;
      float baseHalf = 0.06F;
      matrix.method_22903();
      matrix.method_22904(lifted.field_1352, lifted.field_1351, lifted.field_1350);
      matrix.method_22907(quat);
      this.method1463(matrix, gap, gap + size, 0.0F, 0.0F, baseHalf, color);
      this.method1463(matrix, -gap, -(gap + size), 0.0F, 0.0F, baseHalf, color);
      this.method1463(matrix, 0.0F, 0.0F, gap, gap + size, baseHalf, color);
      this.method1463(matrix, 0.0F, 0.0F, -gap, -(gap + size), baseHalf, color);
      matrix.method_22909();
   }

   private void method1463(class_4587 matrix, float bx, float tx, float bz, float tz, float baseHalf, Color color) {
      float dx = tx - bx;
      float dz = tz - bz;
      float len = (float)Math.sqrt((double)(dx * dx + dz * dz));
      if (!(len < 0.001F)) {
         float nx = -dz / len;
         float nz = dx / len;
         class_243 tip = new class_243((double)tx, (double)0.0F, (double)tz);
         class_243 bLeft = new class_243((double)(bx + nx * baseHalf), (double)0.0F, (double)(bz + nz * baseHalf));
         class_243 bRight = new class_243((double)(bx - nx * baseHalf), (double)0.0F, (double)(bz - nz * baseHalf));
         WorldRenderHelper.method0337(matrix, tip, bLeft, color);
         WorldRenderHelper.method0337(matrix, bLeft, bRight, color);
         WorldRenderHelper.method0337(matrix, bRight, tip, color);
      }
   }

   private Quaternionf method1280(class_2350 surface) {
      Quaternionf var10000;
      switch (surface) {
         case field_11043:
         case field_11035:
            var10000 = class_7833.field_40714.rotationDegrees(90.0F);
            break;
         case field_11039:
         case field_11034:
            var10000 = class_7833.field_40718.rotationDegrees(90.0F);
            break;
         default:
            var10000 = new Quaternionf();
      }

      return var10000;
   }

   private void method1505(class_4587 matrix, class_243 pos, class_2350 surface, float radius, Color color) {
      matrix.method_22903();
      matrix.method_22904(pos.field_1352, pos.field_1351 + 0.02000001037642601, pos.field_1350);
      matrix.method_22907(this.method1280(surface));
      int segments = 48;

      for(int i = 0; i < segments; ++i) {
         double a1 = 6.283185314844992 * (double)i / (double)segments;
         double a2 = 6.283185314844992 * (double)(i + 1) / (double)segments;
         class_243 p1 = new class_243(Math.cos(a1) * (double)radius, (double)0.0F, -Math.sin(a1) * (double)radius);
         class_243 p2 = new class_243(Math.cos(a2) * (double)radius, (double)0.0F, -Math.sin(a2) * (double)radius);
         WorldRenderHelper.method0337(matrix, p1, p2, color);
      }

      matrix.method_22909();
   }

   @EventHandler
   public void onRender2D(HudRenderEvent event) {
      if (!method1974()) {
         class_332 ctx = event.method1806();
         class_4587 stack = ctx.method_51448();
         if ((Boolean)this.field1141.method0492()) {
            class_4184 camera = field0796.field_1773.method_19418();
            class_243 camPos = camera.method_19326();
            float yawRad = (float)Math.toRadians((double)camera.method_19330());
            float pitchRad = (float)Math.toRadians((double)camera.method_19329());
            double cosP = Math.cos((double)pitchRad);
            double fwdX = -Math.sin((double)yawRad) * cosP;
            double fwdY = -Math.sin((double)pitchRad);
            double fwdZ = Math.cos((double)yawRad) * cosP;
            float screenW = ScreenLayoutHelper.method2047();
            float screenH = ScreenLayoutHelper.method1762();
            float screenCx = screenW / 2.0F;
            float screenCy = screenH / 2.0F;
            float edgeMargin = 30.0F;
            GuiRenderHelper.method0578();

            try {
               String ownNick = field0796.field_1724 != null ? field0796.field_1724.method_5477().getString() : null;
               float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
               long now2D = System.currentTimeMillis();

               for(PathPoint tag : this.field1595) {
                  class_1297 ent = tag.method0563();
                  float anim = tag.method0774(now2D);
                  if (!(anim < 0.01F)) {
                     float remaining = Math.max(0.0F, ((float)(tag.method2048() - ent.field_6012) - tickDelta) * 0.05F);
                     this.method1443(ctx, stack, tag.method0024(), tag.method1801(), ownNick, remaining, anim, camPos, fwdX, fwdY, fwdZ, screenW, screenH, screenCx, screenCy, edgeMargin);
                  }
               }

               for(PathMesh point : this.field0885) {
                  class_1297 le = point.entity;
                  class_1297 var10000;
                  if (le instanceof class_1676) {
                     class_1676 pe = (class_1676)le;
                     var10000 = pe.method_24921();
                  } else {
                     var10000 = null;
                  }

                  class_1297 owner = var10000;
                  if (owner != field0796.field_1724) {
                     String nick = null;
                     if (owner instanceof class_1309) {
                        class_1309 le = (class_1309)owner;
                        if (!owner.method_5767()) {
                           nick = le.method_5477().getString();
                        }
                     }

                     this.method1443(ctx, stack, point.pos, point.stack, nick, point.remainingTime, 1.0F, camPos, fwdX, fwdY, fwdZ, screenW, screenH, screenCx, screenCy, edgeMargin);
                  }
               }
            } finally {
               GuiRenderHelper.method0025();
            }
         }

         if ((Boolean)this.field1093.method0492()) {
            this.method1432(ctx, stack);
         }

      }
   }

   private void method1443(class_332 ctx, class_4587 stack, class_243 worldPos, class_1799 itemStack, String nick, float remainingTime, float anim, class_243 camPos, double fwdX, double fwdY, double fwdZ, float screenW, float screenH, float screenCx, float screenCy, float edgeMargin) {
      double dx = worldPos.field_1352 - camPos.field_1352;
      double dy = worldPos.field_1351 - camPos.field_1351;
      double dz = worldPos.field_1350 - camPos.field_1350;
      double dot = dx * fwdX + dy * fwdY + dz * fwdZ;
      class_243 projected = ProjectionHelper.method1299(worldPos);
      float sx = (float)projected.field_1352;
      float sy = (float)projected.field_1351;
      if (dot <= (double)0.0F) {
         sx = 2.0F * screenCx - sx;
         sy = 2.0F * screenCy - sy;
      }

      boolean onScreen = dot > (double)0.0F && sx >= 0.0F && sx <= screenW && sy >= 0.0F && sy <= screenH;
      if (!onScreen) {
         float dirX = sx - screenCx;
         float dirY = sy - screenCy;
         float len = (float)Math.sqrt((double)(dirX * dirX + dirY * dirY));
         if (len < 0.001F) {
            dirX = 0.0F;
            dirY = -1.0F;
         } else {
            dirX /= len;
            dirY /= len;
         }

         float halfW = screenCx - edgeMargin;
         float halfH = screenCy - edgeMargin;
         float tx = Math.abs(dirX) > 0.001F ? halfW / Math.abs(dirX) : Float.POSITIVE_INFINITY;
         float ty = Math.abs(dirY) > 0.001F ? halfH / Math.abs(dirY) : Float.POSITIVE_INFINITY;
         float t = Math.min(tx, ty);
         sx = screenCx + dirX * t;
         sy = screenCy + dirY * t;
      }

      float distScale = 0.9116279F;
      this.method1442(ctx, stack, itemStack, nick, remainingTime, sx, sy, distScale, anim);
   }

   private static Color method0964(Color c, float mult) {
      int a = Math.max(0, Math.min(255, (int)((float)c.getAlpha() * mult)));
      return new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
   }

   private void method1442(class_332 ctx, class_4587 stack, class_1799 itemStack, String nick, float remainingTime, float x, float y, float distScale, float anim) {
      FontSize font = Fonts.field0075.method0654(6.0F);
      float padding = 3.0F;
      float radius = 6.0F;
      float innerPad = 4.0F;
      float sepGap = 5.0F;
      float smallSepH = 7.0F;
      float itemSize = 9.0F;
      Object[] var10001 = new Object[]{Math.max(0.0F, remainingTime)};
      String timeText = String.format("%.1f", var10001) + "s";
      boolean hasNick = nick != null && !nick.isEmpty();
      float nickWidth = hasNick ? font.method0998(nick) : 0.0F;
      float timeWidth = font.method0998(timeText);
      float totalW = innerPad + itemSize + sepGap + 1.0F + sepGap + timeWidth;
      if (hasNick) {
         totalW += sepGap + 1.0F + sepGap + nickWidth;
      }

      totalW += innerPad;
      float bgHeight = font.method0530() + padding * 2.5F;
      float bgX = -totalW / 2.0F;
      float bgY = -bgHeight;
      float scaledBlur = (Float)ThemePalette.field0367.get();
      stack.method_22903();
      stack.method_46416(x, y - 4.0F, 0.0F);
      float popScale = 0.55F + 0.45F * anim;
      stack.method_22905(distScale * popScale, distScale * popScale, 1.0F);
      Color bgColor = method0964((Color)ThemePalette.field0930.get(), anim);
      Color borderColor = method0964(ThemePalette.field1564, anim);
      Color textPrimary = method0964(new Color(227, 227, 227), anim);
      Color textSecondary = method0964(new Color(255, 255, 255, 184), anim);
      Color separator = method0964(new Color(255, 255, 255, 80), anim);
      GuiRenderHelper.method1462(stack, bgX, bgY, totalW, bgHeight, radius, scaledBlur, method0964(new Color(255, 255, 255), anim));
      GuiRenderHelper.method1463(stack, bgX, bgY, totalW, bgHeight, radius, bgColor);
      GuiRenderHelper.method1461(stack, bgX, bgY, totalW, bgHeight, radius, 0.5F, 0.5F, borderColor);
      float centerY = bgY + bgHeight / 2.0F;
      float textY = centerY - font.method0530() / 2.0F;
      float smallSepY = centerY - smallSepH / 2.0F;
      float currentX = bgX + innerPad;
      stack.method_22903();
      stack.method_46416(currentX, centerY - itemSize / 2.0F, 200.0F);
      float itemScale = itemSize / 16.0F;
      stack.method_22905(itemScale, itemScale, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, anim);
      ctx.method_51427(itemStack, 0, 0);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      stack.method_22909();
      currentX += itemSize;
      if (hasNick) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, separator);
         currentX += 1.0F + sepGap;
         GuiRenderHelper.method1491(stack, font, nick, currentX, textY, textPrimary);
         currentX += nickWidth;
      }

      currentX += sepGap;
      GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, separator);
      currentX += 1.0F + sepGap;
      GuiRenderHelper.method1491(stack, font, timeText, currentX, textY, textSecondary);
      stack.method_22909();
   }

   private void method1432(class_332 ctx, class_4587 stack) {
      long now = System.currentTimeMillis();
      float dt = this.field1673 == 0L ? 0.016F : (float)(now - this.field1673) / 1000.0F;
      this.field1673 = now;
      dt = Math.min(dt, 0.1F);
      class_1799 displayItem = this.field0441;
      float displayTime = this.field0255;
      if (displayItem.method_7960() && this.field1698 != null) {
         class_1297 ent = this.field1698;
         if (ent instanceof class_1676) {
            class_1676 proj = (class_1676)ent;
            if (ent.method_5805() && !ent.method_31481()) {
               HitResult tr = this.method0292(ent.method_19538(), ent.method_18798(), proj);
               float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
               if (tr != null) {
                  displayTime = Math.max(0.0F, ((float)tr.ticks - tickDelta) * 0.05F);
               } else {
                  displayTime = 0.0F;
               }

               if (ent instanceof class_3857) {
                  class_3857 ti = (class_3857)ent;
                  displayItem = ti.method_7495();
               } else if (ent instanceof class_1665) {
                  class_1665 pp = (class_1665)ent;
                  displayItem = pp.method_54759();
               }
            }
         }
      }

      if (!displayItem.method_7960() && displayTime >= 0.0F) {
         this.field1761 = displayItem;
         this.field1739 = displayTime;
         this.field1767 = now;
      } else if (now - this.field1767 < 400L && !this.field1761.method_7960()) {
         float elapsed = (float)(now - this.field1767) / 1000.0F;
         displayItem = this.field1761;
         displayTime = Math.max(0.0F, this.field1739 - elapsed);
      }

      boolean hasData = displayTime >= 0.0F && !displayItem.method_7960();
      float targetVis = hasData ? 1.0F : 0.0F;
      float visSpeed = dt / 0.25F;
      this.field0226 += Math.signum(targetVis - this.field0226) * Math.min(Math.abs(targetVis - this.field0226), visSpeed);
      if (this.field0226 < 0.01F && !hasData) {
         this.field0226 = 0.0F;
      } else {
         float vis = this.field0226;
         String timeText = String.format("%.1f", Math.max(0.0F, displayTime));
         if (!timeText.equals(this.field0513)) {
            this.field0534 = this.field0513;
            this.field0513 = timeText;
            this.field0549 = System.currentTimeMillis();
         }

         FontSize labelFont = Fonts.field0075.method0654(6.5F);
         FontSize secondaryFont = Fonts.field0075.method0654(6.5F);
         float itemSize = 10.0F;
         float sepH = 7.0F;
         float padding = 6.0F;
         float gap = 5.0F;
         String suffix = "s";
         float timeW = labelFont.method0998(this.field0513);
         float suffixW = secondaryFont.method0998(suffix);
         float contentW = itemSize + gap + 1.0F + gap + timeW + suffixW;
         float totalW = padding + contentW + padding;
         float totalH = 18.0F;
         float wSpeed = dt / 0.15F * Math.abs(totalW - this.field0289);
         this.field0289 += Math.signum(totalW - this.field0289) * Math.min(Math.abs(totalW - this.field0289), wSpeed);
         if (Math.abs(totalW - this.field0289) < 0.5F) {
            this.field0289 = totalW;
         }

         float animW = this.field0289 * vis;
         float screenCX = ScreenLayoutHelper.method2047() / 2.0F;
         float screenCY = ScreenLayoutHelper.method1762() / 2.0F;
         float x = screenCX + 10.0F;
         float y = screenCY - totalH / 2.0F;
         Color bgBase = ThemeColorManager.method1908().method0141(224);
         Color bg = new Color(bgBase.getRed(), bgBase.getGreen(), bgBase.getBlue(), (int)((float)bgBase.getAlpha() * vis));
         Color textPrimary = new Color(255, 255, 255, (int)(255.0F * vis));
         Color textSecondary = new Color(255, 255, 255, (int)(184.0F * vis));
         Color sepColor = new Color(255, 255, 255, (int)(80.0F * vis));
         float scaleX = Math.max(0.3F, vis);
         float scaleY = Math.max(0.3F, vis * vis);
         float cx = x + animW / 2.0F;
         float cy = y + totalH / 2.0F;
         stack.method_22903();
         stack.method_46416(cx, cy, 0.0F);
         stack.method_22905(scaleX, scaleY, 1.0F);
         stack.method_46416(-cx, -cy, 0.0F);
         if (vis > 0.01F) {
            GuiRenderHelper.method1462(stack, x, y, animW, totalH, 8.0F, 14.0F, new Color(255, 255, 255, (int)(255.0F * vis)));
            GuiRenderHelper.method1463(stack, x, y, animW, totalH, 8.0F, bg);
         }

         GuiRenderHelper.method1404(ctx, x, y, animW, totalH);
         float drawX = x + padding;
         float centerY = y + totalH / 2.0F;
         float itemY = centerY - itemSize / 2.0F;
         stack.method_22903();
         stack.method_46416(drawX, itemY, 200.0F);
         float itemScale = itemSize / 16.0F;
         stack.method_22905(itemScale, itemScale, 1.0F);
         RenderSystem.enableBlend();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, vis);
         ctx.method_51427(displayItem, 0, 0);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         stack.method_22909();
         drawX += itemSize + gap;
         float sepY = centerY - sepH / 2.0F;
         GuiRenderHelper.method0326(stack, drawX, sepY, 1.0F, sepH, 1.0F, sepColor);
         drawX += 1.0F + gap;
         float textY = centerY - labelFont.method0530() / 2.0F;
         long elapsed = System.currentTimeMillis() - this.field0549;
         float textProgress = Math.min(1.0F, (float)elapsed / 150.0F);
         float eased = 1.0F - (1.0F - textProgress) * (1.0F - textProgress);
         if (textProgress < 1.0F && !this.field0534.isEmpty()) {
            float slide = labelFont.method0530() * 0.8F;
            int oldAlpha = (int)(255.0F * (1.0F - eased) * vis);
            if (oldAlpha > 0) {
               GuiRenderHelper.method1491(stack, labelFont, this.field0534, drawX, textY + slide * eased, new Color(255, 255, 255, oldAlpha));
            }

            int newAlpha = (int)(255.0F * eased * vis);
            if (newAlpha > 0) {
               GuiRenderHelper.method1491(stack, labelFont, this.field0513, drawX, textY - slide * (1.0F - eased), new Color(255, 255, 255, newAlpha));
            }
         } else {
            GuiRenderHelper.method1491(stack, labelFont, this.field0513, drawX, textY, textPrimary);
         }

         drawX += timeW;
         GuiRenderHelper.method1491(stack, secondaryFont, suffix, drawX, textY, textSecondary);
         GuiRenderHelper.method1400(ctx);
         stack.method_22909();
      }
   }

   public List<class_1297> method1689() {
      List<class_1297> result = new ArrayList();
      Stream var10000 = this.method2026().filter((e) -> (e instanceof class_1665 || e instanceof class_3857 || e instanceof class_1542) && !this.method1129(e));
      Objects.requireNonNull(result);
      var10000.forEach(result::add);
      return result;
   }

   public class_243 method1147(class_1297 entity, class_243 prevPos, class_243 motion) {
      boolean isInWater = field0796.field_1687.method_8316(class_2338.method_49638(prevPos)).method_15767(class_3486.field_15517);
      double multiply;
      if (entity instanceof class_1685) {
         multiply = 0.9900000190921701;
      } else if (entity instanceof class_1665) {
         multiply = isInWater ? 0.6000003606674028 : 0.9900000190921701;
      } else {
         multiply = isInWater ? 0.7999999493743812 : 0.9900000190921701;
      }

      return motion.method_1021(multiply).method_1031((double)0.0F, -entity.method_56989(), (double)0.0F);
   }

   private void method1146(class_1297 entity, class_243 pos, int ticks, class_239 result) {
      float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
      float remaining = Math.max(0.0F, ((float)ticks - tickDelta) * 0.05F);
      class_2350 var10000;
      if (result instanceof class_3965 bh) {
         var10000 = bh.method_17780();
      } else {
         var10000 = class_2350.field_11036;
      }

      class_2350 facing = var10000;
      boolean isEntityHit = result != null && result.method_17783() == class_240.field_1331;
      class_1799 stack = null;
      boolean isPotion = false;
      if (entity instanceof class_1542 item) {
         stack = item.method_6983();
      } else if (entity instanceof class_3857 thrown) {
         stack = thrown.method_7495();
         isPotion = entity instanceof class_1686;
      } else if (entity instanceof class_1665 persistent) {
         stack = persistent.method_54759();
      }

      if (stack != null) {
         this.field0885.add(new PathMesh(stack, pos, remaining, entity, isPotion, facing, isEntityHit));
      }

   }

   private class_2350 method1294(class_239 result) {
      if (result instanceof class_3965 blockHit) {
         return blockHit.method_17780();
      } else {
         return class_2350.method_58251(result.method_17784().method_1020(field0796.field_1724.method_33571()).method_1029());
      }
   }

   private boolean method1129(class_1297 entity) {
      boolean posSame = entity.method_23317() == entity.field_6014 && entity.method_23318() == entity.field_6036 && entity.method_23321() == entity.field_5969;
      boolean itemOnGround = entity instanceof class_1542 && (entity.method_24828() || this.method0235(entity));
      return posSame || itemOnGround;
   }

   private boolean method0235(class_1297 entity) {
      return field0796.field_1687.method_8316(class_2338.method_49638(entity.method_19538())).method_15767(class_3486.field_15517);
   }

   private double method1234(class_1792 item, class_1799 stack, class_1792 activeItem) {
      if (item instanceof class_1779) {
         return 0.7999999493743812;
      } else if (item instanceof class_1828) {
         return 0.5500000601931105;
      } else if (item instanceof class_1835 && item.equals(activeItem) && field0796.field_1724.method_6048() >= 10) {
         return (double)2.5F;
      } else if (!(item instanceof class_1823) && !(item instanceof class_1771) && !(item instanceof class_1776)) {
         if (item instanceof class_1753 && item.equals(activeItem) && field0796.field_1724.method_6115()) {
            float tickDelta = field0796.method_61966() != null ? field0796.method_61966().method_60637(false) : 0.0F;
            return (double)(3.0F * class_3532.method_15363(((float)field0796.field_1724.method_6048() + tickDelta) / 20.0F, 0.0F, 1.0F));
         } else {
            if (item instanceof class_1764 && class_1764.method_7781(stack)) {
               class_9278 component = (class_9278)stack.method_57824(class_9334.field_49649);
               if (component != null && !component.method_57437().isEmpty()) {
                  return ((class_1799)component.method_57437().getFirst()).method_31574(class_1802.field_8639) ? (double)100.0F : (double)3.0F;
               }
            }

            return (double)-1.0F;
         }
      } else {
         return (double)1.5F;
      }
   }

   private class_1676 method1232(class_1792 item, class_1799 stack) {
      if (item instanceof class_1779) {
         return new class_1683(field0796.field_1687, field0796.field_1724, stack);
      } else if (item instanceof class_1828) {
         return new class_1686(field0796.field_1687, field0796.field_1724, stack);
      } else if (item instanceof class_1835) {
         return new class_1685(field0796.field_1687, field0796.field_1724, stack);
      } else if (item instanceof class_1823) {
         return new class_1680(field0796.field_1687, field0796.field_1724, stack);
      } else if (item instanceof class_1771) {
         return new class_1681(field0796.field_1687, field0796.field_1724, stack);
      } else if (item instanceof class_1776) {
         return new class_1684(field0796.field_1687, field0796.field_1724, stack);
      } else {
         return !(item instanceof class_1753) && !(item instanceof class_1764) ? null : new class_1667(field0796.field_1687, field0796.field_1724, stack, stack);
      }
   }

   private HitResult method0292(class_243 pos, class_243 motion, class_1676 entity) {
      int i = 0;

      while(true) {
         if (i < 300) {
            class_243 prevPos = pos;
            pos = pos.method_1019(motion);
            motion = this.method1147(entity, prevPos, motion);
            class_239 result = field0796.field_1687.method_17742(new class_3959(prevPos, pos, class_3960.field_17558, class_242.field_1348, entity));
            if (!result.method_17783().equals(class_240.field_1333)) {
               return new HitResult(result, i);
            }

            boolean entityHit = this.method2026().filter((ent) -> {
               boolean var10000;
               if (ent instanceof class_1309 living) {
                  if (living != entity.method_24921() && living.method_5805()) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }).anyMatch((ent) -> this.method1293(ent.method_5829().method_1014(0.3000001804584443), prevPos, pos));
            if (entityHit) {
               return new HitResult(new class_239(pos) {
                  public class_239.class_240 method_17783() {
                     return class_240.field_1331;
                  }
               }, i);
            }

            if (!(pos.field_1351 < (double)-128.0F)) {
               ++i;
               continue;
            }
         }

         return null;
      }
   }

   private static class PathPoint {
      final class_1297 field0730;
      final class_243 field0157;
      final int field1411;
      final class_1799 field1040;
      final long field0760;
      long field1244 = 0L;

      PathPoint(class_1297 entity, class_243 impactPos, int initialTicks, class_1799 stack) {
         this.field0730 = entity;
         this.field0157 = impactPos;
         this.field1411 = initialTicks;
         this.field1040 = stack;
         this.field0760 = System.currentTimeMillis();
      }

      class_1297 method0563() {
         return this.field0730;
      }

      class_243 method0024() {
         return this.field0157;
      }

      int method2048() {
         return this.field1411;
      }

      class_1799 method1801() {
         return this.field1040;
      }

      void method1634() {
         if (this.field1244 == 0L) {
            this.field1244 = System.currentTimeMillis();
         }

      }

      float method0774(long now) {
         if (this.field1244 != 0L) {
            float t = (float)(now - this.field1244) / 200.0F;
            t = Math.min(1.0F, Math.max(0.0F, t));
            return 1.0F - t * t;
         } else {
            float t = (float)(now - this.field0760) / 220.0F;
            t = Math.min(1.0F, Math.max(0.0F, t));
            return 1.0F - (1.0F - t) * (1.0F - t);
         }
      }

      boolean method0161(long now) {
         return this.field1244 != 0L && now - this.field1244 > 200L;
      }
   }

   private static final class ProjectilePath {
      final float field0566;
      final float field0003;

      ProjectilePath(float yaw, float pitch) {
         this.field0566 = yaw;
         this.field0003 = pitch;
      }

      float method0530() {
         return this.field0566;
      }

      float method0002() {
         return this.field0003;
      }

      ProjectilePath method0659(float delta) {
         return new ProjectilePath(this.field0566 + delta, this.field0003);
      }

      ProjectilePath method0123(float delta) {
         return new ProjectilePath(this.field0566, this.field0003 + delta);
      }

      class_243 method2077() {
         float p = (float)Math.toRadians((double)this.field0003);
         float y = (float)Math.toRadians((double)(-this.field0566));
         float cp = class_3532.method_15362(p);
         return new class_243((double)(class_3532.method_15374(y) * cp), (double)(-class_3532.method_15374(p)), (double)(class_3532.method_15362(y) * cp));
      }
   }

   private static record PathMesh(class_1799 stack, class_243 pos, float remainingTime, class_1297 entity, boolean isPotion, class_2350 facing, boolean isEntityHit) {
      public class_1799 method0567() {
         return this.stack;
      }

      public class_243 method0024() {
         return this.pos;
      }

      public float method2047() {
         return this.remainingTime;
      }

      public class_1297 method1798() {
         return this.entity;
      }

      public boolean method1635() {
         return this.isPotion;
      }

      public class_2350 method1969() {
         return this.facing;
      }

      public boolean method0431() {
         return this.isEntityHit;
      }
   }

   private static record HitResult(class_239 hit, int ticks) {
      public class_239 method0568() {
         return this.hit;
      }

      public int method0003() {
         return this.ticks;
      }
   }
}
