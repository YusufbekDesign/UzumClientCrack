package aethereal;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_7924;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public final class CrystalPositionHelper {
   private static final int field0567 = 12;
   private static final class_2382[] field0174;
   private static final int[] field1529 = new int[13];

   private static class_310 method0572() {
      return class_310.method_1551();
   }

   private CrystalPositionHelper() {
   }

   public static int method0609(double radius) {
      return field1529[class_3532.method_15340((int)Math.ceil(radius), 0, field1529.length - 1)];
   }

   public static class_2382 method0726(int index) {
      return field0174[index];
   }

   public static class_243 method1273(class_2338 position, class_2350 direction) {
      return position.method_46558().method_1031((double)direction.method_10148() / (double)2.0F, (double)direction.method_10164() / (double)2.0F, (double)direction.method_10165() / (double)2.0F);
   }

   public static class_2350 method1279(class_2338 position, boolean strictDirection) {
      class_310 mc = method0572();
      if (strictDirection) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (mc.field_1724.method_23318() >= (double)position.method_10264()) {
               return class_2350.field_11036;
            } else {
               class_3965 result = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_33571(), class_243.method_24953(position), class_3960.field_17559, class_242.field_1348, mc.field_1724));
               return result != null && result.method_17783() == class_240.field_1332 && result.method_17780() != null ? result.method_17780() : method1862(position);
            }
         } else {
            return method1862(position);
         }
      } else {
         return method1862(position);
      }
   }

   private static class_2350 method1862(class_2338 position) {
      class_310 mc = method0572();
      if (mc.field_1724 == null) {
         return class_2350.field_11036;
      } else {
         class_2350 closest = null;
         class_243 closestVec = null;

         for(class_2350 direction : class_2350.values()) {
            class_243 hit = method1273(position, direction);
            if (closest == null || mc.field_1724.method_5707(hit) < mc.field_1724.method_5707(closestVec)) {
               closest = direction;
               closestVec = hit;
            }
         }

         return closest;
      }
   }

   public static boolean method1596(class_2338... pos) {
      class_310 mc = method0572();
      return mc.field_1687 == null ? false : Arrays.stream(pos).allMatch((p) -> mc.field_1687.method_8320(p).method_26204().method_36555() != -1.0F);
   }

   public static boolean method0352(class_2338... pos) {
      class_310 mc = method0572();
      return mc.field_1687 == null ? false : Arrays.stream(pos).allMatch((p) -> mc.field_1687.method_8320(p).method_45474());
   }

   public static class_2248 method1261(class_2338 pos) {
      class_310 mc = method0572();
      return mc.field_1687 == null ? null : mc.field_1687.method_8320(pos).method_26204();
   }

   public static boolean method0279(class_2338 position) {
      return method0281(position, false);
   }

   public static boolean method0281(class_2338 position, boolean excludeSelf) {
      class_310 mc = method0572();
      if (mc.field_1687 != null && mc.field_1724 != null) {
         return !mc.field_1687.method_8320(position).method_45474() ? false : mc.field_1687.method_8335((class_1297)null, new class_238(position)).stream().noneMatch((e) -> !(e instanceof class_1511) && !(e instanceof class_1303) && !(e instanceof class_1542) && (!e.equals(mc.field_1724) || !excludeSelf));
      } else {
         return false;
      }
   }

   public static boolean method2159(class_2338 position) {
      class_310 mc = method0572();
      if (mc.field_1687 == null) {
         return false;
      } else {
         return !mc.field_1687.method_8320(position).method_45474() ? false : mc.field_1687.method_8335((class_1297)null, new class_238(position)).stream().noneMatch((e) -> !(e instanceof class_1511) && !(e instanceof class_1303));
      }
   }

   public static float method1364(class_2680 state, int slot) {
      class_310 mc = method0572();
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float speed = ((class_1799)mc.field_1724.method_31548().field_7547.get(slot)).method_7924(state);
         if (speed > 1.0F) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            int efficiency = class_1890.method_8225(mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9131), stack);
            if (efficiency > 0 && !stack.method_7960()) {
               speed += (float)(StrictMath.pow((double)efficiency, (double)2.0F) + (double)1.0F);
            }
         }

         if (mc.field_1724.method_6059(class_1294.field_5917)) {
            speed *= 1.0F + (float)(mc.field_1724.method_6112(class_1294.field_5917).method_5578() + 1) * 0.2F;
         }

         if (mc.field_1724.method_6059(class_1294.field_5901)) {
            speed *= (float)Math.pow((double)0.30000013F, (double)(mc.field_1724.method_6112(class_1294.field_5901).method_5578() + 1));
         }

         if (mc.field_1724.method_5777(class_3486.field_15517)) {
            speed *= (float)mc.field_1724.method_5996(class_5134.field_51576).method_6194();
         }

         if (!mc.field_1724.method_24828()) {
            speed /= 5.0F;
         }

         speed = speed < 0.0F ? 0.0F : speed;
         float hardness = state.method_26204().method_36555();
         return hardness <= 0.0F ? 0.0F : speed / hardness / (float)(state.method_29291() && !((class_1799)mc.field_1724.method_31548().field_7547.get(slot)).method_7951(state) ? 100 : 30);
      } else {
         return 0.0F;
      }
   }

   static {
      class_2338 origin = class_2338.field_10980;
      Set<class_2338> positions = new TreeSet((o, p) -> {
         if (o.equals(p)) {
            return 0;
         } else {
            int compare = Double.compare(origin.method_10262(o), origin.method_10262(p));
            if (compare == 0) {
               compare = Integer.compare(Math.abs(o.method_10263()) + Math.abs(o.method_10264()) + Math.abs(o.method_10260()), Math.abs(p.method_10263()) + Math.abs(p.method_10264()) + Math.abs(p.method_10260()));
            }

            return compare == 0 ? 1 : compare;
         }
      });

      for(int x = -12; x <= 12; ++x) {
         for(int z = -12; z <= 12; ++z) {
            for(int y = -12; y < 12; ++y) {
               double sq = (double)x * (double)x + (double)y * (double)y + (double)z * (double)z;
               if (sq < (double)class_3532.method_34954(12)) {
                  positions.add(new class_2338(x, y, z));
               }
            }
         }
      }

      field0174 = new class_2382[positions.size()];
      int i = 0;
      int currentDistance = 0;

      class_2338 position;
      for(Iterator var9 = positions.iterator(); var9.hasNext(); field0174[i++] = position) {
         for(position = (class_2338)var9.next(); Math.sqrt(origin.method_10262(position)) > (double)currentDistance && currentDistance < field1529.length; field1529[currentDistance++] = i) {
         }
      }

      while(currentDistance < field1529.length) {
         field1529[currentDistance++] = i;
      }

   }
}
