package aethereal;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class SettingWidgetFactory {
   private SettingWidgetFactory() {
      throw new AssertionError("No instances");
   }

   public static List<SettingWidget> method0841(ModuleCard module) {
      Objects.requireNonNull(module, "module must not be null");
      List<Setting<?>> settings = module.method1954().method1914();
      List<SettingWidget> result = new ArrayList(settings.size());

      for(int i = 0; i < settings.size(); ++i) {
         SettingWidget sd = method0866(module.method0418(), (Setting)settings.get(i));
         if (sd != null) {
            result.add(sd);
         }
      }

      return result;
   }

   public static SettingWidget method0866(Animation animation, Setting setting) {
      Objects.requireNonNull(animation, "animation must not be null");
      Objects.requireNonNull(setting, "setting must not be null");
      Objects.requireNonNull(setting);
      byte var3 = 0;
      Object var10000;
      //$FF: var3->value
      //0->aethereal/BooleanSetting
      //1->aethereal/FloatSetting
      //2->aethereal/EnumSetting
      //3->aethereal/MultiSelectSetting
      //4->aethereal/KeyBindSetting
      //5->aethereal/ColorSetting
      //6->aethereal/BlockListSetting
      //7->aethereal/KeyBindListSetting
      //8->aethereal/NumberListSetting
      //9->aethereal/ConditionalBooleanSetting
      switch (setting.typeSwitch<invokedynamic>(setting, var3)) {
         case 0:
            BooleanSetting s = (BooleanSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new BooleanSettingWidget(s, animation::method0002);
            break;
         case 1:
            FloatSetting s = (FloatSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new NumberSettingWidget(s, animation::method0002);
            break;
         case 2:
            EnumSetting<?> s = (EnumSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new EnumSettingWidget(s, animation::method0002);
            break;
         case 3:
            MultiSelectSetting s = (MultiSelectSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new MultiSelectSettingWidget(s, animation::method0002);
            break;
         case 4:
            KeyBindSetting s = (KeyBindSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new KeyBindSettingWidget(s, animation::method0002);
            break;
         case 5:
            ColorSetting s = (ColorSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new ColorSettingWidget(s, animation::method0002);
            break;
         case 6:
            BlockListSetting s = (BlockListSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new BlockListSettingWidget(s, animation::method0002);
            break;
         case 7:
            KeyBindListSetting s = (KeyBindListSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new KeyBindListSettingWidget(s, animation::method0002);
            break;
         case 8:
            NumberListSetting s = (NumberListSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new NumberListSettingWidget(s, animation::method0002);
            break;
         case 9:
            ConditionalBooleanSetting s = (ConditionalBooleanSetting)setting;
            Objects.requireNonNull(animation);
            var10000 = new ConditionalToggleWidget(s, animation::method0002);
            break;
         default:
            var10000 = null;
      }

      return (SettingWidget)var10000;
   }
}
