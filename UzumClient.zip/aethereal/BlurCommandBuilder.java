package aethereal;

public final class BlurCommandBuilder extends RenderCommandBuilder<BlurRenderCommand> {
   private RenderSize field0680;
   private CornerRadius field0050;
   private QuadColor field1481;
   private float field0957;
   private float field0758;

   public BlurCommandBuilder method0919(RenderSize size) {
      this.field0680 = size;
      return this;
   }

   public BlurCommandBuilder method0818(CornerRadius radius) {
      this.field0050 = radius;
      return this;
   }

   public BlurCommandBuilder method0910(QuadColor color) {
      this.field1481 = color;
      return this;
   }

   public BlurCommandBuilder method0647(float smoothness) {
      this.field0957 = smoothness;
      return this;
   }

   public BlurCommandBuilder method0116(float blurRadius) {
      this.field0758 = blurRadius;
      return this;
   }

   protected BlurRenderCommand method1765() {
      return new BlurRenderCommand(this.field0680, this.field0050, this.field1481, this.field0957, this.field0758);
   }

   protected void method0025() {
      this.field0680 = RenderSize.NONE;
      this.field0050 = CornerRadius.NO_ROUND;
      this.field1481 = QuadColor.WHITE;
      this.field0957 = 1.0F;
      this.field0758 = 0.0F;
   }

   // $FF: synthetic method
   protected Object method2066() {
      return this.method1765();
   }
}
