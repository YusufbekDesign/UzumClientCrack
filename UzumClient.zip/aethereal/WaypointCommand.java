package aethereal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_243;
import net.minecraft.class_2561;

public final class WaypointCommand extends Command implements MinecraftAccess {
   public WaypointCommand() {
      super("waypoint", "Manage waypoints", "wp");
      this.method1013("Управление вейпойнтами");
   }

   private WaypointManager method1616() {
      return ArbuzClient.method2004().method1956();
   }

   public void method0800(CommandContext context) {
      String[] args = context.method1814();
      if (args.length == 0) {
         this.method2112(context);
      } else {
         switch (args[0].toLowerCase()) {
            case "add":
               this.method0803(context, args);
               break;
            case "del":
            case "remove":
               this.method0168(context, args);
               break;
            case "list":
               this.method2113(context, args);
               break;
            case "clear":
               this.method0167(context);
               break;
            default:
               this.method2112(context);
         }

      }
   }

   private void method0803(CommandContext context, String[] args) {
      if (args.length < 2) {
         context.method0213("Usage: .wp add <name> [x y z]");
      } else {
         String name = args[1];
         if (name.contains("|")) {
            context.method0213("Name cannot contain '|'");
         } else if (field0796.field_1687 == null) {
            context.method0213("Cannot add waypoint: not in a world");
         } else if (this.method1616().method1009(name) != null) {
            context.method0213("Waypoint '" + name + "' already exists here");
         } else {
            double x;
            double y;
            double z;
            if (args.length == 2) {
               if (field0796.field_1724 == null) {
                  context.method0213("Cannot add waypoint: no player");
                  return;
               }

               x = field0796.field_1724.method_23317();
               y = field0796.field_1724.method_23318();
               z = field0796.field_1724.method_23321();
            } else {
               if (args.length != 5) {
                  context.method0213("Usage: .wp add <name> [x y z]");
                  return;
               }

               try {
                  x = Double.parseDouble(args[2]);
                  y = Double.parseDouble(args[3]);
                  z = Double.parseDouble(args[4]);
               } catch (NumberFormatException var12) {
                  context.method0213("Invalid coordinates");
                  return;
               }
            }

            int color = WaypointManager.method1947();
            WaypointManager.Waypoint wp = new WaypointManager.Waypoint(name, x, y, z, color, WaypointManager.method1791(), WaypointManager.method1619());
            this.method1616().method0941(wp);
            context.method1013(String.format("Added waypoint '%s' at %d %d %d", name, (int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z)));
         }
      }
   }

   private void method0168(CommandContext context, String[] args) {
      if (args.length < 2) {
         context.method0213("Usage: .wp del <name>");
      } else {
         String name = args[1];
         if (!this.method1616().method0214(name)) {
            context.method0213("Waypoint '" + name + "' not found here");
         } else {
            context.method1013("Removed waypoint '" + name + "'");
         }
      }
   }

   private void method2113(CommandContext context, String[] args) {
      boolean all = args.length >= 2 && args[1].equalsIgnoreCase("all");
      List<WaypointManager.Waypoint> list;
      if (all) {
         list = this.method1616().method2192();
      } else {
         list = this.method1616().method0424();
      }

      if (list.isEmpty()) {
         context.method2134(all ? "No waypoints saved" : "No waypoints in current world");
      } else {
         context.method2134("Waypoints (" + list.size() + "):");
         if (all) {
            for(WaypointManager.Waypoint wp : list) {
               context.method1846(String.format("- [%s | %s] %s  %d %d %d", wp.method1961(), method2131(wp.method0423()), wp.method0557(), (int)Math.floor(wp.method0001()), (int)Math.floor(wp.method2046()), (int)Math.floor(wp.method1761())));
            }
         } else {
            for(WaypointManager.Waypoint wp : list) {
               long dist = field0796.field_1724 == null ? 0L : Math.round(field0796.field_1724.method_19538().method_1022(new class_243(wp.method0001(), wp.method2046(), wp.method1761())));
               context.method1846(String.format("- %s  %d %d %d  (%dm)", wp.method0557(), (int)Math.floor(wp.method0001()), (int)Math.floor(wp.method2046()), (int)Math.floor(wp.method1761()), dist));
            }
         }

      }
   }

   private void method0167(CommandContext context) {
      int removed = this.method1616().method0356();
      context.method1013("Cleared " + removed + " waypoint" + (removed == 1 ? "" : "s"));
   }

   private static String method2131(String dim) {
      String var10000;
      switch (dim) {
         case "minecraft:overworld" -> var10000 = "o";
         case "minecraft:the_nether" -> var10000 = "n";
         case "minecraft:the_end" -> var10000 = "e";
         default -> var10000 = dim;
      }

      return var10000;
   }

   public List<String> method1593(String[] args) {
      if (args.length <= 1) {
         String input = args.length == 1 ? args[0].toLowerCase() : "";
         return List.of("add", "del", "list", "clear").stream().filter((s) -> s.startsWith(input)).toList();
      } else if (args.length != 2 || !args[0].equalsIgnoreCase("del") && !args[0].equalsIgnoreCase("remove")) {
         if (args.length == 2 && args[0].equalsIgnoreCase("list")) {
            String input = args[1].toLowerCase();
            return "all".startsWith(input) ? List.of("all") : List.of();
         } else {
            return List.of();
         }
      } else {
         String input = args[1].toLowerCase();
         List<String> names = new ArrayList();

         for(WaypointManager.Waypoint wp : this.method1616().method0424()) {
            if (wp.method0557().toLowerCase().startsWith(input)) {
               names.add(wp.method0557());
            }
         }

         return names;
      }
   }

   public String method2179(String[] args) {
      if (args.length == 2) {
         String var4;
         switch (args[0].toLowerCase()) {
            case "add":
            case "del":
            case "remove":
               var4 = method1813() ? "<имя>" : "<name>";
               break;
            default:
               var4 = "";
         }

         return var4;
      } else if (args.length >= 3 && args[0].equalsIgnoreCase("add")) {
         String var10000;
         switch (args.length) {
            case 3 -> var10000 = "<x> <y> <z>";
            case 4 -> var10000 = "<y> <z>";
            case 5 -> var10000 = "<z>";
            default -> var10000 = "";
         }

         return var10000;
      } else {
         return "";
      }
   }

   public Map<String, String> method0351(String[] args) {
      return args.length <= 1 ? Map.of("add", "Add waypoint at current position", "del", "Remove waypoint", "list", "Show waypoints", "clear", "Clear waypoints in current world") : Map.of();
   }

   private void method2112(CommandContext context) {
      String prefix = ArbuzClient.method2004().method2257().method2067();
      context.method0297(class_2561.method_43470("Waypoint commands:").method_27694((s) -> s.method_36139(8947848)));
      context.method0297(class_2561.method_43470(prefix + "wp add <name> [x y z]").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(" - Add waypoint").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "wp del <name>").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(" - Remove waypoint").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "wp list [all]").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(" - Show waypoints").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "wp clear").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(" - Clear current world's waypoints").method_27694((s) -> s.method_36139(7829367))));
   }
}
