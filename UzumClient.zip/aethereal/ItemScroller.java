package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;
import org.patch.arbuzhack.api.mixins.accessors.IHandledScreen;

public class ItemScroller extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("itemscroller.delay", 100.0F, 1.0F, 100.0F, 1.0F)).method1007("Kechikish").method0210("Delay in ms between item moves").method2130("Buyum harakatlari orasidagi kechikish");
   private final Stopwatch field1464 = new Stopwatch();

   public ItemScroller() {
      super("ItemScroller", ModuleCategory.field1470, "Inventarda buyumlarni tez ko'chirish");
      this.method1013("Inventarda buyumlarni tez ko'chirish");
   }

   @EventHandler
   private void onRender2D(HudRenderEvent var1) {
      if (!method1974()) {
         class_437 var3 = field0796.field_1755;
         if (var3 instanceof class_465) {
            class_465<?> var2 = (class_465)var3;
            IHandledScreen var9 = (IHandledScreen)var2;
            class_1735 var4 = var9.getFocusedSlot();
            if (var4 != null && var4.method_7681()) {
               long var5 = field0796.method_22683().method_4490();
               boolean var7 = GLFW.glfwGetMouseButton(var5, 0) == 1;
               boolean var8 = class_3675.method_15987(var5, 340) || class_3675.method_15987(var5, 344);
               if (var7 && var8 && this.field1464.method0779(((Float)this.field0060.method0492()).longValue())) {
                  var9.arbuz$onMouseClick(var4, var4.field_7874, 0, class_1713.field_7794);
                  this.field1464.method1812();
               }
            }
         }
      }

   }
}
