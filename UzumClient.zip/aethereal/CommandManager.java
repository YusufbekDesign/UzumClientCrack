package aethereal;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class CommandManager {
   private final Map<String, Command> field0720;
   private String field0136;

   public CommandManager() {
      this(".");
   }

   public CommandManager(String prefix) {
      this.field0720 = new ConcurrentHashMap();
      this.field0136 = prefix;
   }

   public void method0578() {
      this.method1589(new HelpCommand(), new ConfigCommand(), new PrefixCommand(), new FriendCommand(), new WaypointCommand(), new GpsCommand(), new StaffCommand());
   }

   public void method1589(Command... commands) {
      for(Command command : commands) {
         this.method0849(command);
      }

   }

   public void method0849(Command command) {
      Objects.requireNonNull(command, "Command cannot be null");
      this.field0720.put(command.method0557().toLowerCase(), command);
   }

   public void method1013(String name) {
      this.field0720.remove(name.toLowerCase());
   }

   public boolean method0214(String input) {
      if (!input.startsWith(this.field0136)) {
         return false;
      } else {
         String[] parts = input.substring(this.field0136.length()).trim().split("\\s+");
         if (parts.length != 0 && !parts[0].isEmpty()) {
            String commandName = parts[0];
            String[] args = (String[])Arrays.copyOfRange(parts, 1, parts.length);
            Optional<Command> command = this.method2133(commandName);
            if (command.isPresent()) {
               try {
                  CommandContext context = new CommandContext((Command)command.get(), commandName, input, args);
                  ((Command)command.get()).method0800(context);
                  return true;
               } catch (Exception e) {
                  CommandContext errorContext = new CommandContext((Command)null, commandName, input, args);
                  errorContext.method0213("Command execution error: " + e.getMessage());
                  return false;
               }
            } else {
               CommandContext errorContext = new CommandContext((Command)null, commandName, input, args);
               errorContext.method0213("Unknown command");
               errorContext.method2134("Use 'help' command for available commands");
               return false;
            }
         } else {
            CommandContext emptyContext = new CommandContext((Command)null, "", input, new String[0]);
            emptyContext.method2134("Use 'help' command for available commands");
            return true;
         }
      }
   }

   public Collection<Command> method0018() {
      return Collections.unmodifiableCollection(this.field0720.values());
   }

   public Optional<Command> method2133(String name) {
      return this.field0720.values().stream().filter((cmd) -> cmd.method0214(name)).findFirst();
   }

   public String method2067() {
      return this.field0136;
   }

   public void method1846(String prefix) {
      this.field0136 = (String)Objects.requireNonNull(prefix, "Prefix cannot be null");
   }
}
