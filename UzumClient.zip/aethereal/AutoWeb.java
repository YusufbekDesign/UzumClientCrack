package aethereal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3532;

public class AutoWeb extends Module {
   private static final float field0003 = 6.0F;
   private static final float field1410 = 10.0F;
   private final EnumSetting<PlacementMode> field0984;
   private final MultiSelectSetting field0202;
   private final FloatSetting field0470;
   private final BooleanSetting field1619;
   private final TargetSelector field1549;
   private final Stopwatch field1720;
   private class_1309 field1157;
   private PlacementCandidate field1092;
   private int field1197;

   public static AutoWeb method1704() {
      ArbuzClient arbuz = ArbuzClient.method2004();
      return arbuz != null && arbuz.method1783() != null ? (AutoWeb)arbuz.method1783().method0976(AutoWeb.class) : null;
   }

   public AutoWeb() {
      super("AutoWeb", ModuleCategory.field0661, "Places cobwebs under enemy feet to immobilize them");
      this.field0984 = (EnumSetting)(new EnumSetting("autoweb.placemode", AutoWeb.PlacementMode.field0596)).method1007("Place Mode").method0210("Default: single web at feet. Multi: 2 webs vertically at feet + 1 web around target").method2130("Default: 1 паутина под ноги. Multi: по 1 вокруг");
      this.field0202 = (MultiSelectSetting)(new MultiSelectSetting("autoweb.targettype", Arrays.asList("Players", "Naked", "Mobs", "Animals", "Friends", "Armor Stand"), false, () -> true)).method1007("Target Type").method0210("Entity types that can be targeted").method2130("Типы сущностей, которые можно таргетить");
      this.field0470 = (FloatSetting)(new FloatSetting("autoweb.placespeed", 20.0F, 1.0F, 20.0F, 1.0F)).method1007("Place Speed").method0210("Place rate in webs per second").method2130("Скорость установки");
      this.field1619 = (BooleanSetting)(new BooleanSetting("autoweb.frominventory", false)).method1007("From Inventory").method0210("Use cobweb from the main inventory when none is in hotbar (swap → place → swap back)").method2130("Ставить паутину из инвентаря, если в хотбаре её нет");
      this.field1549 = new TargetSelector();
      this.field1720 = new Stopwatch();
      this.field1197 = -1;
      this.method1013("Застраивает ноги противника паутиной");
   }

   public void method2078() {
      this.method1691();
      this.field1549.method0578();
      this.field1157 = null;
      this.field1092 = null;
      super.method2078();
   }

   @EventHandler
   public void onRotationUpdate(RotationUpdateEvent e) {
      if (e.method1760() == 0) {
         if (!method1974()) {
            this.field1157 = this.method2027();
            this.field1092 = null;
            if (this.field1157 != null) {
               if (this.method1755()) {
                  this.field1092 = this.method1259(this.field1157.method_24515());
                  if (this.field1092 != null) {
                     ThreadLocalRandom rng = ThreadLocalRandom.current();
                     float jy = (rng.nextFloat() - 0.5F) * 0.4F;
                     float jp = (rng.nextFloat() - 0.5F) * 0.4F;
                     Rotation jittered = new Rotation(this.field1092.field1466.method2047() + jy, this.field1092.field1466.method1762() + jp);
                     RotationHandler cfg = new RotationHandler(new AutoWebRotationStrategy(), true, true);
                     RotationManager.field0618.method0875(jittered, cfg, RotationPriority.field0778, this);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onUpdateMovementPost(PostMovementEvent e) {
      if (!method1974()) {
         this.method1691();
         if (this.field1092 != null && this.field1157 != null) {
            if (this.method1755()) {
               if (this.field1720.method1646((long)(1000.0F / (Float)this.field0470.method0492()))) {
                  Rotation server = RotationManager.field0618.method2258();
                  if (!(RotationManager.method0871(server, this.field1092.field1466) > (double)10.0F)) {
                     this.method1274(this.field1092.field0733, this.field1092.field0155);
                  }
               }
            }
         }
      }
   }

   private void method1691() {
      if (this.field1197 != -1) {
         if (field0796.field_1724 != null && field0796.method_1562() != null) {
            field0796.method_1562().method_52787(new class_2868(this.field1197));
            this.field1197 = -1;
         } else {
            this.field1197 = -1;
         }
      }
   }

   private void method1274(class_2338 pos, class_2350 support) {
      int previousSlot = field0796.field_1724.method_31548().field_7545;
      class_1268 hand = BlockPlacementContext.method1219(class_1802.field_8786);
      if (hand != null) {
         boolean placed = BlockPlacementContext.method1275(pos, support, hand, false);
         if (placed) {
            this.field1720.method1634();
         }

      } else {
         int hotbarSlot = InventoryManager.method2154(class_1802.field_8786);
         if (hotbarSlot != -1) {
            field0796.method_1562().method_52787(new class_2868(hotbarSlot));
            boolean placed = BlockPlacementContext.method1275(pos, support, class_1268.field_5808, false);
            this.field1197 = previousSlot;
            if (placed) {
               this.field1720.method1634();
            }

         } else if ((Boolean)this.field1619.method0492()) {
            int invSlot = InventoryManager.method1859(class_1802.field_8786);
            if (invSlot != -1) {
               field0796.field_1761.method_2906(0, invSlot, previousSlot, class_1713.field_7791, field0796.field_1724);
               boolean placed = BlockPlacementContext.method1275(pos, support, class_1268.field_5808, false);
               field0796.field_1761.method_2906(0, invSlot, previousSlot, class_1713.field_7791, field0796.field_1724);
               if (placed) {
                  this.field1720.method1634();
               }

            }
         }
      }
   }

   private PlacementCandidate method1259(class_2338 feet) {
      List<class_2338> wanted = new ArrayList();
      switch (((PlacementMode)this.field0984.method0492()).ordinal()) {
         case 0:
            wanted.add(feet);
            break;
         case 1:
            wanted.add(feet);
            wanted.add(feet.method_10084());
            wanted.add(feet.method_10095());
            wanted.add(feet.method_10072());
            wanted.add(feet.method_10078());
            wanted.add(feet.method_10067());
      }

      class_243 eye = field0796.field_1724.method_33571();
      double reach = field0796.field_1724.method_55754();
      double reachSq = class_3532.method_33723(reach);

      for(class_2338 pos : wanted) {
         if (field0796.field_1687.method_8320(pos).method_45474()) {
            class_2350 support = BlockPlacementContext.method0277(pos);
            if (support != null) {
               class_2338 supportPos = pos.method_10093(support);
               class_2350 clickFace = support.method_10153();
               class_243 hit = new class_243((double)supportPos.method_10263() + (double)0.5F + (double)clickFace.method_10148() * (double)0.5F, (double)supportPos.method_10264() + (double)0.5F + (double)clickFace.method_10164() * (double)0.5F, (double)supportPos.method_10260() + (double)0.5F + (double)clickFace.method_10165() * (double)0.5F);
               if (!(eye.method_1025(hit) > reachSq)) {
                  Rotation angle = RotationHelper.method1296(hit.method_1020(eye));
                  return new PlacementCandidate(pos, support, angle);
               }
            }
         }
      }

      return null;
   }

   private boolean method1755() {
      if (field0796.field_1724.method_6047().method_7909() == class_1802.field_8786) {
         return true;
      } else if (field0796.field_1724.method_6079().method_7909() == class_1802.field_8786) {
         return true;
      } else if (InventoryManager.method2154(class_1802.field_8786) != -1) {
         return true;
      } else {
         return (Boolean)this.field1619.method0492() && InventoryManager.method1859(class_1802.field_8786) != -1;
      }
   }

   private class_1309 method2027() {
      class_1309 auraTarget = this.method2013();
      if (auraTarget != null) {
         return auraTarget;
      } else {
         TargetSelector.TargetScore filter = new TargetSelector.TargetScore(this.field0202.method1936());
         this.field1549.method0986(field0796.field_1687.method_18112(), 6.0F, 360.0F, true);
         TargetSelector var10000 = this.field1549;
         Objects.requireNonNull(filter);
         var10000.method1105(filter::method1159);
         return this.field1549.method2074();
      }
   }

   private class_1309 method2013() {
      Aura aura = Aura.method1701();
      if (aura != null && aura.method2195()) {
         class_1309 t = aura.method0409();
         if (t != null && t.method_5805()) {
            return t;
         } else {
            class_1309 last = aura.method0520();
            return last != null && last.method_5805() ? last : null;
         }
      } else {
         return null;
      }
   }

   public static enum PlacementMode implements DisplayNamed {
      field0596("Default"),
      field0031("Multi");

      private final String field1504;

      private PlacementMode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static PlacementMode[] method0049() {
         return new PlacementMode[]{field0596, field0031};
      }
   }

   private static final class PlacementCandidate {
      final class_2338 field0733;
      final class_2350 field0155;
      final Rotation field1466;

      PlacementCandidate(class_2338 pos, class_2350 support, Rotation angle) {
         this.field0733 = pos;
         this.field0155 = support;
         this.field1466 = angle;
      }
   }
}
