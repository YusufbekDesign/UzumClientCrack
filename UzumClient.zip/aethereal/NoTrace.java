package aethereal;

import net.minecraft.class_1297;
import net.minecraft.class_1829;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class NoTrace extends Module {
   private final MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("notrace.modes", new BooleanSetting[]{(BooleanSetting)(new BooleanSetting("notrace.player", false)).method1007("Player").method0210("Hit through entities").method2130("Бить сквозь сущности"), (BooleanSetting)(new BooleanSetting("notrace.web", true)).method1007("Web").method0210("Interact through cobwebs as if invisible").method2130("Взаимодействовать сквозь паутину как если её нет")})).method1007("Modes").method0210("What to ignore when targeting").method2130("Что игнорировать при наведении");
   private final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("notrace.nosword", true)).method1007("No Sword").method0210("Disable when holding a sword").method2130("Отключить с мечом в руке");

   public NoTrace() {
      super("NoTrace", ModuleCategory.field1470, "Ignores entities or cobwebs when targeting");
      this.method1013("Игнорирует сущности или паутину при наведении");
   }

   private boolean method1755() {
      if (this.method2195() && field0796.field_1724 != null) {
         return !(field0796.field_1724.method_6047().method_7909() instanceof class_1829) || !(Boolean)this.field1432.method0492();
      } else {
         return false;
      }
   }

   public boolean method1736() {
      return this.method1755() && (Boolean)this.field0089.method0439("notrace.player").method0492();
   }

   public boolean method1692() {
      return this.method1755() && (Boolean)this.field0089.method0439("notrace.web").method0492();
   }

   public class_3965 method1131(class_1297 entity, double maxDistance, float tickDelta, boolean includeFluids) {
      class_243 start = entity.method_5836(tickDelta);
      class_243 look = entity.method_5828(tickDelta);
      class_243 end = start.method_1031(look.field_1352 * maxDistance, look.field_1351 * maxDistance, look.field_1350 * maxDistance);
      class_3959.class_242 fluidHandling = includeFluids ? class_242.field_1347 : class_242.field_1348;
      class_1937 world = field0796.field_1687;
      class_3959 ctx = new class_3959(start, end, class_3960.field_17559, fluidHandling, entity);
      class_3965[] firstWebHit = new class_3965[1];
      return (class_3965)class_1922.method_17744(start, end, ctx, (context, pos) -> {
         class_2680 state = world.method_8320(pos);
         if (state.method_27852(class_2246.field_10343)) {
            if (firstWebHit[0] == null) {
               class_265 shape = context.method_17748(state, world, pos);
               class_3965 webHit = world.method_17745(context.method_17750(), context.method_17747(), pos, shape, state);
               if (webHit != null) {
                  firstWebHit[0] = webHit;
               }
            }

            return null;
         } else {
            class_3610 fluidState = world.method_8316(pos);
            class_243 s = context.method_17750();
            class_243 e = context.method_17747();
            class_265 blockShape = context.method_17748(state, world, pos);
            class_3965 blockHit = world.method_17745(s, e, pos, blockShape, state);
            class_265 fluidShape = context.method_17749(fluidState, world, pos);
            class_3965 fluidHit = fluidShape.method_1092(s, e, pos);
            double blockDist = blockHit == null ? 1.7976922776554363E308 : s.method_1025(blockHit.method_17784());
            double fluidDist = fluidHit == null ? 1.7976922776554363E308 : s.method_1025(fluidHit.method_17784());
            return blockDist <= fluidDist ? blockHit : fluidHit;
         }
      }, (context) -> {
         if (firstWebHit[0] != null) {
            return firstWebHit[0];
         } else {
            class_243 v = context.method_17750().method_1020(context.method_17747());
            return class_3965.method_17778(context.method_17747(), class_2350.method_10147((float)v.field_1352, (float)v.field_1351, (float)v.field_1350), class_2338.method_49638(context.method_17747()));
         }
      });
   }
}
