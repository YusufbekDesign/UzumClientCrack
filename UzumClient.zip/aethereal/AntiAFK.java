package aethereal;

import meteordevelopment.orbit.EventHandler;

public class AntiAFK extends Module {
   private final EnumSetting<Mode> field0058;
   private final FloatSetting field1450;
   private final FloatSetting field0985;
   private final FloatSetting field0190;
   private final FloatSetting field0470;
   private final TextSetting field1640;
   private final Stopwatch field1560;

   public AntiAFK() {
      super("AntiAFK", ModuleCategory.field1470, "AFK ga ketishga ruxsat bermaydi");
      this.field0058 = (EnumSetting)(new EnumSetting("antiafk.mode", AntiAFK.Mode.field0571)).method1007("Rejim").method0210("Action").method2130("Amal");
      this.field1450 = (FloatSetting)(new FloatSetting("antiafk.jumptime", 1.0F, 1.0F, 60.0F, 1.0F, () -> this.field0058.method0492() == AntiAFK.Mode.field0571)).method1007("Sakrash vaqti").method0210("Seconds between jumps").method2130("Sakrashlar orasidagi soniyalar");
      this.field0985 = (FloatSetting)(new FloatSetting("antiafk.rottime", 1.0F, 1.0F, 60.0F, 1.0F, () -> this.field0058.method0492() == AntiAFK.Mode.field0008)).method1007("Aylanish vaqti").method0210("Seconds between rotations").method2130("Aylanishlar orasidagi soniyalar");
      this.field0190 = (FloatSetting)(new FloatSetting("antiafk.angle", 10.0F, 1.0F, 180.0F, 10.0F, () -> this.field0058.method0492() == AntiAFK.Mode.field0008)).method1007("Aylanish burchagi").method0210("Yaw").method2130("Burchak");
      this.field0470 = (FloatSetting)(new FloatSetting("antiafk.msgtime", 15.0F, 1.0F, 60.0F, 1.0F, () -> this.field0058.method0492() == AntiAFK.Mode.field1415)).method1007("Xabar vaqti").method0210("Seconds between messages").method2130("Xabarlar orasidagi soniyalar");
      this.field1640 = (TextSetting)(new TextSetting("antiafk.msg", "/арбуздыняананасяпидорас", () -> this.field0058.method0492() == AntiAFK.Mode.field1415, false)).method1007("Xabar").method0210("Text or command to send").method2130("Jo'natish uchun matn yoki buyruq");
      this.field1560 = new Stopwatch();
      this.method1013("AFK ga ketishga ruxsat bermaydi");
   }

   public void method0025() {
      this.field1560.method1812();
      super.method0025();
   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (!method1974()) {
         switch (((Mode)this.field0058.method0492()).ordinal()) {
            case 0:
               if (!this.field1560.method0779((long)((Float)this.field1450.method0492() * 1000.0F))) {
                  return;
               }

               if (field0796.field_1724.method_24828()) {
                  field0796.field_1724.method_6043();
                  this.field1560.method1812();
               }
               break;
            case 1:
               if (!this.field1560.method0779((long)((Float)this.field0985.method0492() * 1000.0F))) {
                  return;
               }

               field0796.field_1724.method_36456(field0796.field_1724.method_36454() + (Float)this.field0190.method0492());
               this.field1560.method1812();
               break;
            case 2:
               if (!this.field1560.method0779((long)((Float)this.field0470.method0492() * 1000.0F))) {
                  return;
               }

               String var2 = (String)this.field1640.method0492();
               if (var2 == null || var2.isBlank()) {
                  return;
               }

               if (var2.startsWith("/")) {
                  field0796.field_1724.field_3944.method_45730(var2.substring(1));
               } else {
                  field0796.field_1724.field_3944.method_45729(var2);
               }

               this.field1560.method1812();
         }
      }

   }

   public static enum Mode implements DisplayNamed {
      field0571("Jump"),
      field0008("Rotate"),
      field1415("Message");

      private final String field1030;

      private Mode(String var3) {
         this.field1030 = var3;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0571, field0008, field1415};
      }
   }
}
