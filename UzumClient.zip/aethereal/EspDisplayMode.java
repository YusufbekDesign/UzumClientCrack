package aethereal;

public enum EspDisplayMode implements DisplayNamed {
   field0669("Visual"),
   field0097("Skeleton"),
   field1474("Slots");

   private final String field1030;

   private EspDisplayMode(String var3) {
      this.field1030 = var3;
   }

   public String method0557() {
      return this.field1030;
   }

   // $FF: synthetic method
   private static EspDisplayMode[] $values() {
      return new EspDisplayMode[]{field0669, field0097, field1474};
   }
}
