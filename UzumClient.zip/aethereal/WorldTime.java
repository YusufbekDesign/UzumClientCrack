package aethereal;

public class WorldTime extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("worldtime.hour", 12.0F, 0.0F, 24.0F, 1.0F)).method1007("Soat").method0210("Kunduzgi vizual vaqt soatlarda").method2130("Vizual kun vaqti soatlarda");

   public WorldTime() {
      super("WorldTime", ModuleCategory.field1004, "Kunduzgi vizual vaqtni boshqaradi");
   }

   public long method1699() {
      float var1 = (Float)this.field0060.method0492();
      long var2 = (long)((var1 - 6.0F) * 1000.0F);
      if (var2 < 0L) {
         var2 += 24000L;
      }

      return var2;
   }
}
