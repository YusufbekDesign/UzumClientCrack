package aethereal;

public class NoRender extends Module {
   public MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("norender.elements", new BooleanSetting[]{(BooleanSetting)(new BooleanSetting("norender.fire", false)).method1007("Olov").method0210("Ekrandagi olov qoplamasini yashirish").method2130("Ekrandagi olov qoplamasini yashirish"), (BooleanSetting)(new BooleanSetting("norender.hurtcam", false)).method1007("Zarba kamerasi").method0210("Zarba olinganda ekran silkinishini o'chirish").method2130("Zarba olinganda ekran silkinishini o'chirish"), (BooleanSetting)(new BooleanSetting("norender.totem", false)).method1007("Totem").method0210("Totem chiqish animatsiyasini yashirish").method2130("Totem chiqish animatsiyasini yashirish"), (BooleanSetting)(new BooleanSetting("norender.potions", false)).method1007("Dorilar").method0210("Dori effekti zarrachalarini yashirish").method2130("Dori effekti zarrachalarini yashirish"), (BooleanSetting)(new BooleanSetting("norender.scoreboard", false)).method1007("Hisob paneli").method0210("Hisob paneli yon panelini yashirish").method2130("Hisob paneli yon panelini yashirish"), (BooleanSetting)(new BooleanSetting("norender.bossbar", false)).method1007("Boss paneli").method0210("Boss salomatlik panelini yashirish").method2130("Boss salomatlik panelini yashirish"), (BooleanSetting)(new BooleanSetting("norender.underwater", false)).method1007("Suv osti").method0210("Suv osti qoplamasi va tumanini yashirish").method2130("Suv osti qoplamasi va tumanini yashirish"), (BooleanSetting)(new BooleanSetting("norender.portal", false)).method1007("Portal").method0210("Nether portal qoplamasini yashirish").method2130("Nether portal qoplamasini yashirish"), (BooleanSetting)(new BooleanSetting("norender.blindness", false)).method1007("Ko'rlik").method0210("Ko'rlik effektini olib tashlash").method2130("Ko'rlik effektini olib tashlash"), (BooleanSetting)(new BooleanSetting("norender.nausea", false)).method1007("Ko'ngil aynish").method0210("Ko'ngil aynish/laylak effektini olib tashlash").method2130("Ko'ngil aynish effektini olib tashlash"), (BooleanSetting)(new BooleanSetting("norender.blockoverlay", false)).method1007("Blok qoplamasi").method0210("Bosh blok ichida bo'lganda qoplamani yashirish").method2130("Bosh blok ichida bo'lganda qoplamani yashirish"), (BooleanSetting)(new BooleanSetting("norender.armor", false)).method1007("Yomon").method0210("Mavjudotlardagi yomoni yashirish").method2130("Mavjudotlardagi yomoni yashirish"), (BooleanSetting)(new BooleanSetting("norender.explosions", false)).method1007("Portlashlar").method0210("Portlash zarrachalarini yashirish").method2130("Portlash zarrachalarini yashirish"), (BooleanSetting)(new BooleanSetting("norender.signtext", false)).method1007("Yozuv matni").method0210("Yozuvlardagi matnni yashirish").method2130("Yozuvlardagi matnni yashirish"), (BooleanSetting)(new BooleanSetting("norender.vignette", false)).method1007("Vinjetka").method0210("Ekran chekkasidagi vinjetkani yashirish").method2130("Ekran chekkasidagi vinjetkani yashirish"), (BooleanSetting)(new BooleanSetting("norender.pumpkin", false)).method1007("G'abo'r").method0210("G'abo'r bosh qoplamasini yashirish").method2130("G'abo'r bosh qoplamasini yashirish"), (BooleanSetting)(new BooleanSetting("norender.snow", false)).method1007("Qor").method0210("Qor ob-havo zarrachalarini yashirish").method2130("Qor ob-havo zarrachalarini yashirish"), (BooleanSetting)(new BooleanSetting("norender.rain", false)).method1007("Yomg'ir").method0210("Yomg'ir ob-havo ko'rsatishini yashirish").method2130("Yomg'irni yashirish"), (BooleanSetting)(new BooleanSetting("norender.itemframes", false)).method1007("Ramkalar").method0210("Buyum ramkalarini yashirish").method2130("Ramkalarni yashirish"), (BooleanSetting)(new BooleanSetting("norender.camera", false)).method1007("Kamera").method0210("Uchinchi shaxsa kamerasining bloklar bilan to'qnashuvini o'chirish").method2130("F5 da kameradan bloklarni olib tashlash")})).method1007("Elementlar").method0210("O'chiriladigan ko'rsatish effektlari").method2130("Turlari");

   public NoRender() {
      super("NoRender", ModuleCategory.field1004, "Ishlash tezligi uchun turli ko'rsatish effektlarini o'chiradi");
      this.method1013("Turli qiziq effektlarni o'chiradi");
   }

   public boolean method1736() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.fire").method0492();
   }

   public boolean method1692() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.hurtcam").method0492();
   }

   public boolean method1755() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.totem").method0492();
   }

   public boolean method2030() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.potions").method0492();
   }

   public boolean method2016() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.scoreboard").method0492();
   }

   public boolean method2044() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.bossbar").method0492();
   }

   public boolean method0472() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.portal").method0492();
   }

   public boolean method0458() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.underwater").method0492();
   }

   public boolean method0480() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.blindness").method0492();
   }

   public boolean method0406() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.nausea").method0492();
   }

   public boolean method0399() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.blockoverlay").method0492();
   }

   public boolean method0411() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.armor").method0492();
   }

   public boolean method0522() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.explosions").method0492();
   }

   public boolean method0517() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.signtext").method0492();
   }

   public boolean method0528() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.vignette").method0492();
   }

   public boolean method2247() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.pumpkin").method0492();
   }

   public boolean method2244() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.snow").method0492();
   }

   public boolean method2252() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.rain").method0492();
   }

   public boolean method2208() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.itemframes").method0492();
   }

   public boolean method2203() {
      return this.method2195() && (Boolean)this.field0089.method0439("norender.camera").method0492();
   }
}
