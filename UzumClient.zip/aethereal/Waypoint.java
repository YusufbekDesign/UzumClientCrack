package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public class Waypoint extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("waypoint.showdistance", true)).method1007("Show Distance").method0210("Show the distance").method2130("Отображать дистанцию");
   private static final class_2960 field1522 = class_2960.method_60655("arbuzhack", "textures/glow.png");
   private static final float field0957 = 6.0F;
   private static final float field0177 = 3.0F;
   private static final float field0458 = 6.0F;
   private static final float field1614 = 7.0F;
   private static final float field1538 = 16.0F;
   private static final Color field1726 = new Color(255, 255, 255, 80);
   private static final Color field1153 = new Color(227, 227, 227);
   private static final Color field1104 = new Color(255, 255, 255, 184);

   public Waypoint() {
      super("Waypoint", ModuleCategory.field1004, "Renders for saved waypoints");
      this.method1013("Метки сохранённых вейпойнтов");
      this.method0213("W");
   }

   @EventHandler
   public void onRender(Render2DEvent event) {
      if (!method1974()) {
         List<WaypointManager.Waypoint> active = new ArrayList(WaypointManager.method0552().method0424());
         WaypointManager.Waypoint gps = WaypointManager.method0552().method0014();
         if (gps != null) {
            active.add(gps);
         }

         if (!active.isEmpty()) {
            class_332 ctx = event.method1806();
            class_4587 stack = ctx.method_51448();
            class_4184 camera = field0796.field_1773.method_19418();
            class_243 camPos = camera.method_19326();
            float yawRad = (float)Math.toRadians((double)camera.method_19330());
            float pitchRad = (float)Math.toRadians((double)camera.method_19329());
            double cosP = Math.cos((double)pitchRad);
            double fwdX = -Math.sin((double)yawRad) * cosP;
            double fwdY = -Math.sin((double)pitchRad);
            double fwdZ = Math.cos((double)yawRad) * cosP;
            float screenW = ScreenLayoutHelper.method2047();
            float screenH = ScreenLayoutHelper.method1762();
            float screenCx = screenW / 2.0F;
            float screenCy = screenH / 2.0F;
            float edgeMargin = 30.0F;
            GuiRenderHelper.method0578();

            try {
               for(WaypointManager.Waypoint wp : active) {
                  class_243 worldPos = new class_243(wp.method0001() + (double)0.5F, wp.method2046() + (double)1.0F, wp.method1761() + (double)0.5F);
                  double distance = camPos.method_1022(worldPos);
                  double dx = worldPos.field_1352 - camPos.field_1352;
                  double dy = worldPos.field_1351 - camPos.field_1351;
                  double dz = worldPos.field_1350 - camPos.field_1350;
                  double dot = dx * fwdX + dy * fwdY + dz * fwdZ;
                  class_243 projected = ProjectionHelper.method1299(worldPos);
                  float sx = (float)projected.field_1352;
                  float sy = (float)projected.field_1351;
                  if (dot <= (double)0.0F) {
                     sx = 2.0F * screenCx - sx;
                     sy = 2.0F * screenCy - sy;
                  }

                  boolean onScreen = dot > (double)0.0F && sx >= 0.0F && sx <= screenW && sy >= 0.0F && sy <= screenH;
                  if (!onScreen) {
                     float dirX = sx - screenCx;
                     float dirY = sy - screenCy;
                     float len = (float)Math.sqrt((double)(dirX * dirX + dirY * dirY));
                     if (len < 0.001F) {
                        dirX = 0.0F;
                        dirY = -1.0F;
                     } else {
                        dirX /= len;
                        dirY /= len;
                     }

                     float halfW = screenCx - edgeMargin;
                     float halfH = screenCy - edgeMargin;
                     float tx = Math.abs(dirX) > 0.001F ? halfW / Math.abs(dirX) : Float.POSITIVE_INFINITY;
                     float ty = Math.abs(dirY) > 0.001F ? halfH / Math.abs(dirY) : Float.POSITIVE_INFINITY;
                     float t = Math.min(tx, ty);
                     sx = screenCx + dirX * t;
                     sy = screenCy + dirY * t;
                  }

                  float distScale = 0.9116279F;
                  this.method1493(stack, wp, sx, sy, distScale, distance);
               }
            } finally {
               GuiRenderHelper.method0025();
            }

         }
      }
   }

   private void method1493(class_4587 stack, WaypointManager.Waypoint wp, float x, float y, float distScale, double distance) {
      FontSize font = Fonts.field0075.method0654(6.0F);
      String name = wp.method0557();
      boolean hasName = name != null && !name.isEmpty();
      int var10000 = (int)Math.floor(wp.method0001());
      String coordsText = "X " + var10000 + ", Y " + (int)Math.floor(wp.method2046()) + ", Z " + (int)Math.floor(wp.method1761());
      boolean drawDistance = this.field0034.method1938();
      String distText = drawDistance ? Math.round(distance) + "m" : "";
      Color circleColor = new Color(wp.method1604() & 16777215);
      float sepGap = 5.0F;
      float innerPad = 4.0F;
      float smallSepH = 7.0F;
      float nameWidth = hasName ? font.method0998(name) : 0.0F;
      float coordsWidth = font.method0998(coordsText);
      float distWidth = drawDistance ? font.method0998(distText) : 0.0F;
      float totalW = innerPad + 7.0F + sepGap + 1.0F + sepGap + coordsWidth;
      if (hasName) {
         totalW += sepGap + 1.0F + sepGap + nameWidth;
      }

      if (drawDistance) {
         totalW += sepGap + 1.0F + sepGap + distWidth;
      }

      totalW += innerPad;
      float bgHeight = font.method0530() + 7.5F;
      float bgX = -totalW / 2.0F;
      float bgY = -bgHeight;
      float scaledBlur = (Float)ThemePalette.field0367.get();
      stack.method_22903();
      stack.method_46416(x, y - 4.0F, 0.0F);
      stack.method_22905(distScale, distScale, 1.0F);
      Color bgColor = (Color)ThemePalette.field0930.get();
      Color borderColor = ThemePalette.field1564;
      GuiRenderHelper.method1462(stack, bgX, bgY, totalW, bgHeight, 6.0F, scaledBlur, ThemePalette.field0134);
      GuiRenderHelper.method1463(stack, bgX, bgY, totalW, bgHeight, 6.0F, bgColor);
      GuiRenderHelper.method1461(stack, bgX, bgY, totalW, bgHeight, 6.0F, 0.5F, 0.5F, borderColor);
      float centerY = bgY + bgHeight / 2.0F;
      float textY = centerY - font.method0530() / 2.0F;
      float smallSepY = centerY - smallSepH / 2.0F;
      float currentX = bgX + innerPad;
      Color glowColor = new Color(circleColor.getRed(), circleColor.getGreen(), circleColor.getBlue(), 200);
      GuiRenderHelper.method1466(stack, currentX + 3.5F - 8.0F, centerY - 8.0F, 16.0F, 16.0F, 8.0F, field1522, glowColor);
      GuiRenderHelper.method0326(stack, currentX, centerY - 3.5F, 7.0F, 7.0F, 2.5F, circleColor);
      currentX += 7.0F;
      if (hasName) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field1726);
         currentX += 1.0F + sepGap;
         GuiRenderHelper.method1491(stack, font, name, currentX, textY, field1153);
         currentX += nameWidth;
      }

      currentX += sepGap;
      GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field1726);
      currentX += 1.0F + sepGap;
      GuiRenderHelper.method1491(stack, font, coordsText, currentX, textY, field1104);
      currentX += coordsWidth;
      if (drawDistance) {
         currentX += sepGap;
         GuiRenderHelper.method0326(stack, currentX, smallSepY, 1.0F, smallSepH, 1.0F, field1726);
         currentX += 1.0F + sepGap;
         GuiRenderHelper.method1491(stack, font, distText, currentX, textY, field1104);
      }

      stack.method_22909();
   }
}
