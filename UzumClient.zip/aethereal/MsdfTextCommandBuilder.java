package aethereal;

import java.awt.Color;

public final class MsdfTextCommandBuilder extends RenderCommandBuilder<MsdfTextRenderCommand> {
   private MsdfFontRenderer field0646;
   private String field0136;
   private float field1410;
   private float field0957;
   private int field0759;
   private float field1242;
   private float field0314;
   private int field0178;
   private float field0458;

   public MsdfTextCommandBuilder method0853(MsdfFontRenderer font) {
      this.field0646 = font;
      return this;
   }

   public MsdfTextCommandBuilder method1004(String text) {
      this.field0136 = text;
      return this;
   }

   public MsdfTextCommandBuilder method0658(float size) {
      this.field1410 = size;
      return this;
   }

   public MsdfTextCommandBuilder method0122(float thickness) {
      this.field0957 = thickness;
      return this;
   }

   public MsdfTextCommandBuilder method0959(Color color) {
      return this.method0722(color.getRGB());
   }

   public MsdfTextCommandBuilder method0722(int color) {
      this.field0759 = color;
      return this;
   }

   public MsdfTextCommandBuilder method2096(float smoothness) {
      this.field1242 = smoothness;
      return this;
   }

   public MsdfTextCommandBuilder method1820(float spacing) {
      this.field0314 = spacing;
      return this;
   }

   public MsdfTextCommandBuilder method0963(Color color, float thickness) {
      return this.method0734(color.getRGB(), thickness);
   }

   public MsdfTextCommandBuilder method0734(int color, float thickness) {
      this.field0178 = color;
      this.field0458 = thickness;
      return this;
   }

   protected MsdfTextRenderCommand method1784() {
      return new MsdfTextRenderCommand(this.field0646, this.field0136, this.field1410, this.field0957, this.field0759, this.field1242, this.field0314, this.field0178, this.field0458);
   }

   protected void method0025() {
      this.field0646 = null;
      this.field0136 = "";
      this.field1410 = 0.0F;
      this.field0957 = 0.05F;
      this.field0759 = -1;
      this.field1242 = 0.5F;
      this.field0314 = 0.0F;
      this.field0178 = 0;
      this.field0458 = 0.0F;
   }

   // $FF: synthetic method
   protected Object method2066() {
      return this.method1784();
   }
}
