package aethereal;

import meteordevelopment.orbit.EventHandler;

public class AspectRatio extends Module {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("aspectratio.ratio", 1.0F, 0.1F, 2.0F, 0.01F)).method1007("Nisbat").method0210("Kenglik va balandlik nisbati ko'paytiruvchisi").method2130("Tomonlar nisbati ko'paytiruvchisi");

   public AspectRatio() {
      super("AspectRatio", ModuleCategory.field1004, "O'yinning tomonlar nisbatini o'zgartiradi");
      this.method1013("Ekran tomonlar nisbatini o'zgartiradi");
   }

   @EventHandler
   public void onAspectRatio(FovEvent var1) {
      var1.method0665((Float)this.field0060.method0492());
      var1.method0578();
   }
}
