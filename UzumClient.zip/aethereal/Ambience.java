package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

public class Ambience extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("ambience.time", false)).method1007("Custom Time").method0210("Override visual time of day").method2130("Время суток");
   private final FloatSetting field1450;
   private final BooleanSetting field0970;
   private final ColorSetting field0185;
   private final ColorSetting field0466;
   private final FloatSetting field1627;
   private final ColorSetting field1550;
   private final ColorSetting field1711;
   private final ColorSetting field1143;
   private final FloatSetting field1097;
   private final BooleanSetting field1201;
   private final ColorSetting field0878;
   private final FloatSetting field0836;
   private final FloatSetting field0919;
   private final FloatSetting field1341;
   private final FloatSetting field1302;
   private final FloatSetting field1377;
   private final FloatSetting field0393;
   private final CustomSkyRenderer field0356;
   private final ToneShaderRenderer field0427;
   private final BooleanSetting field0259;
   private final FloatSetting field0234;
   private final FloatSetting field0295;
   private final FloatSetting field0529;
   private final ColorSetting field0504;
   private final BooleanSetting field0550;
   private final FloatSetting field1676;
   private final FloatSetting field1661;
   private final FloatSetting field1693;
   private final FloatSetting field1593;
   private final ColorSetting field1581;
   private static final float field1601 = 20.0F;
   private static final float field1753 = 20.0F;
   private static final float field1739 = 0.15F;
   private static final float field1766 = 0.06F;
   private static final float field1174 = 0.08F;
   private static final float field1164 = 15.0F;
   private final List<SkyAnimation> field1191;
   private final List<SkyMesh> field1124;
   private final List<ColoredVertex> field1116;
   private final List<SkyObject> field1134;
   private final List<SkyMesh> field1232;
   private final List<SkyMesh> field1224;
   private final List<SkyLayer> field1238;
   private final List<SkyLayer> field0902;
   private final float[] field0898;
   private final float[] field0908;
   private final float[] field0861;
   private final float[] field0854;
   private final float[] field0869;
   private final float[] field0947;
   private final float[] field0939;
   private final int[] field0954;
   private final List<SkyMesh> field1359;
   private final Map<Integer, List<SkyMesh>> field1354;
   private final List<SkyMesh> field1363;
   private final List<SkyObject> field1323;
   private final List<class_2338> field1318;
   private int field1325;
   private final Random field1399;
   private static final class_2960 field1393 = ArbuzClient.method1012("textures/glow.png");
   private static final class_2960 field1406 = ArbuzClient.method1012("textures/spark.png");
   private static final class_2960[] field0416 = new class_2960[]{ArbuzClient.method1012("textures/particles/2.png"), ArbuzClient.method1012("textures/particles/3.png"), ArbuzClient.method1012("textures/particles/4.png"), ArbuzClient.method1012("textures/particles/5.png"), ArbuzClient.method1012("textures/particles/7.png"), ArbuzClient.method1012("textures/particles/8.png"), ArbuzClient.method1012("textures/particles/9.png"), ArbuzClient.method1012("textures/particles/10.png"), ArbuzClient.method1012("textures/particles/13.png"), ArbuzClient.method1012("textures/particles/17.png"), ArbuzClient.method1012("textures/particles/20.png"), ArbuzClient.method1012("textures/particles/21.png"), ArbuzClient.method1012("textures/particles/23.png"), ArbuzClient.method1012("textures/particles/24.png"), ArbuzClient.method1012("textures/particles/25.png"), ArbuzClient.method1012("textures/particles/26.png"), ArbuzClient.method1012("textures/particles/28.png"), ArbuzClient.method1012("textures/particles/29.png"), ArbuzClient.method1012("textures/particles/30.png"), ArbuzClient.method1012("textures/particles/32.png"), ArbuzClient.method1012("textures/particles/33.png"), ArbuzClient.method1012("textures/particles/36.png"), ArbuzClient.method1012("textures/particles/42.png"), ArbuzClient.method1012("textures/particles/43.png"), ArbuzClient.method1012("textures/particles/44.png"), ArbuzClient.method1012("textures/particles/48.png"), ArbuzClient.method1012("textures/particles/49.png"), ArbuzClient.method1012("textures/particles/50.png"), ArbuzClient.method1012("textures/particles/51.png"), ArbuzClient.method1012("textures/particles/52.png"), ArbuzClient.method1012("textures/particles/55.png")};

   public Ambience() {
      super("Ambience", ModuleCategory.field1004, "Time of day and falling star effects");
      BooleanSetting var10008 = this.field0034;
      Objects.requireNonNull(var10008);
      this.field1450 = (FloatSetting)(new FloatSetting("ambience.timehour", 12.0F, 0.0F, 24.0F, 0.5F, var10008::method0492)).method1007("Hour").method0210("Visual time of day (0=midnight, 12=noon)").method2130("Изменить время суток на уровне клиента");
      this.field0970 = (BooleanSetting)(new BooleanSetting("ambience.skyshader", false)).method1007("Sky Shader").method0210("Replace the vanilla sky with a custom shader").method2130("Шейдерное небо вместо ванильного");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field0185 = (ColorSetting)(new ColorSetting("ambience.skycolor1", 0, 0, 13, 255, var10008::method0492)).method1007("Sky Color 1").method0210("Top sky gradient color").method2130("Верхний цвет градиента");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field0466 = (ColorSetting)(new ColorSetting("ambience.skycolor2", 5, 3, 38, 255, var10008::method0492)).method1007("Sky Color 2").method0210("Bottom sky gradient color").method2130("Нижний цвет градиента");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1627 = (FloatSetting)(new FloatSetting("ambience.nebulaintensity", 0.3F, 0.0F, 1.5F, 0.05F, var10008::method0492)).method1007("Nebula Intensity").method0210("Nebula brightness").method2130("Интенсивность туманности");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1550 = (ColorSetting)(new ColorSetting("ambience.nebulacolor", 178, 71, 35, 255, var10008::method0492)).method1007("Nebula Color 1").method0210("Warm nebula tint").method2130("Тёплый цвет туманности");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1711 = (ColorSetting)(new ColorSetting("ambience.nebulacolor2", 51, 0, 51, 255, var10008::method0492)).method1007("Nebula Color 2").method0210("Cool nebula tint").method2130("Холодный цвет туманности");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1143 = (ColorSetting)(new ColorSetting("ambience.suncolor", 102, 102, 51, 255, var10008::method0492)).method1007("Sun Color").method0210("Sun disc color").method2130("Цвет солнца");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1097 = (FloatSetting)(new FloatSetting("ambience.sunsize", 1.0F, 0.1F, 5.0F, 0.1F, var10008::method0492)).method1007("Sun Size").method0210("Sun disc size (1.0 = default, larger = bigger softer disc)").method2130("Размер солнечного диска");
      this.field1201 = (BooleanSetting)(new BooleanSetting("ambience.tone", false)).method1007("Tone Grading").method0210("Color tone post-process").method2130("Цветовой постпроцесс");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0878 = (ColorSetting)(new ColorSetting("ambience.tonetint", 255, 220, 180, 255, var10008::method0492)).method1007("Tone Tint").method0210("Tint color").method2130("Цвет тинта");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0836 = (FloatSetting)(new FloatSetting("ambience.tonestrength", 0.25F, 0.0F, 1.0F, 0.05F, var10008::method0492)).method1007("Tint Strength").method0210("Tint intensity").method2130("Сила тинта");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0919 = (FloatSetting)(new FloatSetting("ambience.tonesat", 1.15F, 0.0F, 2.0F, 0.05F, var10008::method0492)).method1007("Saturation").method0210("Color saturation").method2130("Насыщенность");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field1341 = (FloatSetting)(new FloatSetting("ambience.tonecontrast", 1.05F, 0.5F, 1.6F, 0.05F, var10008::method0492)).method1007("Contrast").method0210("Image contrast").method2130("Контраст");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field1302 = (FloatSetting)(new FloatSetting("ambience.tonebright", 1.0F, 0.4F, 1.6F, 0.05F, var10008::method0492)).method1007("Brightness").method0210("Image brightness").method2130("Яркость");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field1377 = (FloatSetting)(new FloatSetting("ambience.tonevignette", 0.4F, 0.0F, 1.0F, 0.05F, var10008::method0492)).method1007("Vignette").method0210("Vignette darkness at edges").method2130("Виньетка");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0393 = (FloatSetting)(new FloatSetting("ambience.tonebloom", 0.3F, 0.0F, 1.5F, 0.05F, var10008::method0492)).method1007("Bloom").method0210("Highlight bloom strength").method2130("Свечение бликов");
      this.field0356 = new CustomSkyRenderer();
      this.field0427 = new ToneShaderRenderer();
      this.field0259 = (BooleanSetting)(new BooleanSetting("ambience.starrain", false)).method1007("Star Rain").method0210("Falling glowing star particles").method2130("Падающие звёздные частицы");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0234 = (FloatSetting)(new FloatSetting("ambience.starparticleamount", 400.0F, 50.0F, 1500.0F, 50.0F, var10008::method0492)).method1007("Particle Amount").method0210("Max number of star particles").method2130("Максимальное количество звёздных частиц");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0295 = (FloatSetting)(new FloatSetting("ambience.starradius", 30.0F, 10.0F, 80.0F, 5.0F, var10008::method0492)).method1007("Radius").method0210("Spawn radius around player").method2130("Радиус вокруг игрока");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0529 = (FloatSetting)(new FloatSetting("ambience.starsize", 0.06F, 0.01F, 0.3F, 0.01F, var10008::method0492)).method1007("Star Size").method0210("Size of each falling star").method2130("Размер падающей звезды");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0504 = (ColorSetting)(new ColorSetting("ambience.starcolor", 255, 200, 255, 160, var10008::method0492)).method1882().method1007("Star Color").method0210("Color of falling stars").method2130("Цвет");
      this.field0550 = (BooleanSetting)(new BooleanSetting("ambience.sirocco", true)).method1007("Sirocco").method0210("Hot desert wind: ash, embers, petals, streaks").method2130("Жаркий ветер пустыни");
      var10008 = this.field0550;
      Objects.requireNonNull(var10008);
      this.field1676 = (FloatSetting)(new FloatSetting("ambience.siroccocount", 800.0F, 20.0F, 800.0F, 20.0F, var10008::method0492)).method1007("Particle Count").method0210("Max Sirocco particles").method2130("Кол-во частиц");
      var10008 = this.field0550;
      Objects.requireNonNull(var10008);
      this.field1661 = (FloatSetting)(new FloatSetting("ambience.siroccoradius", 12.0F, 8.0F, 60.0F, 2.0F, var10008::method0492)).method1007("Radius").method0210("Spawn radius around player").method2130("Радиус");
      var10008 = this.field0550;
      Objects.requireNonNull(var10008);
      this.field1693 = (FloatSetting)(new FloatSetting("ambience.siroccowindangle", 360.0F, 0.0F, 360.0F, 5.0F, var10008::method0492)).method1007("Wind Angle").method0210("Wind direction in degrees").method2130("Угол ветра");
      var10008 = this.field0550;
      Objects.requireNonNull(var10008);
      this.field1593 = (FloatSetting)(new FloatSetting("ambience.siroccowindspeed", 0.5F, 0.5F, 12.0F, 0.25F, var10008::method0492)).method1007("Wind Speed").method0210("Wind speed").method2130("Скорость ветра");
      var10008 = this.field0550;
      Objects.requireNonNull(var10008);
      this.field1581 = (ColorSetting)(new ColorSetting("ambience.siroccocolor", 255, 0, 0, 255, var10008::method0492)).method1882().method1007("Color").method0210("Color for all Sirocco elements").method2130("Цвет всех элементов");
      this.field1191 = new ArrayList();
      this.field1124 = new ArrayList();
      this.field1116 = new ArrayList();
      this.field1134 = new ArrayList();
      this.field1232 = new ArrayList();
      this.field1224 = new ArrayList();
      this.field1238 = new ArrayList();
      this.field0902 = new ArrayList();
      this.field0898 = new float[16];
      this.field0908 = new float[16];
      this.field0861 = new float[16];
      this.field0854 = new float[16];
      this.field0869 = new float[16];
      this.field0947 = new float[16];
      this.field0939 = new float[16];
      this.field0954 = new int[16];
      this.field1359 = new ArrayList();
      this.field1354 = new HashMap();
      this.field1363 = new ArrayList();
      this.field1323 = new ArrayList();
      this.field1318 = new ArrayList();
      this.field1325 = 0;
      this.field1399 = new Random();
      this.method1013("Разные изменения в игровом мире");
   }

   public boolean method1736() {
      return this.field0751 && (Boolean)this.field0034.method0492();
   }

   public long method1681() {
      float h = (Float)this.field1450.method0492();
      long ticks = (long)((h - 6.0F) * 1000.0F);
      if (ticks < 0L) {
         ticks += 24000L;
      }

      return ticks;
   }

   public boolean method1755() {
      return this.field0751 && (Boolean)this.field0970.method0492();
   }

   public void method2029() {
      SkyOverlayRenderer.method0706((Float)this.field1627.method0492(), this.field0185.method1726(), this.field0466.method1726(), this.field1550.method1726(), this.field1711.method1726(), this.field1143.method1726(), (Float)this.field1097.method0492());
   }

   @EventHandler
   public void onRenderShaderPost(RenderShaderEvent.Pre event) {
      if (!method1974()) {
         if ((Boolean)this.field1201.method0492()) {
            this.field0427.method0961(this.field0878.method1726());
            this.field0427.method0665((Float)this.field0836.method0492());
            this.field0427.method2098((Float)this.field0919.method0492());
            this.field0427.method1638((Float)this.field1341.method0492());
            this.field0427.method1822((Float)this.field1302.method0492());
            this.field0427.method0124((Float)this.field1377.method0492());
            this.field0427.method1977((Float)this.field0393.method0492());
            this.field0427.method0578();
         }
      }
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         if ((Boolean)this.field0259.method0492()) {
            this.method0457();
         }

         if ((Boolean)this.field0550.method0492()) {
            this.method2015();
         }

      }
   }

   private void method2015() {
      if (field0796.field_1724 != null) {
         class_243 player = field0796.field_1724.method_19538();
         class_243 wind = this.method2042();
         int target = ((Float)this.field1676.method0492()).intValue();
         int toSpawn = Math.min(Math.max(0, target - this.field1134.size()), 6);

         for(int i = 0; i < toSpawn; ++i) {
            this.method1329(player, wind);
         }

         if (this.field1399.nextFloat() < 0.04F) {
            this.field1134.add(this.method1304(this.method1299(player), (double)0.0F));
         }

         if (this.field1399.nextFloat() < 0.008F) {
            int burst = 2 + this.field1399.nextInt(2);

            for(int i = 0; i < burst; ++i) {
               this.field1134.add(this.method1304(this.method1299(player), (double)0.0F));
            }
         }

         if (this.field1399.nextFloat() < 0.05F) {
            this.field1134.add(this.method1994(player));
         }

         if (this.field1399.nextFloat() < 0.018F) {
            this.field1134.add(this.method1667(player));
         }

         if (this.field1399.nextFloat() < 0.014F) {
            this.field1134.add(this.method1864(player));
         }

         if (this.field1399.nextFloat() < 0.18F) {
            this.field1134.add(this.method2162(player));
         }

         if (--this.field1325 <= 0) {
            this.method0288(player);
            this.field1325 = 40;
         }

         if (!this.field1318.isEmpty()) {
            if (this.field1399.nextFloat() < 0.22F) {
               class_2338 lpos = (class_2338)this.field1318.get(this.field1399.nextInt(this.field1318.size()));
               this.field1134.add(this.method1257(lpos));
            }

            if (this.field1399.nextFloat() < 0.35F) {
               class_2338 lpos = (class_2338)this.field1318.get(this.field1399.nextInt(this.field1318.size()));
               this.field1134.add(this.method0275(lpos));
            }
         }

         Iterator<SkyObject> it = this.field1134.iterator();

         while(it.hasNext()) {
            SkyObject p = (SkyObject)it.next();
            this.method0789(p, wind);
            double dx = p.field0002 - player.field_1352;
            double dz = p.field0956 - player.field_1350;
            double rsq = (double)(Float)this.field1661.method0492() * (double)2.5F;
            if (p.field1539 >= p.field1705 || dx * dx + dz * dz > rsq * rsq) {
               it.remove();
            }
         }

         if (!this.field1323.isEmpty()) {
            this.field1134.addAll(this.field1323);
            this.field1323.clear();
         }

      }
   }

   private class_243 method2042() {
      double a = Math.toRadians((double)(Float)this.field1693.method0492());
      double s = (double)(Float)this.field1593.method0492() / (double)20.0F;
      return new class_243(Math.cos(a) * s, (double)0.0F, Math.sin(a) * s);
   }

   private SkyObjectType method0463() {
      List<SkyObjectType> pool = new ArrayList();
      pool.add(Ambience.SkyObjectType.field0006);
      pool.add(Ambience.SkyObjectType.field0006);
      pool.add(Ambience.SkyObjectType.field0006);
      pool.add(Ambience.SkyObjectType.field0006);
      pool.add(Ambience.SkyObjectType.field0006);
      pool.add(Ambience.SkyObjectType.field0569);
      pool.add(Ambience.SkyObjectType.field0569);
      pool.add(Ambience.SkyObjectType.field0569);
      pool.add(Ambience.SkyObjectType.field0569);
      pool.add(Ambience.SkyObjectType.field0180);
      pool.add(Ambience.SkyObjectType.field0180);
      pool.add(Ambience.SkyObjectType.field0461);
      pool.add(Ambience.SkyObjectType.field0461);
      pool.add(Ambience.SkyObjectType.field0461);
      pool.add(Ambience.SkyObjectType.field1413);
      pool.add(Ambience.SkyObjectType.field1413);
      pool.add(Ambience.SkyObjectType.field0761);
      pool.add(Ambience.SkyObjectType.field0761);
      pool.add(Ambience.SkyObjectType.field1199);
      pool.add(Ambience.SkyObjectType.field1199);
      return (SkyObjectType)pool.get(this.field1399.nextInt(pool.size()));
   }

   private void method1329(class_243 player, class_243 wind) {
      SkyObjectType type = this.method0463();
      if (type != null) {
         double r = (double)(Float)this.field1661.method0492();
         double a = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
         double dist = r * (0.3000000093137463 + this.field1399.nextDouble() * 0.700000000954607);
         double sx = player.field_1352 + Math.cos(a) * dist;
         double sz = player.field_1350 + Math.sin(a) * dist;
         double sy = player.field_1351 + (double)4.0F + this.field1399.nextDouble() * r * 0.700000000954607;
         SkyObject p = new SkyObject();
         p.field0569 = type;
         p.field0002 = sx;
         p.field1409 = sy;
         p.field0956 = sz;
         p.field0757 = sx;
         p.field1241 = sy;
         p.field0313 = sz;
         p.field1196 = 0.4F + this.field1399.nextFloat() * 1.3F;
         switch (type.ordinal()) {
            case 0:
               p.field1136 = (0.06F + this.field1399.nextFloat() * 0.08F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 320 + this.field1399.nextInt(200);
               p.field0176 = wind.field_1352 * ((double)0.25F + this.field1399.nextDouble() * 0.3000000093137463) * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field1613 = wind.field_1350 * ((double)0.25F + this.field1399.nextDouble() * 0.3000000093137463) * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field0457 = (this.field1399.nextDouble() - 0.6000000484588345) * 0.005999998620070951 * (double)p.field1196;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.03F;
               break;
            case 1:
               p.field1136 = (0.05F + this.field1399.nextFloat() * 0.06F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 140 + this.field1399.nextInt(100);
               p.field0176 = wind.field_1352 * 0.20000000981720706 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field1613 = wind.field_1350 * 0.20000000981720706 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field0457 = 0.005000002112303237 + this.field1399.nextDouble() * 0.011999996541534604;
               p.field0871 = this.field1399.nextFloat();
               break;
            case 2:
               p.field1136 = (0.09F + this.field1399.nextFloat() * 0.07F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 200 + this.field1399.nextInt(120);
               p.field0176 = wind.field_1352 * (double)0.25F * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field1613 = wind.field_1350 * (double)0.25F * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field0457 = -0.005000001892210841 - this.field1399.nextDouble() * 0.010000003294232477;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.14F;
               break;
            case 3:
            case 6:
               return;
            case 4:
               p.field1136 = (0.05F + this.field1399.nextFloat() * 0.05F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 160 + this.field1399.nextInt(80);
               p.field0176 = wind.field_1352 * 0.15000000077852818 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.011999996541534604;
               p.field1613 = wind.field_1350 * 0.15000000077852818 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.011999996541534604;
               p.field0457 = -(0.03500000774912257 + this.field1399.nextDouble() * 0.04500000458047833) * (double)p.field1196;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.06F;
            case 5:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            default:
               break;
            case 7:
               p.field1136 = (0.55F + this.field1399.nextFloat() * 0.55F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 320 + this.field1399.nextInt(220);
               p.field0176 = wind.field_1352 * 0.4000000310832036 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
               p.field1613 = wind.field_1350 * 0.4000000310832036 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
               p.field0457 = 0.0029999991208599216 + this.field1399.nextDouble() * 0.007999995405319822;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.012F;
               break;
            case 8:
               p.field1136 = (0.025F + this.field1399.nextFloat() * 0.025F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 140 + this.field1399.nextInt(120);
               p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.010000003294232477;
               p.field0457 = 0.02500000005873084 + this.field1399.nextDouble() * 0.02500000005873084;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               break;
            case 14:
               p.field1136 = (0.1F + this.field1399.nextFloat() * 0.06F) * p.field1196;
               p.field1087 = p.field1136;
               p.field1705 = 180 + this.field1399.nextInt(140);
               p.field0176 = wind.field_1352 * 0.35000012316843765 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.011999996541534604;
               p.field1613 = wind.field_1350 * 0.35000012316843765 * (double)p.field1196 + (this.field1399.nextDouble() - (double)0.5F) * 0.011999996541534604;
               p.field0457 = -(0.029999992609062415 + this.field1399.nextDouble() * 0.02500000005873084) * (double)p.field1196;
               p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
               p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.1F;
               int trailLen = 9;
               p.field0241 = new double[trailLen];
               p.field0303 = new double[trailLen];
               p.field0539 = new double[trailLen];

               for(int i = 0; i < trailLen; ++i) {
                  p.field0241[i] = p.field0002;
                  p.field0303[i] = p.field1409;
                  p.field0539[i] = p.field0956;
               }
         }

         this.field1134.add(p);
      }
   }

   private class_243 method1299(class_243 player) {
      double r = (double)(Float)this.field1661.method0492();
      double a = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
      double dist = r * (0.6000000484588345 + this.field1399.nextDouble() * (double)0.5F);
      return new class_243(player.field_1352 + Math.cos(a) * dist, player.field_1351 + (double)14.0F + this.field1399.nextDouble() * r * 0.4000000310832036, player.field_1350 + Math.sin(a) * dist);
   }

   private void method0288(class_243 player) {
      this.field1318.clear();
      if (field0796.field_1687 != null) {
         int range = 14;
         int px = (int)player.field_1352;
         int py = (int)player.field_1351;
         int pz = (int)player.field_1350;
         class_2338.class_2339 mut = new class_2338.class_2339();

         for(int dx = -range; dx <= range; dx += 2) {
            for(int dy = -4; dy <= 10; dy += 2) {
               for(int dz = -range; dz <= range; dz += 2) {
                  mut.method_10103(px + dx, py + dy, pz + dz);
                  class_2680 bs = field0796.field_1687.method_8320(mut);
                  if (bs.method_26164(class_3481.field_15503)) {
                     this.field1318.add(mut.method_10062());
                  }
               }
            }
         }

      }
   }

   private SkyObject method2162(class_243 player) {
      double r = (double)(Float)this.field1661.method0492() * (double)0.75F;
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1707;
      p.field0002 = player.field_1352 + (this.field1399.nextDouble() - (double)0.5F) * r * (double)2.0F;
      p.field0956 = player.field_1350 + (this.field1399.nextDouble() - (double)0.5F) * r * (double)2.0F;
      p.field1409 = player.field_1351 + (double)1.0F + this.field1399.nextDouble() * r * 0.8999997783500137;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 0.6F + this.field1399.nextFloat() * 1.0F;
      p.field1136 = (0.018F + this.field1399.nextFloat() * 0.022F) * p.field1196;
      p.field1087 = 0.0F;
      p.field1705 = 60 + this.field1399.nextInt(80);
      p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.005999998620070951;
      p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.005999998620070951;
      p.field0457 = (this.field1399.nextDouble() - (double)0.5F) * 0.003999997703356243;
      p.field0871 = this.field1399.nextFloat() * 6.28F;
      return p;
   }

   private SkyObject method1257(class_2338 leaf) {
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1139;
      p.field0002 = (double)leaf.method_10263() + this.field1399.nextDouble();
      p.field1409 = (double)leaf.method_10264() + this.field1399.nextDouble() * 0.6000000484588345;
      p.field0956 = (double)leaf.method_10260() + this.field1399.nextDouble();
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 1.0F;
      p.field1136 = 0.07F + this.field1399.nextFloat() * 0.05F;
      p.field1087 = p.field1136;
      p.field1705 = 160 + this.field1399.nextInt(120);
      p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.02500000005873084;
      p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.02500000005873084;
      p.field0457 = -0.01800000002188833 - this.field1399.nextDouble() * 0.01499999499508052;
      p.field0871 = this.field1399.nextFloat() * 6.28F;
      p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.16F;
      return p;
   }

   private SkyObject method0275(class_2338 leaf) {
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1090;
      p.field0002 = (double)leaf.method_10263() + this.field1399.nextDouble();
      p.field1409 = (double)leaf.method_10264() + this.field1399.nextDouble();
      p.field0956 = (double)leaf.method_10260() + this.field1399.nextDouble();
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 1.0F;
      p.field1136 = 0.035F + this.field1399.nextFloat() * 0.03F;
      p.field1087 = 0.0F;
      p.field1705 = 80 + this.field1399.nextInt(60);
      p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field0457 = 0.003999997703356243 + this.field1399.nextDouble() * 0.007999995405319822;
      p.field0871 = this.field1399.nextFloat() * 6.28F;
      return p;
   }

   private SkyObject method1864(class_243 player) {
      double r = (double)(Float)this.field1661.method0492();
      double a = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
      double dist = r * ((double)0.5F + this.field1399.nextDouble() * (double)0.5F);
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1617;
      p.field0002 = player.field_1352 + Math.cos(a) * dist;
      p.field0956 = player.field_1350 + Math.sin(a) * dist;
      p.field1409 = player.field_1351 + (double)16.0F + this.field1399.nextDouble() * (double)8.0F;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 1.0F;
      p.field1136 = 0.09F + this.field1399.nextFloat() * 0.05F;
      p.field1087 = p.field1136;
      p.field1705 = 70 + this.field1399.nextInt(40);
      double windAngle = Math.toRadians((double)(Float)this.field1693.method0492());
      double speed = 0.22000000006059642 + this.field1399.nextDouble() * 0.11999995622966886;
      p.field0176 = Math.cos(windAngle) * speed * 0.5500001491047446;
      p.field1613 = Math.sin(windAngle) * speed * 0.5500001491047446;
      p.field0457 = -speed;
      return p;
   }

   private SkyObject method0618(double sx, double sy, double sz) {
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1541;
      double jitter = (double)0.25F;
      p.field0002 = sx + (this.field1399.nextDouble() - (double)0.5F) * jitter;
      p.field1409 = sy + (this.field1399.nextDouble() - (double)0.5F) * jitter;
      p.field0956 = sz + (this.field1399.nextDouble() - (double)0.5F) * jitter;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 1.0F;
      p.field1136 = 0.035F + this.field1399.nextFloat() * 0.04F;
      p.field1087 = 0.0F;
      p.field1705 = 24 + this.field1399.nextInt(22);
      p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field0457 = -0.003999998168394917 - this.field1399.nextDouble() * 0.005000002112303237;
      p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
      p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.06F;
      p.field1293 = this.field1399.nextInt(field0416.length);
      return p;
   }

   private SkyObject method1667(class_243 player) {
      double r = (double)(Float)this.field1661.method0492();
      double a = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
      double dist = r * (0.3000000093137463 + this.field1399.nextDouble() * 0.700000000954607);
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field0317;
      p.field1368 = player.field_1352 + Math.cos(a) * dist;
      p.field0350 = player.field_1350 + Math.sin(a) * dist;
      p.field0384 = player.field_1351 + (double)5.0F + this.field1399.nextDouble() * (double)24.0F;
      p.field1196 = 0.6F + this.field1399.nextFloat() * 0.9F;
      p.field0423 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
      p.field0255 = 0.4F + this.field1399.nextFloat() * 3.2F;
      p.field0002 = p.field1368 + Math.cos((double)p.field0423) * (double)p.field0255;
      p.field1409 = p.field0384;
      p.field0956 = p.field0350 + Math.sin((double)p.field0423) * (double)p.field0255;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1136 = 0.05F + this.field1399.nextFloat() * 0.05F;
      p.field1087 = p.field1136;
      p.field1705 = 90 + this.field1399.nextInt(70);
      p.field0457 = -(0.020000008440140268 + this.field1399.nextDouble() * 0.02500000005873084);
      p.field0826 = 0.18F + this.field1399.nextFloat() * 0.22F;
      if (this.field1399.nextBoolean()) {
         p.field0826 = -p.field0826;
      }

      int trailLen = 14;
      p.field0241 = new double[trailLen];
      p.field0303 = new double[trailLen];
      p.field0539 = new double[trailLen];

      for(int i = 0; i < trailLen; ++i) {
         p.field0241[i] = p.field0002;
         p.field0303[i] = p.field1409;
         p.field0539[i] = p.field0956;
      }

      return p;
   }

   private SkyObject method1994(class_243 player) {
      double r = (double)(Float)this.field1661.method0492();
      double a = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
      double dist = r * (0.3000000093137463 + this.field1399.nextDouble() * 0.700000000954607);
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field1245;
      p.field0002 = player.field_1352 + Math.cos(a) * dist;
      p.field0956 = player.field_1350 + Math.sin(a) * dist;
      p.field1409 = player.field_1351 + (double)2.0F + this.field1399.nextDouble() * r * 0.800000026077553;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 0.5F + this.field1399.nextFloat() * 1.2F;
      p.field1136 = (0.06F + this.field1399.nextFloat() * 0.09F) * p.field1196;
      p.field1087 = 0.0F;
      p.field1705 = 90 + this.field1399.nextInt(110);
      p.field0176 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field1613 = (this.field1399.nextDouble() - (double)0.5F) * 0.007999995405319822;
      p.field0457 = (this.field1399.nextDouble() - 0.4000000310832036) * 0.011999996541534604;
      p.field0871 = this.field1399.nextFloat() * ((float)Math.PI * 2F);
      p.field0826 = (this.field1399.nextFloat() - 0.5F) * 0.03F;
      p.field1293 = this.field1399.nextInt(field0416.length);
      return p;
   }

   private SkyObject method1304(class_243 anchor, double jitter) {
      SkyObject p = new SkyObject();
      p.field0569 = Ambience.SkyObjectType.field0960;
      p.field0002 = anchor.field_1352 + (this.field1399.nextDouble() - (double)0.5F) * jitter;
      p.field1409 = anchor.field_1351 + (this.field1399.nextDouble() - (double)0.5F) * jitter * 0.6000000484588345;
      p.field0956 = anchor.field_1350 + (this.field1399.nextDouble() - (double)0.5F) * jitter;
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      p.field1196 = 1.0F;
      p.field1136 = 0.11F + this.field1399.nextFloat() * 0.06F;
      p.field1087 = p.field1136;
      p.field1705 = 18 + this.field1399.nextInt(12);
      double windAngle = Math.toRadians((double)(Float)this.field1693.method0492());
      double speed = 0.700000000954607 + this.field1399.nextDouble() * 0.4000000310832036;
      p.field0176 = Math.cos(windAngle) * speed;
      p.field1613 = Math.sin(windAngle) * speed;
      p.field0457 = -speed * 0.8999997783500137;
      p.field0931 = this.field1399.nextFloat() < 0.55F;
      return p;
   }

   private void method0789(SkyObject p, class_243 wind) {
      p.field0757 = p.field0002;
      p.field1241 = p.field1409;
      p.field0313 = p.field0956;
      ++p.field1539;
      switch (p.field0569.ordinal()) {
         case 0:
            p.field0176 = p.field0176 * 0.9700000610052666 + wind.field_1352 * 0.029999992609062415 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9700000610052666 + wind.field_1350 * 0.029999992609062415 * (double)p.field1196;
            p.field0457 -= 5.000000005447899E-4 * (double)p.field1196;
            if (p.field0457 < -0.08000000096784139) {
               p.field0457 = -0.08000000096784139;
            }

            p.field0002 += p.field0176 + Math.sin((double)p.field1539 * 0.07000000061174955) * 0.005999998620070951;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613 + Math.cos((double)p.field1539 * 0.07000000061174955) * 0.005999998620070951;
            p.field0871 += p.field0826;
            if (!p.field1350 && this.method0788(p)) {
               p.field1350 = true;
               int rem = p.field1705 - p.field1539;
               if (rem > 6) {
                  p.field1539 = p.field1705 - 6;
               }
            }
            break;
         case 1:
            p.field0176 = p.field0176 * 0.9799995850626044 + wind.field_1352 * 0.020000008440140268 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9799995850626044 + wind.field_1350 * 0.020000008440140268 * (double)p.field1196;
            p.field0457 = p.field0457 * 0.9900000205074073 + 3.999998342730354E-4;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            break;
         case 2:
            p.field0176 = p.field0176 * 0.959999763444066 + wind.field_1352 * 0.04000000566798708 * (double)p.field1196 + Math.sin((double)p.field1539 * 0.0600000020991191) * 0.005999998620070951;
            p.field1613 = p.field1613 * 0.959999763444066 + wind.field_1350 * 0.04000000566798708 * (double)p.field1196 + Math.cos((double)p.field1539 * 0.0600000020991191) * 0.005999998620070951;
            p.field0457 = -0.0029999993027588533 + Math.sin((double)p.field1539 * 0.09000000745087192) * 0.00700000230307797;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            p.field0871 += p.field0826;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            p.field1087 = p.field1136 * (1.0F - lifeT * 0.55F);
            break;
         case 3:
            p.field0457 -= 0.011999996541534604;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            break;
         case 4:
            p.field0176 = p.field0176 * 0.9900000205074073 + wind.field_1352 * 0.010000003294232477 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9900000205074073 + wind.field_1350 * 0.010000003294232477 * (double)p.field1196;
            p.field0457 -= 3.999998342730354E-4 * (double)p.field1196;
            if (p.field0457 < -0.12000000048749848) {
               p.field0457 = -0.12000000048749848;
            }

            p.field0002 += p.field0176 + Math.sin((double)p.field1539 * 0.08000004191318248) * 0.003999997703356243;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613 + Math.cos((double)p.field1539 * 0.08000004191318248) * 0.003999997703356243;
            p.field0871 += p.field0826;
            break;
         case 5:
            p.field0176 = p.field0176 * 0.9850001258200113 + wind.field_1352 * 0.005000002112303237 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9850001258200113 + wind.field_1350 * 0.005000002112303237 * (double)p.field1196;
            p.field0457 *= 0.9900000205074073;
            p.field0002 += p.field0176 + Math.sin((double)p.field1539 * 0.05000001140965078) * 0.0029999991208599216;
            p.field1409 += p.field0457 + Math.cos((double)p.field1539 * 0.04000000566798708) * 0.0020000000153774806;
            p.field0956 += p.field1613 + Math.cos((double)p.field1539 * 0.05000001140965078) * 0.0029999991208599216;
            p.field0871 += p.field0826;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            float scale = lifeT < 0.25F ? lifeT / 0.25F : 1.0F - (lifeT - 0.25F) / 0.75F * 0.4F;
            p.field1087 = p.field1136 * scale;
            break;
         case 6:
            p.field1368 += wind.field_1352 * 0.05000001140965078 * (double)p.field1196;
            p.field0350 += wind.field_1350 * 0.05000001140965078 * (double)p.field1196;
            p.field0457 -= 0.0018000000000147173;
            if (p.field0457 < -0.2800000896520831) {
               p.field0457 = -0.2800000896520831;
            }

            p.field0384 += p.field0457;
            p.field0423 += p.field0826 * p.field1196;
            p.field0255 *= 0.965F;
            p.field0002 = p.field1368 + Math.cos((double)p.field0423) * (double)p.field0255;
            p.field1409 = p.field0384;
            p.field0956 = p.field0350 + Math.sin((double)p.field0423) * (double)p.field0255;
            p.field0502 = (p.field0502 + 1) % p.field0241.length;
            p.field0241[p.field0502] = p.field0002;
            p.field0303[p.field0502] = p.field1409;
            p.field0539[p.field0502] = p.field0956;
            break;
         case 7:
            p.field0176 = p.field0176 * 0.9960000149887187 + wind.field_1352 * 0.003999997703356243 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9960000149887187 + wind.field_1350 * 0.003999997703356243 * (double)p.field1196;
            p.field0457 = p.field0457 * 0.998000141139481 + 1.5000008738365585E-4;
            p.field0002 += p.field0176 + Math.sin((double)p.field1539 * 0.02500000005873084) * 0.005000002112303237;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613 + Math.cos((double)p.field1539 * 0.02500000005873084) * 0.005000002112303237;
            p.field0871 += p.field0826;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            p.field1087 = p.field1136 * (1.0F + lifeT * 0.5F);
            break;
         case 8:
            p.field0176 = p.field0176 * 0.9200000037255532 + (double)((float)Math.sin((double)p.field1539 * 0.15000000077852818 + (double)(p.field0871 * 4.0F))) * 0.011999996541534604;
            p.field1613 = p.field1613 * 0.9200000037255532 + (double)((float)Math.cos((double)p.field1539 * 0.15000000077852818 + (double)(p.field0871 * 4.0F))) * 0.011999996541534604;
            p.field0457 = 0.022000000001943833 + Math.sin((double)p.field1539 * 0.08000004191318248) * 0.011999996541534604;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            break;
         case 9:
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            this.field1323.add(this.method0618(p.field0002, p.field1409, p.field0956));
            break;
         case 10:
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            p.field0871 += p.field0826;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            float scale = lifeT < 0.2F ? lifeT / 0.2F : 1.0F - (lifeT - 0.2F) / 0.8F * 0.5F;
            p.field1087 = p.field1136 * scale;
            break;
         case 11:
            p.field0176 = p.field0176 * 0.9900000205074073 + wind.field_1352 * 0.003999997703356243 * (double)p.field1196;
            p.field1613 = p.field1613 * 0.9900000205074073 + wind.field_1350 * 0.003999997703356243 * (double)p.field1196;
            p.field0002 += p.field0176 + Math.sin((double)p.field1539 * 0.07000000061174955) * 0.0020000000153774806;
            p.field1409 += p.field0457 + Math.cos((double)p.field1539 * 0.05000001140965078) * 0.0014999995752660923;
            p.field0956 += p.field1613 + Math.cos((double)p.field1539 * 0.07000000061174955) * 0.0020000000153774806;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            float scale = lifeT < 0.15F ? lifeT / 0.15F : 1.0F;
            p.field1087 = p.field1136 * scale;
            break;
         case 12:
            p.field0176 = p.field0176 * 0.9500000003748397 + wind.field_1352 * 0.05000001140965078 + Math.sin((double)p.field1539 * 0.11999995622966886) * 0.011999996541534604;
            p.field1613 = p.field1613 * 0.9500000003748397 + wind.field_1350 * 0.05000001140965078 + Math.cos((double)p.field1539 * 0.11999995622966886) * 0.011999996541534604;
            p.field0457 = p.field0457 * 0.9900000205074073 - 6.000001166863272E-4;
            if (p.field0457 < -0.06000000046657533) {
               p.field0457 = -0.06000000046657533;
            }

            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            p.field0871 += p.field0826;
            break;
         case 13:
            p.field0176 = p.field0176 * 0.9700000610052666 + (double)((float)Math.sin((double)p.field1539 * 0.1000000074513778 + (double)p.field0871)) * 0.0029999991208599216;
            p.field1613 = p.field1613 * 0.9700000610052666 + (double)((float)Math.cos((double)p.field1539 * 0.1000000074513778 + (double)p.field0871)) * 0.0029999991208599216;
            p.field0457 = p.field0457 * 0.9950000121147059 + 1.9999990269916785E-4;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0956 += p.field1613;
            float lifeT = (float)p.field1539 / (float)p.field1705;
            float scale = lifeT < 0.2F ? lifeT / 0.2F : 1.0F - (lifeT - 0.2F) / 0.8F * 0.4F;
            p.field1087 = p.field1136 * scale;
            break;
         case 14:
            if (!p.field1350) {
               p.field0176 = p.field0176 * 0.9700000610052666 + wind.field_1352 * 0.029999992609062415 * (double)p.field1196 + Math.sin((double)p.field1539 * 0.09000000745087192) * 0.005000002112303237;
               p.field1613 = p.field1613 * 0.9700000610052666 + wind.field_1350 * 0.029999992609062415 * (double)p.field1196 + Math.cos((double)p.field1539 * 0.09000000745087192) * 0.005000002112303237;
               p.field0457 -= 2.4999984915444217E-4 * (double)p.field1196;
               if (p.field0457 < -0.04999999450665436) {
                  p.field0457 = -0.04999999450665436;
               }

               double newX = p.field0002 + p.field0176;
               double newY = p.field1409 + p.field0457;
               double newZ = p.field0956 + p.field1613;
               boolean collided = false;
               if (field0796.field_1687 != null) {
                  class_2338 cp = class_2338.method_49637(newX, newY, newZ);
                  class_2680 bs = field0796.field_1687.method_8320(cp);
                  if (!bs.method_26220(field0796.field_1687, cp).method_1110()) {
                     collided = true;
                  }
               }

               if (collided) {
                  p.field0176 = (double)0.0F;
                  p.field0457 = (double)0.0F;
                  p.field1613 = (double)0.0F;
                  p.field1350 = true;
                  int rem = p.field1705 - p.field1539;
                  if (rem > 14) {
                     p.field1539 = p.field1705 - 14;
                  }
               } else {
                  p.field0002 = newX;
                  p.field1409 = newY;
                  p.field0956 = newZ;
               }
            }

            p.field0871 += p.field0826;
            p.field0502 = (p.field0502 + 1) % p.field0241.length;
            p.field0241[p.field0502] = p.field0002;
            p.field0303[p.field0502] = p.field1409;
            p.field0539[p.field0502] = p.field0956;
      }

   }

   private boolean method0788(SkyObject p) {
      if (field0796.field_1687 == null) {
         return false;
      } else {
         class_238 box = new class_238(p.field0002 - 0.0600000020991191, p.field1409 - 0.0600000020991191, p.field0956 - 0.0600000020991191, p.field0002 + 0.0600000020991191, p.field1409 + 0.0600000020991191, p.field0956 + 0.0600000020991191);
         List<class_1309> hits = field0796.field_1687.method_8390(class_1309.class, box, (e) -> e != field0796.field_1724 && e.method_5805());
         return !hits.isEmpty();
      }
   }

   private void method0457() {
      class_243 playerPos = field0796.field_1724.method_19538();
      int maxParticles = ((Float)this.field0234.method0492()).intValue();
      int toSpawn = 20;

      for(int i = 0; i < toSpawn && this.field1191.size() < maxParticles; ++i) {
         double angle = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
         double dist = this.field1399.nextDouble() * (double)(Float)this.field0295.method0492();
         double x = playerPos.field_1352 + Math.cos(angle) * dist;
         double z = playerPos.field_1350 + Math.sin(angle) * dist;
         double y = playerPos.field_1351 + (double)20.0F + (this.field1399.nextDouble() - (double)0.5F) * (double)5.0F;
         float speedMult = 0.4F + this.field1399.nextFloat() * 1.2F;
         double vx = (this.field1399.nextDouble() - (double)0.5F) * 0.04000000566798708 * (double)speedMult;
         double vy = (double)(-(0.15F * speedMult));
         double vz = (this.field1399.nextDouble() - (double)0.5F) * 0.04000000566798708 * (double)speedMult;
         this.field1191.add(new SkyAnimation(x, y, z, vx, vy, vz, 300, false, true));
      }

      List<SkyAnimation> toAdd = new ArrayList();
      Iterator<SkyAnimation> it = this.field1191.iterator();

      while(it.hasNext()) {
         SkyAnimation p = (SkyAnimation)it.next();
         p.field0956 = p.field0565;
         p.field0757 = p.field0002;
         p.field1241 = p.field1409;
         p.field0565 += p.field0313;
         p.field0002 += p.field0176;
         p.field1409 += p.field0457;
         ++p.field1615;
         if (p.field1161 && !p.field1735) {
            double ox = (this.field1399.nextDouble() - (double)0.5F) * 0.15000000077852818;
            double oy = (this.field1399.nextDouble() - (double)0.5F) * 0.1000000074513778;
            double oz = (this.field1399.nextDouble() - (double)0.5F) * 0.15000000077852818;
            int trailLife = 15 + this.field1399.nextInt(20);
            toAdd.add(new SkyAnimation(p.field0956 + ox, p.field0757 + oy, p.field1241 + oz, (double)0.0F, (double)0.0F, (double)0.0F, trailLife, false, false));
         }

         if (p.field1161 && !p.field1735) {
            class_2338 below = class_2338.method_49637(p.field0565, p.field0002 - 0.1000000074513778, p.field1409);
            if (!field0796.field_1687.method_8320(below).method_26215()) {
               int burstCount = 4 + this.field1399.nextInt(4);

               for(int i = 0; i < burstCount; ++i) {
                  double speed = (double)0.08F * ((double)0.5F + this.field1399.nextDouble());
                  double bAngle = this.field1399.nextDouble() * 3.1415936675679283 * (double)2.0F;
                  double bvx = Math.cos(bAngle) * speed;
                  double bvz = Math.sin(bAngle) * speed;
                  double bvy = this.field1399.nextDouble() * speed * 0.700000000954607;
                  toAdd.add(new SkyAnimation(p.field0565, p.field0002, p.field1409, bvx, bvy, bvz, 15, true, false));
               }

               it.remove();
               continue;
            }
         } else if (p.field1735) {
            p.field0313 *= 0.9200000037255532;
            p.field0176 -= 0.007999995405319822;
            p.field0457 *= 0.9200000037255532;
         }

         double distSq = (p.field0565 - playerPos.field_1352) * (p.field0565 - playerPos.field_1352) + (p.field1409 - playerPos.field_1350) * (p.field1409 - playerPos.field_1350);
         double maxDist = (double)(Float)this.field0295.method0492() * 1.8000000019795739;
         if (p.field1615 >= p.field1539 || distSq > maxDist * maxDist) {
            it.remove();
         }
      }

      if (!toAdd.isEmpty()) {
         int space = maxParticles - this.field1191.size();
         if (space > 0) {
            this.field1191.addAll(toAdd.subList(0, Math.min(toAdd.size(), space)));
         }
      }

   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent event) {
      if (!method1974()) {
         if ((Boolean)this.field0550.method0492() && !this.field1134.isEmpty()) {
            this.method0839(event);
         }

         if ((Boolean)this.field0259.method0492() && !this.field1191.isEmpty()) {
            this.field1124.clear();
            this.field1116.clear();
            class_243 camera = field0796.field_1773.method_19418().method_19326();
            Matrix4f matrix = new Matrix4f();
            Color baseColor = this.field0504.method1726();
            int baseRgb = baseColor.getRGB() & 16777215;
            float partialTick = event.method1603();
            float pSize = (Float)this.field0529.method0492();
            boolean glow = true;

            for(SkyAnimation p : this.field1191) {
               float lifePercent = 1.0F - (float)p.field1615 / (float)p.field1539;
               if (!(lifePercent <= 0.0F)) {
                  float rx = (float)(p.field0956 + (p.field0565 - p.field0956) * (double)partialTick - camera.field_1352);
                  float ry = (float)(p.field0757 + (p.field0002 - p.field0757) * (double)partialTick - camera.field_1351);
                  float rz = (float)(p.field1241 + (p.field1409 - p.field1241) * (double)partialTick - camera.field_1350);
                  float alphaMult = p.field1161 ? 1.0F : lifePercent;
                  int a = Math.max(0, Math.min(255, (int)((float)baseColor.getAlpha() * alphaMult)));
                  int rgb = (a & 255) << 24 | baseRgb;
                  float sizeMult = p.field1161 ? 1.5F : lifePercent;
                  float size = pSize * sizeMult;
                  this.field1116.add(new ColoredVertex(matrix, rx - size, ry, rz, rgb));
                  this.field1116.add(new ColoredVertex(matrix, rx + size, ry, rz, rgb));
                  this.field1116.add(new ColoredVertex(matrix, rx, ry - size, rz, rgb));
                  this.field1116.add(new ColoredVertex(matrix, rx, ry + size, rz, rgb));
                  this.field1116.add(new ColoredVertex(matrix, rx, ry, rz - size, rgb));
                  this.field1116.add(new ColoredVertex(matrix, rx, ry, rz + size, rgb));
                  if (glow) {
                     float glowSize = size * 4.0F;
                     double dx = p.field0565 - camera.field_1352;
                     double dz = p.field1409 - camera.field_1350;
                     double dist = Math.sqrt(dx * dx + dz * dz);
                     float rightX;
                     float rightZ;
                     if (dist > 9.999995499875352E-4) {
                        rightX = (float)(-dz / dist);
                        rightZ = (float)(dx / dist);
                     } else {
                        rightX = 1.0F;
                        rightZ = 0.0F;
                     }

                     this.field1124.add(new SkyMesh(matrix, rx - rightX * glowSize, ry - glowSize, rz - rightZ * glowSize, rx + rightX * glowSize, ry - glowSize, rz + rightZ * glowSize, rx + rightX * glowSize, ry + glowSize, rz + rightZ * glowSize, rx - rightX * glowSize, ry + glowSize, rz - rightZ * glowSize, rgb));
                  }
               }
            }

            if (!this.field1116.isEmpty()) {
               this.method0521();
            }

            if (!this.field1124.isEmpty()) {
               this.method0516();
            }

         }
      }
   }

   private void method0839(GlowRenderEvent event) {
      this.field1232.clear();
      this.field1224.clear();
      this.field1238.clear();
      this.field1359.clear();
      this.field1354.clear();
      this.field1363.clear();
      this.field0902.clear();
      class_243 cam = field0796.field_1773.method_19418().method_19326();
      Matrix4f matrix = new Matrix4f();
      Color sirocco = this.field1581.method1726();
      int siroccoRgb = sirocco.getRGB() & 16777215;
      int siroccoA = sirocco.getAlpha();
      int tintRgb = siroccoRgb;
      int tintA = siroccoA;
      int streakRgb = siroccoRgb;
      int streakA = siroccoA;
      int sparkRgb = siroccoRgb;
      int sparkA = siroccoA;
      int flareRgb = siroccoRgb;
      int flareA = siroccoA;
      int spiralRgb = siroccoRgb;
      int spiralA = siroccoA;
      int smokeRgb = 3750201;
      int smokeA = 130;
      int glowbugRgb = siroccoRgb;
      int glowbugA = siroccoA;
      int starRgb = siroccoRgb;
      int starA = siroccoA;
      int tinyStarRgb = siroccoRgb;
      int tinyStarA = siroccoA;
      int treePetalRgb = siroccoRgb;
      int treePetalA = siroccoA;
      int leafEmberRgb = siroccoRgb;
      int leafEmberA = siroccoA;
      int debrisRgb = siroccoRgb;
      int debrisA = siroccoA;
      float partial = event.method1603();
      Quaternionf rot = field0796.field_1773.method_19418().method_23767();
      Vector3f r = new Vector3f(1.0F, 0.0F, 0.0F);
      rot.transform(r);
      Vector3f u = new Vector3f(0.0F, 1.0F, 0.0F);
      rot.transform(u);
      float rx = r.x;
      float ry = r.y;
      float rz = r.z;
      float ux = u.x;
      float uy = u.y;
      float uz = u.z;

      for(SkyObject p : this.field1134) {
         float lifeT = (float)p.field1539 / (float)p.field1705;
         float fade = lifeT < 0.1F ? lifeT / 0.1F : (1.0F - lifeT) / 0.9F;
         if (!(fade <= 0.0F)) {
            float px = (float)(p.field0757 + (p.field0002 - p.field0757) * (double)partial - cam.field_1352);
            float py = (float)(p.field1241 + (p.field1409 - p.field1241) * (double)partial - cam.field_1351);
            float pz = (float)(p.field0313 + (p.field0956 - p.field0313) * (double)partial - cam.field_1350);
            switch (p.field0569.ordinal()) {
               case 0:
                  int tr = tintRgb >> 16 & 255;
                  int tg = tintRgb >> 8 & 255;
                  int tb = tintRgb & 255;
                  int ar = (int)((float)tr * 0.45F);
                  int ag = (int)((float)tg * 0.32F);
                  int ab = (int)((float)tb * 0.25F);
                  int aa = Math.max(0, Math.min(255, (int)(210.0F * fade)));
                  int ashRgba = aa << 24 | ar << 16 | ag << 8 | ab;
                  this.method1086(this.field1224, matrix, px, py, pz, p.field1087, ashRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  break;
               case 1:
                  float pulse = (float)Math.sin((double)((float)p.field1539 * 0.18F + p.field0871 * 6.28F)) * 0.25F + 0.9F;
                  int ea = Math.max(0, Math.min(255, (int)((float)tintA * fade * pulse * 1.7F)));
                  int eRgba = ea << 24 | tintRgb;
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 1.4F, eRgba, rx, ry, rz, ux, uy, uz);
                  break;
               case 2:
                  int pa = Math.max(0, Math.min(255, (int)((float)tintA * fade)));
                  int pRgba = pa << 24 | tintRgb;
                  this.method1086(this.field1232, matrix, px, py, pz, p.field1087, pRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  break;
               case 3:
                  float vmag = (float)Math.sqrt(p.field0176 * p.field0176 + p.field0457 * p.field0457 + p.field1613 * p.field1613);
                  float streakLen = p.field1136 * 14.0F + vmag * 4.0F;
                  float width = p.field1136 * 0.55F;
                  int headA = Math.max(0, Math.min(255, (int)((float)streakA * fade)));
                  int headColor = headA << 24 | streakRgb;
                  this.method0343(matrix, px, py, pz, (float)p.field0176, (float)p.field0457, (float)p.field1613, streakLen, width, headColor, streakRgb);
                  if (p.field0931) {
                     int coreA = Math.max(0, Math.min(255, (int)(255.0F * fade)));
                     int coreColor = coreA << 24 | 16777215;
                     this.method0343(matrix, px, py, pz, (float)p.field0176, (float)p.field0457, (float)p.field1613, streakLen * 0.65F, width * 0.4F, coreColor, 16777215);
                  }

                  this.method1085(this.field1232, matrix, px, py, pz, p.field1136 * 1.6F, headColor, rx, ry, rz, ux, uy, uz);
                  break;
               case 4:
                  float twinkle = (float)Math.sin((double)((float)p.field1539 * 0.25F + p.field0871 * 3.0F)) * 0.25F + 0.85F;
                  int haloA = Math.max(0, Math.min(255, (int)((float)sparkA * fade * twinkle * 0.85F)));
                  int haloRgba = haloA << 24 | sparkRgb;
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 2.2F, haloRgba, rx, ry, rz, ux, uy, uz);
                  int spriteA = Math.max(0, Math.min(255, (int)(255.0F * fade * twinkle)));
                  int spriteRgba = spriteA << 24 | sparkRgb;
                  this.method1086(this.field1359, matrix, px, py, pz, p.field1087 * 1.1F, spriteRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  break;
               case 5:
                  float twinkle = (float)Math.sin((double)((float)p.field1539 * 0.15F + (float)p.field1293 * 1.7F)) * 0.2F + 0.85F;
                  int fa = Math.max(0, Math.min(255, (int)((float)flareA * fade * twinkle)));
                  int fRgba = fa << 24 | flareRgb;
                  List<SkyMesh> batch = (List)this.field1354.computeIfAbsent(p.field1293, (k) -> new ArrayList());
                  this.method1086(batch, matrix, px, py, pz, p.field1087, fRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  int haloA = Math.max(0, Math.min(255, (int)((float)flareA * fade * 0.35F)));
                  int haloRgba = haloA << 24 | flareRgb;
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 1.8F, haloRgba, rx, ry, rz, ux, uy, uz);
                  break;
               case 6:
                  int len = p.field0241.length;
                  int M = len - 1;
                  int headA = Math.max(0, Math.min(255, (int)((float)spiralA * fade)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1136 * 1.5F, headA << 24 | spiralRgb, rx, ry, rz, ux, uy, uz);
                  if (M < 2) {
                     break;
                  }

                  float width = p.field1136 * 0.55F;

                  for(int i = 0; i < M; ++i) {
                     int idxNew = (p.field0502 - i + len) % len;
                     int idxOld = (p.field0502 - i - 1 + len) % len;
                     double lerpX = p.field0241[idxOld] + (p.field0241[idxNew] - p.field0241[idxOld]) * (double)partial;
                     double lerpY = p.field0303[idxOld] + (p.field0303[idxNew] - p.field0303[idxOld]) * (double)partial;
                     double lerpZ = p.field0539[idxOld] + (p.field0539[idxNew] - p.field0539[idxOld]) * (double)partial;
                     this.field0898[i] = (float)(lerpX - cam.field_1352);
                     this.field0908[i] = (float)(lerpY - cam.field_1351);
                     this.field0861[i] = (float)(lerpZ - cam.field_1350);
                     this.field0939[i] = width;
                     float t = 1.0F - (float)i / (float)(M - 1);
                     int a = Math.max(0, Math.min(255, (int)((float)spiralA * fade * t)));
                     this.field0954[i] = a << 24 | spiralRgb;
                  }

                  this.method1559(matrix, M);
                  break;
               case 7:
                  int sma = Math.max(0, Math.min(255, (int)((float)smokeA * fade)));
                  int smRgba = sma << 24 | smokeRgb;
                  this.method1086(this.field1363, matrix, px, py, pz, p.field1087, smRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  break;
               case 8:
                  float pulse = (float)Math.sin((double)((float)p.field1539 * 0.3F + p.field0871 * 5.0F)) * 0.3F + 0.85F;
                  int ga = Math.max(0, Math.min(255, (int)((float)glowbugA * fade * pulse)));
                  int gRgba = ga << 24 | glowbugRgb;
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 2.2F, gRgba, rx, ry, rz, ux, uy, uz);
                  int coreA = Math.max(0, Math.min(255, (int)(255.0F * fade * pulse)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 0.8F, coreA << 24 | glowbugRgb, rx, ry, rz, ux, uy, uz);
                  break;
               case 9:
                  float vmag = (float)Math.sqrt(p.field0176 * p.field0176 + p.field0457 * p.field0457 + p.field1613 * p.field1613);
                  float streakLen = p.field1136 * 8.0F + vmag * 7.0F;
                  float width = p.field1136 * 0.5F;
                  int headA = Math.max(0, Math.min(255, (int)((float)starA * fade)));
                  int headColor = headA << 24 | starRgb;
                  this.method0343(matrix, px, py, pz, (float)p.field0176, (float)p.field0457, (float)p.field1613, streakLen, width, headColor, starRgb);
                  int coreA = Math.max(0, Math.min(255, (int)(255.0F * fade)));
                  this.method0343(matrix, px, py, pz, (float)p.field0176, (float)p.field0457, (float)p.field1613, streakLen * 0.6F, width * 0.35F, coreA << 24 | 16777215, 16777215);
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1136 * 2.0F, headColor, rx, ry, rz, ux, uy, uz);
                  break;
               case 10:
                  float twinkle = (float)Math.sin((double)((float)p.field1539 * 0.3F + p.field0871 * 4.0F)) * 0.25F + 0.85F;
                  int la = Math.max(0, Math.min(255, (int)((float)starA * fade * twinkle)));
                  int lRgba = la << 24 | starRgb;
                  List<SkyMesh> batch = (List)this.field1354.computeIfAbsent(p.field1293, (k) -> new ArrayList());
                  this.method1086(batch, matrix, px, py, pz, p.field1087, lRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  int haloA = Math.max(0, Math.min(255, (int)((float)starA * fade * 0.4F)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 1.7F, haloA << 24 | starRgb, rx, ry, rz, ux, uy, uz);
                  break;
               case 11:
                  float twinkle = (float)Math.sin((double)((float)p.field1539 * 0.4F + p.field0871 * 7.0F)) * 0.4F + 0.7F;
                  int coreA = Math.max(0, Math.min(255, (int)(255.0F * fade * twinkle)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087, coreA << 24 | tinyStarRgb, rx, ry, rz, ux, uy, uz);
                  int haloA = Math.max(0, Math.min(255, (int)((float)tinyStarA * fade * twinkle * 0.5F)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 2.6F, haloA << 24 | tinyStarRgb, rx, ry, rz, ux, uy, uz);
                  break;
               case 12:
                  int tpa = Math.max(0, Math.min(255, (int)((float)treePetalA * fade)));
                  int tpRgba = tpa << 24 | treePetalRgb;
                  this.method1086(this.field1232, matrix, px, py, pz, p.field1087, tpRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  break;
               case 13:
                  float pulse = (float)Math.sin((double)((float)p.field1539 * 0.25F + p.field0871 * 3.0F)) * 0.3F + 0.85F;
                  int la = Math.max(0, Math.min(255, (int)((float)leafEmberA * fade * pulse)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 1.6F, la << 24 | leafEmberRgb, rx, ry, rz, ux, uy, uz);
                  int coreA = Math.max(0, Math.min(255, (int)(255.0F * fade * pulse)));
                  this.method1085(this.field1232, matrix, px, py, pz, p.field1087 * 0.6F, coreA << 24 | leafEmberRgb, rx, ry, rz, ux, uy, uz);
                  break;
               case 14:
                  int len = p.field0241.length;
                  int M = len - 1;
                  int headA = Math.max(0, Math.min(255, (int)((float)debrisA * fade)));
                  int dRgba = headA << 24 | debrisRgb;
                  this.method1557(matrix, px, py, pz, p.field1087, dRgba, rx, ry, rz, ux, uy, uz, p.field0871);
                  if (M >= 2) {
                     for(int i = 0; i < M; ++i) {
                        int idxNew = (p.field0502 - i + len) % len;
                        int idxOld = (p.field0502 - i - 1 + len) % len;
                        double lerpX = p.field0241[idxOld] + (p.field0241[idxNew] - p.field0241[idxOld]) * (double)partial;
                        double lerpY = p.field0303[idxOld] + (p.field0303[idxNew] - p.field0303[idxOld]) * (double)partial;
                        double lerpZ = p.field0539[idxOld] + (p.field0539[idxNew] - p.field0539[idxOld]) * (double)partial;
                        this.field0898[i] = (float)(lerpX - cam.field_1352);
                        this.field0908[i] = (float)(lerpY - cam.field_1351);
                        this.field0861[i] = (float)(lerpZ - cam.field_1350);
                        float ratio = (float)i / (float)(M - 1);
                        this.field0939[i] = p.field1136 * (0.45F + ratio * 2.4F);
                        float trailA = (1.0F - ratio) * (1.0F - ratio) * fade;
                        int curA = Math.max(0, Math.min(255, (int)((float)debrisA * trailA)));
                        this.field0954[i] = curA << 24 | debrisRgb;
                     }

                     this.method1559(matrix, M);
                  }
            }
         }
      }

      if (!this.field1363.isEmpty()) {
         this.method0405();
      }

      if (!this.field0902.isEmpty()) {
         this.method0479();
      }

      if (!this.field1238.isEmpty()) {
         this.method2141(this.field1238);
      }

      if (!this.field1232.isEmpty()) {
         this.method0225(this.field1232);
      }

      if (!this.field1359.isEmpty()) {
         this.method1074(this.field1359);
      }

      if (!this.field1354.isEmpty()) {
         this.method0398();
      }

      if (!this.field1224.isEmpty()) {
         this.method0410();
      }

   }

   private void method1559(Matrix4f m, int count) {
      if (count >= 2) {
         for(int i = 0; i < count; ++i) {
            float tdx;
            float tdy;
            float tdz;
            if (i == 0) {
               tdx = this.field0898[1] - this.field0898[0];
               tdy = this.field0908[1] - this.field0908[0];
               tdz = this.field0861[1] - this.field0861[0];
            } else if (i == count - 1) {
               tdx = this.field0898[i] - this.field0898[i - 1];
               tdy = this.field0908[i] - this.field0908[i - 1];
               tdz = this.field0861[i] - this.field0861[i - 1];
            } else {
               tdx = this.field0898[i + 1] - this.field0898[i - 1];
               tdy = this.field0908[i + 1] - this.field0908[i - 1];
               tdz = this.field0861[i + 1] - this.field0861[i - 1];
            }

            float tlen = (float)Math.sqrt((double)(tdx * tdx + tdy * tdy + tdz * tdz));
            if (tlen < 1.0E-5F) {
               this.field0854[i] = 0.0F;
               this.field0869[i] = 0.0F;
               this.field0947[i] = 0.0F;
            } else {
               tdx /= tlen;
               tdy /= tlen;
               tdz /= tlen;
               float cdx = this.field0898[i];
               float cdy = this.field0908[i];
               float cdz = this.field0861[i];
               float clen = (float)Math.sqrt((double)(cdx * cdx + cdy * cdy + cdz * cdz));
               if (clen < 1.0E-5F) {
                  this.field0854[i] = 0.0F;
                  this.field0869[i] = 0.0F;
                  this.field0947[i] = 0.0F;
               } else {
                  cdx /= clen;
                  cdy /= clen;
                  cdz /= clen;
                  float crx = tdy * cdz - tdz * cdy;
                  float cry = tdz * cdx - tdx * cdz;
                  float crz = tdx * cdy - tdy * cdx;
                  float crlen = (float)Math.sqrt((double)(crx * crx + cry * cry + crz * crz));
                  if (crlen < 1.0E-5F) {
                     this.field0854[i] = 0.0F;
                     this.field0869[i] = 0.0F;
                     this.field0947[i] = 0.0F;
                  } else {
                     this.field0854[i] = crx / crlen;
                     this.field0869[i] = cry / crlen;
                     this.field0947[i] = crz / crlen;
                  }
               }
            }
         }

         for(int i = 0; i < count - 1; ++i) {
            float hH = this.field0939[i] * 0.5F;
            float hT = this.field0939[i + 1] * 0.5F;
            float hpX = this.field0854[i] * hH;
            float hpY = this.field0869[i] * hH;
            float hpZ = this.field0947[i] * hH;
            float tpX = this.field0854[i + 1] * hT;
            float tpY = this.field0869[i + 1] * hT;
            float tpZ = this.field0947[i + 1] * hT;
            this.field0902.add(new SkyLayer(m, this.field0898[i] - hpX, this.field0908[i] - hpY, this.field0861[i] - hpZ, this.field0954[i], this.field0898[i] + hpX, this.field0908[i] + hpY, this.field0861[i] + hpZ, this.field0954[i], this.field0898[i + 1] + tpX, this.field0908[i + 1] + tpY, this.field0861[i + 1] + tpZ, this.field0954[i + 1], this.field0898[i + 1] - tpX, this.field0908[i + 1] - tpY, this.field0861[i + 1] - tpZ, this.field0954[i + 1]));
         }

      }
   }

   private void method0479() {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyLayer q : this.field0902) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.5F, 0.0F).method_39415(q.c1);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(0.5F, 1.0F).method_39415(q.c2);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(0.5F, 1.0F).method_39415(q.c3);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.5F, 0.0F).method_39415(q.c4);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private void method1554(Matrix4f m, float hx, float hy, float hz, float tx, float ty, float tz, float headWidth, float tailWidth, int headColor, int tailColor) {
      float dx = hx - tx;
      float dy = hy - ty;
      float dz = hz - tz;
      float dlen = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(dlen < 1.0E-4F)) {
         dx /= dlen;
         dy /= dlen;
         dz /= dlen;
         float midX = (hx + tx) * 0.5F;
         float midY = (hy + ty) * 0.5F;
         float midZ = (hz + tz) * 0.5F;
         float cLen = (float)Math.sqrt((double)(midX * midX + midY * midY + midZ * midZ));
         if (!(cLen < 1.0E-4F)) {
            float cdx = midX / cLen;
            float cdy = midY / cLen;
            float cdz = midZ / cLen;
            float pX = dy * cdz - dz * cdy;
            float pY = dz * cdx - dx * cdz;
            float pZ = dx * cdy - dy * cdx;
            float pLen = (float)Math.sqrt((double)(pX * pX + pY * pY + pZ * pZ));
            if (!(pLen < 1.0E-4F)) {
               float invP = 1.0F / pLen;
               float headHW = headWidth * 0.5F * invP;
               float tailHW = tailWidth * 0.5F * invP;
               float hPX = pX * headHW;
               float hPY = pY * headHW;
               float hPZ = pZ * headHW;
               float tPX = pX * tailHW;
               float tPY = pY * tailHW;
               float tPZ = pZ * tailHW;
               this.field1238.add(new SkyLayer(m, hx - hPX, hy - hPY, hz - hPZ, headColor, hx + hPX, hy + hPY, hz + hPZ, headColor, tx + tPX, ty + tPY, tz + tPZ, tailColor, tx - tPX, ty - tPY, tz - tPZ, tailColor));
            }
         }
      }
   }

   private void method1555(Matrix4f m, float hx, float hy, float hz, float tx, float ty, float tz, float width, int headColor, int tailColor) {
      float dx = hx - tx;
      float dy = hy - ty;
      float dz = hz - tz;
      float dlen = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(dlen < 1.0E-4F)) {
         dx /= dlen;
         dy /= dlen;
         dz /= dlen;
         float midX = (hx + tx) * 0.5F;
         float midY = (hy + ty) * 0.5F;
         float midZ = (hz + tz) * 0.5F;
         float cLen = (float)Math.sqrt((double)(midX * midX + midY * midY + midZ * midZ));
         if (!(cLen < 1.0E-4F)) {
            float cdx = midX / cLen;
            float cdy = midY / cLen;
            float cdz = midZ / cLen;
            float pX = dy * cdz - dz * cdy;
            float pY = dz * cdx - dx * cdz;
            float pZ = dx * cdy - dy * cdx;
            float pLen = (float)Math.sqrt((double)(pX * pX + pY * pY + pZ * pZ));
            if (!(pLen < 1.0E-4F)) {
               float hw = width * 0.5F / pLen;
               pX *= hw;
               pY *= hw;
               pZ *= hw;
               this.field1238.add(new SkyLayer(m, hx - pX, hy - pY, hz - pZ, headColor, hx + pX, hy + pY, hz + pZ, headColor, tx + pX, ty + pY, tz + pZ, tailColor, tx - pX, ty - pY, tz - pZ, tailColor));
            }
         }
      }
   }

   private void method0405() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyMesh q : this.field1363) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(1.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.0F, 1.0F).method_39415(q.color);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
   }

   private void method0398() {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShader(class_10142.field_53880);

      for(Map.Entry<Integer, List<SkyMesh>> entry : this.field1354.entrySet()) {
         List<SkyMesh> quads = (List)entry.getValue();
         if (!quads.isEmpty()) {
            RenderSystem.setShaderTexture(0, field0416[(Integer)entry.getKey()]);
            class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

            for(SkyMesh q : quads) {
               buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.0F, 0.0F).method_39415(q.color);
               buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(1.0F, 0.0F).method_39415(q.color);
               buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.color);
               buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.0F, 1.0F).method_39415(q.color);
            }

            class_286.method_43433(buffer.method_60800());
         }
      }

      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private void method1074(List<SkyMesh> quads) {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1406);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyMesh q : quads) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(1.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.0F, 1.0F).method_39415(q.color);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private void method1085(List<SkyMesh> list, Matrix4f m, float x, float y, float z, float size, int rgba, float rx, float ry, float rz, float ux, float uy, float uz) {
      float h = size * 0.5F;
      float arx = rx * h;
      float ary = ry * h;
      float arz = rz * h;
      float aux = ux * h;
      float auy = uy * h;
      float auz = uz * h;
      list.add(new SkyMesh(m, x - arx - aux, y - ary - auy, z - arz - auz, x + arx - aux, y + ary - auy, z + arz - auz, x + arx + aux, y + ary + auy, z + arz + auz, x - arx + aux, y - ary + auy, z - arz + auz, rgba));
   }

   private void method1557(Matrix4f m, float x, float y, float z, float size, int rgba, float rx, float ry, float rz, float ux, float uy, float uz, float theta) {
      float c = (float)Math.cos((double)theta);
      float s = (float)Math.sin((double)theta);
      float rrx = c * rx + s * ux;
      float rry = c * ry + s * uy;
      float rrz = c * rz + s * uz;
      float rux = -s * rx + c * ux;
      float ruy = -s * ry + c * uy;
      float ruz = -s * rz + c * uz;
      float halfH = size * 0.65F;
      float halfW = size * 0.22F;
      this.field1224.add(new SkyMesh(m, x + rux * halfH, y + ruy * halfH, z + ruz * halfH, x + rrx * halfW, y + rry * halfW, z + rrz * halfW, x - rux * halfH, y - ruy * halfH, z - ruz * halfH, x - rrx * halfW, y - rry * halfW, z - rrz * halfW, rgba));
   }

   private void method1086(List<SkyMesh> list, Matrix4f m, float x, float y, float z, float size, int rgba, float rx, float ry, float rz, float ux, float uy, float uz, float theta) {
      float c = (float)Math.cos((double)theta);
      float s = (float)Math.sin((double)theta);
      float rrx = c * rx + s * ux;
      float rry = c * ry + s * uy;
      float rrz = c * rz + s * uz;
      float rux = -s * rx + c * ux;
      float ruy = -s * ry + c * uy;
      float ruz = -s * rz + c * uz;
      this.method1085(list, m, x, y, z, size, rgba, rrx, rry, rrz, rux, ruy, ruz);
   }

   private void method0343(Matrix4f m, float hx, float hy, float hz, float vx, float vy, float vz, float length, float width, int headColor, int tailColor) {
      float vlen = (float)Math.sqrt((double)(vx * vx + vy * vy + vz * vz));
      if (!(vlen < 1.0E-4F)) {
         float dx = vx / vlen;
         float dy = vy / vlen;
         float dz = vz / vlen;
         float tx = hx - dx * length;
         float ty = hy - dy * length;
         float tz = hz - dz * length;
         float midX = (hx + tx) * 0.5F;
         float midY = (hy + ty) * 0.5F;
         float midZ = (hz + tz) * 0.5F;
         float cLen = (float)Math.sqrt((double)(midX * midX + midY * midY + midZ * midZ));
         if (!(cLen < 1.0E-4F)) {
            float cdx = midX / cLen;
            float cdy = midY / cLen;
            float cdz = midZ / cLen;
            float pX = dy * cdz - dz * cdy;
            float pY = dz * cdx - dx * cdz;
            float pZ = dx * cdy - dy * cdx;
            float pLen = (float)Math.sqrt((double)(pX * pX + pY * pY + pZ * pZ));
            if (!(pLen < 1.0E-4F)) {
               float hw = width * 0.5F / pLen;
               pX *= hw;
               pY *= hw;
               pZ *= hw;
               this.field1238.add(new SkyLayer(m, hx - pX, hy - pY, hz - pZ, headColor, hx + pX, hy + pY, hz + pZ, headColor, tx + pX, ty + pY, tz + pZ, tailColor, tx - pX, ty - pY, tz - pZ, tailColor));
            }
         }
      }
   }

   private void method0225(List<SkyMesh> quads) {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyMesh q : quads) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(1.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.0F, 1.0F).method_39415(q.color);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private void method2141(List<SkyLayer> quads) {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyLayer q : quads) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.5F, 0.0F).method_39415(q.c1);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(0.5F, 1.0F).method_39415(q.c2);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.c3);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(1.0F, 0.0F).method_39415(q.c4);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private void method0410() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyMesh q : this.field1224) {
         buffer.method_22918(q.matrix, q.x1, q.y1, q.z1).method_22913(0.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x2, q.y2, q.z2).method_22913(1.0F, 0.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x3, q.y3, q.z3).method_22913(1.0F, 1.0F).method_39415(q.color);
         buffer.method_22918(q.matrix, q.x4, q.y4, q.z4).method_22913(0.0F, 1.0F).method_39415(q.color);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
   }

   private void method0521() {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 32772);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);

      for(ColoredVertex v : this.field1116) {
         buffer.method_22918(v.matrix, v.x, v.y, v.z).method_39415(v.color);
      }

      RenderSystem.setShader(class_10142.field_53876);
      GL11.glHint(3154, 4354);
      GL11.glEnable(2848);
      class_286.method_43433(buffer.method_60800());
      GL11.glDisable(2848);
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
   }

   private void method0516() {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 32772);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShaderTexture(0, field1393);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(SkyMesh quad : this.field1124) {
         buffer.method_22918(quad.matrix, quad.x1, quad.y1, quad.z1).method_22913(0.0F, 0.0F).method_39415(quad.color);
         buffer.method_22918(quad.matrix, quad.x2, quad.y2, quad.z2).method_22913(1.0F, 0.0F).method_39415(quad.color);
         buffer.method_22918(quad.matrix, quad.x3, quad.y3, quad.z3).method_22913(1.0F, 1.0F).method_39415(quad.color);
         buffer.method_22918(quad.matrix, quad.x4, quad.y4, quad.z4).method_22913(0.0F, 1.0F).method_39415(quad.color);
      }

      class_286.method_43433(buffer.method_60800());
      RenderSystem.setShaderTexture(0, 0);
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
   }

   public void method0025() {
      super.method0025();
      this.field1191.clear();
      this.field1134.clear();
   }

   public void method2078() {
      super.method2078();
      this.field1191.clear();
      this.field1134.clear();
   }

   private static enum SkyObjectType {
      field0569,
      field0006,
      field1413,
      field0960,
      field0761,
      field1245,
      field0317,
      field0180,
      field0461,
      field1617,
      field1541,
      field1707,
      field1139,
      field1090,
      field1199;

      // $FF: synthetic method
      private static SkyObjectType[] method0580() {
         return new SkyObjectType[]{field0569, field0006, field1413, field0960, field0761, field1245, field0317, field0180, field0461, field1617, field1541, field1707, field1139, field1090, field1199};
      }
   }

   private static class SkyObject {
      SkyObjectType field0569;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      double field0313;
      double field0176;
      double field0457;
      double field1613;
      int field1539;
      int field1705;
      float field1136;
      float field1087;
      float field1196;
      float field0871;
      float field0826;
      boolean field0931;
      boolean field1350;
      int field1293;
      double field1368;
      double field0384;
      double field0350;
      float field0423;
      float field0255;
      double[] field0241;
      double[] field0303;
      double[] field0539;
      int field0502;
   }

   private static record SkyLayer(Matrix4f matrix, float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2, float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
      public Matrix4f method0577() {
         return this.matrix;
      }

      public float method0002() {
         return this.x1;
      }

      public float method2047() {
         return this.y1;
      }

      public float method1762() {
         return this.z1;
      }

      public int method1604() {
         return this.c1;
      }

      public float method1946() {
         return this.x2;
      }

      public float method0413() {
         return this.y2;
      }

      public float method0355() {
         return this.z2;
      }

      public int method0484() {
         return this.c2;
      }

      public float method2213() {
         return this.x3;
      }

      public float method2182() {
         return this.y3;
      }

      public float method2253() {
         return this.z3;
      }

      public int method1902() {
         return this.c3;
      }

      public float method1878() {
         return this.x4;
      }

      public float method1928() {
         return this.y4;
      }

      public float method1697() {
         return this.z4;
      }

      public int method1680() {
         return this.c4;
      }
   }

   private static class SkyAnimation {
      double field0565;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      double field0313;
      double field0176;
      double field0457;
      int field1615;
      int field1539;
      boolean field1735;
      boolean field1161;

      SkyAnimation(double x, double y, double z, double vx, double vy, double vz, int maxAge, boolean scattered, boolean isHead) {
         this.field0565 = x;
         this.field0002 = y;
         this.field1409 = z;
         this.field0956 = x;
         this.field0757 = y;
         this.field1241 = z;
         this.field0313 = vx;
         this.field0176 = vy;
         this.field0457 = vz;
         this.field1615 = 0;
         this.field1539 = maxAge;
         this.field1735 = scattered;
         this.field1161 = isHead;
      }
   }

   private static record ColoredVertex(Matrix4f matrix, float x, float y, float z, int color) {
      public Matrix4f method0577() {
         return this.matrix;
      }

      public float method0002() {
         return this.x;
      }

      public float method2047() {
         return this.y;
      }

      public float method1762() {
         return this.z;
      }

      public int method1604() {
         return this.color;
      }
   }

   private static record SkyMesh(Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, int color) {
      public Matrix4f method0577() {
         return this.matrix;
      }

      public float method0002() {
         return this.x1;
      }

      public float method2047() {
         return this.y1;
      }

      public float method1762() {
         return this.z1;
      }

      public float method1603() {
         return this.x2;
      }

      public float method1946() {
         return this.y2;
      }

      public float method0413() {
         return this.z2;
      }

      public float method0355() {
         return this.x3;
      }

      public float method0483() {
         return this.y3;
      }

      public float method2213() {
         return this.z3;
      }

      public float method2182() {
         return this.x4;
      }

      public float method2253() {
         return this.y4;
      }

      public float method1901() {
         return this.z4;
      }

      public int method1879() {
         return this.color;
      }
   }
}
