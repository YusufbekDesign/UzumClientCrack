package aethereal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;

public class UseTracker extends Module {
   public final MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("usetracker.tracks", Arrays.asList("Potions", "Food", "Ender Pearls", "Totems"), true, () -> true)).method1007("Track").method0210("Which actions to notify about").method2130("Какие действия отслеживать");
   private static final long field1412 = 1500L;
   private static final int field0958 = 2;
   private final Map<UUID, UseSession> field0210 = new HashMap();
   private final List<UseEntry> field0488 = new ArrayList();
   private final Set<Integer> field1647 = new HashSet();

   public static UseTracker method1725() {
      ArbuzClient arbuz = ArbuzClient.method2004();
      return arbuz != null && arbuz.method1783() != null ? (UseTracker)arbuz.method1783().method0976(UseTracker.class) : null;
   }

   public UseTracker() {
      super("UseTracker", ModuleCategory.field0776, "Notifies when nearby players use items");
      this.method1013("Уведомления о использовании предметов");
   }

   public void method0025() {
      super.method0025();
      this.field0210.clear();
      this.field0488.clear();
      this.field1647.clear();
   }

   public void method2078() {
      this.field0210.clear();
      this.field0488.clear();
      this.field1647.clear();
      super.method2078();
   }

   @EventHandler
   public void onSpawn(EntitySpawnEvent e) {
      if (!method1974()) {
         if (this.field0089.method0387("Ender Pearls")) {
            class_1297 entity = e.method1798();
            if (entity instanceof class_1684) {
               class_1684 pearl = (class_1684)entity;
               if (!this.field1647.contains(pearl.method_5628())) {
                  if (!this.field0488.stream().anyMatch((p) -> p.field0567 == pearl.method_5628())) {
                     class_1297 owner = pearl.method_24921();
                     if (owner instanceof class_1657) {
                        class_1657 player = (class_1657)owner;
                        if (player != field0796.field_1724) {
                           this.field1647.add(pearl.method_5628());
                           this.method1182(player);
                           return;
                        }
                     }

                     this.field0488.add(new UseEntry(pearl.method_5628()));
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onPopTotem(TotemPopEvent e) {
      if (!method1974()) {
         if (this.field0089.method0387("Totems")) {
            class_1657 player = e.method1800();
            if (player != null && player != field0796.field_1724) {
               class_1799 stack = new class_1799(class_1802.field_8288);
               boolean ru = method2030();
               String message = (ru ? "потерял " : "lost ") + "\"" + stack.method_7964().getString() + "\"";
               NewHUD.method1053(player.method_5477().getString(), message, stack, false);
            }
         }
      }
   }

   @EventHandler
   public void onPlayerTick(PlayerTickEvent e) {
      if (!method1974()) {
         this.method1691();
         this.method1754();
      }
   }

   private void method1691() {
      if (!this.field0488.isEmpty()) {
         boolean wantPearls = this.field0089.method0387("Ender Pearls");
         Iterator<UseEntry> it = this.field0488.iterator();

         while(it.hasNext()) {
            UseEntry p = (UseEntry)it.next();
            class_1297 en = field0796.field_1687.method_8469(p.field0567);
            if (en instanceof class_1684) {
               class_1684 pearl = (class_1684)en;
               class_1297 owner = pearl.method_24921();
               if (owner instanceof class_1657) {
                  class_1657 player = (class_1657)owner;
                  if (player != field0796.field_1724) {
                     if (wantPearls && !this.field1647.contains(pearl.method_5628())) {
                        this.field1647.add(pearl.method_5628());
                        this.method1182(player);
                     }

                     it.remove();
                     continue;
                  }
               }
            } else if (en == null) {
               it.remove();
               continue;
            }

            ++p.field0004;
            if (p.field0004 > 10) {
               it.remove();
            }
         }
      }

      this.field1647.removeIf((id) -> field0796.field_1687.method_8469(id) == null);
   }

   private void method1754() {
      boolean wantPotions = this.field0089.method0387("Potions");
      boolean wantFood = this.field0089.method0387("Food");
      Set<UUID> seen = new HashSet();

      for(class_1657 player : field0796.field_1687.method_18456()) {
         if (player != field0796.field_1724) {
            UUID uuid = player.method_5667();
            seen.add(uuid);
            UseSession state = (UseSession)this.field0210.computeIfAbsent(uuid, (k) -> new UseSession());
            boolean isUsing = player.method_6115();
            if (isUsing) {
               if (!state.field0751) {
                  state.field1520 = player.method_6030().method_7972();
                  state.field0751 = true;
               }

               state.field0004 = 0;
            } else if (state.field0751) {
               ++state.field0004;
               if (state.field0004 >= 2) {
                  this.method1195(player, state, wantPotions, wantFood);
                  state.field0751 = false;
                  state.field0004 = 0;
                  state.field1520 = null;
               }
            }
         }
      }

      this.field0210.keySet().removeIf((uuidx) -> !seen.contains(uuidx));
   }

   private void method1195(class_1657 player, UseSession state, boolean wantPotions, boolean wantFood) {
      class_1799 stack = state.field1520;
      if (stack != null && !stack.method_7960()) {
         boolean isPotion = stack.method_31574(class_1802.field_8574) || stack.method_31574(class_1802.field_20417) || stack.method_31574(class_1802.field_8103);
         boolean isFood = !isPotion && stack.method_57824(class_9334.field_50075) != null;
         if (!isPotion || wantPotions) {
            if (!isFood || wantFood) {
               if (isPotion || isFood) {
                  long now = System.currentTimeMillis();
                  if (now - state.field0959 >= 1500L) {
                     state.field0959 = now;
                     boolean ru = method2030();
                     String itemName = stack.method_7964().getString();
                     String message;
                     if (isPotion) {
                        message = (ru ? "выпил " : "drank ") + "\"" + itemName + "\"";
                     } else {
                        message = (ru ? "съел " : "ate ") + "\"" + itemName + "\"";
                     }

                     NewHUD.method1053(player.method_5477().getString(), message, stack.method_7972(), true);
                  }
               }
            }
         }
      }
   }

   private void method1182(class_1657 player) {
      boolean ru = method2030();
      String message = ru ? "бросил эндер-жемчуг" : "threw an ender pearl";
      NewHUD.method1053(player.method_5477().getString(), message, new class_1799(class_1802.field_8634), true);
   }

   private static boolean method2030() {
      try {
         return ClickGuiDashboard.field0984.method0492() == ClickGuiDashboard.Language.field0631;
      } catch (Exception var1) {
         return true;
      }
   }

   private static class UseSession {
      boolean field0751;
      int field0004;
      class_1799 field1520;
      long field0959;
   }

   private static class UseEntry {
      final int field0567;
      int field0004;

      UseEntry(int id) {
         this.field0567 = id;
      }
   }
}
