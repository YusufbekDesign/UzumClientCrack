package aethereal;

public class MultiTask extends Module {
   public MultiTask() {
      super("MultiTask", ModuleCategory.field1470, "Qazish paytida buyumlarni ishlatish imkonini beradi");
      this.method1013("Qazish paytida buyumlarni ishlatish imkonini beradi");
   }
}
