package aethereal;

import java.awt.Color;
import java.util.Objects;
import net.minecraft.class_1306;
import net.minecraft.class_1799;

public class EmberHands extends Module implements MinecraftAccess {
   private final FloatSetting field0060 = (FloatSetting)(new FloatSetting("emberhands.glowradius", 15.0F, 6.0F, 32.0F, 1.0F)).method1007("Nur radiusi").method0210("Buyum atrofidagi nurlanish radiusi piksellarda").method2130("Buyum atrofidagi nurlanish radiusi");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("emberhands.flameheight", 28.0F, 8.0F, 56.0F, 1.0F)).method1007("Olov balandligi").method0210("Olov ustunining buyum ustidan qanchalik balandligi").method2130("Buyum ustidagi olov balandligi");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("emberhands.traillength", 12.0F, 3.0F, 28.0F, 1.0F)).method1007("Iz uzunligi").method0210("Kuzatilayotgan olovning davomiyligi").method2130("Olov izining uzunligi");
   private final FloatSetting field0190 = (FloatSetting)(new FloatSetting("emberhands.flowspeed", 1.1F, 0.25F, 2.0F, 0.05F)).method1007("Oqim tezligi").method0210("Olov buramasining animatsiya tezligi").method2130("Olov harakati tezligi");
   private final BooleanSetting field0464 = (BooleanSetting)(new BooleanSetting("emberhands.usecustomcolor", false)).method1007("Maxsus rang").method0210("Buyum rangi o'rniga olov rangini almashtirish").method2130("Buyum rangi o'rniga maxsus olov rangini ishlatish");
   private final ColorSetting field1623;
   private final BurningHandsRenderer field1547;

   public EmberHands() {
      super("EmberHands", ModuleCategory.field1004, "Qo'lga olingan buyumda yonayotgan olov effekti");
      BooleanSetting var10008 = this.field0464;
      Objects.requireNonNull(var10008);
      this.field1623 = (ColorSetting)(new ColorSetting("emberhands.firecolor", 255, 120, 30, 255, var10008::method0492)).method1007("Olov rangi").method0210("Maxsus olov rangi").method2130("Olov rangi");
      this.field1547 = new BurningHandsRenderer();
      this.method1013("Qo'lga olingan buyumda yonayotgan olov effekti");
   }

   public void method2078() {
      super.method2078();
      this.field1547.method0578();
   }

   public void method0991(Runnable var1) {
      class_1799 var2 = field0796.field_1724 == null ? class_1799.field_8037 : field0796.field_1724.method_6047();
      class_1799 var3 = field0796.field_1724 == null ? class_1799.field_8037 : field0796.field_1724.method_6079();
      boolean var4 = !var2.method_7960();
      boolean var5 = !var3.method_7960();
      boolean var6 = field0796.field_1724 == null || field0796.field_1724.method_6068() == class_1306.field_6183;
      float var7 = 0.0F;
      float var8 = 0.0F;
      if (var4) {
         if (var6) {
            var8 = 1.0F;
         } else {
            var7 = 1.0F;
         }
      }

      if (var5) {
         if (var6) {
            var7 = 1.0F;
         } else {
            var8 = 1.0F;
         }
      }

      Color var9 = this.field1623.method1726();
      float var10 = (float)var9.getRed() / 255.0F;
      float var11 = (float)var9.getGreen() / 255.0F;
      float var12 = (float)var9.getBlue() / 255.0F;
      float var13 = (Boolean)this.field0464.method0492() ? 1.0F : 0.0F;
      this.field1547.method0993(var1, var7, var8, (Float)this.field0060.method0492(), (Float)this.field1450.method0492(), (Float)this.field0985.method0492(), (Float)this.field0190.method0492(), var10, var11, var12, var13);
   }
}
