package aethereal;

public class ThrowXP extends Module {
   public ThrowXP() {
      super("ThrowXP", ModuleCategory.field0776, "AntiKick AutoCrystal uchun qistirilma");
      this.method1013("AntiKick AutoCrystal uchun qistirilma");
   }

   public static ThrowXP method1723() {
      ArbuzClient var0 = ArbuzClient.method2004();
      return var0 != null && var0.method1783() != null ? (ThrowXP)var0.method1783().method0976(ThrowXP.class) : null;
   }
}
