package aethereal;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class AimAssistRotationStrategy extends RotationStrategy {
   private final float fraction;

   public AimAssistRotationStrategy(float fraction) {
      super("AimAssist");
      this.fraction = class_3532.method_15363(fraction, 0.01F, 0.6F);
   }

   public Rotation method0874(Rotation var1, Rotation var2, class_243 var3, class_1297 var4) {
      float yawDelta = class_3532.method_15393(var2.method2047() - var1.method2047());
      float pitchDelta = var2.method1762() - var1.method1762();
      float newYaw = var1.method2047() + yawDelta * this.fraction;
      float newPitch = class_3532.method_15363(var1.method1762() + pitchDelta * this.fraction, -90.0F, 90.0F);
      return (new Rotation(newYaw, newPitch)).method0545();
   }

   public class_243 method0569() {
      return new class_243((double)0.0F, (double)0.0F, (double)0.0F);
   }
}
