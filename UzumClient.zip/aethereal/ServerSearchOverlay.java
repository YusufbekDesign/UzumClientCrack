package aethereal;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9848;

public class ServerSearchOverlay {
   private static final float field0566 = 104.0F;
   private static final float field0003 = 19.0F;
   private static final float field1410 = 6.0F;
   private static final float field0957 = 10.0F;
   private static final float field0758 = 10.0F;
   private static final float field1242 = 4.0F;
   private static final float field0314 = 10.0F;
   private static final float field0177 = 7.0F;
   private static final float field0458 = 2.5F;
   private static final float field1614 = 5.0F;
   private static final float field1538 = 1.5F;
   private static final float field1704 = 3.0F;
   private static final Color field1153 = new Color(255, 255, 255, 80);
   private static final Color field1104 = new Color(255, 255, 255, 15);
   private static final Color field1210 = new Color(255, 255, 255, 40);
   private boolean field0890 = false;
   private float field0826;
   private float field0910;
   private float field1331 = 0.0F;
   private boolean field1312 = false;
   private final Animation field1382;
   private static final int field0386 = 8;
   private static final int field0352 = 8;
   private String field0437;
   private String field0270;
   private String field0237;
   private List<Setting<?>> field0300;
   private final Animation[] field0540;
   private final Animation[] field0516;
   private boolean field0558;
   private int field1672;
   private float field1657;
   private float field1688;
   private final Map<String, Float> field1596;
   private static final float field1577 = 0.32F;
   private static final float field1601 = 11.0F;
   private static final float field1753 = 1.5F;
   private static final float field1739 = 12.0F;

   public ServerSearchOverlay() {
      this.field1382 = new Animation(150L, (double)1.0F, false, EasingCurve.field1011);
      this.field0437 = "";
      this.field0270 = "";
      this.field0237 = "";
      this.field0300 = List.of();
      this.field0540 = new Animation[8];
      this.field0516 = new Animation[8];
      this.field0558 = false;
      this.field1672 = -1;
      this.field1657 = 0.0F;
      this.field1688 = 0.0F;
      this.field1596 = new HashMap();

      for(int i = 0; i < 8; ++i) {
         this.field0540[i] = new Animation(200L, (double)1.0F, false, EasingCurve.field1477);
      }

      for(int i = 0; i < 8; ++i) {
         this.field0516[i] = new Animation(250L, (double)1.0F, true, EasingCurve.field0672);
      }

   }

   public void method0703(float mouseX, float mouseY, String elementName) {
      NewHUD hud = this.method1955();
      if (hud != null) {
         this.field0437 = elementName;
         this.field0300 = hud.method2132(elementName);
         this.field0558 = elementName.equals("NewServerInfo");
         if (!this.field0300.isEmpty() || this.field0558) {
            this.field0237 = hud.method1844(elementName);
            this.field0270 = hud.method1655(elementName);
            int enumIdx = 0;

            for(int i = 0; i < this.field0300.size(); ++i) {
               Object var9 = this.field0300.get(i);
               if (var9 instanceof BooleanSetting) {
                  BooleanSetting bs = (BooleanSetting)var9;
                  this.field0540[i].method1570((Boolean)bs.method0492());
               } else {
                  var9 = this.field0300.get(i);
                  if (var9 instanceof EnumSetting) {
                     EnumSetting<?> es = (EnumSetting)var9;
                     Enum<?>[] constants = (Enum[])((Enum)es.method0492()).getClass().getEnumConstants();

                     for(Enum<?> val : constants) {
                        if (enumIdx < 8) {
                           this.field0516[enumIdx].method1570(es.method0492() == val);
                           this.field0516[enumIdx].method1973();
                           ++enumIdx;
                        }
                     }
                  }
               }
            }

            this.field1672 = -1;
            this.field1596.clear();
            float screenW = ScreenLayoutHelper.method2047();
            float screenH = ScreenLayoutHelper.method1762();
            float panelH = this.method1603();
            this.field0826 = mouseX;
            this.field0910 = mouseY;
            if (this.field0826 + 104.0F > screenW) {
               this.field0826 = screenW - 104.0F - 4.0F;
            }

            if (this.field0910 + panelH > screenH) {
               this.field0910 = screenH - panelH - 4.0F;
            }

            if (this.field0826 < 4.0F) {
               this.field0826 = 4.0F;
            }

            if (this.field0910 < 4.0F) {
               this.field0910 = 4.0F;
            }

            this.field0890 = true;
            this.field1312 = true;
         }
      }
   }

   public void method0578() {
      this.field1312 = false;
      this.field1672 = -1;
   }

   public boolean method0026() {
      return this.field0890;
   }

   public boolean method1014(String elementName) {
      NewHUD hud = this.method1955();
      if (hud == null) {
         return false;
      } else if (elementName.equals("NewServerInfo")) {
         return true;
      } else {
         return !hud.method2132(elementName).isEmpty();
      }
   }

   private float method2047() {
      float y = this.field0910 + 19.0F + 6.0F;
      if (!this.field0300.isEmpty()) {
         for(Setting<?> s : this.field0300) {
            y += 14.0F;
            if (s instanceof EnumSetting) {
               y += 12.0F;
            }
         }

         y -= 4.0F;
         y += 6.0F;
      }

      return y;
   }

   private int method1763() {
      NewHUD hud = this.method1955();
      return hud != null && this.field0558 ? hud.method2025().size() : 0;
   }

   private float method1603() {
      float h = 25.0F;
      if (!this.field0300.isEmpty()) {
         for(Setting<?> s : this.field0300) {
            h += 14.0F;
            if (s instanceof EnumSetting) {
               h += 12.0F;
            }
         }

         h -= 4.0F;
      }

      if (this.field0558) {
         int orderCount = this.method1763();
         if (!this.field0300.isEmpty()) {
            h += 6.0F;
         }

         h += (float)orderCount * 10.0F + (orderCount > 1 ? (float)(orderCount - 1) * 4.0F : 0.0F);
      }

      h += 6.0F;
      return h;
   }

   private NewHUD method1955() {
      return (NewHUD)ArbuzClient.method2004().method1783().method0976(NewHUD.class);
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.field0890) {
         float target = this.field1312 ? 1.0F : 0.0F;
         this.field1331 += (target - this.field1331) * 0.22F;
         if (Math.abs(target - this.field1331) < 0.004F) {
            this.field1331 = target;
         }

         if (!this.field1312 && this.field1331 <= 0.005F) {
            this.field1331 = 0.0F;
            this.field0890 = false;
         } else {
            float alpha = this.field1331;
            class_4587 stack = context.method_51448();
            float panelH = this.method1603();
            float scale = 0.94F + 0.06F * this.field1331;
            float pivotX = this.field0826 + 52.0F;
            float pivotY = this.field0910 + panelH;
            stack.method_22903();
            stack.method_46416(pivotX, pivotY, 0.0F);
            stack.method_22905(scale, scale, 1.0F);
            stack.method_46416(-pivotX, -pivotY, 0.0F);
            Color bgColor = ThemeColorManager.method1908().method0141(224);
            GuiRenderHelper.method1462(stack, this.field0826, this.field0910, 104.0F, panelH, 10.0F, 14.0F, method0964(Color.WHITE, alpha));
            GuiRenderHelper.method1463(stack, this.field0826, this.field0910, 104.0F, panelH, 10.0F, method0964(bgColor, alpha));
            FontSize headerFont = Fonts.field0075.method0654(5.5F);
            FontSize headerIconFont = Fonts.field0774.method0654(5.5F);
            Color brandColor = ThemeColorManager.method1908().method2063();
            float headerY = this.field0910 + 6.0F;
            float hx = this.field0826 + 6.0F;
            if (!this.field0270.isEmpty()) {
               GuiRenderHelper.method1491(stack, headerIconFont, this.field0270, hx, headerY, method0964(brandColor, alpha));
               hx += headerIconFont.method0998(this.field0270) + 3.0F;
            }

            float hSepY = this.field0910 + 8.0F - 1.5F;
            GuiRenderHelper.method0326(stack, hx, hSepY, 1.3F, 6.0F, 0.2F, method0964(field1153, alpha));
            hx += 3.5F;
            GuiRenderHelper.method1491(stack, headerFont, this.field0237, hx, headerY, method0964(Color.WHITE, alpha));
            FontSize closeFont = Fonts.field0774.method0654(4.0F);
            float closeFw = closeFont.method0998("F");
            float closeFh = closeFont.method0530();
            float closeX = this.field0826 + 104.0F - 6.0F - closeFw - 4.0F;
            float closeY = headerY + 1.0F;
            float closeHitPad = 3.0F;
            boolean closeHovered = this.field1331 > 0.5F && MathHelper.method0689(closeX - closeHitPad, closeY - closeHitPad, closeFw + closeHitPad * 2.0F, closeFh + closeHitPad * 2.0F, (float)mouseX, (float)mouseY);
            if (this.field1382.method0376() != closeHovered) {
               this.field1382.method1570(closeHovered);
            }

            float hoverVal = this.field1382.method0002();
            int closeR = (int)(170.0F + 70.0F * hoverVal);
            int closeG = (int)(170.0F + 70.0F * hoverVal);
            int closeB = (int)(170.0F + 80.0F * hoverVal);
            int closeA = (int)(2.55F * (52.0F + 90.0F * hoverVal));
            Color closeColor = new Color(Math.min(255, closeR), Math.min(255, closeG), Math.min(255, closeB), Math.min(255, closeA));
            float closeScale = 1.0F + 0.18F * hoverVal;
            float closeCx = closeX + closeFw / 2.0F;
            float closeCy = closeY + closeFh / 2.0F;
            stack.method_22903();
            stack.method_46416(closeCx, closeCy, 0.0F);
            stack.method_22905(closeScale, closeScale, 1.0F);
            stack.method_46416(-closeCx, -closeCy, 0.0F);
            GuiRenderHelper.method1491(stack, closeFont, "F", closeX, closeY, method0964(closeColor, alpha));
            stack.method_22909();
            float fullSepY = this.field0910 + 19.0F - 0.5F;
            GuiRenderHelper.method1463(stack, this.field0826, fullSepY, 104.0F, 0.5F, 0.0F, method0964(new Color(255, 255, 255, 10), alpha));
            FontSize nameFont = Fonts.field0075.method0654(5.5F);
            float currentY = this.field0910 + 19.0F + 6.0F;
            int enumIdx = 0;
            FontSize settingIconFont = Fonts.field0774.method0654(4.0F);

            for(int i = 0; i < this.field0300.size(); ++i) {
               Setting<?> setting = (Setting)this.field0300.get(i);
               float textY = currentY + (10.0F - nameFont.method0530()) / 2.0F;
               if (setting instanceof EnumSetting) {
                  GuiRenderHelper.method1491(stack, settingIconFont, "g", this.field0826 + 6.0F, textY + 1.0F, method0964(brandColor, alpha));
                  GuiRenderHelper.method1491(stack, nameFont, setting.method2067(), this.field0826 + 6.0F + settingIconFont.method0998("g") + 2.0F, textY, method0964(Color.WHITE, alpha));
               } else {
                  GuiRenderHelper.method1491(stack, settingIconFont, "r", this.field0826 + 6.0F, textY + 1.0F, method0964(brandColor, alpha));
                  GuiRenderHelper.method1491(stack, nameFont, setting.method2067(), this.field0826 + 6.0F + settingIconFont.method0998("r") + 2.0F, textY, method0964(Color.WHITE, alpha));
               }

               if (setting instanceof BooleanSetting) {
                  BooleanSetting bs = (BooleanSetting)setting;
                  if (this.field0540[i].method0376() != (Boolean)bs.method0492()) {
                     this.field0540[i].method1570((Boolean)bs.method0492());
                  }

                  float cbX = this.field0826 + 104.0F - 6.0F - 10.0F;
                  float cbY = currentY + 1.5F;
                  float cbProgress = this.field0540[i].method0002();
                  int boxBg = class_9848.method_61319(cbProgress, method0195(new Color(255, 255, 255, (int)(2.55F * (12.0F + 12.0F * cbProgress))), alpha), method0195(brandColor, alpha));
                  int knobColor = method0195(new Color(246, 247, 255, 255), alpha);
                  GuiRenderHelper.method0326(stack, cbX, cbY, 10.0F, 7.0F, 2.5F, new Color(boxBg, true));
                  GuiRenderHelper.method0326(stack, cbX + 1.0F + 3.0F * cbProgress, cbY + 1.0F, 5.0F, 5.0F, 1.5F, new Color(knobColor, true));
               } else if (setting instanceof EnumSetting) {
                  EnumSetting<?> es = (EnumSetting)setting;
                  float btnY = currentY + 10.0F + 1.0F;
                  float btnX = this.field0826 + 6.0F - 2.0F;
                  FontSize iconsFont = Fonts.field0774.method0654(5.0F);
                  Enum<?>[] constants = (Enum[])((Enum)es.method0492()).getClass().getEnumConstants();

                  for(int j = 0; j < constants.length; ++j) {
                     Enum<?> enumVal = constants[j];
                     boolean selected = es.method0492() == enumVal;
                     if (enumIdx < 8) {
                        if (this.field0516[enumIdx].method0376() != selected) {
                           this.field0516[enumIdx].method1570(selected);
                        }

                        float animVal = selected ? this.field0516[enumIdx].method0002() : 0.0F;
                        String enumName = ((DisplayNamed)enumVal).method0557();
                        float btnW = 8.0F + nameFont.method0998(enumName) + (float)(selected ? 8 : 0);
                        int eBg = class_9848.method_61319(animVal, method0195(new Color(255, 255, 255, (int)(2.55F * (2.0F + 10.0F * animVal))), alpha), method0195(brandColor, alpha));
                        int eTxt = method0195(new Color(246, 247, 255, (int)(2.55F * (24.0F + 24.0F * animVal + 52.0F))), alpha);
                        int eChk = method0195(new Color(246, 247, 255, (int)(2.55F * (24.0F * animVal + 76.0F * animVal))), alpha);
                        GuiRenderHelper.method1463(stack, btnX, btnY, btnW, 11.0F, 2.0F, new Color(eBg, true));
                        GuiRenderHelper.method1488(stack, iconsFont, "q", btnX + 4.0F, btnY + 2.5F, 0.1F, new Color(eChk, true));
                        GuiRenderHelper.method1488(stack, nameFont, enumName, btnX + btnW - 4.0F - nameFont.method0998(enumName), btnY + 2.0F, 0.05F, new Color(eTxt, true));
                        btnX += btnW + 1.5F;
                        ++enumIdx;
                     }
                  }
               }

               currentY += 14.0F;
               if (setting instanceof EnumSetting) {
                  currentY += 12.0F;
               }
            }

            if (this.field0558) {
               NewHUD hud = this.method1955();
               if (hud != null) {
                  List<String> order = hud.method2025();
                  if (!this.field0300.isEmpty()) {
                     GuiRenderHelper.method1463(stack, this.field0826 + 6.0F, currentY - 2.0F, 92.0F, 0.5F, 0.0F, method0964(field1153, alpha));
                  }

                  float orderStartY = this.method2047();
                  FontSize dragIconFont = Fonts.field0774.method0654(4.0F);
                  float minY = orderStartY;
                  float maxY = orderStartY + (float)(order.size() - 1) * 14.0F;

                  for(int i = 0; i < order.size(); ++i) {
                     String name = (String)order.get(i);
                     float targetY = orderStartY + (float)i * 14.0F;
                     float rowY;
                     if (this.field1672 == i) {
                        float rowY = this.field1688 - this.field1657;
                        rowY = Math.max(minY, Math.min(maxY, rowY));
                        this.field1596.put(name, rowY);
                        GuiRenderHelper.method0326(stack, this.field0826 + 6.0F - 2.0F, rowY - 1.0F, 96.0F, 12.0F, 3.0F, method0964(field1104, alpha));
                     } else {
                        float current = (Float)this.field1596.getOrDefault(name, targetY);
                        current += (targetY - current) * 0.32F;
                        if (Math.abs(targetY - current) < 0.1F) {
                           current = targetY;
                        }

                        this.field1596.put(name, current);
                        rowY = current;
                     }

                     float textY = rowY + (10.0F - nameFont.method0530()) / 2.0F;
                     GuiRenderHelper.method1491(stack, dragIconFont, "g", this.field0826 + 6.0F, rowY + (10.0F - dragIconFont.method0530()) / 2.0F, method0964(field1210, alpha));
                     float nameX = this.field0826 + 6.0F + dragIconFont.method0998("g") + 4.0F;
                     Color nameColor = this.field1672 == i ? method0964(brandColor, alpha) : method0964(Color.WHITE, alpha);
                     GuiRenderHelper.method1491(stack, nameFont, name, nameX, textY, nameColor);
                  }
               }
            }

            stack.method_22909();
         }
      }
   }

   public boolean method0627(double mouseX, double mouseY, int button) {
      if (!this.field0890) {
         return false;
      } else {
         float panelH = this.method1603();
         if (!MathHelper.method0689(this.field0826, this.field0910, 104.0F, panelH, (float)mouseX, (float)mouseY)) {
            this.method0578();
            return false;
         } else {
            if (button == 0) {
               FontSize closeFont = Fonts.field0774.method0654(4.0F);
               float closeFw = closeFont.method0998("F");
               float closeFh = closeFont.method0530();
               float closeX = this.field0826 + 104.0F - 6.0F - closeFw - 4.0F;
               float closeY = this.field0910 + 6.0F + 1.0F;
               float closeHitPad = 3.0F;
               if (MathHelper.method0689(closeX - closeHitPad, closeY - closeHitPad, closeFw + closeHitPad * 2.0F, closeFh + closeHitPad * 2.0F, (float)mouseX, (float)mouseY)) {
                  this.method0578();
                  return true;
               }

               float currentY = this.field0910 + 19.0F + 6.0F;
               int clickEnumIdx = 0;

               for(int i = 0; i < this.field0300.size(); ++i) {
                  Setting<?> setting = (Setting)this.field0300.get(i);
                  if (setting instanceof BooleanSetting) {
                     BooleanSetting bs = (BooleanSetting)setting;
                     if (MathHelper.method0689(this.field0826, currentY, 104.0F, 10.0F, (float)mouseX, (float)mouseY)) {
                        bs.method0206(!(Boolean)bs.method0492());
                        this.field0540[i].method1570((Boolean)bs.method0492());
                        this.field0540[i].method1634();
                        ArbuzClient.method2004().method2216().method1634();
                        return true;
                     }
                  } else if (setting instanceof EnumSetting) {
                     EnumSetting<?> es = (EnumSetting)setting;
                     float btnY = currentY + 10.0F + 1.0F;
                     float btnX = this.field0826 + 6.0F - 2.0F;
                     FontSize nf = Fonts.field0075.method0654(5.5F);
                     Enum<?>[] constants = (Enum[])((Enum)es.method0492()).getClass().getEnumConstants();

                     for(int j = 0; j < constants.length; ++j) {
                        Enum<?> enumVal = constants[j];
                        boolean selected = es.method0492() == enumVal;
                        String enumName = ((DisplayNamed)enumVal).method0557();
                        float btnW = 8.0F + nf.method0998(enumName) + (float)(selected ? 8 : 0);
                        if (MathHelper.method0689(btnX, btnY, btnW, 11.0F, (float)mouseX, (float)mouseY)) {
                           es.method0442(((DisplayNamed)enumVal).method0557());
                           if (clickEnumIdx < 8) {
                              this.field0516[clickEnumIdx].method1634();
                           }

                           ArbuzClient.method2004().method2216().method1634();
                           return true;
                        }

                        btnX += btnW + 1.5F;
                        ++clickEnumIdx;
                     }
                  }

                  currentY += 14.0F;
                  if (setting instanceof EnumSetting) {
                     currentY += 12.0F;
                  }
               }

               if (this.field0558) {
                  float orderStartY = this.method2047();
                  int orderCount = this.method1763();

                  for(int i = 0; i < orderCount; ++i) {
                     float rowY = orderStartY + (float)i * 14.0F;
                     if (MathHelper.method0689(this.field0826, rowY, 104.0F, 10.0F, (float)mouseX, (float)mouseY)) {
                        this.field1672 = i;
                        this.field1657 = (float)mouseY - rowY;
                        this.field1688 = (float)mouseY;
                        return true;
                     }
                  }
               }
            }

            return true;
         }
      }
   }

   public void method0615(double mouseX, double mouseY) {
      if (this.field1672 >= 0) {
         this.field1688 = (float)mouseY;
         this.method0430();
      }
   }

   public void method0111(double mouseX, double mouseY, int button) {
      if (this.field1672 >= 0 && button == 0) {
         this.field1672 = -1;
      }

   }

   private void method0430() {
      NewHUD hud = this.method1955();
      if (hud != null) {
         List<String> order = hud.method2025();
         if (this.field1672 >= 0 && this.field1672 < order.size()) {
            float orderStartY = this.method2047();
            float draggedRowCenter = this.field1688 - this.field1657 + 5.0F;
            int targetSlot = Math.round((draggedRowCenter - orderStartY) / 14.0F);
            targetSlot = Math.max(0, Math.min(order.size() - 1, targetSlot));
            if (targetSlot != this.field1672) {
               hud.method0738(this.field1672, targetSlot);
               this.field1672 = targetSlot;
               ArbuzClient.method2004().method2216().method1634();
            }

         }
      }
   }

   private static Color method0964(Color c, float alpha) {
      return alpha >= 0.99F ? c : new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, (int)((float)c.getAlpha() * alpha))));
   }

   private static int method0195(Color c, float alpha) {
      int a = Math.max(0, Math.min(255, (int)((float)c.getAlpha() * alpha)));
      return a << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }
}
