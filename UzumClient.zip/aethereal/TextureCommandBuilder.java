package aethereal;

import net.minecraft.class_1044;

public final class TextureCommandBuilder extends RenderCommandBuilder<TextureRenderCommand> {
   private RenderSize field0680;
   private CornerRadius field0050;
   private QuadColor field1481;
   private float field0957;
   private float field0758;
   private float field1242;
   private float field0314;
   private float field0177;
   private int field0459;

   public TextureCommandBuilder method0926(RenderSize size) {
      this.field0680 = size;
      return this;
   }

   public TextureCommandBuilder method0825(CornerRadius radius) {
      this.field0050 = radius;
      return this;
   }

   public TextureCommandBuilder method0917(QuadColor color) {
      this.field1481 = color;
      return this;
   }

   public TextureCommandBuilder method0661(float smoothness) {
      this.field0957 = smoothness;
      return this;
   }

   public TextureCommandBuilder method0698(float u, float v, float texWidth, float texHeight, class_1044 texture) {
      return this.method0695(u, v, texWidth, texHeight, texture.method_4624());
   }

   public TextureCommandBuilder method0695(float u, float v, float texWidth, float texHeight, int textureId) {
      this.field0758 = u;
      this.field1242 = v;
      this.field0314 = texWidth;
      this.field0177 = texHeight;
      this.field0459 = textureId;
      return this;
   }

   protected TextureRenderCommand method1789() {
      return new TextureRenderCommand(this.field0680, this.field0050, this.field1481, this.field0957, this.field0758, this.field1242, this.field0314, this.field0177, this.field0459);
   }

   protected void method0025() {
      this.field0680 = RenderSize.NONE;
      this.field0050 = CornerRadius.NO_ROUND;
      this.field1481 = QuadColor.WHITE;
      this.field0957 = 1.0F;
      this.field0758 = 0.0F;
      this.field1242 = 0.0F;
      this.field0314 = 0.0F;
      this.field0177 = 0.0F;
      this.field0459 = 0;
   }

   // $FF: synthetic method
   protected Object method2066() {
      return this.method1789();
   }
}
