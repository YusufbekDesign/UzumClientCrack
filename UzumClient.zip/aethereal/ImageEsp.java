package aethereal;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Arrays;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

public class ImageEsp extends Module {
   private static final class_2960 field0403 = class_2960.method_60655("arbuzhack", "textures/glow.png");
   public final FloatSetting field0060 = (FloatSetting)(new FloatSetting("imageesp.heightscale", 1.3F, 0.5F, 3.0F, 0.05F)).method1007("Balanchlik masshtabi").method0210("Nurlanish balandligi mavjudot balandligi ko'paytmasi sifatida").method2130("Mavjudot balandligiga nisbatan nurlanish balandligi");
   public final FloatSetting field1450 = (FloatSetting)(new FloatSetting("imageesp.widthscale", 2.0F, 0.5F, 6.0F, 0.05F)).method1007("Kenglik masshtabi").method0210("Nurlanish kengligi mavjudot kengligi ko'paytmasi sifatida").method2130("Mavjudot kengligiga nisbatan nurlanish kengligi");
   public final FloatSetting field0985 = (FloatSetting)(new FloatSetting("imageesp.pad", 0.3F, 0.0F, 3.0F, 0.05F)).method1007("Qo'shimcha").method0210("Avtomatik moslashuvga qo'shimcha o'lcham (bloklarda)").method2130("Avtomatik moslashuvdan qo'shimcha o'lcham");
   public final FloatSetting field0190 = (FloatSetting)(new FloatSetting("imageesp.heightoffset", 0.0F, -2.0F, 4.0F, 0.05F)).method1007("Balanchlik siljishi").method0210("Mavjudot markazidan vertikal siljish").method2130("Markazdan vertikal siljish");
   public final FloatSetting field0470 = (FloatSetting)(new FloatSetting("imageesp.opacity", 1.0F, 0.05F, 1.0F, 0.05F)).method1007("Shaffoflik").method0210("Umumiy shaffoflik ko'paytmasi").method2130("Umumiy shaffoflik");
   public final FloatSetting field1627 = (FloatSetting)(new FloatSetting("imageesp.layers", 2.0F, 1.0F, 5.0F, 1.0F)).method1007("Qatlamlar").method0210("Qo'shib qo'yilgan spraitlar soni (ko'p = yorug'roq halqa)").method2130("Qatlamlar soni (yorug'roq halqa)");
   public final BooleanSetting field1544 = (BooleanSetting)(new BooleanSetting("imageesp.throughwalls", false)).method1007("Devorlar orqali").method0210("Bloklar orqali ko'rsatish (va mavjudot ustida)").method2130("Bloklar orqali chizish");
   public final BooleanSetting field1709 = (BooleanSetting)(new BooleanSetting("imageesp.additive", true)).method1007("Qo'shish").method0210("Yorug'roq nurlanish uchun qo'shish aralashtirishni ishlatish").method2130("Rang qo'shish (yorug'roq)");
   public final MultiSelectSetting field1152 = (MultiSelectSetting)(new MultiSelectSetting("imageesp.target", Arrays.asList("Players", "Hostiles", "Animals", "Ambient", "Invisibles", "Items", "Crystals", "Others"), false, () -> true)).method1007("Maqsad").method0210("Nurlanish ko'rsatiladigan mavjudot turlari").method2130("Mavjudot turlari");
   public final ColorSetting field1095 = (ColorSetting)(new ColorSetting("imageesp.playerscolor", 133, 232, 80, 255, () -> (Boolean)this.field1152.method0439("Players").method0492())).method1882().method1007("O'yinchilar rangi").method0210("O'yinchilar uchun nurlanish rangi").method2130("O'yinchilar rangi");
   public final ColorSetting field1203 = (ColorSetting)(new ColorSetting("imageesp.hostilescolor", 250, 150, 255, 255, () -> (Boolean)this.field1152.method0439("Hostiles").method0492())).method1882().method1007("Dushmamonlar rangi").method0210("Dushmamonlar uchun nurlanish rangi").method2130("Dushmamonlar rangi");
   public final ColorSetting field0878 = (ColorSetting)(new ColorSetting("imageesp.animalscolor", 100, 255, 100, 255, () -> (Boolean)this.field1152.method0439("Animals").method0492())).method1882().method1007("Hayvonlar rangi").method0210("Hayvonlar uchun nurlanish rangi").method2130("Hayvonlar rangi");
   public final ColorSetting field0833 = (ColorSetting)(new ColorSetting("imageesp.ambientcolor", 150, 150, 255, 255, () -> (Boolean)this.field1152.method0439("Ambient").method0492())).method1882().method1007("Atrof-muhit rangi").method0210("Atrof-muhit mavjudotlari uchun nurlanish rangi").method2130("Atrof-muhit mavjudotlari rangi");
   public final ColorSetting field0916 = (ColorSetting)(new ColorSetting("imageesp.invisiblescolor", 253, 121, 218, 255, () -> (Boolean)this.field1152.method0439("Invisibles").method0492())).method1882().method1007("Ko'rinmaslar rangi").method0210("Ko'rinmas mavjudotlar uchun nurlanish rangi").method2130("Ko'rinmas mavjudotlar rangi");
   public final ColorSetting field1338 = (ColorSetting)(new ColorSetting("imageesp.itemscolor", 244, 156, 255, 255, () -> (Boolean)this.field1152.method0439("Items").method0492())).method1882().method1007("Buyumlar rangi").method0210("Buyumlar uchun nurlanish rangi").method2130("Buyumlar rangi");
   public final ColorSetting field1299 = (ColorSetting)(new ColorSetting("imageesp.crystalscolor", 255, 145, 255, 255, () -> (Boolean)this.field1152.method0439("Crystals").method0492())).method1882().method1007("Kristallar rangi").method0210("Tugun kristallari uchun nurlanish rangi").method2130("Kristallar rangi");
   public final ColorSetting field1374 = (ColorSetting)(new ColorSetting("imageesp.otherscolor", 128, 128, 128, 255, () -> (Boolean)this.field1152.method0439("Others").method0492())).method1882().method1007("Boshqalar rangi").method0210("Boshqa mavjudotlar uchun nurlanish rangi").method2130("Boshqa mavjudotlar rangi");

   public ImageEsp() {
      super("ImageEsp", ModuleCategory.field1004, "Har bir mavjudot orqasida glow.png spriteini ko'rsatadi, tanaga cho'zilgan");
      this.method1013("Har bir mavjudot orqasida glow.png billboardini chizadi, tanaga cho'zilgan");
      this.field1152.method0439("Players").method0206(true);
      this.field1152.method0439("Hostiles").method0206(true);
      this.field1152.method0439("Animals").method0206(true);
      this.field1152.method0439("Ambient").method0206(true);
      this.field1152.method0439("Invisibles").method0206(true);
      this.field1152.method0439("Items").method0206(true);
      this.field1152.method0439("Crystals").method0206(true);
      this.field1152.method0439("Others").method0206(false);
   }

   @EventHandler
   public void onRenderEntity(RenderEntityEvent var1) {
      if (!method1974()) {
         class_1297 var2 = var1.method1798();
         if (this.method1129(var2)) {
            Color var3 = this.method0234(var2);
            if (var3.getAlpha() > 0) {
               class_4184 var4 = field0796.field_1773.method_19418();
               class_4587 var5 = var1.method2227();
               float var6 = var2.method_17682();
               float var7 = var2.method_17681();
               float var8 = (Float)this.field0985.method0492();
               float var9 = var6 * (Float)this.field0060.method0492() + var8;
               float var10 = var7 * (Float)this.field1450.method0492() + var8;
               double var11 = var1.method1945();
               double var13 = var1.method0412() + (double)var6 * (double)0.5F + (double)(Float)this.field0190.method0492();
               double var15 = var1.method0354();
               RenderSystem.setShader(class_10142.field_53880);
               RenderSystem.setShaderTexture(0, field0403);
               RenderSystem.enableBlend();
               if ((Boolean)this.field1709.method0492()) {
                  RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
               } else {
                  RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
               }

               RenderSystem.disableCull();
               RenderSystem.depthMask(false);
               if ((Boolean)this.field1544.method0492()) {
                  RenderSystem.disableDepthTest();
               } else {
                  RenderSystem.enableDepthTest();
               }

               int var17 = Math.max(1, ((Float)this.field1627.method0492()).intValue());
               float var18 = (Float)this.field0470.method0492();

               for(int var19 = 0; var19 < var17; ++var19) {
                  float var20 = 1.0F + (float)var19 * 0.3F;
                  float var21 = var18 * (1.0F / (1.0F + (float)var19 * 0.6F));
                  int var22 = class_3532.method_15340((int)((float)var3.getAlpha() * var21), 0, 255);
                  if (var22 > 0) {
                     int var23 = (new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), var22)).getRGB();
                     var5.method_22903();
                     var5.method_22904(var11, var13, var15);
                     var5.method_22907(var4.method_23767());
                     float var24 = var10 * var20 * 0.5F;
                     float var25 = var9 * var20 * 0.5F;
                     Matrix4f var26 = var5.method_23760().method_23761();
                     class_287 var27 = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
                     var27.method_22918(var26, -var24, -var25, 0.0F).method_22913(0.0F, 1.0F).method_39415(var23);
                     var27.method_22918(var26, var24, -var25, 0.0F).method_22913(1.0F, 1.0F).method_39415(var23);
                     var27.method_22918(var26, var24, var25, 0.0F).method_22913(1.0F, 0.0F).method_39415(var23);
                     var27.method_22918(var26, -var24, var25, 0.0F).method_22913(0.0F, 0.0F).method_39415(var23);
                     class_286.method_43433(var27.method_60800());
                     var5.method_22909();
                  }
               }

               RenderSystem.enableDepthTest();
               RenderSystem.depthMask(true);
               RenderSystem.enableCull();
               RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
               RenderSystem.disableBlend();
            }
         }
      }

   }

   private boolean method1129(class_1297 var1) {
      if (!var1.method_5805()) {
         return false;
      } else if (var1 == field0796.field_1724 && field0796.field_1690.method_31044().method_31034()) {
         return false;
      } else if ((Boolean)this.field1152.method0439("Players").method0492() && EntityFilter.method1129(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Hostiles").method0492() && EntityFilter.method0235(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Animals").method0492() && EntityFilter.method2144(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Ambient").method0492() && EntityFilter.method1851(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Invisibles").method0492() && EntityFilter.method0444(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Items").method0492() && EntityFilter.method1660(var1)) {
         return true;
      } else if ((Boolean)this.field1152.method0439("Crystals").method0492() && EntityFilter.method1988(var1)) {
         return true;
      } else {
         return (Boolean)this.field1152.method0439("Others").method0492() ? EntityFilter.method2237(var1) == EntityFilter.EntityKind.field0196 : false;
      }
   }

   private Color method0234(class_1297 var1) {
      Color var10000;
      switch (EntityFilter.method2237(var1)) {
         case field0644 -> var10000 = this.field1095.method1726();
         case field0074 -> var10000 = this.field1203.method1726();
         case field1459 -> var10000 = this.field0878.method1726();
         case field0994 -> var10000 = this.field0833.method1726();
         case field0773 -> var10000 = this.field0916.method1726();
         case field1257 -> var10000 = this.field1338.method1726();
         case field0324 -> var10000 = this.field1299.method1726();
         case field0196 -> var10000 = this.field1374.method1726();
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }
}
