package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

public class GappleIndicator extends Module {
   private static final class_2960 field0160 = ArbuzClient.method1012("textures/glow.png");
   private static final int field1411 = 255;
   private static final int field0958 = 215;
   private static final int field0178 = 0;
   private final List<IndicatorState> field0488 = new ArrayList();
   private final Random field1646 = new Random();
   private final Set<Integer> field1567 = new HashSet();

   public GappleIndicator() {
      super("GappleIndicator", ModuleCategory.field1004, "Shows healing cross particles when players eat golden apples");
      this.method1013("Показывает частицы при поедании золотых яблок");
   }

   public void method0025() {
      super.method0025();
      this.field0488.clear();
      this.field1567.clear();
   }

   public void method2078() {
      super.method2078();
      this.field0488.clear();
      this.field1567.clear();
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         for(class_1657 player : field0796.field_1687.method_18456()) {
            if (player != field0796.field_1724 || !field0796.field_1690.method_31044().method_31034()) {
               boolean hasRegen = player.method_6059(class_1294.field_5924);
               if (hasRegen) {
                  this.field1567.add(player.method_5628());
                  int count = 1 + this.field1646.nextInt(2);

                  for(int i = 0; i < count; ++i) {
                     this.method1182(player);
                  }
               } else {
                  this.field1567.remove(player.method_5628());
               }
            }
         }

         Iterator<IndicatorState> it = this.field0488.iterator();

         while(it.hasNext()) {
            IndicatorState p = (IndicatorState)it.next();
            p.field0956 = p.field0565;
            p.field0757 = p.field0002;
            p.field1241 = p.field1409;
            p.field0565 += p.field0313;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0176 += 0.001999998866807356;
            p.field0313 *= 0.9600000169531109;
            p.field0457 *= 0.9600000169531109;
            ++p.field1615;
            if (p.field1615 >= p.field1539) {
               it.remove();
            }
         }

      }
   }

   private void method1182(class_1657 player) {
      double cx = player.method_23317() + (this.field1646.nextDouble() - (double)0.5F) * 0.7999999428167943;
      double cy = player.method_23318() + (double)0.5F + this.field1646.nextDouble() * 1.2000001196168377;
      double cz = player.method_23321() + (this.field1646.nextDouble() - (double)0.5F) * 0.7999999428167943;
      double vx = (this.field1646.nextDouble() - (double)0.5F) * 0.04000001724767218;
      double vy = 0.020000001006107267 + this.field1646.nextDouble() * 0.04000001724767218;
      double vz = (this.field1646.nextDouble() - (double)0.5F) * 0.04000001724767218;
      int maxAge = 20 + this.field1646.nextInt(25);
      float size = 0.07F + this.field1646.nextFloat() * 0.08F;
      float rotation = this.field1646.nextFloat() * 360.0F;
      this.field0488.add(new IndicatorState(cx, cy, cz, vx, vy, vz, maxAge, size, rotation));
   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent event) {
      if (!method1974() && !this.field0488.isEmpty()) {
         class_243 camera = field0796.field_1773.method_19418().method_19326();
         float partialTick = event.method1603();
         Matrix4f matrix = new Matrix4f();
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(770, 1);
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.disableCull();
         RenderSystem.setShader(class_10142.field_53876);
         class_287 quadsPhase1 = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);
         boolean hasCrosses = false;

         for(IndicatorState p : this.field0488) {
            float life = 1.0F - (float)p.field1615 / (float)p.field1539;
            if (!(life <= 0.0F)) {
               float alpha = life < 0.4F ? life / 0.4F : 1.0F;
               int a = (int)(alpha * 160.0F);
               int color = a << 24 | 16711680 | '휀' | 0;
               float rx = (float)(method0625(p.field0956, p.field0565, partialTick) - camera.field_1352);
               float ry = (float)(method0625(p.field0757, p.field0002, partialTick) - camera.field_1351);
               float rz = (float)(method0625(p.field1241, p.field1409, partialTick) - camera.field_1350);
               float s = p.field1704 * (0.7F + 0.3F * life);
               float t = s * 0.3F;
               float dx = (float)(p.field0565 - camera.field_1352);
               float dz = (float)(p.field1409 - camera.field_1350);
               double dist = Math.sqrt((double)(dx * dx + dz * dz));
               float rightX;
               float rightZ;
               if (dist > 0.0010000000441768861) {
                  rightX = (float)((double)(-dz) / dist);
                  rightZ = (float)((double)dx / dist);
               } else {
                  rightX = 1.0F;
                  rightZ = 0.0F;
               }

               quadsPhase1.method_22918(matrix, rx - rightX * t, ry - s, rz - rightZ * t).method_39415(color);
               quadsPhase1.method_22918(matrix, rx + rightX * t, ry - s, rz + rightZ * t).method_39415(color);
               quadsPhase1.method_22918(matrix, rx + rightX * t, ry + s, rz + rightZ * t).method_39415(color);
               quadsPhase1.method_22918(matrix, rx - rightX * t, ry + s, rz - rightZ * t).method_39415(color);
               float hLen = s * 0.75F;
               quadsPhase1.method_22918(matrix, rx - rightX * hLen, ry - t, rz - rightZ * hLen).method_39415(color);
               quadsPhase1.method_22918(matrix, rx + rightX * hLen, ry - t, rz + rightZ * hLen).method_39415(color);
               quadsPhase1.method_22918(matrix, rx + rightX * hLen, ry + t, rz + rightZ * hLen).method_39415(color);
               quadsPhase1.method_22918(matrix, rx - rightX * hLen, ry + t, rz - rightZ * hLen).method_39415(color);
               hasCrosses = true;
            }
         }

         if (hasCrosses) {
            class_286.method_43433(quadsPhase1.method_60800());
         }

         RenderSystem.enableCull();
         RenderSystem.setShaderTexture(0, field0160);
         RenderSystem.setShader(class_10142.field_53880);
         class_287 quads = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
         boolean hasQuads = false;

         for(IndicatorState p : this.field0488) {
            float life = 1.0F - (float)p.field1615 / (float)p.field1539;
            if (!(life <= 0.0F)) {
               float alpha = life < 0.4F ? life / 0.4F : 1.0F;
               int a = (int)(alpha * 50.0F);
               int color = a << 24 | 16711680 | '휀' | 0;
               float rx = (float)(method0625(p.field0956, p.field0565, partialTick) - camera.field_1352);
               float ry = (float)(method0625(p.field0757, p.field0002, partialTick) - camera.field_1351);
               float rz = (float)(method0625(p.field1241, p.field1409, partialTick) - camera.field_1350);
               float glowSize = p.field1704 * 3.0F * (0.5F + 0.5F * life);
               float dx = (float)(p.field0565 - camera.field_1352);
               float dz = (float)(p.field1409 - camera.field_1350);
               double dist = Math.sqrt((double)(dx * dx + dz * dz));
               float rightX;
               float rightZ;
               if (dist > 0.0010000000441768861) {
                  rightX = (float)((double)(-dz) / dist);
                  rightZ = (float)((double)dx / dist);
               } else {
                  rightX = 1.0F;
                  rightZ = 0.0F;
               }

               quads.method_22918(matrix, rx - rightX * glowSize, ry - glowSize, rz - rightZ * glowSize).method_22913(0.0F, 0.0F).method_39415(color);
               quads.method_22918(matrix, rx + rightX * glowSize, ry - glowSize, rz + rightZ * glowSize).method_22913(1.0F, 0.0F).method_39415(color);
               quads.method_22918(matrix, rx + rightX * glowSize, ry + glowSize, rz + rightZ * glowSize).method_22913(1.0F, 1.0F).method_39415(color);
               quads.method_22918(matrix, rx - rightX * glowSize, ry + glowSize, rz - rightZ * glowSize).method_22913(0.0F, 1.0F).method_39415(color);
               hasQuads = true;
            }
         }

         if (hasQuads) {
            class_286.method_43433(quads.method_60800());
         }

         RenderSystem.setShaderTexture(0, 0);
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         RenderSystem.blendFunc(770, 771);
      }
   }

   private static double method0625(double a, double b, float t) {
      return a + (b - a) * (double)t;
   }

   private static class IndicatorState {
      double field0565;
      double field0002;
      double field1409;
      double field0956;
      double field0757;
      double field1241;
      double field0313;
      double field0176;
      double field0457;
      int field1615;
      int field1539;
      float field1704;
      float field1136;

      IndicatorState(double x, double y, double z, double vx, double vy, double vz, int maxAge, float size, float rotation) {
         this.field0565 = x;
         this.field0002 = y;
         this.field1409 = z;
         this.field0956 = x;
         this.field0757 = y;
         this.field1241 = z;
         this.field0313 = vx;
         this.field0176 = vy;
         this.field0457 = vz;
         this.field1615 = 0;
         this.field1539 = maxAge;
         this.field1704 = size;
         this.field1136 = rotation;
      }
   }
}
