package aethereal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import lombok.Generated;

public class AnimatedValue<T> {
   private final List<ValueState<T>> field0719 = new ArrayList();

   public void method0862(ValueState<T> req) {
      this.field0719.removeIf((r) -> r.field1469 == req.field1469);
      this.field0719.add(req);
      this.field0719.sort(Comparator.comparingInt(ValueState::method2048).reversed());
   }

   public T method0555() {
      return (T)(this.field0719.isEmpty() ? null : ((ValueState)this.field0719.get(0)).field1029);
   }

   public ValueState<T> method0011() {
      return this.field0719.isEmpty() ? null : (ValueState)this.field0719.get(0);
   }

   public void method2078() {
      this.field0719.forEach(ValueState::method0578);
      this.field0719.removeIf((r) -> r.field0567 <= 0);
   }

   public static class ValueState<T> {
      private int field0567;
      private final int field0004;
      private final Module field1469;
      private final T field1029;

      public void method0578() {
         --this.field0567;
      }

      @Generated
      public int method0003() {
         return this.field0567;
      }

      @Generated
      public int method2048() {
         return this.field0004;
      }

      @Generated
      public Module method1782() {
         return this.field1469;
      }

      @Generated
      public T method1618() {
         return this.field1029;
      }

      @Generated
      public ValueState(int ttl, int priority, Module owner, T value) {
         this.field0567 = ttl;
         this.field0004 = priority;
         this.field1469 = owner;
         this.field1029 = value;
      }
   }
}
