package aethereal;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class FullBright extends Module {
   private final EnumSetting<Mode> field0058;

   public FullBright() {
      super("FullBright", ModuleCategory.field1004, "Maksimal yorug'lik, qorong'ilikni olib tashlaydi");
      this.field0058 = (EnumSetting)(new EnumSetting("fullbright.mode", FullBright.Mode.field0062)).method1007("Rejim").method0210("Yorug'likni oshirish usuli").method2130("Yorug'lik oshirish usuli");
      this.method1013("Yorug'likni oshirish uchun sveta qo'yadi");
   }

   public void method2078() {
      super.method2078();
      if (field0796.field_1724 != null) {
         field0796.field_1724.method_6016(class_1294.field_5925);
      }

   }

   @EventHandler
   public void onTick(ClientTickEvent var1) {
      if (!method1974()) {
         if (this.field0058.method0492() == FullBright.Mode.field0062) {
            field0796.field_1724.method_6092(new class_1293(class_1294.field_5925, Integer.MAX_VALUE, 0, false, false));
         } else if (field0796.field_1724.method_6059(class_1294.field_5925)) {
            class_1293 var2 = field0796.field_1724.method_6112(class_1294.field_5925);
            if (var2 != null && var2.method_5584() == Integer.MAX_VALUE && !var2.method_5581()) {
               field0796.field_1724.method_6016(class_1294.field_5925);
            }
         }
      }

   }

   public boolean method1736() {
      return this.field0058.method0492() == FullBright.Mode.field0629;
   }

   public static enum Mode implements DisplayNamed {
      field0629("Gamma"),
      field0062("NightVision");

      private final String field1504;

      private Mode(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0629, field0062};
      }
   }
}
