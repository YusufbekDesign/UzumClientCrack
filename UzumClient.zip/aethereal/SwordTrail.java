package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1743;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1829;

public class SwordTrail extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("swordtrail.onlymainhand", true)).method1007("Only Main Hand").method0210("Effects only on the main hand").method2130("Эффекты только на главной руке");
   private final EnumSetting<ItemFilter> field1448;
   private final BooleanSetting field0970;
   private final FloatSetting field0190;
   private final FloatSetting field0470;
   private final FloatSetting field1627;
   private final FloatSetting field1553;
   private final FloatSetting field1716;
   private final BooleanSetting field1141;
   private final BooleanSetting field1093;
   private final ColorSetting field1203;
   private final BooleanSetting field0875;
   private final FloatSetting field0836;
   private final BooleanSetting field0914;
   private final FloatSetting field1341;
   private final FloatSetting field1302;
   private final ColorSetting field1374;
   private final ColorSetting field0391;
   private final EnumSetting<GradientMode> field0359;
   private final EnumSetting<FadeMode> field0429;
   private final BooleanSetting field0259;
   private final FloatSetting field0234;
   private final FloatSetting field0295;
   private final ColorSetting field0527;
   private final FloatSetting field0506;
   private final FloatSetting field0552;
   private final FloatSetting field1676;
   private final BooleanSetting field1659;
   private final SwordTrailBuffer field1694;
   private final SwordTrailGlow field1594;
   private final List<SwordTrailAnimation> field1585;
   private float field1601;
   private boolean field1762;
   private int field1740;

   public SwordTrail() {
      super("SwordTrail", ModuleCategory.field1004, "Arc, afterimage and particle trails for swings");
      this.field1448 = (EnumSetting)(new EnumSetting("swordtrail.itemfilter", SwordTrail.ItemFilter.field0118)).method1007("Item Filter").method0210("Which held items trigger effects").method2130("Какие предметы активируют эффекты");
      this.field0970 = (BooleanSetting)(new BooleanSetting("swordtrail.mesh", false)).method1007("Mesh Afterimage").method0210("3D ghost copies of the hand/item along the swing").method2130("3D-призраки руки/предмета вдоль взмаха");
      BooleanSetting var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field0190 = (FloatSetting)(new FloatSetting("swordtrail.mesh.interval", 2.0F, 1.0F, 10.0F, 1.0F, var10008::method0492)).method1007("Spawn Interval").method0210("Ticks between ghost spawns while swinging").method2130("Тиков между появлениями призраков во время удара");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field0470 = (FloatSetting)(new FloatSetting("swordtrail.mesh.lifetime", 20.0F, 5.0F, 60.0F, 1.0F, var10008::method0492)).method1007("Lifetime").method0210("How long each ghost lives (ticks) before disappearing").method2130("Сколько тиков живёт каждый призрак до исчезновения");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1627 = (FloatSetting)(new FloatSetting("swordtrail.mesh.fadein", 0.25F, 0.0F, 0.5F, 0.05F, var10008::method0492)).method1007("Fade In Ratio").method0210("Fraction of lifetime used to fade in (appear)").method2130("Доля жизни на проявление");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1553 = (FloatSetting)(new FloatSetting("swordtrail.mesh.fadeout", 0.4F, 0.0F, 0.9F, 0.05F, var10008::method0492)).method1007("Fade Out Ratio").method0210("Fraction of lifetime used to fade out (disappear)").method2130("Доля жизни на исчезновение");
      var10008 = this.field0970;
      Objects.requireNonNull(var10008);
      this.field1716 = (FloatSetting)(new FloatSetting("swordtrail.mesh.opacity", 0.5F, 0.1F, 1.0F, 0.05F, var10008::method0492)).method1007("Mesh Opacity").method0210("Peak brightness of a ghost at its midlife").method2130("Пиковая яркость призрака в середине жизни");
      Boolean var10004 = false;
      BooleanSetting var10005 = this.field0970;
      Objects.requireNonNull(var10005);
      this.field1141 = (BooleanSetting)(new BooleanSetting("swordtrail.mesh.perghost", var10004, var10005::method0492)).method1007("Per-Ghost Shader Pass").method0210("Run Shaders effect independently per ghost (more expensive)").method2130("Запускать Shaders-эффект отдельно на каждого призрака (дороже)");
      var10004 = false;
      var10005 = this.field0970;
      Objects.requireNonNull(var10005);
      this.field1093 = (BooleanSetting)(new BooleanSetting("swordtrail.mesh.tint", var10004, var10005::method0492)).method1007("Mesh Tint Enabled").method0210("Overlay tint color on ghosts").method2130("Накладывать цвет поверх призраков");
      this.field1203 = (ColorSetting)(new ColorSetting("swordtrail.mesh.tintcolor", 255, 150, 255, 128, () -> (Boolean)this.field0970.method0492() && (Boolean)this.field1093.method0492())).method1007("Mesh Tint Color").method0210("Tint color for ghosts").method2130("Цвет наложения на призраков");
      var10004 = false;
      var10005 = this.field0970;
      Objects.requireNonNull(var10005);
      this.field0875 = (BooleanSetting)(new BooleanSetting("swordtrail.mesh.pulse", var10004, var10005::method0492)).method1007("Alpha Pulse").method0210("Each ghost fades in and out over time (phase-shifted across ghosts)").method2130("Каждый призрак появляется и исчезает по времени (с фазовым сдвигом)");
      this.field0836 = (FloatSetting)(new FloatSetting("swordtrail.mesh.pulsespeed", 2.0F, 0.3F, 6.0F, 0.1F, () -> (Boolean)this.field0970.method0492() && (Boolean)this.field0875.method0492())).method1007("Pulse Speed").method0210("Pulsation frequency (Hz)").method2130("Частота пульсации (Гц)");
      this.field0914 = (BooleanSetting)(new BooleanSetting("swordtrail.arc", false)).method1007("Arc Trail").method0210("Glowing ribbon along the tip trajectory").method2130("Светящаяся лента вдоль траектории кончика");
      var10008 = this.field0914;
      Objects.requireNonNull(var10008);
      this.field1341 = (FloatSetting)(new FloatSetting("swordtrail.arc.length", 20.0F, 5.0F, 40.0F, 1.0F, var10008::method0492)).method1007("Arc Length").method0210("Segments of trajectory to render").method2130("Сегментов траектории для рендера");
      var10008 = this.field0914;
      Objects.requireNonNull(var10008);
      this.field1302 = (FloatSetting)(new FloatSetting("swordtrail.arc.width", 0.15F, 0.05F, 0.5F, 0.01F, var10008::method0492)).method1007("Arc Width").method0210("Ribbon width in blocks").method2130("Ширина ленты в блоках");
      var10008 = this.field0914;
      Objects.requireNonNull(var10008);
      this.field1374 = (ColorSetting)(new ColorSetting("swordtrail.arc.start", 120, 220, 255, 255, var10008::method0492)).method1007("Arc Start Color").method0210("Color at the tip end of the ribbon").method2130("Цвет у головы ленты");
      var10008 = this.field0914;
      Objects.requireNonNull(var10008);
      this.field0391 = (ColorSetting)(new ColorSetting("swordtrail.arc.end", 120, 220, 255, 0, var10008::method0492)).method1007("Arc End Color").method0210("Color at the tail end of the ribbon").method2130("Цвет у хвоста ленты");
      GradientMode var3 = SwordTrail.GradientMode.field0120;
      var10005 = this.field0914;
      Objects.requireNonNull(var10005);
      this.field0359 = (EnumSetting)(new EnumSetting("swordtrail.arc.gradient", var3, var10005::method0492)).method1007("Arc Gradient Mode").method0210("Color mode").method2130("Режим окраски");
      FadeMode var4 = SwordTrail.FadeMode.field0119;
      var10005 = this.field0914;
      Objects.requireNonNull(var10005);
      this.field0429 = (EnumSetting)(new EnumSetting("swordtrail.arc.fade", var4, var10005::method0492)).method1007("Arc Fade Curve").method0210("Alpha falloff curve along the ribbon").method2130("Кривая затухания прозрачности по ленте");
      this.field0259 = (BooleanSetting)(new BooleanSetting("swordtrail.particle", false)).method1007("Particle Shatter").method0210("Glow particles spawned along the swing with physics").method2130("Светящиеся частицы по траектории удара с физикой");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0234 = (FloatSetting)(new FloatSetting("swordtrail.particle.rate", 5.0F, 1.0F, 20.0F, 1.0F, var10008::method0492)).method1007("Particle Rate").method0210("Particles spawned per tick of swing").method2130("Частиц за тик свинга");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0295 = (FloatSetting)(new FloatSetting("swordtrail.particle.lifetime", 15.0F, 5.0F, 40.0F, 1.0F, var10008::method0492)).method1007("Particle Lifetime").method0210("Ticks before particle dies").method2130("Тиков жизни частицы");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0527 = (ColorSetting)(new ColorSetting("swordtrail.particle.color", 255, 220, 140, 200, var10008::method0492)).method1007("Particle Color").method0210("Particle tint").method2130("Цвет частиц");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0506 = (FloatSetting)(new FloatSetting("swordtrail.particle.size", 0.05F, 0.02F, 0.2F, 0.005F, var10008::method0492)).method1007("Particle Size").method0210("Particle size in blocks").method2130("Размер частиц в блоках");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field0552 = (FloatSetting)(new FloatSetting("swordtrail.particle.spread", 15.0F, 0.0F, 45.0F, 1.0F, var10008::method0492)).method1007("Particle Spread").method0210("Cone half-angle in degrees").method2130("Полу-угол конуса разлёта, градусы");
      var10008 = this.field0259;
      Objects.requireNonNull(var10008);
      this.field1676 = (FloatSetting)(new FloatSetting("swordtrail.particle.gravity", 0.02F, 0.0F, 0.2F, 0.005F, var10008::method0492)).method1007("Particle Gravity").method0210("Downward pull per tick").method2130("Ускорение вниз за тик");
      Boolean var5 = true;
      var10005 = this.field0259;
      Objects.requireNonNull(var10005);
      this.field1659 = (BooleanSetting)(new BooleanSetting("swordtrail.particle.glowtex", var5, var10005::method0492)).method1007("Glow Texture").method0210("Use glow.png as particle sprite").method2130("Использовать glow.png как спрайт частицы");
      this.field1694 = new SwordTrailBuffer();
      this.field1594 = new SwordTrailGlow();
      this.field1585 = new ArrayList();
      this.field1601 = 0.0F;
      this.field1762 = false;
      this.field1740 = 0;
      this.method1013("Эффекты следа при ударе: дуга, призраки и частицы");
   }

   public SwordTrailBuffer method1712() {
      return this.field1694;
   }

   public boolean method1692() {
      return this.field1762;
   }

   public boolean method1755() {
      return (Boolean)this.field0034.method0492();
   }

   public boolean method2030() {
      return this.field0751 && (Boolean)this.field0970.method0492() && this.method2278();
   }

   public float method2001() {
      return (Float)this.field1716.method0492();
   }

   public boolean method2044() {
      return (Boolean)this.field1141.method0492();
   }

   public boolean method0472() {
      return (Boolean)this.field1093.method0492();
   }

   public Color method0453() {
      return this.field1203.method1726();
   }

   public boolean method0480() {
      return this.field0751 && (Boolean)this.field0914.method0492() && this.method2278();
   }

   public int method0400() {
      return ((Float)this.field1341.method0492()).intValue();
   }

   public float method0393() {
      return (Float)this.field1302.method0492();
   }

   public Color method0407() {
      return this.field1374.method1726();
   }

   public Color method0518() {
      return this.field0391.method1726();
   }

   public GradientMode method0514() {
      return (GradientMode)this.field0359.method0492();
   }

   public FadeMode method0525() {
      return (FadeMode)this.field0429.method0492();
   }

   public boolean method2247() {
      return this.field0751 && (Boolean)this.field0259.method0492() && this.method2278();
   }

   public int method2240() {
      return ((Float)this.field0234.method0492()).intValue();
   }

   public int method2248() {
      return ((Float)this.field0295.method0492()).intValue();
   }

   public Color method2205() {
      return this.field0527.method1726();
   }

   public float method2200() {
      return (Float)this.field0506.method0492();
   }

   public float method2209() {
      return (Float)this.field0552.method0492();
   }

   public float method2273() {
      return (Float)this.field1676.method0492();
   }

   public boolean method2272() {
      return (Boolean)this.field1659.method0492();
   }

   public void method0025() {
      super.method0025();
      this.field1694.method0578();
      this.field1585.clear();
      this.field1740 = 0;
      this.field1601 = 0.0F;
      this.field1762 = false;
   }

   public void method2078() {
      super.method2078();
      this.field1694.method0578();
      this.field1594.method0025();
      this.field1585.clear();
   }

   private boolean method1241(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         boolean var10000;
         switch (((ItemFilter)this.field1448.method0492()).ordinal()) {
            case 0 -> var10000 = false;
            case 1 -> var10000 = stack.method_7909() instanceof class_1829;
            case 2 -> var10000 = stack.method_7909() instanceof class_1829 || stack.method_7909() instanceof class_1743 || stack.method_7909() instanceof class_1766;
            case 3 -> var10000 = true;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return this.field1448.method0492() == SwordTrail.ItemFilter.field1018;
      }
   }

   public boolean method2278() {
      if (method1974()) {
         return false;
      } else {
         return !this.field0751 ? false : this.method1241(field0796.field_1724.method_6047());
      }
   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!this.method2278()) {
         this.field1762 = false;
         this.method1896();
      } else {
         float swing = field0796.field_1724.method_6055(1.0F);
         this.field1762 = field0796.field_1724.field_6279 > 0 || swing > 0.001F;
         if (this.field1762) {
            this.field1694.method0827(this.field1694.method1187(field0796.field_1724, 1.0F));
            if ((Boolean)this.field0970.method0492()) {
               int interval = Math.max(1, ((Float)this.field0190.method0492()).intValue());
               if (this.field1740 <= 0) {
                  this.field1585.add(new SwordTrailAnimation(swing, Math.max(2, ((Float)this.field0470.method0492()).intValue())));
                  this.field1740 = interval;
               } else {
                  --this.field1740;
               }
            }
         } else {
            this.field1740 = 0;
         }

         this.method1896();
         if (field0796.field_1687 != null) {
            this.field1694.method0782(field0796.field_1687.method_8510(), 60L);
         }

         this.field1594.method0578();
         this.field1601 = swing;
      }
   }

   private void method1896() {
      Iterator<SwordTrailAnimation> it = this.field1585.iterator();

      while(it.hasNext()) {
         SwordTrailAnimation g = (SwordTrailAnimation)it.next();
         ++g.field0004;
         if (g.method0579()) {
            it.remove();
         }
      }

   }

   public List<SwordTrailAnimation> method1924() {
      return this.field1585;
   }

   public float method1919() {
      return (Float)this.field1627.method0492();
   }

   public float method1925() {
      return (Float)this.field1553.method0492();
   }

   @EventHandler
   public void onRenderWorld(GlowRenderEvent event) {
      if (this.method2278()) {
         SwordTrailTransform.method1452(event.method1808());
         this.field1594.method0665(event.method1603());
      }
   }

   public static enum ItemFilter implements DisplayNamed {
      field0694("None"),
      field0118("Swords Only"),
      field1489("Tools"),
      field1018("Any");

      private final String field0791;

      private ItemFilter(String n) {
         this.field0791 = n;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static ItemFilter[] method0089() {
         return new ItemFilter[]{field0694, field0118, field1489, field1018};
      }
   }

   public static enum FadeMode implements DisplayNamed {
      field0695("Linear"),
      field0119("EaseOut");

      private final String field1504;

      private FadeMode(String n) {
         this.field1504 = n;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static FadeMode[] method0090() {
         return new FadeMode[]{field0695, field0119};
      }
   }

   public static enum GradientMode implements DisplayNamed {
      field0696("Solid"),
      field0120("Gradient"),
      field1490("Rainbow");

      private final String field1030;

      private GradientMode(String n) {
         this.field1030 = n;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static GradientMode[] method0091() {
         return new GradientMode[]{field0696, field0120, field1490};
      }
   }
}
