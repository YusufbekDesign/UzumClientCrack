package aethereal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class BindCommand extends Command {
   private static final Map<String, Integer> KEY_MAP = new HashMap();

   public BindCommand() {
      super("bind", "Set module keybinds", "b");
      this.method1013("Modul kalb bog'lanishlarini o'rnatish");
   }

   public void method0800(CommandContext var1) {
      String[] var2 = var1.method1814();
      if (var2.length == 0) {
         this.method1834(var1);
      } else if (var2[0].equalsIgnoreCase("list")) {
         this.method0167(var1);
      } else if (var2.length < 2) {
         var1.method0213("Ishlatish: .bind <module> <key>");
      } else {
         String var3 = var2[0].toLowerCase();
         Module var4 = this.method0201(var3);
         if (var4 == null) {
            var1.method0213("Modul topilmadi: " + var2[0]);
         } else {
            String var5 = var2[1].toLowerCase();
            if (!var5.equals("clear") && !var5.equals("none") && !var5.equals("reset")) {
               int var6 = this.method0282(var5);
               if (var6 == -1) {
                  var1.method0213("Noma'lum kalit: " + var2[1]);
                  var1.method2134("Ishlatish: a-z, 0-9, f1-f25, shift, ctrl, alt, space, va h.k.");
               } else {
                  boolean var7 = var5.startsWith("mouse") || var5.startsWith("m");
                  if (var7) {
                     try {
                        var6 = Integer.parseInt(var5.replaceAll("[^0-9]", "")) - 1;
                     } catch (NumberFormatException var9) {
                        var1.method0213("Noto'g'ri sichqoncha tugmasi: " + var2[1]);
                        return;
                     }
                  }

                  var4.method0881(new KeyBind(var6, var7));
                  ArbuzClient.method2004().method2216().method1634();
                  String var10001 = var4.method0423();
                  var1.method1013(var10001 + " bog'landi " + var4.method2259().toString());
               }
            } else {
               var4.method0881(new KeyBind(-1, false));
               ArbuzClient.method2004().method2216().method1634();
               var1.method1013(var4.method0423() + " bog'lanish tozalandi");
            }
         }
      }
   }

   private Module method0201(String var1) {
      String var2 = var1.toLowerCase().replace(" ", "");

      for(Module var4 : ArbuzClient.method2004().method1783().method0019()) {
         if (var4.method0423().toLowerCase().replace(" ", "").equals(var2)) {
            return var4;
         }
      }

      for(Module var4 : ArbuzClient.method2004().method1783().method0019()) {
         if (var4.method0423().toLowerCase().replace(" ", "").contains(var2)) {
            return var4;
         }
      }

      return null;
   }

   private void method0167(CommandContext var1) {
      List<Module> var2 = (List)ArbuzClient.method2004().method1783().method0019().stream().filter((var3) -> var3.method2259() != null && var3.method2259().method2048() != -1).collect(Collectors.toList());
      if (var2.isEmpty()) {
         var1.method2134("Kalit bog'lanishlari o'rnatilmagan");
      } else {
         var1.method2134("Kalit bog'lanishlari:");
         var2.forEach((var3) -> {
            String var10001 = var3.method0423();
            var1.method1846("  " + var10001 + " -> " + var3.method2259().toString());
         });
      }

   }

   private int method0282(String var1) {
      String var2 = var1.toLowerCase();
      if (KEY_MAP.isEmpty()) {
         this.method0383();
      }

      Integer var3 = (Integer)KEY_MAP.get(var2);
      if (var3 != null) {
         return var3;
      } else if (var2.length() == 1) {
         char var4 = var2.charAt(0);
         return var4 >= 'a' && var4 <= 'z' ? var4 - 32 : var4;
      } else {
         return -1;
      }
   }

   private void method0383() {
      KEY_MAP.put("space", 32);
      KEY_MAP.put("esc", 256);
      KEY_MAP.put("escape", 256);
      KEY_MAP.put("enter", 257);
      KEY_MAP.put("return", 257);
      KEY_MAP.put("tab", 258);
      KEY_MAP.put("backspace", 259);
      KEY_MAP.put("bspc", 259);
      KEY_MAP.put("insert", 260);
      KEY_MAP.put("ins", 260);
      KEY_MAP.put("delete", 261);
      KEY_MAP.put("del", 261);
      KEY_MAP.put("right", 262);
      KEY_MAP.put("left", 263);
      KEY_MAP.put("down", 264);
      KEY_MAP.put("up", 265);
      KEY_MAP.put("pageup", 266);
      KEY_MAP.put("pgup", 266);
      KEY_MAP.put("pagedown", 267);
      KEY_MAP.put("pgdn", 267);
      KEY_MAP.put("home", 268);
      KEY_MAP.put("end", 269);
      KEY_MAP.put("capslock", 280);
      KEY_MAP.put("caps", 280);
      KEY_MAP.put("scrolllock", 281);
      KEY_MAP.put("scrlk", 281);
      KEY_MAP.put("numlock", 282);
      KEY_MAP.put("numlk", 282);
      KEY_MAP.put("printscreen", 283);
      KEY_MAP.put("prtsc", 283);
      KEY_MAP.put("f1", 290);
      KEY_MAP.put("f2", 291);
      KEY_MAP.put("f3", 292);
      KEY_MAP.put("f4", 293);
      KEY_MAP.put("f5", 294);
      KEY_MAP.put("f6", 295);
      KEY_MAP.put("f7", 296);
      KEY_MAP.put("f8", 297);
      KEY_MAP.put("f9", 298);
      KEY_MAP.put("f10", 299);
      KEY_MAP.put("f11", 300);
      KEY_MAP.put("f12", 301);
      KEY_MAP.put("f13", 302);
      KEY_MAP.put("f14", 303);
      KEY_MAP.put("f15", 304);
      KEY_MAP.put("f16", 305);
      KEY_MAP.put("f17", 306);
      KEY_MAP.put("f18", 307);
      KEY_MAP.put("f19", 308);
      KEY_MAP.put("f20", 309);
      KEY_MAP.put("f21", 310);
      KEY_MAP.put("f22", 311);
      KEY_MAP.put("f23", 312);
      KEY_MAP.put("f24", 313);
      KEY_MAP.put("f25", 314);
      KEY_MAP.put("lshift", 340);
      KEY_MAP.put("shift", 340);
      KEY_MAP.put("lctrl", 341);
      KEY_MAP.put("ctrl", 341);
      KEY_MAP.put("lalt", 342);
      KEY_MAP.put("alt", 342);
      KEY_MAP.put("lwin", 343);
      KEY_MAP.put("win", 343);
      KEY_MAP.put("rshift", 344);
      KEY_MAP.put("rctrl", 345);
      KEY_MAP.put("ralt", 346);
      KEY_MAP.put("rwin", 347);
      KEY_MAP.put("np0", 320);
      KEY_MAP.put("np1", 321);
      KEY_MAP.put("np2", 322);
      KEY_MAP.put("np3", 323);
      KEY_MAP.put("np4", 324);
      KEY_MAP.put("np5", 325);
      KEY_MAP.put("np6", 326);
      KEY_MAP.put("np7", 327);
      KEY_MAP.put("np8", 328);
      KEY_MAP.put("np9", 329);
      KEY_MAP.put("np.", 330);
      KEY_MAP.put("np/", 331);
      KEY_MAP.put("np*", 332);
      KEY_MAP.put("np-", 333);
      KEY_MAP.put("np+", 334);
      KEY_MAP.put("npenter", 335);
      KEY_MAP.put("np=", 336);
   }

   public List<String> method1593(String[] var1) {
      if (var1.length == 0) {
         List<String> var2 = (List)ArbuzClient.method2004().method1783().method0019().stream().map(Module::method0423).collect(Collectors.toList());
         var2.add("list");
         return var2;
      } else if (var1.length == 1) {
         List<String> var2 = (List)ArbuzClient.method2004().method1783().method0019().stream().map(Module::method0423).collect(Collectors.toList());
         var2.add("list");
         return (List)var2.stream().filter((var3) -> var3.toLowerCase().startsWith(var1[0].toLowerCase())).collect(Collectors.toList());
      } else {
         return var1.length == 2 ? (List)List.of("clear", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "shift", "ctrl", "alt", "space", "tab", "enter", "esc").stream().filter((var2x) -> var2x.startsWith(var1[1].toLowerCase())).collect(Collectors.toList()) : List.of();
      }
   }

   public Map<String, String> method0351(String[] var1) {
      return var1.length <= 1 ? Map.of("list", "Barcha kalit bog'lanishlarini ro'yxatga olish", "<module> <key>", "Modul uchun bog'lanishni o'rnatish", "<module> clear", "Moduldan bog'lanishni o'chirish") : Map.of();
   }

   public String method2179(String[] var1) {
      if (var1.length == 1) {
         return "<module>";
      } else {
         return var1.length == 2 ? "<key>/clear" : "";
      }
   }

   private void method1834(CommandContext var1) {
      var1.method2134(".bind <module> <key> - Bog'lanishni o'rnatish");
      var1.method2134(".bind <module> clear - Bog'lanishni o'chirish");
      var1.method2134(".bind list - Barcha bog'lanishlarni ro'yxatga olish");
      var1.method2134("Misol: .bind killaura k");
      var1.method2134("Misol: .bind speed shift");
      var1.method2134("Misol: .bind esp clear");
   }
}
