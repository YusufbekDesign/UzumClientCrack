package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_9960;
import org.patch.arbuzhack.api.mixins.accessors.GameRendererAccessor;
import org.patch.arbuzhack.api.mixins.accessors.PostEffectProcessorAccessor;

public class PanoramaHatRenderer implements MinecraftAccess {
   private class_276 field0737;
   private boolean field0169 = false;
   private float field1410 = 0.3F;
   private float field0957 = 2.0F;

   private void method0578() {
      if (!this.field0169 && field0796.method_22683() != null) {
         this.field0737 = new class_6367(field0796.method_22683().method_4489(), field0796.method_22683().method_4506(), true);
         this.field0169 = true;
      }

   }

   public void method0738(int width, int height) {
      this.method0578();
      if (this.field0169) {
         this.field0737.method_1234(width, height);
      }

   }

   public PanoramaHatRenderer method0652(float height) {
      this.field1410 = Math.max(0.0F, Math.min(1.0F, height));
      return this;
   }

   public PanoramaHatRenderer method0117(float strength) {
      this.field0957 = strength;
      return this;
   }

   public void method2098(float opacity) {
      this.method0578();
      if (this.field0169) {
         try {
            class_279 shader = field0796.method_62887().method_62941(class_2960.method_60655("arbuzhack", "hat"), class_9960.field_53902);
            if (shader == null) {
               return;
            }

            List<class_283> passes = ((PostEffectProcessorAccessor)shader).getPasses();
            if (passes == null || passes.isEmpty()) {
               return;
            }

            class_5944 program = ((class_283)passes.getFirst()).method_62922();
            if (program == null) {
               return;
            }

            if (program.method_34582("Time") == null) {
               return;
            }

            program.method_62899("DiffuseSampler", field0796.method_1522().method_30277());
            program.method_34582("PanSpeed").method_1251(opacity);
            program.method_34582("Tilt").method_1251(this.field1410);
            program.method_34582("FOV").method_1251(this.field0957);
            program.method_34582("Time").method_1251((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            RenderSystem.disableBlend();
            shader.method_1258(field0796.method_1522(), ((GameRendererAccessor)field0796.field_1773).getPool());
            field0796.method_1522().method_1235(false);
         } catch (Exception var5) {
         }

      }
   }
}
