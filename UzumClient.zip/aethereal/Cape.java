package aethereal;

import net.minecraft.class_2960;

public final class Cape extends Module {
   private static final class_2960 field0160 = class_2960.method_60655("arbuzhack", "textures/capes/cape1.png");
   private static final class_2960 field1522 = class_2960.method_60655("arbuzhack", "textures/capes/cape2.png");
   private final EnumSetting<CapeType> field0984;

   public Cape() {
      super("Cape", ModuleCategory.field1004, "O'yinchiga maxsus plashchlarni ko'rsatadi");
      this.field0984 = (EnumSetting)(new EnumSetting("cape.type", Cape.CapeType.field0599)).method1007("Tur").method0210("Plashch rejimi").method2130("Plashch turi");
      this.method1013("Mijoz logotipi bilan plashchni ko'rsatadi");
   }

   public class_2960 method1734() {
      if (!this.method2195()) {
         return null;
      } else {
         class_2960 var10000;
         switch (((CapeType)this.field0984.method0492()).ordinal()) {
            case 0 -> var10000 = field0160;
            case 1 -> var10000 = field1522;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   public static enum CapeType implements DisplayNamed {
      field0599("Cape 1"),
      field0035("Cape 2");

      private final String field1504;

      private CapeType(String var3) {
         this.field1504 = var3;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static CapeType[] $values() {
         return new CapeType[]{field0599, field0035};
      }
   }
}
