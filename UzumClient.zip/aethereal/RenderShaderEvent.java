package aethereal;

public class RenderShaderEvent extends CancellableEvent {
   public static class Pre extends CancellableEvent {
   }
}
