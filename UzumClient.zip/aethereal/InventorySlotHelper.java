package aethereal;

import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;
import lombok.Generated;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_4174;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class InventorySlotHelper implements MinecraftAccess {
   public static int method0716(int index) {
      return index >= 0 && index <= 8 ? 36 + index : index;
   }

   public static void method0143(int slotId) {
      if (field0796.field_1724 != null && field0796.field_1761 != null) {
         field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, slotId, 0, class_1713.field_7794, field0796.field_1724);
      }
   }

   public static void method2102(int invIndex) {
      if (field0796.field_1724 != null && field0796.field_1761 != null) {
         field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, method0716(invIndex), 40, class_1713.field_7791, field0796.field_1724);
      }
   }

   public static int method1106(Predicate<class_1799> predicate, int start, int end) {
      if (field0796.field_1724 == null) {
         return -1;
      } else {
         for(int i = end; i >= start; --i) {
            class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
            if (predicate.test(stack)) {
               return i;
            }
         }

         return -1;
      }
   }

   public static int method1225(class_1792 item, int start, int end) {
      return method1106((stack) -> stack.method_7909() == item, start, end);
   }

   public static int method1217(class_1792 item) {
      return method1225(item, 0, 8);
   }

   public static int method0262(class_1792 item) {
      return method1225(item, 0, 35);
   }

   public static int method0531() {
      if (field0796.field_1724 == null) {
         return -1;
      } else {
         Optional<class_1735> found = field0796.field_1724.field_7498.field_7761.stream().filter((slot) -> slot.method_7681() && slot.field_7874 >= 9 && slot.field_7874 <= 44).filter((slot) -> slot.method_7677().method_57824(class_9334.field_50075) != null).max(Comparator.comparingDouble((slot) -> {
            class_4174 food = (class_4174)slot.method_7677().method_57824(class_9334.field_50075);
            return food == null ? (double)0.0F : (double)food.comp_2492();
         }));
         return (Integer)found.map((slot) -> method1826(slot.field_7874)).orElse(-1);
      }
   }

   public static int method1529(class_6880<class_1291> effect) {
      if (field0796.field_1724 == null) {
         return -1;
      } else {
         for(class_1735 slot : field0796.field_1724.field_7498.field_7761) {
            if (slot.method_7681() && slot.field_7874 >= 9 && slot.field_7874 <= 44) {
               class_1799 stack = slot.method_7677();
               if (stack.method_7909() == class_1802.field_8574 || stack.method_7909() == class_1802.field_8436 || stack.method_7909() == class_1802.field_8150) {
                  class_1844 component = (class_1844)stack.method_57824(class_9334.field_49651);
                  if (component != null && !component.comp_2378().isEmpty()) {
                     boolean hasEffect = ((class_1842)((class_6880)component.comp_2378().get()).comp_349()).method_8049().stream().anyMatch((instance) -> instance.method_5579().equals(effect));
                     if (hasEffect) {
                        return method1826(slot.field_7874);
                     }
                  }
               }
            }
         }

         return -1;
      }
   }

   public static int method1826(int slotId) {
      return slotId >= 36 && slotId <= 44 ? slotId - 36 : slotId;
   }

   public static class_1268 method1118(class_1268 hand) {
      return hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
   }

   @Generated
   private InventorySlotHelper() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
