package aethereal;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_640;
import net.minecraft.class_7439;

public class AutoDuel extends Module {
   private final Pattern field0145 = Pattern.compile("^\\w{3,16}$");
   private final EnumSetting<Mode> field1448;
   private final FloatSetting field0985;
   private final BooleanSetting field0184;
   private final TextSetting field0483;
   private final List<String> field1644;
   private final IntervalTimer field1559;
   private final IntervalTimer field1719;
   private final IntervalTimer field1149;
   private final IntervalTimer field1101;
   private double field1195;
   private double field0870;
   private double field0825;

   public AutoDuel() {
      super("AutoDuel", ModuleCategory.field0776, "Automatically sends duel requests to nearby players");
      this.field1448 = (EnumSetting)(new EnumSetting("autoduel.mode", AutoDuel.Mode.field0589)).method1007("Mode").method0210("Duel set to pick from the in-game menu").method2130("Набор поединка");
      this.field0985 = (FloatSetting)(new FloatSetting("autoduel.delay", 500.0F, 300.0F, 1000.0F, 100.0F)).method1007("Send Delay").method0210("Delay").method2130("Задержка");
      this.field0184 = (BooleanSetting)(new BooleanSetting("autoduel.money", false)).method1007("For Money").method0210("Attach a wager to each duel request").method2130("Играть на деньги");
      BooleanSetting var10005 = this.field0184;
      Objects.requireNonNull(var10005);
      this.field0483 = (TextSetting)(new TextSetting("autoduel.moneyamount", "10000", var10005::method0492, true)).method1007("Money").method0210("Coin amount for the wager").method2130("Сумма монет для ставки");
      this.field1644 = Lists.newArrayList();
      this.field1559 = new IntervalTimer();
      this.field1719 = new IntervalTimer();
      this.field1149 = new IntervalTimer();
      this.field1101 = new IntervalTimer();
      this.method1013("Автоматически отправляет запросы на дуэль игрокам");
   }

   public void method0025() {
      super.method0025();
      this.field1644.clear();
      this.field1559.method0578();
      this.field1719.method0578();
      this.field1149.method0578();
      this.field1101.method0578();
      if (field0796.field_1724 != null) {
         this.field1195 = field0796.field_1724.method_23317();
         this.field0870 = field0796.field_1724.method_23318();
         this.field0825 = field0796.field_1724.method_23321();
      }

   }

   @EventHandler
   public void onTick(PreTickEvent event) {
      if (!method1974()) {
         double dx = this.field1195 - field0796.field_1724.method_23317();
         double dy = this.field0870 - field0796.field_1724.method_23318();
         double dz = this.field0825 - field0796.field_1724.method_23321();
         if (Math.sqrt(dx * dx + dy * dy + dz * dz) > (double)500.0F) {
            this.method1812();
         } else {
            this.field1195 = field0796.field_1724.method_23317();
            this.field0870 = field0796.field_1724.method_23318();
            this.field0825 = field0796.field_1724.method_23321();
            List<String> players = this.method1729();
            if (this.field1719.method0612((double)800.0F * (double)Math.max(1, players.size()))) {
               this.field1644.clear();
               this.field1719.method0578();
            }

            String selfName = field0796.field_1724.method_7334().getName();

            for(String player : players) {
               if (!this.field1644.contains(player) && !player.equals(selfName)) {
                  if (!this.field1559.method0612(((Float)this.field0985.method0492()).doubleValue())) {
                     break;
                  }

                  String command = (Boolean)this.field0184.method0492() ? "duel " + player + " " + (String)this.field0483.method0492() : "duel " + player;
                  field0796.field_1724.field_3944.method_45730(command);
                  this.field1644.add(player);
                  this.field1559.method0578();
               }
            }

            if (field0796.field_1755 != null && field0796.field_1724.field_7512 != null) {
               class_1703 handler = field0796.field_1724.field_7512;
               String title = field0796.field_1755.method_25440().getString();
               if (title.contains("Выбор набора (1/1)")) {
                  if (this.field1149.method0612((double)150.0F)) {
                     int slotId = ((Mode)this.field1448.method0492()).method0003();
                     if (slotId >= 0) {
                        field0796.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7794, field0796.field_1724);
                     }

                     this.field1149.method0578();
                  }
               } else if (title.contains("Настройка поединка") && this.field1101.method0612((double)150.0F)) {
                  field0796.field_1761.method_2906(handler.field_7763, 0, 0, class_1713.field_7794, field0796.field_1724);
                  this.field1101.method0578();
               }
            }

         }
      }
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound event) {
      if (!method1974()) {
         class_2596 var3 = event.method1970();
         if (var3 instanceof class_7439) {
            class_7439 chat = (class_7439)var3;
            String text = chat.comp_763().getString().toLowerCase();
            if (text.contains("начало") && text.contains("через") && text.contains("секунд!") || text.contains("во время поединка запрещено использовать команды")) {
               this.method1812();
            }

         }
      }
   }

   private List<String> method1729() {
      return (List)field0796.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::getName).filter((n) -> this.field0145.matcher(n).matches()).collect(Collectors.toList());
   }

   public static enum Mode implements DisplayNamed {
      field0589("Шары", 5),
      field0024("Щит", 0),
      field1427("Шипы 3", 1),
      field0966("Незеритка", 8),
      field0764("Читерский рай", 7),
      field1249("Лук", 2),
      field0319("Классик", 6),
      field0182("Тотемы", 3),
      field0463("Нодебафф", 4);

      private final String field1643;
      private final int field1539;

      private Mode(String name, int slot) {
         this.field1643 = name;
         this.field1539 = slot;
      }

      public String method0557() {
         return this.field1643;
      }

      public int method0003() {
         return this.field1539;
      }

      // $FF: synthetic method
      private static Mode[] method2081() {
         return new Mode[]{field0589, field0024, field1427, field0966, field0764, field1249, field0319, field0182, field0463};
      }
   }
}
