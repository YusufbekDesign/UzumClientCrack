package aethereal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4081;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class AutoDodge extends Module {
   private final MultiSelectSetting field0089 = (MultiSelectSetting)(new MultiSelectSetting("autododge.types", new BooleanSetting[]{(BooleanSetting)(new BooleanSetting("autododge.types.debuffs", true)).method1007("Debuffs").method0210("Dodge debuff potions").method2130("Уклоняться от зелий с дебаффами"), (BooleanSetting)(new BooleanSetting("autododge.types.arrows", true)).method1007("Arrows").method0210("Dodge arrows").method2130("Уклоняться от стрел"), (BooleanSetting)(new BooleanSetting("autododge.types.tridents", false)).method1007("Tridents").method0210("Dodge tridents").method2130("Уклоняться от трезубцев")})).method1007("Dodge Types").method0210("What projectiles to dodge").method2130("От чего уклоняться");
   private boolean field1527;
   private float field0957;
   private boolean field0219;

   public AutoDodge() {
      super("AutoDodge", ModuleCategory.field0088, "Automatically dodges incoming projectiles");
      this.method1013("Автоматически уклоняется от плохих штучек");
   }

   @EventHandler
   private void onPlayerTick(PlayerTickEvent e) {
      if (!method1974()) {
         this.field1527 = false;
         this.field0219 = false;
         if (this.field0089.method0730(0)) {
            this.method1735();
         }

         if (this.field0089.method0730(1)) {
            this.method0977(class_1667.class);
         }

         if (this.field0089.method0730(2)) {
            this.method0977(class_1685.class);
         }

      }
   }

   @EventHandler
   private void onKeyboard(KeyboardEvent e) {
      if (!method1974() && this.field1527) {
         this.method0885(e);
         if (this.field0219 && field0796.field_1724.method_24828()) {
            e.method0345(true);
         }

      }
   }

   private void method1735() {
      Stream var10000 = StreamSupport.stream(field0796.field_1687.method_18112().spliterator(), false);
      Objects.requireNonNull(class_1686.class);
      var10000 = var10000.filter(class_1686.class::isInstance);
      Objects.requireNonNull(class_1686.class);
      List<class_1686> potions = var10000.map(class_1686.class::cast).filter((p) -> p.method_24921() != field0796.field_1724).filter(this::method1203).toList();
      if (!potions.isEmpty()) {
         for(class_1686 potion : potions) {
            class_243 landing = this.method1145(potion, potion.method_18798());
            float effectRadius = potion.method_7495().method_31574(class_1802.field_8150) ? 4.0F : 5.0F;
            double dist = field0796.field_1724.method_19538().method_1022(landing);
            if (dist <= (double)effectRadius) {
               class_243 playerPos = field0796.field_1724.method_19538();
               class_243 dirToPotion = landing.method_1020(playerPos).method_1029();
               this.field0957 = (float)class_3532.method_15338(Math.toDegrees(Math.atan2(dirToPotion.field_1350, dirToPotion.field_1352)) - (double)90.0F) + 180.0F;
               this.field1527 = true;
               this.field0219 = this.method1692();
               break;
            }
         }

      }
   }

   private <T extends class_1297> void method0977(Class<T> type) {
      if (!this.field1527) {
         Stream var10000 = StreamSupport.stream(field0796.field_1687.method_18112().spliterator(), false);
         Objects.requireNonNull(type);
         var10000 = var10000.filter(type::isInstance);
         Objects.requireNonNull(type);
         List<T> projectiles = var10000.map(type::cast).toList();
         if (!projectiles.isEmpty()) {
            class_243 playerPos = field0796.field_1724.method_19538();
            List<ThreatPath> threats = new ArrayList();
            Iterator var5 = projectiles.iterator();

            while(true) {
               T proj;
               class_1665 pp;
               do {
                  if (!var5.hasNext()) {
                     if (!threats.isEmpty()) {
                        this.field0957 = this.method1321(playerPos, threats);
                        this.field1527 = true;
                        this.field0219 = this.method1692();
                     }

                     return;
                  }

                  proj = (T)(var5.next());
                  if (!(proj instanceof class_1665)) {
                     break;
                  }

                  pp = (class_1665)proj;
               } while(pp.method_24921() == field0796.field_1724);

               if (!(proj.method_18798().method_1027() < 0.010000000583934252)) {
                  class_243 motion = proj.method_18798();
                  class_243 pos = proj.method_19538();

                  for(int i = 0; i < 100; ++i) {
                     class_243 prevPos = pos;
                     pos = pos.method_1019(motion);
                     motion = this.method1322(motion, proj);
                     class_3965 result = field0796.field_1687.method_17742(new class_3959(prevPos, pos, class_3960.field_17558, class_242.field_1348, proj));
                     if (result.method_17783() != class_240.field_1333) {
                        pos = result.method_17784();
                        break;
                     }

                     if (pos.field_1351 <= (double)field0796.field_1687.method_31607()) {
                        break;
                     }

                     class_243 closest = this.method1337(prevPos, pos, playerPos);
                     double distance = playerPos.method_1022(closest);
                     if (distance <= (double)2.0F) {
                        threats.add(new ThreatPath(prevPos, pos, distance));
                        break;
                     }
                  }
               }
            }
         }
      }
   }

   private float method1321(class_243 playerPos, List<ThreatPath> threats) {
      if (threats.size() == 1) {
         ThreatPath t = (ThreatPath)threats.get(0);
         class_243 lineDir = t.end.method_1020(t.start).method_1029();
         class_243 perp = (new class_243(-lineDir.field_1350, (double)0.0F, lineDir.field_1352)).method_1029();
         double leftDist = this.method0293(t.start, t.end, playerPos.method_1019(perp.method_1021((double)1.0F)));
         double rightDist = this.method0293(t.start, t.end, playerPos.method_1020(perp.method_1021((double)1.0F)));
         class_243 chosen = leftDist > rightDist ? perp : perp.method_1021((double)-1.0F);
         return (float)class_3532.method_15338(Math.toDegrees(Math.atan2(chosen.field_1350, chosen.field_1352)) - (double)90.0F);
      } else {
         double bestScore = Double.NEGATIVE_INFINITY;
         float bestYaw = 0.0F;

         for(int angle = 0; angle < 360; angle += 15) {
            double rad = Math.toRadians((double)angle);
            class_243 testPos = playerPos.method_1019((new class_243(Math.cos(rad), (double)0.0F, Math.sin(rad))).method_1021(0.80000015285335));
            double score = (double)0.0F;

            for(ThreatPath t : threats) {
               double d = this.method0293(t.start, t.end, testPos);
               score += d / (t.distance + 0.10000000116491012);
            }

            if (score > bestScore) {
               bestScore = score;
               bestYaw = (float)angle;
            }
         }

         return bestYaw;
      }
   }

   private class_243 method1145(class_1297 entity, class_243 motion) {
      class_243 pos = entity.method_19538();

      for(int i = 0; i < 200; ++i) {
         class_243 prev = pos;
         pos = pos.method_1019(motion);
         motion = this.method1322(motion, entity);
         class_3965 result = field0796.field_1687.method_17742(new class_3959(prev, pos, class_3960.field_17558, class_242.field_1348, entity));
         if (result.method_17783() != class_240.field_1333) {
            return result.method_17784();
         }

         if (pos.field_1351 <= (double)field0796.field_1687.method_31607()) {
            break;
         }
      }

      return pos;
   }

   private class_243 method1322(class_243 motion, class_1297 entity) {
      double drag = entity.method_5799() ? 0.80000015285335 : 0.9900000193145464;
      return motion.method_1021(drag).method_1023((double)0.0F, 0.04999999500158768, (double)0.0F);
   }

   private class_243 method1337(class_243 start, class_243 end, class_243 point) {
      class_243 line = end.method_1020(start);
      double lenSq = line.method_1027();
      if (lenSq == (double)0.0F) {
         return start;
      } else {
         double t = class_3532.method_15350(point.method_1020(start).method_1026(line) / lenSq, (double)0.0F, (double)1.0F);
         return start.method_1019(line.method_1021(t));
      }
   }

   private double method0293(class_243 start, class_243 end, class_243 point) {
      return point.method_1022(this.method1337(start, end, point));
   }

   private boolean method1203(class_1686 potion) {
      class_1799 stack = potion.method_7495();
      if (!stack.method_31574(class_1802.field_8436) && !stack.method_31574(class_1802.field_8150)) {
         return false;
      } else {
         class_1844 contents = (class_1844)stack.method_57824(class_9334.field_49651);
         if (contents == null) {
            return false;
         } else {
            float score = 0.0F;

            for(class_1293 effect : contents.method_57397()) {
               class_4081 cat = ((class_1291)effect.method_5579().comp_349()).method_18792();
               int level = effect.method_5578() + 1;
               if (cat == class_4081.field_18271) {
                  score += (float)level;
               } else if (cat == class_4081.field_18272) {
                  score -= (float)level * (method1124(effect) ? 2.0F : 1.0F);
               }
            }

            return score < 0.0F;
         }
      }
   }

   private static boolean method1124(class_1293 effect) {
      class_1291 type = (class_1291)effect.method_5579().comp_349();
      return type == class_1294.field_5920.comp_349() || type == class_1294.field_5921.comp_349() || type == class_1294.field_5899.comp_349() || type == class_1294.field_5902.comp_349();
   }

   private boolean method1692() {
      if (field0796.field_1724.method_6059(class_1294.field_5904)) {
         int amp = field0796.field_1724.method_6112(class_1294.field_5904).method_5578();
         if (amp < 1) {
            return true;
         }
      }

      if (field0796.field_1724.method_6059(class_1294.field_5909)) {
         int amp = field0796.field_1724.method_6112(class_1294.field_5909).method_5578();
         if (amp > 2) {
            return true;
         }
      }

      return false;
   }

   private void method0885(KeyboardEvent event) {
      float bestForward = 0.0F;
      float bestStrafe = 0.0F;
      float bestDifference = Float.MAX_VALUE;

      for(float forward = -1.0F; forward <= 1.0F; ++forward) {
         for(float strafe = -1.0F; strafe <= 1.0F; ++strafe) {
            if (forward != 0.0F || strafe != 0.0F) {
               float yaw = this.method0681(field0796.field_1724.method_36454(), forward, strafe);
               float difference = Math.abs(class_3532.method_15393(yaw - this.field0957));
               if (difference < bestDifference) {
                  bestDifference = difference;
                  bestForward = forward;
                  bestStrafe = strafe;
               }
            }
         }
      }

      event.method0665(bestForward);
      event.method0124(bestStrafe);
   }

   private float method0681(float yaw, float forward, float strafe) {
      if (forward < 0.0F) {
         yaw += 180.0F;
      }

      float factor = 1.0F;
      if (forward < 0.0F) {
         factor = -0.5F;
      } else if (forward > 0.0F) {
         factor = 0.5F;
      }

      if (strafe > 0.0F) {
         yaw -= 90.0F * factor;
      }

      if (strafe < 0.0F) {
         yaw += 90.0F * factor;
      }

      return class_3532.method_15393(yaw);
   }

   private static record ThreatPath(class_243 start, class_243 end, double distance) {
      public class_243 method0569() {
         return this.start;
      }

      public class_243 method0024() {
         return this.end;
      }

      public double method2046() {
         return this.distance;
      }
   }
}
