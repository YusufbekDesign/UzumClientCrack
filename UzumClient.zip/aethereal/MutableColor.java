package aethereal;

import java.awt.Color;

public class MutableColor extends Color {
   private int field0567;

   public MutableColor() {
      super(0, true);
      this.field0567 = 0;
   }

   public MutableColor(int var1) {
      super(0, true);
      this.field0567 = var1;
   }

   public void method0729(int var1) {
      this.field0567 = var1;
   }

   public void method0749(int var1, int var2, int var3, int var4) {
      this.field0567 = (var4 & 255) << 24 | (var1 & 255) << 16 | (var2 & 255) << 8 | var3 & 255;
   }

   public int getAlpha() {
      return this.field0567 >> 24 & 255;
   }

   public int getRed() {
      return this.field0567 >> 16 & 255;
   }

   public int getGreen() {
      return this.field0567 >> 8 & 255;
   }

   public int getBlue() {
      return this.field0567 & 255;
   }

   public int getRGB() {
      return this.field0567;
   }

   public float[] getRGBComponents(float[] var1) {
      float[] var2 = var1 != null && var1.length >= 4 ? var1 : new float[4];
      var2[0] = (float)this.getRed() / 255.0F;
      var2[1] = (float)this.getGreen() / 255.0F;
      var2[2] = (float)this.getBlue() / 255.0F;
      var2[3] = (float)this.getAlpha() / 255.0F;
      return var2;
   }

   public float[] getComponents(float[] var1) {
      return this.getRGBComponents(var1);
   }
}
