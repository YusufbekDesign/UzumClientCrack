package aethereal;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1779;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2606;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_640;

public class AutoCrystal extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("autocrystal.attack", true)).method1007("Attack").method0210("Auto-attack safe crystals").method2130("Авто-удар по безопасным кристаллам");
   private final FloatSetting field1450 = (FloatSetting)(new FloatSetting("autocrystal.attackspeed", 20.0F, 0.1F, 20.0F, 0.1F)).method1007("Attack Speed").method0210("Crystal attack rate (1..20/s)").method2130("Скорость ударов");
   private final FloatSetting field0985 = (FloatSetting)(new FloatSetting("autocrystal.attackrange", 4.5F, 0.0F, 8.0F, 0.1F)).method1007("Attack Range").method0210("Max attack distance").method2130("Макс. дистанция");
   private final FloatSetting field0190 = (FloatSetting)(new FloatSetting("autocrystal.attackwalls", 4.5F, 0.0F, 8.0F, 0.1F, () -> false)).method1007("Walls Range (Attack)").method0210("Hidden — defaults to attack range").method2130("Скрыто");
   private final EnumSetting<AntiWeaknessMode> field0469;
   private final BooleanSetting field1619;
   private final BooleanSetting field1544;
   private final BooleanSetting field1709;
   private final FloatSetting field1144;
   private final FloatSetting field1097;
   private final FloatSetting field1206;
   private final EnumSetting<PlacementMode> field0880;
   private final BooleanSetting field0830;
   private final EnumSetting<SwitchMode> field0918;
   private final EnumSetting<SequentialMode> field1340;
   private final EnumSetting<RotationMode> field1301;
   private final EnumSetting<SwingMode> field1376;
   private final BooleanSetting field0389;
   private final FloatSetting field0360;
   private final BooleanSetting field0426;
   private final FloatSetting field0262;
   private final FloatSetting field0234;
   private final BooleanSetting field0292;
   private final BooleanSetting field0526;
   private final BooleanSetting field0503;
   private final FloatSetting field0552;
   private final EnumSetting<EatingMode> field1675;
   private final BooleanSetting field1659;
   private final FloatSetting field1693;
   private final FloatSetting field1593;
   private final EnumSetting<GodSwingMode> field1583;
   private final BooleanSetting field1604;
   private final BooleanSetting field1756;
   private final FloatSetting field1744;
   private final EnumSetting<FacePlaceMode> field1768;
   private final EnumSetting<FacePlaceSpeedMode> field1177;
   private final FloatSetting field1167;
   private final BooleanSetting field1188;
   private final FloatSetting field1122;
   private final BooleanSetting field1114;
   private final FloatSetting field1132;
   private final FloatSetting field1230;
   private final FloatSetting field1222;
   private final FloatSetting field1236;
   private final BooleanSetting field0900;
   private final BooleanSetting field0894;
   private final BooleanSetting field0904;
   private final EnumSetting<RenderMode> field0857;
   private final ColorSetting field0849;
   private final ColorSetting field0866;
   private final ExecutorService field0945;
   private Runnable field0935;
   private Runnable field0950;
   private final Map<Integer, Long> field1360;
   private final Map<class_2338, Long> field1354;
   private final Map<class_2338, Long> field1364;
   private final Stopwatch field1321;
   private final Stopwatch field1316;
   private final Stopwatch field1326;
   private final Stopwatch field1398;
   private boolean field1394;
   private boolean field1407;
   private boolean field0415;
   private boolean field0410;
   private class_1657 field0421;
   private class_1511 field0376;
   private RenderState field0373;
   private RenderState field0380;
   private final SelectedSlotTracker field0449;
   private int field0444;
   private int field0453;
   private String field0282;
   private long field0274;
   private long field0285;
   private static final String[] field0249 = new String[]{"entityId", "field_12870"};

   private void method2134(String msg) {
      if ((Boolean)this.field0904.method0492()) {
         if (field0796.field_1705 != null) {
            field0796.field_1705.method_1743().method_1812(class_2561.method_43470("§8[§bAC§8] §7" + msg));
         }
      }
   }

   private void method1045(String tag, String reason) {
      if ((Boolean)this.field0904.method0492()) {
         long now = System.currentTimeMillis();
         String key = tag + ":" + reason;
         if (!key.equals(this.field0282) || now - this.field0274 >= 1000L) {
            this.field0282 = key;
            this.field0274 = now;
            this.method2134(tag + " skip — " + reason);
         }
      }
   }

   public AutoCrystal() {
      super("AutoCrystal", ModuleCategory.field0661, "AutoCrystal port with ReallyWorld rotation");
      this.field0469 = (EnumSetting)(new EnumSetting("autocrystal.antiweakness", AutoCrystal.AntiWeaknessMode.field1418, () -> false)).method1007("Anti Weakness").method0210("Hidden default Silent").method2130("Скрытый дефолт");
      this.field1619 = (BooleanSetting)(new BooleanSetting("autocrystal.instant", true, () -> false)).method1007("Instant").method0210("Hidden default true").method2130("Скрытый дефолт");
      this.field1544 = (BooleanSetting)(new BooleanSetting("autocrystal.inhibit", true, () -> false)).method1007("Inhibit").method0210("Hidden default true").method2130("Скрытый дефолт");
      this.field1709 = (BooleanSetting)(new BooleanSetting("autocrystal.place", true)).method1007("Place").method0210("Auto-place crystals").method2130("Авто-постановка");
      this.field1144 = (FloatSetting)(new FloatSetting("autocrystal.placespeed", 20.0F, 0.1F, 20.0F, 0.1F)).method1007("Place Speed").method0210("Place rate (1..20/s)").method2130("Скорость постановки");
      this.field1097 = (FloatSetting)(new FloatSetting("autocrystal.placerange", 4.5F, 0.0F, 8.0F, 0.1F)).method1007("Place Range").method0210("Max place distance").method2130("Макс. дистанция постановки");
      this.field1206 = (FloatSetting)(new FloatSetting("autocrystal.placewalls", 4.5F, 0.0F, 8.0F, 0.1F, () -> false)).method1007("Walls Range (Place)").method0210("Hidden default").method2130("Скрыто");
      this.field0880 = (EnumSetting)(new EnumSetting("autocrystal.placements", AutoCrystal.PlacementMode.field0586, () -> false)).method1007("Placements").method0210("Hidden default").method2130("Скрыто");
      this.field0830 = (BooleanSetting)(new BooleanSetting("autocrystal.blockdestruction", false, () -> false)).method1007("Block Destruction").method0210("Hidden — needs SpeedMine").method2130("Скрыто");
      this.field0918 = (EnumSetting)(new EnumSetting("autocrystal.switch", AutoCrystal.SwitchMode.field0588)).method1007("Switch").method0210("Auto-switch mode").method2130("Режим переключения");
      this.field1340 = (EnumSetting)(new EnumSetting("autocrystal.sequential", AutoCrystal.SequentialMode.field0583, () -> false)).method1007("Sequential").method0210("Hidden default").method2130("Скрыто");
      this.field1301 = (EnumSetting)(new EnumSetting("autocrystal.rotate", AutoCrystal.RotationMode.field1423)).method1007("Rotate").method0210("Rotation mode").method2130("Режим ротации");
      this.field1376 = (EnumSetting)(new EnumSetting("autocrystal.swing", AutoCrystal.SwingMode.field0582, () -> false)).method1007("Swing").method0210("Hidden default").method2130("Скрыто");
      this.field0389 = (BooleanSetting)(new BooleanSetting("autocrystal.yawstep", false, () -> false)).method1007("Yaw Step").method0210("Hidden default").method2130("Скрыто");
      this.field0360 = (FloatSetting)(new FloatSetting("autocrystal.yawstepthr", 75.0F, 1.0F, 180.0F, 1.0F, () -> false)).method1007("Yaw Step Threshold").method0210("Hidden default").method2130("Скрыто");
      this.field0426 = (BooleanSetting)(new BooleanSetting("autocrystal.raytrace", false, () -> false)).method1007("Raytrace").method0210("Hidden default").method2130("Скрыто");
      this.field0262 = (FloatSetting)(new FloatSetting("autocrystal.extrapolation", 0.0F, 0.0F, 20.0F, 1.0F, () -> false)).method1007("Extrapolation").method0210("Hidden default").method2130("Скрыто");
      this.field0234 = (FloatSetting)(new FloatSetting("autocrystal.enemyrange", 10.0F, 0.0F, 24.0F, 0.5F, () -> false)).method1007("Enemy Range").method0210("Hidden default").method2130("Скрыто");
      this.field0292 = (BooleanSetting)(new BooleanSetting("autocrystal.chestbreak", false, () -> false)).method1007("Chest Break").method0210("Hidden default").method2130("Скрыто");
      this.field0526 = (BooleanSetting)(new BooleanSetting("autocrystal.async", true, () -> false)).method1007("Asynchronous").method0210("Hidden default").method2130("Скрыто");
      this.field0503 = (BooleanSetting)(new BooleanSetting("autocrystal.gameloop", false, () -> false)).method1007("Game Loop").method0210("Hidden default").method2130("Скрыто");
      this.field0552 = (FloatSetting)(new FloatSetting("autocrystal.loopdelay", 50.0F, 0.0F, 1000.0F, 10.0F, () -> false)).method1007("Loop Delay").method0210("Hidden default").method2130("Скрыто");
      this.field1675 = (EnumSetting)(new EnumSetting("autocrystal.whileeating", AutoCrystal.EatingMode.field0962, () -> false)).method1007("While Eating").method0210("Hidden default").method2130("Скрыто");
      this.field1659 = (BooleanSetting)(new BooleanSetting("autocrystal.godsync", false, () -> false)).method1007("God Sync").method0210("Hidden — entity-id prediction").method2130("Скрыто");
      this.field1693 = (FloatSetting)(new FloatSetting("autocrystal.predictions", 10.0F, 1.0F, 20.0F, 1.0F, () -> false)).method1007("Predictions").method0210("Hidden default").method2130("Скрыто");
      this.field1593 = (FloatSetting)(new FloatSetting("autocrystal.offset", 0.0F, 0.0F, 2.0F, 1.0F, () -> false)).method1007("Offset").method0210("Hidden default").method2130("Скрыто");
      this.field1583 = (EnumSetting)(new EnumSetting("autocrystal.godswing", AutoCrystal.GodSwingMode.field0022, () -> false)).method1007("God Swing").method0210("Hidden default").method2130("Скрыто");
      this.field1604 = (BooleanSetting)(new BooleanSetting("autocrystal.fast", false, () -> false)).method1007("Fast").method0210("Hidden default").method2130("Скрыто");
      this.field1756 = (BooleanSetting)(new BooleanSetting("autocrystal.antikick", false, () -> false)).method1007("Anti Kick").method0210("Hidden default").method2130("Скрыто");
      this.field1744 = (FloatSetting)(new FloatSetting("autocrystal.kickthr", 5.0F, 1.0F, 10.0F, 1.0F, () -> false)).method1007("Kick Threshold").method0210("Hidden default").method2130("Скрыто");
      this.field1768 = (EnumSetting)(new EnumSetting("autocrystal.faceplace", AutoCrystal.FacePlaceMode.field0014)).method1007("Faceplace").method0210("Faceplace logic").method2130("Режим фейспласа");
      this.field1177 = (EnumSetting)(new EnumSetting("autocrystal.faceplacespeed", AutoCrystal.FacePlaceSpeedMode.field0580, () -> false)).method1007("Faceplace Speed").method0210("Hidden default").method2130("Скрыто");
      this.field1167 = (FloatSetting)(new FloatSetting("autocrystal.faceplacedelay", 11.0F, 0.0F, 20.0F, 1.0F, () -> false)).method1007("Faceplace Delay").method0210("Hidden default").method2130("Скрыто");
      this.field1188 = (BooleanSetting)(new BooleanSetting("autocrystal.healthplace", true, () -> false)).method1007("Health FP").method0210("Hidden default").method2130("Скрыто");
      this.field1122 = (FloatSetting)(new FloatSetting("autocrystal.health", 8.0F, 0.0F, 36.0F, 0.5F, () -> false)).method1007("Faceplace Health").method0210("Hidden default").method2130("Скрыто");
      this.field1114 = (BooleanSetting)(new BooleanSetting("autocrystal.armorplace", true, () -> false)).method1007("Armor FP").method0210("Hidden default").method2130("Скрыто");
      this.field1132 = (FloatSetting)(new FloatSetting("autocrystal.armorpct", 10.0F, 1.0F, 100.0F, 1.0F, () -> false)).method1007("Armor %").method0210("Hidden default").method2130("Скрыто");
      this.field1230 = (FloatSetting)(new FloatSetting("autocrystal.mindamage", 6.0F, 0.0F, 36.0F, 0.5F)).method1007("Min Damage").method0210("Min damage to enemies").method2130("Мин. урон цели");
      this.field1222 = (FloatSetting)(new FloatSetting("autocrystal.maxselfdamage", 10.0F, 0.0F, 36.0F, 0.5F)).method1007("Max Self Damage").method0210("Max self damage").method2130("Макс. самоурон");
      this.field1236 = (FloatSetting)(new FloatSetting("autocrystal.lethalmult", 1.5F, 0.0F, 4.0F, 0.05F, () -> false)).method1007("Lethal Multiplier").method0210("Hidden default").method2130("Скрыто");
      this.field0900 = (BooleanSetting)(new BooleanSetting("autocrystal.antisuicide", true, () -> false)).method1007("Anti Suicide").method0210("Hidden default").method2130("Скрыто");
      this.field0894 = (BooleanSetting)(new BooleanSetting("autocrystal.ignoreterrain", true, () -> false)).method1007("Ignore Terrain").method0210("Hidden default").method2130("Скрыто");
      this.field0904 = (BooleanSetting)(new BooleanSetting("autocrystal.debug", false)).method1007("Debug").method0210("Print decision trace to chat").method2130("Печатать трассу решений в чат");
      this.field0857 = (EnumSetting)(new EnumSetting("autocrystal.rendermode", AutoCrystal.RenderMode.field0964)).method1007("Render").method0210("Render mode for place position").method2130("Отрисовка позиции");
      this.field0849 = (ColorSetting)(new ColorSetting("autocrystal.fill", 100, 200, 255, 60, () -> false)).method1007("Fill Color").method0210("Hidden").method2130("Скрыто");
      this.field0866 = (ColorSetting)(new ColorSetting("autocrystal.outline", 100, 200, 255, 255, () -> this.field0857.method0492() == AutoCrystal.RenderMode.field1424 || this.field0857.method0492() == AutoCrystal.RenderMode.field0964)).method1007("Outline Color").method0210("Outline color").method2130("Цвет обводки");
      this.field0945 = Executors.newSingleThreadExecutor((r) -> {
         Thread t = new Thread(r, "AutoCrystal-Worker");
         t.setDaemon(true);
         return t;
      });
      this.field0935 = null;
      this.field0950 = null;
      this.field1360 = new ConcurrentHashMap();
      this.field1354 = new ConcurrentHashMap();
      this.field1364 = new ConcurrentHashMap();
      this.field1321 = new Stopwatch();
      this.field1316 = new Stopwatch();
      this.field1326 = new Stopwatch();
      this.field1398 = new Stopwatch();
      this.field1394 = false;
      this.field1407 = true;
      this.field0415 = false;
      this.field0410 = false;
      this.field0421 = null;
      this.field0376 = null;
      this.field0373 = null;
      this.field0380 = null;
      this.field0449 = new SelectedSlotTracker();
      this.field0444 = -100000;
      this.field0453 = 0;
      this.field0282 = "";
      this.field0274 = 0L;
      this.field0285 = 0L;
      this.method1013("AutoCrystal с ротацией ReallyWorld");
   }

   @EventHandler
   public void onPlayerUpdate(PlayerTickEvent e) {
      if (!method1974()) {
         long ping = (long)this.method0462();
         long minTtl = 500L;
         long attackTtl = 30000L;
         long placeTtl = Math.max(minTtl, ping * 2L + (long)((20.0F - (Float)this.field1450.method0492()) * 50.0F));
         this.field1360.entrySet().removeIf((entry) -> System.currentTimeMillis() - (Long)entry.getValue() > attackTtl);
         this.field1354.entrySet().removeIf((entry) -> System.currentTimeMillis() - (Long)entry.getValue() > placeTtl);
         this.field1364.entrySet().removeIf((entry) -> System.currentTimeMillis() - (Long)entry.getValue() > minTtl);
         if ((Boolean)this.field0904.method0492() && System.currentTimeMillis() - this.field0285 > 1000L) {
            this.field0285 = System.currentTimeMillis();
            int enemies = 0;

            try {
               FriendManager fm = ArbuzClient.method2004().method1608();

               for(class_1657 p : field0796.field_1687.method_18456()) {
                  if (p != field0796.field_1724 && p.method_5805() && !(field0796.field_1724.method_5858(p) > class_3532.method_33723(((Float)this.field0234.method0492()).doubleValue())) && (fm == null || !fm.method2135(p.method_5477().getString()))) {
                     ++enemies;
                  }
               }
            } catch (Throwable var14) {
            }

            String pt = this.field0373 != null && this.field0373.field0733 != null ? this.field0373.field0733.method_23854() + " dmg=" + String.format("%.1f", this.field0373.field0758) : "null";
            String at = this.field0376 != null ? "id=" + this.field0376.method_5628() : "null";
            this.method2134("tick: enemies=" + enemies + " placeT=" + pt + " atkT=" + at + " ping=" + ping + " switch=" + String.valueOf(this.field0918.method0492()) + " rotate=" + String.valueOf(this.field1301.method0492()) + " placed=" + this.field1354.size());
         }

         Runnable runnable = () -> {
            try {
               this.field0376 = this.method2014();
               this.field0373 = this.method1258((class_2338)null);
               this.field0421 = this.field0373 == null ? null : this.field0373.field0152;
            } catch (Throwable var2) {
            }

         };
         if ((Boolean)this.field0526.method0492()) {
            this.field0945.submit(runnable);
         } else {
            runnable.run();
         }

         if (!(Boolean)this.field0503.method0492()) {
            this.method1691();
         }
      }
   }

   @EventHandler
   public void onGameLoop(GameLoopEvent e) {
      if (!method1974()) {
         if ((Boolean)this.field0503.method0492()) {
            if (this.field1398.method1646(((Float)this.field0552.method0492()).longValue())) {
               this.field1398.method1634();
               this.method1691();
               if (this.field0935 != null) {
                  this.field0935.run();
                  this.field0935 = null;
               }

               if (this.field0950 != null) {
                  this.field0950.run();
                  this.field0950 = null;
               }

            }
         }
      }
   }

   private void method1691() {
      this.field0935 = null;
      this.field0950 = null;
      if (this.field1340.method0492() == AutoCrystal.SequentialMode.field0583) {
         if (this.field1394) {
            this.field1394 = false;
            this.field1407 = true;
            this.method1754();
            return;
         }

         if (this.field1407) {
            this.field1394 = true;
            this.field1407 = false;
            this.method1876(false);
         }
      } else {
         if ((Boolean)this.field0034.method0492()) {
            this.method1754();
         }

         if ((Boolean)this.field1709.method0492()) {
            this.method1876(false);
         }
      }

   }

   @EventHandler
   public void onUpdateMovementPost(PostMovementEvent e) {
      if (!method1974()) {
         if (this.field0935 != null) {
            this.field0935.run();
         }

         if (this.field0950 != null) {
            this.field0950.run();
         }

      }
   }

   @EventHandler
   public void onSpawnEntity(EntitySpawnEvent e) {
      if (!method1974()) {
         if ((Boolean)this.field0034.method0492() && (Boolean)this.field1619.method0492()) {
            class_1297 var3 = e.method1798();
            if (var3 instanceof class_1511) {
               class_1511 crystal = (class_1511)var3;
               if (!this.field1321.method1646((long)(1000.0F - (Float)this.field1450.method0492() * 50.0F))) {
                  this.method1045("instant", "cooldown");
               } else if ((Boolean)this.field1544.method0492() && this.field1360.containsKey(crystal.method_5628())) {
                  this.method1045("instant", "inhibited");
               } else if (!this.field1354.containsKey(crystal.method_24515().method_10074())) {
                  this.method1045("instant", "not our crystal (placedCrystals miss)");
               } else {
                  class_243 eye = field0796.field_1724.method_33571();
                  if (crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0985.method0492()).doubleValue())) {
                     this.method1045("instant", "out of range");
                  } else if (!field0796.field_1687.method_8621().method_11952(crystal.method_24515())) {
                     this.method1045("instant", "world border");
                  } else if (BlockPlacementHelper.method1301(crystal.method_5829().method_1005()) || !(Boolean)this.field0426.method0492() && !(crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0190.method0492()).doubleValue()))) {
                     this.method2134("INSTANT attack on spawn id=" + crystal.method_5628());
                     this.method1300(class_243.method_26410(crystal.method_24515(), (double)0.0F));
                     this.method1174(crystal);
                     this.field0415 = true;
                  } else {
                     this.method1045("instant", "blocked by walls");
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onDestroyBlock(BlockDestroyEvent e) {
      if (!method1974()) {
         this.field0453 = 0;
         if ((Boolean)this.field0830.method0492()) {
            if (this.field1316.method1646((long)(1000.0F - (Float)this.field1144.method0492() * 50.0F))) {
               class_2338 minedPosition = e.method1802();
               if (minedPosition != null) {
                  int slot = InventoryManager.method2154(class_1802.field_8301);
                  int previousSlot = field0796.field_1724.method_31548().field_7545;
                  boolean switched = false;
                  if (this.field0918.method0492() == AutoCrystal.SwitchMode.field0588 || slot != -1 || field0796.field_1724.method_6047().method_7909() == class_1802.field_8301 || field0796.field_1724.method_6079().method_7909() == class_1802.field_8301) {
                     RenderState mt = this.field0380 == null ? null : this.field0380.method0533();
                     if (mt == null || mt.field0733 != null && !minedPosition.equals(mt.field1041)) {
                        mt = this.method1258(minedPosition);
                     }

                     if (mt != null && mt.field0733 != null) {
                        class_2338 position = mt.field0733;
                        class_243 eye = field0796.field_1724.method_33571();
                        if (!(eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1097.method0492()).doubleValue()))) {
                           if (BlockPlacementHelper.method1301(class_243.method_24953(position)) || !(Boolean)this.field0426.method0492() && !(eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1206.method0492()).doubleValue()))) {
                              this.method1300(class_243.method_26410(position, (double)1.0F));
                              Iterator var9 = field0796.field_1687.method_8335((class_1297)null, new class_238(position.method_10084())).stream().filter((en) -> en instanceof class_1511).toList().iterator();
                              if (var9.hasNext()) {
                                 class_1297 entity = (class_1297)var9.next();
                                 this.method1300(entity.method_5829().method_1005());
                                 field0796.field_1724.field_3944.method_52787(class_2824.method_34206(entity, field0796.field_1724.method_5715()));
                                 field0796.field_1724.field_3944.method_52787(new class_2879(class_1268.field_5808));
                              }

                              if (this.field0918.method0492() != AutoCrystal.SwitchMode.field0588 && field0796.field_1724.method_6047().method_7909() != class_1802.field_8301 && field0796.field_1724.method_6079().method_7909() != class_1802.field_8301) {
                                 this.method0738(slot, previousSlot);
                                 switched = true;
                              }

                              this.method0278(position);
                              if (switched) {
                                 this.method0148(slot, previousSlot);
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Inbound e) {
      if (!method1974()) {
         class_2596 position = e.method1970();
         if (position instanceof class_2604) {
            class_2604 packet = (class_2604)position;
            if (packet.method_11167() > this.field0444) {
               this.field0444 = packet.method_11167();
            }

            class_2338 position = class_2338.method_49637(packet.method_11175(), packet.method_11174(), packet.method_11176()).method_10069(0, -1, 0);
            if (this.field1364.containsKey(position)) {
               if (this.field1326.method1646(((Float)this.field1167.method0492()).longValue() * 50L)) {
                  this.field1326.method1634();
               }

               this.field1364.remove(position);
               this.field0449.method0578();
            }
         }

         position = e.method1970();
         if (position instanceof class_2606) {
            class_2606 packet = (class_2606)position;
            if (packet.method_11183() > this.field0444) {
               this.field0444 = packet.method_11183();
            }
         }

      }
   }

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent e) {
      this.field0453 = 0;
   }

   @EventHandler
   public void onClientConnect(ClientConnectEvent e) {
      this.field0444 = -100000;
   }

   @EventHandler
   public void onRender(WorldRenderEvent.WorldPass event) {
      if (!method1974()) {
         RenderState pt = this.field0373;
         if (pt != null && pt.field0733 != null && this.field0857.method0492() != AutoCrystal.RenderMode.field0585) {
            class_238 box = new class_238(pt.field0733.method_10084());
            class_4587 matrices = new class_4587();
            RenderMode m = (RenderMode)this.field0857.method0492();
            if (m == AutoCrystal.RenderMode.field0020 || m == AutoCrystal.RenderMode.field0964) {
               WorldRenderHelper.method1498(matrices, box, this.field0849.method1726());
            }

            if (m == AutoCrystal.RenderMode.field1424 || m == AutoCrystal.RenderMode.field0964) {
               WorldRenderHelper.method2173(matrices, box, this.field0866.method1726());
            }

         }
      }
   }

   private void method1754() {
      class_1511 overrideCrystal = null;
      boolean flag = this.field0373 != null && this.field0373.field1508 != null && !this.field0373.field1508.isEmpty();

      for(class_1297 entity : flag ? this.field0373.field1508 : field0796.field_1687.method_18112()) {
         if (entity instanceof class_1511 crystal) {
            if (crystal.method_5805() && (!(Boolean)this.field1544.method0492() || !this.field1360.containsKey(entity.method_5628())) && (flag || this.field1354.containsKey(crystal.method_24515().method_10074()))) {
               class_243 eye = field0796.field_1724.method_33571();
               if (!(crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0985.method0492()).doubleValue())) && field0796.field_1687.method_8621().method_11952(crystal.method_24515()) && (BlockPlacementHelper.method1301(crystal.method_5829().method_1005()) || !(Boolean)this.field0426.method0492() && !(crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0190.method0492()).doubleValue())))) {
                  overrideCrystal = crystal;
                  break;
               }
            }
         }
      }

      class_1511 crystal = overrideCrystal == null ? this.field0376 : overrideCrystal;
      if (crystal == null) {
         this.method1045("attack", "no candidate (calc=null & no override)");
      } else {
         if (this.field1301.method0492() == AutoCrystal.RotationMode.field0019) {
            this.method1300(class_243.method_26410(crystal.method_24515(), (double)0.0F));
         }

         if (this.field1321.method1646((long)(1000.0F - (Float)this.field1450.method0492() * 50.0F)) && !this.field0415) {
            class_1297 entity = field0796.field_1687.method_8469(crystal.method_5628());
            if (entity != null && entity instanceof class_1511) {
               class_1511 ec = (class_1511)entity;
               if (ec.method_5805()) {
                  if ((Boolean)this.field1544.method0492() && this.field1360.containsKey(entity.method_5628())) {
                     this.method1045("attack", "inhibited (already attacked)");
                     return;
                  }

                  class_243 eye2 = field0796.field_1724.method_33571();
                  if (ec.method_5829().method_49271(eye2) > class_3532.method_33723(((Float)this.field0985.method0492()).doubleValue())) {
                     this.method1045("attack", "out of range");
                     return;
                  }

                  if (!field0796.field_1687.method_8621().method_11952(ec.method_24515())) {
                     this.method1045("attack", "world border");
                     return;
                  }

                  if (BlockPlacementHelper.method1301(ec.method_5829().method_1005()) || !(Boolean)this.field0426.method0492() && !(ec.method_5829().method_49271(eye2) > class_3532.method_33723(((Float)this.field0190.method0492()).doubleValue()))) {
                     this.field0935 = () -> this.method1174(crystal);
                     return;
                  }

                  this.method1045("attack", "blocked by walls");
                  return;
               }
            }

            this.method1045("attack", "crystal vanished");
         } else {
            if (this.field0415) {
               this.field0415 = false;
            } else {
               this.method1045("attack", "cooldown");
            }

         }
      }
   }

   private void method1876(boolean forceSequential) {
      RenderState pt = this.field0373 == null ? null : this.field0373.method0533();
      if (pt != null && pt.field0733 != null) {
         int slot = InventoryManager.method2154(class_1802.field_8301);
         int previousSlot = field0796.field_1724.method_31548().field_7545;
         boolean inHand = field0796.field_1724.method_6047().method_7909() == class_1802.field_8301 || field0796.field_1724.method_6079().method_7909() == class_1802.field_8301;
         if (this.field0918.method0492() != AutoCrystal.SwitchMode.field0588 && slot == -1 && !inHand) {
            this.method1045("place", "no crystals in hotbar (autoSwitch=" + String.valueOf(this.field0918.method0492()) + ")");
         } else if (this.field0918.method0492() == AutoCrystal.SwitchMode.field0588 && !inHand) {
            this.method1045("place", "no crystal in hand & autoSwitch=None — set Switch=Silent");
         } else {
            class_2338 position = pt.field0733;
            if (this.field1354.containsKey(position)) {
               this.method1045("place", "already placed @" + position.method_23854() + " (in flight)");
            } else {
               class_243 eye = field0796.field_1724.method_33571();
               if (eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1097.method0492()).doubleValue())) {
                  this.method1045("place", "out of range " + String.valueOf(position));
               } else if (!field0796.field_1687.method_8621().method_11952(position)) {
                  this.method1045("place", "world border");
               } else if (field0796.field_1687.method_8320(position).method_26204() != class_2246.field_10540 && field0796.field_1687.method_8320(position).method_26204() != class_2246.field_9987) {
                  this.method1045("place", "not obsidian/bedrock");
               } else if (field0796.field_1687.method_8320(position.method_10069(0, 1, 0)).method_26215() && (this.field0880.method0492() != AutoCrystal.PlacementMode.field0021 || field0796.field_1687.method_8320(position.method_10069(0, 2, 0)).method_26215())) {
                  if (BlockPlacementHelper.method1301(class_243.method_24953(position)) || !(Boolean)this.field0426.method0492() && !(eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1206.method0492()).doubleValue()))) {
                     if (field0796.field_1687.method_8335((class_1297)null, new class_238(position.method_10069(0, 1, 0))).stream().anyMatch((en) -> en.method_5805() && !(en instanceof class_1303) && !(en instanceof class_1511))) {
                        this.method1045("place", "entity blocking spawn");
                     } else {
                        if (this.field1301.method0492() == AutoCrystal.RotationMode.field0019) {
                           this.method1300(class_243.method_26410(position, (double)1.0F));
                        }

                        if (!this.field1316.method1646((long)(1000.0F - (Float)this.field1144.method0492() * 50.0F))) {
                           this.method1045("place", "cooldown");
                        } else if (!forceSequential && this.field0410) {
                           this.field0410 = false;
                           this.method1045("place", "sequenced already");
                        } else {
                           this.field0950 = () -> {
                              boolean switched = false;
                              if (field0796.field_1724.method_6047().method_7909() != class_1802.field_8301 && field0796.field_1724.method_6079().method_7909() != class_1802.field_8301) {
                                 this.method0738(slot, previousSlot);
                                 switched = true;
                              }

                              this.method0278(position);
                              if (switched) {
                                 this.method0148(slot, previousSlot);
                              }

                              if ((Boolean)this.field1659.method0492()) {
                                 this.method2029();
                              }

                           };
                           if (forceSequential) {
                              this.field0950.run();
                              this.field0950 = null;
                              this.field0410 = true;
                           }

                        }
                     }
                  } else {
                     this.method1045("place", "blocked by walls");
                  }
               } else {
                  this.method1045("place", "blocked above");
               }
            }
         }
      } else {
         this.method1045("place", "no target (calc returned null/empty)");
      }
   }

   private void method2029() {
      boolean throwXpHeld = field0796.field_1724.method_6047().method_7909() instanceof class_1779 || field0796.field_1724.method_6079().method_7909() instanceof class_1779;
      ThrowXP txp = ThrowXP.method1723();
      boolean txpToggled = txp != null && txp.method2195();
      boolean kickGate = !(Boolean)this.field1756.method0492() || !throwXpHeld && !txpToggled;
      if ((!(Boolean)this.field1756.method0492() || this.field0453 > ((Float)this.field1744.method0492()).intValue()) && kickGate) {
         if (!(Boolean)this.field1604.method0492()) {
            for(class_1297 entity : field0796.field_1687.method_18112()) {
               if (entity.method_5628() > this.field0444) {
                  this.field0444 = entity.method_5628();
               }
            }
         }

         int n = ((Float)this.field1693.method0492()).intValue();
         int off = ((Float)this.field1593.method0492()).intValue();

         for(int i = 1 - off; i < n; ++i) {
            class_1297 entity = field0796.field_1687.method_8469(this.field0444);
            if (entity == null || entity instanceof class_1511) {
               int id = this.field0444 + i;
               class_2824 packet = class_2824.method_34206(field0796.field_1724, field0796.field_1724.method_5715());
               method1377(packet, id);
               field0796.method_1562().method_52787(packet);
               if (this.field1583.method0492() == AutoCrystal.GodSwingMode.field1425) {
                  field0796.method_1562().method_52787(new class_2879(class_1268.field_5808));
               }

               this.field1360.put(id, System.currentTimeMillis());
            }
         }

         if (this.field1583.method0492() == AutoCrystal.GodSwingMode.field0022) {
            field0796.method_1562().method_52787(new class_2879(class_1268.field_5808));
         }
      }

      ++this.field0453;
   }

   private static void method1377(class_2824 packet, int id) {
      for(String name : field0249) {
         try {
            Field f = class_2824.class.getDeclaredField(name);
            f.setAccessible(true);
            f.setInt(packet, id);
            return;
         } catch (Throwable var8) {
         }
      }

      for(Field f : class_2824.class.getDeclaredFields()) {
         if (!Modifier.isStatic(f.getModifiers()) && f.getType() == Integer.TYPE) {
            try {
               f.setAccessible(true);
               f.setInt(packet, id);
               return;
            } catch (Throwable var7) {
            }
         }
      }

   }

   private class_1511 method2014() {
      if (!(Boolean)this.field0034.method0492()) {
         return null;
      } else if (this.method1677(true)) {
         return null;
      } else if (field0796.field_1687 != null && field0796.field_1724 != null) {
         List<class_1657> players = this.method2041();
         if (players.isEmpty()) {
            return null;
         } else {
            class_1511 optimalCrystal = null;
            float optimalDamage = 0.0F;

            for(class_1297 entity : field0796.field_1687.method_18112()) {
               if (entity instanceof class_1511) {
                  class_1511 crystal = (class_1511)entity;
                  if (crystal.method_5805() && (!(Boolean)this.field1544.method0492() || !this.field1360.containsKey(entity.method_5628()))) {
                     class_243 eye = field0796.field_1724.method_33571();
                     if (!(crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0985.method0492()).doubleValue())) && field0796.field_1687.method_8621().method_11952(crystal.method_24515()) && (BlockPlacementHelper.method1301(crystal.method_5829().method_1005()) || !(Boolean)this.field0426.method0492() && !(crystal.method_5829().method_49271(eye) > class_3532.method_33723(((Float)this.field0190.method0492()).doubleValue())))) {
                        Suicide suicide = Suicide.method1721();
                        if (suicide == null || !suicide.method2195()) {
                           float self = DamageCalculator.method1142(field0796.field_1724, (class_238)null, crystal, (Boolean)this.field0894.method0492());
                           if (self > (Float)this.field1222.method0492() || (Boolean)this.field0900.method0492() && self > field0796.field_1724.method_6032() + field0796.field_1724.method_6067()) {
                              continue;
                           }
                        }

                        boolean override = false;

                        for(class_1657 p : players) {
                           class_238 pred = EntityPositionHelper.method1193(p, ((Float)this.field0262.method0492()).intValue());
                           float dmg = DamageCalculator.method1142(p, pred, crystal, (Boolean)this.field0894.method0492());
                           float minDmg = this.method1186(p, (Float)this.field1230.method0492());
                           if ((!(dmg < minDmg) || !(dmg < p.method_6032() + p.method_6067()) || dmg * (1.0F + (Float)this.field1236.method0492()) >= p.method_6032() + p.method_6067()) && (dmg > optimalDamage || dmg > p.method_6032() + p.method_6067())) {
                              optimalCrystal = crystal;
                              optimalDamage = dmg;
                              if (dmg > p.method_6032() + p.method_6067()) {
                                 override = true;
                                 break;
                              }
                           }
                        }

                        if (override) {
                           break;
                        }
                     }
                  }
               }
            }

            return optimalCrystal;
         }
      } else {
         return null;
      }
   }

   private RenderState method1258(class_2338 exception) {
      if (!(Boolean)this.field1709.method0492()) {
         return null;
      } else if (field0796.field_1687 != null && field0796.field_1724 != null) {
         if (!this.method1677(false) && (this.field0918.method0492() != AutoCrystal.SwitchMode.field0588 && InventoryManager.method2154(class_1802.field_8301) != -1 || field0796.field_1724.method_6047().method_7909() == class_1802.field_8301 || field0796.field_1724.method_6079().method_7909() == class_1802.field_8301)) {
            List<class_1657> players = this.method2041();
            if (players.isEmpty()) {
               return null;
            } else {
               class_2338 optimalPosition = null;
               class_1657 optimalPlayer = null;
               List<class_1297> obstructions = new ArrayList();
               float optimalDamage = 0.0F;
               int calculations = 0;
               int maxIndex = CrystalPositionHelper.method0609(Math.max(((Float)this.field1097.method0492()).doubleValue(), ((Float)this.field1206.method0492()).doubleValue()));
               class_2338 basePos = field0796.field_1724.method_24515();
               class_243 eye = field0796.field_1724.method_33571();

               for(int i = 0; i < maxIndex; ++i) {
                  class_2382 offsetVec = CrystalPositionHelper.method0726(i);
                  class_2338 position = basePos.method_10081(offsetVec);
                  if (!(eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1097.method0492()).doubleValue())) && field0796.field_1687.method_8621().method_11952(position) && (field0796.field_1687.method_8320(position).method_26204() == class_2246.field_10540 || field0796.field_1687.method_8320(position).method_26204() == class_2246.field_9987) && field0796.field_1687.method_8320(position.method_10069(0, 1, 0)).method_26215() && (this.field0880.method0492() != AutoCrystal.PlacementMode.field0021 || field0796.field_1687.method_8320(position.method_10069(0, 2, 0)).method_26215()) && (BlockPlacementHelper.method1301(class_243.method_24953(position)) || !(Boolean)this.field0426.method0492() && !(eye.method_1025(class_243.method_24953(position)) > class_3532.method_33723(((Float)this.field1206.method0492()).doubleValue()))) && !field0796.field_1687.method_8335((class_1297)null, new class_238(position.method_10069(0, 1, 0))).stream().anyMatch((en) -> en.method_5805() && !(en instanceof class_1303) && !(en instanceof class_1511))) {
                     int finalAttackSpeed = ((Float)this.field1450.method0492()).intValue();
                     List<class_1297> obstructingCrystals = field0796.field_1687.method_8335((class_1297)null, new class_238(position.method_10069(0, 1, 0))).stream().filter((en) -> {
                        boolean var10000;
                        if (en instanceof class_1511 ec) {
                           if (ec.field_6012 >= 20 - finalAttackSpeed + 15) {
                              var10000 = true;
                              return var10000;
                           }
                        }

                        var10000 = false;
                        return var10000;
                     }).toList();
                     Suicide suicide = Suicide.method1721();
                     if (suicide == null || !suicide.method2195()) {
                        float self = DamageCalculator.method1143(field0796.field_1724, (class_238)null, position, exception, (Boolean)this.field0894.method0492());
                        if (self > (Float)this.field1222.method0492() || (Boolean)this.field0900.method0492() && self > field0796.field_1724.method_6032() + field0796.field_1724.method_6067()) {
                           continue;
                        }
                     }

                     boolean override = false;

                     for(class_1657 p : players) {
                        ++calculations;
                        class_238 pred = EntityPositionHelper.method1193(p, ((Float)this.field0262.method0492()).intValue());
                        float dmg = DamageCalculator.method1143(p, pred, position, exception, (Boolean)this.field0894.method0492());
                        float minDmg = this.method1186(p, (Float)this.field1230.method0492());
                        if (!(dmg < minDmg) || !(dmg < p.method_6032() + p.method_6067()) || dmg * (1.0F + (Float)this.field1236.method0492()) >= p.method_6032() + p.method_6067()) {
                           if (exception == null && !obstructingCrystals.isEmpty()) {
                              obstructions.add((class_1297)obstructingCrystals.get(0));
                              break;
                           }

                           if (dmg > optimalDamage || dmg > p.method_6032() + p.method_6067()) {
                              optimalPosition = position;
                              optimalPlayer = p;
                              optimalDamage = dmg;
                              if (dmg > p.method_6032() + p.method_6067()) {
                                 override = true;
                                 break;
                              }
                           }
                        }
                     }

                     if (override) {
                        break;
                     }
                  }
               }

               return optimalPosition == null ? new RenderState((class_2338)null, (class_1657)null, obstructions, (class_2338)null, 0.0F, calculations) : new RenderState(optimalPosition, optimalPlayer, obstructions, exception, optimalDamage, calculations);
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void method1300(class_243 aim) {
      Rotation angle = RotationHelper.method1296(aim.method_1020(field0796.field_1724.method_33571()));
      if ((Boolean)this.field0389.method0492()) {
         float serverYaw = ArbuzClient.method2004().method2186().method2047();
         float diff = class_3532.method_15393(serverYaw - angle.method2047());
         float threshold = (Float)this.field0360.method0492();
         if (Math.abs(diff) > threshold) {
            float deltaYaw = (float)(diff > 0.0F ? -1 : 1) * threshold;
            angle = new Rotation(serverYaw + deltaYaw, angle.method1762());
         }
      }

      RotationHandler cfg = new RotationHandler(new LinearRotationStrategy(), true, true);
      RotationManager.field0618.method0875(angle, cfg, RotationPriority.field0778, this);
   }

   private void method1174(class_1511 crystal) {
      int previousSlot = field0796.field_1724.method_31548().field_7545;
      boolean switched = false;
      if (this.field0469.method0492() != AutoCrystal.AntiWeaknessMode.field0578 && field0796.field_1724.method_6059(class_1294.field_5911)) {
         int swordSlot = InventoryManager.method0147(0, 8);
         if (swordSlot != -1) {
            if (this.field0469.method0492() == AutoCrystal.AntiWeaknessMode.field0013) {
               InventoryManager.method0808(InventoryManager.SwitchMode.field0613, swordSlot, previousSlot);
            } else {
               InventoryManager.method0808(InventoryManager.SwitchMode.field0046, swordSlot, previousSlot);
            }

            switched = true;
         }
      }

      this.field1360.put(crystal.method_5628(), System.currentTimeMillis());
      field0796.method_1562().method_52787(class_2824.method_34206(crystal, field0796.field_1724.method_5715()));
      field0796.method_1562().method_52787(new class_2879(class_1268.field_5808));
      int var10001 = crystal.method_5628();
      this.method2134("ATTACK id=" + var10001 + " @ " + crystal.method_24515().method_23854());
      if (switched) {
         if (this.field0469.method0492() == AutoCrystal.AntiWeaknessMode.field0013) {
            InventoryManager.method0169(InventoryManager.SwitchMode.field0613, 0, previousSlot);
         } else {
            InventoryManager.method0169(InventoryManager.SwitchMode.field0046, 0, previousSlot);
         }
      }

      this.field1321.method1634();
   }

   private void method0278(class_2338 position) {
      class_1268 hand = field0796.field_1724.method_6079().method_7909() == class_1802.field_8301 ? class_1268.field_5810 : class_1268.field_5808;
      class_2350 direction = CrystalPositionHelper.method1279(position, true);
      class_243 hitVec = CrystalPositionHelper.method1273(position, direction);
      class_3965 ray = new class_3965(hitVec, direction, position, false);
      this.field1354.put(position, System.currentTimeMillis());
      this.field1364.put(position, System.currentTimeMillis());
      SequencedPacketSender.method1534((seq) -> new class_2885(hand, ray, seq));
      String var10001 = position.method_23854();
      this.method2134("PLACE @ " + var10001 + " hand=" + String.valueOf(hand) + " dir=" + String.valueOf(direction));
      switch (((SwingMode)this.field1376.method0492()).ordinal()) {
         case 0:
            field0796.field_1724.method_6104(hand);
         case 1:
         default:
            break;
         case 2:
            field0796.method_1562().method_52787(new class_2879(hand));
            break;
         case 3:
            field0796.field_1724.method_6104(class_1268.field_5808);
            break;
         case 4:
            field0796.field_1724.method_6104(class_1268.field_5810);
            break;
         case 5:
            field0796.field_1724.method_6104(class_1268.field_5808);
            field0796.field_1724.method_6104(class_1268.field_5810);
      }

      this.field1316.method1634();
   }

   private void method0738(int slot, int previousSlot) {
      switch (((SwitchMode)this.field0918.method0492()).ordinal()) {
         case 1 -> InventoryManager.method0808(InventoryManager.SwitchMode.field0613, slot, previousSlot);
         case 2 -> InventoryManager.method0808(InventoryManager.SwitchMode.field0046, slot, previousSlot);
         case 3 -> InventoryManager.method0808(InventoryManager.SwitchMode.field1440, slot, previousSlot);
      }

   }

   private void method0148(int slot, int previousSlot) {
      switch (((SwitchMode)this.field0918.method0492()).ordinal()) {
         case 1 -> InventoryManager.method0169(InventoryManager.SwitchMode.field0613, slot, previousSlot);
         case 2 -> InventoryManager.method0169(InventoryManager.SwitchMode.field0046, slot, previousSlot);
         case 3 -> InventoryManager.method0169(InventoryManager.SwitchMode.field1440, slot, previousSlot);
      }

   }

   private List<class_1657> method2041() {
      List<class_1657> players = new ArrayList();
      Suicide suicide = Suicide.method1721();
      if (suicide != null && suicide.method2195()) {
         players.add(field0796.field_1724);
         return players;
      } else {
         FriendManager friends = ArbuzClient.method2004().method1608();

         for(class_1657 p : field0796.field_1687.method_18456()) {
            if (p != field0796.field_1724 && p.method_5805() && !(field0796.field_1724.method_5858(p) > class_3532.method_33723(((Float)this.field0234.method0492()).doubleValue())) && (friends == null || !friends.method2135(p.method_5477().getString()))) {
               players.add(p);
            }
         }

         return players;
      }
   }

   private boolean method1677(boolean attackProcess) {
      if (!field0796.field_1724.method_6115()) {
         return false;
      } else {
         EatingMode mode = (EatingMode)this.field1675.method0492();
         if (mode == AutoCrystal.EatingMode.field0581) {
            return true;
         } else if (attackProcess && mode == AutoCrystal.EatingMode.field1420) {
            return true;
         } else {
            return !attackProcess && mode == AutoCrystal.EatingMode.field0016;
         }
      }
   }

   private float method1186(class_1657 player, float minimum) {
      if (player == null) {
         return minimum;
      } else {
         if ((Boolean)this.field0292.method0492()) {
            int finalPlaceSpeed = ((Float)this.field1144.method0492()).intValue();
            int pingDelay = this.method0462() / 50;
            boolean targetItems = field0796.field_1687.method_8335((class_1297)null, (new class_238(player.method_24515())).method_1014((double)1.0F)).stream().anyMatch((en) -> {
               boolean var10000;
               if (en instanceof class_1542 item) {
                  if (item.method_6983().method_7909() == class_1802.field_8281 && item.method_6983().method_7947() >= 8 && item.field_6012 <= 2 + pingDelay + (20 - finalPlaceSpeed)) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            });
            boolean ourItems = field0796.field_1687.method_8335((class_1297)null, (new class_238(field0796.field_1724.method_24515())).method_1014((double)1.0F)).stream().anyMatch((en) -> {
               boolean var10000;
               if (en instanceof class_1542 item) {
                  if (item.method_6983().method_7909() == class_1802.field_8281 && item.method_6983().method_7947() >= 8 && item.field_6012 <= 2 + pingDelay + (20 - finalPlaceSpeed)) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            });
            if (targetItems && !ourItems) {
               return 2.0F;
            }
         }

         if (this.field1768.method0492() == AutoCrystal.FacePlaceMode.field0579) {
            return minimum;
         } else {
            if (this.field1177.method0492() == AutoCrystal.FacePlaceSpeedMode.field0580 || this.field1326.method1646(((Float)this.field1167.method0492()).longValue() * 50L)) {
               if (this.field1768.method0492() == AutoCrystal.FacePlaceMode.field1419) {
                  return Math.min(minimum, 2.0F);
               }

               if (this.field1768.method0492() == AutoCrystal.FacePlaceMode.field0014 && (Boolean)this.field1188.method0492() && player.method_6032() + player.method_6067() <= (Float)this.field1122.method0492()) {
                  return Math.min(minimum, 2.0F);
               }

               if (this.field1768.method0492() == AutoCrystal.FacePlaceMode.field0014 && (Boolean)this.field1114.method0492()) {
                  for(class_1799 stack : player.method_5661()) {
                     if (stack != null && stack.method_7909() instanceof class_1738) {
                        int max = stack.method_7936();
                        if (max > 0) {
                           int remaining = (int)Math.round((double)(max - stack.method_7919()) * (double)100.0F / (double)max);
                           if (remaining <= ((Float)this.field1132.method0492()).intValue()) {
                              return Math.min(minimum, 2.0F);
                           }
                        }
                     }
                  }
               }
            }

            return minimum;
         }
      }
   }

   private int method0462() {
      try {
         if (field0796.method_1562() == null) {
            return 0;
         } else {
            class_640 entry = field0796.method_1562().method_2871(field0796.field_1724.method_5667());
            return entry == null ? 0 : entry.method_2959();
         }
      } catch (Throwable var2) {
         return 0;
      }
   }

   public void method2078() {
      this.field0935 = null;
      this.field0950 = null;
      this.field1360.clear();
      this.field1354.clear();
      this.field1364.clear();
      this.field0415 = false;
      this.field0410 = false;
      this.field0421 = null;
      this.field0373 = null;
      this.field0380 = null;
      this.field0449.method2078();
      this.field0444 = -100000;
      this.field0453 = 0;
      super.method2078();
   }

   @Generated
   public class_1657 method1731() {
      return this.field0421;
   }

   public static enum AntiWeaknessMode implements DisplayNamed {
      field0578("None"),
      field0013("Normal"),
      field1418("Silent");

      private final String field1030;

      private AntiWeaknessMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static AntiWeaknessMode[] method0033() {
         return new AntiWeaknessMode[]{field0578, field0013, field1418};
      }
   }

   public static enum SwitchMode implements DisplayNamed {
      field0588("None"),
      field0023("Normal"),
      field1426("Silent"),
      field0965("AltSwap");

      private final String field0791;

      private SwitchMode(String name) {
         this.field0791 = name;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static SwitchMode[] method0043() {
         return new SwitchMode[]{field0588, field0023, field1426, field0965};
      }
   }

   public static enum SequentialMode implements DisplayNamed {
      field0583("None"),
      field0018("Strict"),
      field1422("Strong");

      private final String field1030;

      private SequentialMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static SequentialMode[] method0038() {
         return new SequentialMode[]{field0583, field0018, field1422};
      }
   }

   public static enum RotationMode implements DisplayNamed {
      field0584("None"),
      field0019("Normal"),
      field1423("Packet");

      private final String field1030;

      private RotationMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static RotationMode[] method0039() {
         return new RotationMode[]{field0584, field0019, field1423};
      }
   }

   public static enum SwingMode implements DisplayNamed {
      field0582("Default"),
      field0017("None"),
      field1421("Packet"),
      field0963("Mainhand"),
      field0763("Offhand"),
      field1248("Both");

      private final String field0336;

      private SwingMode(String name) {
         this.field0336 = name;
      }

      public String method0557() {
         return this.field0336;
      }

      // $FF: synthetic method
      private static SwingMode[] method0037() {
         return new SwingMode[]{field0582, field0017, field1421, field0963, field0763, field1248};
      }
   }

   public static enum FacePlaceMode implements DisplayNamed {
      field0579("None"),
      field0014("Dynamic"),
      field1419("Always");

      private final String field1030;

      private FacePlaceMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static FacePlaceMode[] method0034() {
         return new FacePlaceMode[]{field0579, field0014, field1419};
      }
   }

   public static enum EatingMode implements DisplayNamed {
      field0581("None"),
      field0016("Attack"),
      field1420("Place"),
      field0962("Both");

      private final String field0791;

      private EatingMode(String name) {
         this.field0791 = name;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static EatingMode[] method0036() {
         return new EatingMode[]{field0581, field0016, field1420, field0962};
      }
   }

   public static enum FacePlaceSpeedMode implements DisplayNamed {
      field0580("Normal"),
      field0015("Custom");

      private final String field1504;

      private FacePlaceSpeedMode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static FacePlaceSpeedMode[] method0035() {
         return new FacePlaceSpeedMode[]{field0580, field0015};
      }
   }

   public static enum PlacementMode implements DisplayNamed {
      field0586("Native"),
      field0021("Protocol");

      private final String field1504;

      private PlacementMode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static PlacementMode[] method0041() {
         return new PlacementMode[]{field0586, field0021};
      }
   }

   public static enum GodSwingMode implements DisplayNamed {
      field0587("None"),
      field0022("Normal"),
      field1425("Strict");

      private final String field1030;

      private GodSwingMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static GodSwingMode[] method0042() {
         return new GodSwingMode[]{field0587, field0022, field1425};
      }
   }

   public static enum RenderMode implements DisplayNamed {
      field0585("None"),
      field0020("Fill"),
      field1424("Outline"),
      field0964("Both");

      private final String field0791;

      private RenderMode(String name) {
         this.field0791 = name;
      }

      public String method0557() {
         return this.field0791;
      }

      // $FF: synthetic method
      private static RenderMode[] method0040() {
         return new RenderMode[]{field0585, field0020, field1424, field0964};
      }
   }

   private static class RenderState {
      class_2338 field0733;
      class_1657 field0152;
      List<class_1297> field1508;
      class_2338 field1041;
      float field0758;
      int field1243;

      RenderState(class_2338 position, class_1657 player, List<class_1297> obstructions, class_2338 exception, float damage, int calculations) {
         this.field0733 = position;
         this.field0152 = player;
         this.field1508 = obstructions;
         this.field1041 = exception;
         this.field0758 = damage;
         this.field1243 = calculations;
      }

      RenderState method0533() {
         return new RenderState(this.field0733, this.field0152, this.field1508, this.field1041, this.field0758, this.field1243);
      }
   }
}
