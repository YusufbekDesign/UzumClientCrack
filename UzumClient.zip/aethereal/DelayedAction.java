package aethereal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

public class DelayedAction {
   private final TreeMap<Integer, List<ScheduledAction>> field0722 = new TreeMap();
   private int field0004 = 0;
   private boolean field1527 = false;

   public DelayedAction method0765(int tick, Runnable action, int priority) {
      ((List)this.field0722.computeIfAbsent(tick, (k) -> new ArrayList())).add(new ScheduledAction(action, priority));
      if (!this.field1527) {
         this.field1527 = true;
         this.field0004 = 0;
      }

      return this;
   }

   public void method0578() {
      this.field0722.clear();
      this.field0004 = 0;
      this.field1527 = false;
   }

   public boolean method0026() {
      return !this.field1527;
   }

   public void method2078() {
      if (this.field1527) {
         ++this.field0004;
         List<ScheduledAction> entries = (List)this.field0722.get(this.field0004);
         if (entries != null) {
            entries.sort(Comparator.comparingInt((e) -> e.priority));

            for(ScheduledAction entry : entries) {
               entry.action.run();
            }
         }

         if (this.field0722.isEmpty() || this.field0004 >= (Integer)this.field0722.lastKey()) {
            this.field1527 = false;
            this.field0722.clear();
            this.field0004 = 0;
         }

      }
   }

   private static record ScheduledAction(Runnable action, int priority) {
      public Runnable method0556() {
         return this.action;
      }

      public int method0003() {
         return this.priority;
      }
   }
}
