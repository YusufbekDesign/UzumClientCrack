package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_284;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import net.minecraft.class_9960;
import org.patch.arbuzhack.api.mixins.accessors.GameRendererAccessor;
import org.patch.arbuzhack.api.mixins.accessors.PostEffectProcessorAccessor;

public class ChromaticDistortionRenderer implements MinecraftAccess {
   private float field0566 = 0.004F;
   private float field0003 = 2.0F;
   private float field1410 = 0.0F;
   private float field0957 = 0.0F;
   private float field0177 = 1.0F;
   private float field0458 = 0.7F;
   private float field1614 = 0.4F;
   private float field1538 = 2.0F;
   private float field1704 = 0.3F;

   public void method0675(float amount, float falloff) {
      this.field0566 = amount;
      this.field0003 = falloff;
   }

   public void method0684(float velX, float velY, float amount) {
      this.field1410 = velX;
      this.field0957 = velY;
      this.field0177 = amount;
   }

   public void method0131(float threshold, float intensity, float radius) {
      this.field0458 = threshold;
      this.field1614 = intensity;
      this.field1538 = radius;
   }

   public void method0665(float amount) {
      this.field1704 = amount;
   }

   private static void method1523(class_5944 p, String name, float v) {
      class_284 u = p.method_34582(name);
      if (u != null) {
         u.method_1251(v);
      }

   }

   private static void method1524(class_5944 p, String name, float x, float y) {
      class_284 u = p.method_34582(name);
      if (u != null) {
         u.method_1255(x, y);
      }

   }

   public void method0578() {
      try {
         class_279 shader = field0796.method_62887().method_62941(class_2960.method_60655("arbuzhack", "chromaticdistortion"), class_9960.field_53902);
         if (shader == null) {
            return;
         }

         List<class_283> passes = ((PostEffectProcessorAccessor)shader).getPasses();
         if (passes == null || passes.isEmpty()) {
            return;
         }

         class_5944 program = ((class_283)passes.getFirst()).method_62922();
         if (program == null) {
            return;
         }

         program.method_62899("DiffuseSampler", field0796.method_1522().method_30277());
         method1523(program, "AberrationAmount", this.field0566);
         method1523(program, "AberrationFalloff", this.field0003);
         method1524(program, "MotionVelocity", this.field1410, this.field0957);
         method1523(program, "MotionAmount", this.field0177);
         method1523(program, "BloomThreshold", this.field0458);
         method1523(program, "BloomIntensity", this.field1614);
         method1523(program, "BloomRadius", this.field1538);
         method1523(program, "VignetteAmount", this.field1704);
         RenderSystem.disableBlend();
         shader.method_1258(field0796.method_1522(), ((GameRendererAccessor)field0796.field_1773).getPool());
         field0796.method_1522().method_1235(false);
      } catch (Throwable var4) {
      }

   }
}
