package aethereal;

import java.io.File;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;

public final class ConfigCommand extends Command {
   public ConfigCommand() {
      super("config", "Manage configuration files", "cfg", "c");
      this.method1013("Konfiguratsiya fayllarini boshqarish");
   }

   private ConfigManager method1607() {
      return ArbuzClient.method2004().method2216();
   }

   public void method0800(CommandContext var1) {
      String[] var2 = var1.method1814();
      if (var2.length == 0) {
         this.method1834(var1);
      } else {
         switch (var2[0].toLowerCase()) {
            case "save" -> this.method0168(var1, var2);
            case "load" -> this.method2113(var1, var2);
            case "list" -> this.method0167(var1);
            case "delete" -> this.method1835(var1, var2);
            case "folder" -> this.method2112(var1);
            case "reset" -> this.method0803(var1, var2);
            default -> this.method1834(var1);
         }
      }

   }

   private void method0803(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         this.method1607().method0498();
         var1.method1013("Konfiguratsiya standartlarga qaytarildi");
      } else {
         switch (var2[1].toLowerCase()) {
            case "modules":
               this.method1607().method0430();
               var1.method1013("Modullar va sozlamalar standartlarga qaytarildi");
               break;
            case "binds":
               this.method1607().method0375();
               var1.method1013("Barcha modul bog'lanishlari tozalandi");
               break;
            default:
               var1.method0213("Ishlatish: .config reset [modules|binds]");
         }
      }

   }

   private void method0168(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         var1.method0213("Ishlatish: .config save <nom>");
      } else {
         String var3 = var2[1];
         this.method1607().method1013(var3);
         var1.method1013("Konfiguratsiya saqlandi: " + var3);
      }

   }

   private void method2113(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         var1.method0213("Ishlatish: .config load <nom>");
      } else {
         String var3 = var2[1];
         if (this.method1607().method0214(var3)) {
            var1.method1013("Konfiguratsiya yuklandi: " + var3);
         } else {
            var1.method0213("Konfiguratsiya topilmadi: " + var3);
         }
      }

   }

   private void method0167(CommandContext var1) {
      List var2 = this.method1607().method2068();
      if (var2.isEmpty()) {
         var1.method0213("Konfiguratsiyalar topilmadi");
      } else {
         var1.method2134("Mavjud konfiguratsiyalar:");
         var2.forEach((var1x) -> var1.method1846("- " + String.valueOf(var1x)));
      }

   }

   private void method1835(CommandContext var1, String[] var2) {
      if (var2.length < 2) {
         var1.method0213("Ishlatish: .config delete <nom>");
      } else {
         String var3 = var2[1];
         if (this.method1607().method2135(var3)) {
            var1.method1013("Konfiguratsiya o'chirildi: " + var3);
         } else {
            var1.method0213("Konfiguratsiya topilmadi: " + var3);
         }
      }

   }

   private void method2112(CommandContext var1) {
      try {
         File var2 = this.method1607().method2225().toFile();
         if (!var2.exists()) {
            var2.mkdirs();
         }

         Runtime.getRuntime().exec(new String[]{"explorer.exe", var2.getAbsolutePath()});
         var1.method1013("Konfiguratsiya papkasi ochildi");
      } catch (Exception var3) {
         var1.method0213("Papkani ochib bo'lmadi");
      }

   }

   public List<String> method1593(String[] var1) {
      if (var1.length <= 1) {
         String var4 = var1.length == 1 ? var1[0].toLowerCase() : "";
         return List.of("save", "load", "list", "delete", "folder", "reset").stream().filter((var1x) -> var1x.startsWith(var4)).toList();
      } else if (var1.length != 2 || !var1[0].equalsIgnoreCase("load") && !var1[0].equalsIgnoreCase("delete")) {
         if (var1.length == 2 && var1[0].equalsIgnoreCase("reset")) {
            String var3 = var1[1].toLowerCase();
            return List.of("modules", "binds").stream().filter((var1x) -> var1x.startsWith(var3)).toList();
         } else {
            return List.of();
         }
      } else {
         String var2 = var1[1].toLowerCase();
         return this.method1607().method2068().stream().filter((var1x) -> var1x.toLowerCase().startsWith(var2)).toList();
      }
   }

   public String method2179(String[] var1) {
      if (var1.length == 2) {
         String var10000;
         switch (var1[0].toLowerCase()) {
            case "save":
            case "load":
            case "delete":
               var10000 = "<nom>";
               break;
            case "reset":
               var10000 = "[modules|binds]";
               break;
            default:
               var10000 = "";
         }

         return var10000;
      } else {
         return "";
      }
   }

   public Map<String, String> method0351(String[] var1) {
      if (var1.length <= 1) {
         return Map.of("save", "Konfiguratsiyani saqlash", "load", "Konfiguratsiyani yuklash", "list", "Konfiguratsiyalarni ro'yxatga olish", "delete", "Konfiguratsiyani o'chirish", "folder", "Konfiguratsiya papkasini ochish", "reset", "Konfiguratsiyani standartlarga qaytarish");
      } else {
         return var1.length == 2 && var1[0].equalsIgnoreCase("reset") ? Map.of("modules", "Modullar va sozlamalarni qaytarish", "binds", "Barcha bog'lanishlarni qaytarish") : Map.of();
      }
   }

   private void method1834(CommandContext var1) {
      var1.method0297(class_2561.method_43470("Mavjud konfiguratsiya buyruqlari:").method_27694((var0) -> var0.method_36139(8947848)));
      var1.method0297(class_2561.method_43470(".config save <nom>").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiyani saqlash").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(".config load <nom>").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiyani yuklash").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(".config list").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiyalarni ro'yxatga olish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(".config delete <nom>").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiyani o'chirish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(".config folder").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiya papkasini ochish").method_27694((var0) -> var0.method_36139(7829367))));
      var1.method0297(class_2561.method_43470(".config reset [modules|binds]").method_27694((var0) -> var0.method_36139(11184810)).method_10852(class_2561.method_43470(" - Konfiguratsiyani qaytarish (to'liq / modullar+sozlamalar / bog'lanishlar)").method_27694((var0) -> var0.method_36139(7829367))));
   }
}
