package aethereal;

import java.util.Objects;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class ElytraTarget extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("elytratarget.customrot", true)).method1007("Maxsus aylanish").method2130("Elitradan parvoz paytida maqsad uchun maxsus aylanish");
   private final BooleanSetting field1432;
   private final BooleanSetting field0970;
   private final EnumSetting<TargetPointMode> field0189;
   private final BooleanSetting field0464;
   private final EnumSetting<ElytraPredictionMode> field1626;
   private final BooleanSetting field1544;
   private final FloatSetting field1716;
   private final FloatSetting field1144;
   private final FloatSetting field1097;
   private final BooleanSetting field1201;
   private final FloatSetting field0881;
   private final FloatSetting field0836;
   private final FloatSetting field0919;
   private final ElytraMovementPredictor field1345;
   private final ElytraRotationController field1298;
   private final ElytraTargetController field1373;

   public static ElytraTarget method1710() {
      ArbuzClient var0 = ArbuzClient.method2004();
      return var0 != null && var0.method1783() != null ? (ElytraTarget)var0.method1783().method0976(ElytraTarget.class) : null;
   }

   public ElytraTarget() {
      super("ElytraTarget", ModuleCategory.field0088, "Elitradan parvozda maqsadga nishab olish");
      Boolean var10004 = false;
      BooleanSetting var10005 = this.field0034;
      Objects.requireNonNull(var10005);
      this.field1432 = (BooleanSetting)(new BooleanSetting("elytratarget.sharp", var10004, var10005::method0492)).method1007("O'tkir").method2130("Keskinroq burilishlar");
      this.field0970 = (BooleanSetting)(new BooleanSetting("elytratarget.autodistance", true)).method1007("Avtomatik masofa").method2130("Nishab olish nuqtasini masofaga qarab tuzatish");
      this.field0189 = (EnumSetting)(new EnumSetting("elytratarget.rotateat", TargetPointMode.field0102)).method1007("Aylanish nuqtasi").method2130("Maqsadga nishab olish nuqtasi");
      this.field0464 = (BooleanSetting)(new BooleanSetting("elytratarget.prediction", true)).method1007("Oldindan bilish").method2130("Maqsad harakatini oldindan bilish");
      ElytraPredictionMode var1 = ElytraPredictionMode.field0673;
      var10005 = this.field0464;
      Objects.requireNonNull(var10005);
      this.field1626 = (EnumSetting)(new EnumSetting("elytratarget.predictmode", var1, var10005::method0492)).method1007("Rejim").method2130("Oldindan bilish algoritmi");
      Boolean var2 = true;
      var10005 = this.field0464;
      Objects.requireNonNull(var10005);
      this.field1544 = (BooleanSetting)(new BooleanSetting("elytratarget.glidingonly", var2, var10005::method0492)).method1007("Faqat sirg'aluvchilar").method2130("Faqat uchayotganlarni oldindan bilish");
      BooleanSetting var10008 = this.field0464;
      Objects.requireNonNull(var10008);
      this.field1716 = (FloatSetting)(new FloatSetting("elytratarget.multiplier", 1.8F, 0.5F, 6.0F, 0.1F, var10008::method0492)).method1007("Ko'paytiruvchi").method2130("Oldindan bilish ko'paytiruvchisi");
      this.field1144 = (FloatSetting)(new FloatSetting("elytratarget.findrange", 32.0F, 0.0F, 96.0F, 1.0F)).method1007("Qidirish masofasi").method2130("Elitradan parvozda maqsadni qo'shimcha qidirish masofasi");
      this.field1097 = (FloatSetting)(new FloatSetting("elytratarget.reach", 3.0F, 2.5F, 3.0F, 0.05F)).method1007("Elitra yetishi").method2130("Sirg'alishdagi zarba masofasi. Qattiq cheklov 3.0 — Grim yuqorisini bekor qiladi");
      this.field1201 = (BooleanSetting)(new BooleanSetting("elytratarget.autofirework", true)).method1007("Avtomatik foyerverk").method2130("Maqsadni quvganda avtomatik foyerverk tashlash");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0881 = (FloatSetting)(new FloatSetting("elytratarget.fwclosing", 0.6F, 0.0F, 2.0F, 0.05F, var10008::method0492)).method1007("FW minimal yaqinlashish").method2130("Tashlash uchun minimal yaqinlashish tezligi");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0836 = (FloatSetting)(new FloatSetting("elytratarget.fwcooldown", 6.0F, 4.0F, 30.0F, 1.0F, var10008::method0492)).method1007("FW sovutish").method2130("Foyerverklar orasidagi minimal interval tikalarda");
      var10008 = this.field1201;
      Objects.requireNonNull(var10008);
      this.field0919 = (FloatSetting)(new FloatSetting("elytratarget.spamdistance", 14.0F, 5.0F, 40.0F, 1.0F, var10008::method0492)).method1007("Spam masofasi").method2130("Agressiv qavgan uchun masofa");
      this.field1345 = new ElytraMovementPredictor(this.field0464, this.field1626, this.field1544, this.field1716);
      this.field1298 = new ElytraRotationController(this, this.field1345);
      this.field1373 = new ElytraTargetController(this, this.field1201, this.field0881, this.field0836, this.field0919);
      this.method1013("Elitradan parvoz paytida maqsadni nishab olish");
   }

   public boolean method1692() {
      return this.field0034.method1938();
   }

   public boolean method1755() {
      return this.field1432.method1938();
   }

   public boolean method2030() {
      return this.field0970.method1938();
   }

   public TargetPointMode method2008() {
      return (TargetPointMode)this.field0189.method0492();
   }

   public float method2035() {
      return field0796.field_1724 != null && field0796.field_1724.method_6128() ? (Float)this.field1144.method0492() : 0.0F;
   }

   public float method0461() {
      return Math.min((Float)this.field1097.method0492(), 3.0F);
   }

   public void method2078() {
      this.field1373.method0578();
      super.method2078();
   }

   @EventHandler
   public void onRotationUpdate(RotationUpdateEvent var1) {
      if (var1.method1760() == 0) {
         this.field1298.method0025();
      }

   }

   @EventHandler
   public void onPlayerTick(PlayerTickEvent var1) {
      this.field1373.method0025();
   }

   public class_243 method1157(class_1309 var1) {
      return var1 == null ? null : var1.method_19538().method_1031((double)0.0F, (double)var1.method_17682() * (double)0.5F, (double)0.0F);
   }

   public class_238 method1169(class_1309 var1, class_243 var2) {
      if (var1 != null && var2 != null) {
         double var3 = (double)var1.method_17681() * (double)0.5F;
         double var5 = (double)var1.method_17682() * (double)0.5F;
         return new class_238(var2.field_1352 - var3, var2.field_1351 - var5, var2.field_1350 - var3, var2.field_1352 + var3, var2.field_1351 + var5, var2.field_1350 + var3);
      } else {
         return null;
      }
   }
}
