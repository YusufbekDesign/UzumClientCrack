package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;

public class ChatCommandSuggestions {
   private static final float field0566 = 6.5F;
   private static final float field0003 = 8.0F;
   private static final float field1410 = 17.0F;
   private static final float field0957 = 10.0F;
   private static final float field0758 = 14.0F;
   private static final float field1242 = 6.0F;
   private static final float field0314 = 8.0F;
   private static final float field0177 = 18.0F;
   private static final float field0458 = 1.0F;
   private static final float field1614 = 6.0F;
   private static final float field1538 = 4.0F;
   private static final Color field1726 = new Color(21, 21, 27, 224);
   private static final Color field1153 = new Color(255, 255, 255, 255);
   private static final Color field1104 = new Color(255, 255, 255);
   private static final Color field1210 = new Color(255, 255, 255, 184);
   private boolean field0890 = false;
   private final StringBuilder field0842 = new StringBuilder();
   private int field0911 = 0;
   private int field1332 = -1;
   private final Animation field1305;
   private final Animation field1382;
   private long field0387;
   private static final long field0353 = 80L;
   private float field0423;
   private float field0255;
   private final List<Suggestion> field0238;
   private int field0290;

   public ChatCommandSuggestions() {
      this.field1305 = new Animation(250L, (double)1.0F, false, EasingCurve.field1011);
      this.field1382 = new Animation(280L, (double)1.0F, false, EasingCurve.field0203);
      this.field0387 = 0L;
      this.field0423 = 0.0F;
      this.field0255 = 0.0F;
      this.field0238 = new ArrayList();
      this.field0290 = -1;
   }

   public boolean method0579() {
      return this.field0890;
   }

   public void method1013(String prefix) {
      this.field0890 = true;
      this.field0842.setLength(0);
      this.field0842.append(prefix);
      this.field0911 = prefix.length();
      this.field1332 = -1;
      this.field1305.method1634();
      this.field1305.method1570(true);
      this.field1382.method1634();
      this.field0387 = System.currentTimeMillis();
      this.field0238.clear();
      this.field0290 = -1;
      this.method1973();
   }

   public void method0025() {
      this.field0890 = false;
      this.field0842.setLength(0);
      this.field0911 = 0;
      this.field1332 = -1;
      this.field0238.clear();
      this.field0290 = -1;
   }

   public void method1402(class_332 context, float screenWidth, float screenHeight) {
      if (this.field0890) {
         FontSize font = Fonts.field0075.method0654(6.5F);
         FontSize sugFont = Fonts.field0075.method0654(6.0F);
         class_4587 stack = context.method_51448();
         float vis = this.field1305.method0002();
         if (!(vis <= 0.01F)) {
            long elapsed = System.currentTimeMillis() - this.field0387;
            if (elapsed >= 80L && !this.field1382.method0376()) {
               this.field1382.method1634();
               this.field1382.method1570(true);
            }

            float sugVis = this.field1382.method0002();
            String displayText = this.field0842.toString();
            float textWidth = font.method0998(displayText);
            float textHeight = font.method0530();
            Color accent = ThemeColorManager.method1908().method2063();
            Color bg = ThemeColorManager.method1908().method0141(224);
            float minWidth = 50.0F;
            float targetWidth = Math.max(minWidth, textWidth + 16.0F + 2.0F);
            String ghostText = this.method0368();
            String hintText = ghostText.isEmpty() ? this.method0423() : "";
            String displayGhost = ghostText.isEmpty() ? hintText : ghostText;
            if (!displayGhost.isEmpty()) {
               targetWidth = Math.max(targetWidth, textWidth + font.method0998(displayGhost) + 16.0F + 2.0F);
            }

            this.field0423 = class_3532.method_16439(0.12F, this.field0423, targetWidth);
            float rectX = 4.0F;
            float rectY = screenHeight - 17.0F - 6.0F;
            float scaleX = Math.max(0.3F, vis);
            float scaleY = Math.max(0.3F, vis * vis);
            float pivotY = rectY + 8.5F;
            stack.method_22903();
            stack.method_46416(rectX, pivotY, 0.0F);
            stack.method_22905(scaleX, scaleY, 1.0F);
            stack.method_46416(-rectX, -pivotY, 0.0F);
            Color bgVis = this.method0964(bg, vis);
            Color borderVis = new Color(255, 255, 255, Math.max(0, (int)(10.0F * vis)));
            GuiRenderHelper.method1462(stack, rectX, rectY, this.field0423, 17.0F, 10.0F, 14.0F, this.method0964(field1153, vis));
            GuiRenderHelper.method1463(stack, rectX, rectY, this.field0423, 17.0F, 10.0F, bgVis);
            GuiRenderHelper.method1461(stack, rectX, rectY, this.field0423, 17.0F, 10.0F, 0.5F, 0.5F, borderVis);
            GuiRenderHelper.method1404(context, rectX, rectY, this.field0423, 17.0F);
            float textX = rectX + 8.0F;
            float textY = rectY + (17.0F - textHeight) / 2.0F;
            String prefix = ArbuzClient.method2004().method2257().method2067();
            if (displayText.startsWith(prefix)) {
               GuiRenderHelper.method1491(stack, font, prefix, textX, textY, this.method0964(accent, vis));
               float prefixW = font.method0998(prefix);
               String rest = displayText.substring(prefix.length());
               if (!rest.isEmpty()) {
                  GuiRenderHelper.method1491(stack, font, rest, textX + prefixW, textY, this.method0964(field1104, vis));
               }

               if (!displayGhost.isEmpty()) {
                  float ghostX = textX + font.method0998(displayText);
                  GuiRenderHelper.method1491(stack, font, displayGhost, ghostX, textY, new Color(255, 255, 255, Math.max(0, (int)(60.0F * vis))));
               }
            } else {
               GuiRenderHelper.method1491(stack, font, displayText, textX, textY, this.method0964(field1104, vis));
            }

            if (this.method2079()) {
               int selStart = Math.min(this.field1332, this.field0911);
               int selEnd = Math.max(this.field1332, this.field0911);
               String beforeSel = displayText.substring(0, Math.min(selStart, displayText.length()));
               String selText = displayText.substring(Math.min(selStart, displayText.length()), Math.min(selEnd, displayText.length()));
               float selX = textX + font.method0998(beforeSel);
               float selW = font.method0998(selText);
               Color selColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.max(0, (int)(80.0F * vis)));
               GuiRenderHelper.method1463(stack, selX, rectY + 3.0F, selW, 11.0F, 2.0F, selColor);
            }

            double cursorBlink = (double)0.5F + (double)0.5F * Math.sin((double)System.currentTimeMillis() / (double)150.0F);
            int cursorAlpha = (int)(cursorBlink * (double)255.0F * (double)vis);
            String beforeCursor = displayText.substring(0, Math.min(this.field0911, displayText.length()));
            float cursorX = textX + font.method0998(beforeCursor);
            float cursorH = 7.0F;
            float cursorYPos = rectY + (17.0F - cursorH) / 2.0F;
            GuiRenderHelper.method0326(stack, cursorX, cursorYPos, 1.0F, cursorH, 1.0F, new Color(255, 255, 255, Math.max(0, cursorAlpha)));
            GuiRenderHelper.method1400(context);
            stack.method_22909();
            if (!this.field0238.isEmpty() && sugVis > 0.01F) {
               float targetSugH = (float)this.field0238.size() * 18.0F + (float)(this.field0238.size() - 1) * 1.0F;
               this.field0255 = class_3532.method_16439(0.15F, this.field0255, targetSugH);
               FontSize descIconFont = Fonts.field0774.method0654(4.5F);
               float sugW = 0.0F;

               for(Suggestion entry : this.field0238) {
                  float w = sugFont.method0998(entry.display) + 16.0F;
                  if (entry.description != null) {
                     w += 10.0F + descIconFont.method0998("d") + 5.0F + sugFont.method0998(entry.description);
                  }

                  sugW = Math.max(sugW, w);
               }

               sugW = Math.max(sugW, this.field0423);
               float sugX = rectX;
               float sugY = rectY - this.field0255 - 2.0F;
               float sugScaleX = Math.max(0.3F, sugVis);
               float sugScaleY = Math.max(0.3F, sugVis * sugVis);
               float sugPivotY = sugY + this.field0255 / 2.0F;
               stack.method_22903();
               stack.method_46416(rectX, sugPivotY, 0.0F);
               stack.method_22905(sugScaleX, sugScaleY, 1.0F);
               stack.method_46416(-rectX, -sugPivotY, 0.0F);
               Color sugBgVis = this.method0964(bg, sugVis);
               Color sugBorderVis = new Color(255, 255, 255, Math.max(0, (int)(10.0F * sugVis)));
               GuiRenderHelper.method1462(stack, rectX, sugY, sugW, this.field0255, 10.0F, 14.0F, this.method0964(field1153, sugVis));
               GuiRenderHelper.method1463(stack, rectX, sugY, sugW, this.field0255, 10.0F, sugBgVis);
               GuiRenderHelper.method1461(stack, rectX, sugY, sugW, this.field0255, 10.0F, 0.5F, 0.5F, sugBorderVis);
               GuiRenderHelper.method1404(context, rectX, sugY, sugW, this.field0255);
               float itemY = sugY;

               for(int i = 0; i < this.field0238.size(); ++i) {
                  Suggestion entry = (Suggestion)this.field0238.get(i);
                  if (i == this.field0290) {
                     Color selColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.max(0, (int)(28.0F * sugVis)));
                     GuiRenderHelper.method1463(stack, sugX + 3.0F, itemY + 3.0F, sugW - 6.0F, 12.5F, 10.0F, selColor);
                  }

                  float nameX = sugX + 8.0F;
                  float nameY = itemY + (18.0F - sugFont.method0530()) / 2.0F;
                  Color nameColor = this.method0964(i == this.field0290 ? accent : field1104, sugVis);
                  GuiRenderHelper.method1491(stack, sugFont, entry.display, nameX, nameY, nameColor);
                  if (entry.description != null) {
                     FontSize iconFont = Fonts.field0774.method0654(4.5F);
                     float iconX = nameX + sugFont.method0998(entry.display) + 10.0F;
                     float iconY = itemY + (18.0F - iconFont.method0530()) / 2.0F;
                     GuiRenderHelper.method1491(stack, iconFont, "d", iconX, iconY - 0.5F, new Color(255, 255, 255, Math.max(0, (int)(80.0F * sugVis))));
                     float descX = iconX + iconFont.method0998("d") + 5.0F;
                     GuiRenderHelper.method1491(stack, sugFont, entry.description, descX, nameY, new Color(255, 255, 255, Math.max(0, (int)(80.0F * sugVis))));
                  }

                  if (i < this.field0238.size() - 1) {
                     float sepY = itemY + 18.0F;
                     GuiRenderHelper.method1463(stack, sugX + 8.0F, sepY, sugW - 16.0F, 0.5F, 0.0F, new Color(255, 255, 255, Math.max(0, (int)(15.0F * sugVis))));
                  }

                  itemY += 19.0F;
               }

               GuiRenderHelper.method1400(context);
               stack.method_22909();
            } else {
               this.field0255 = class_3532.method_16439(0.15F, this.field0255, 0.0F);
            }

         }
      }
   }

   private Color method0964(Color c, float vis) {
      return vis >= 0.99F ? c : new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, (int)((float)c.getAlpha() * vis)));
   }

   public boolean method0746(int keyCode, int scanCode, int modifiers) {
      if (!this.field0890) {
         return false;
      } else {
         boolean ctrl = (modifiers & 2) != 0;
         String prefix = ArbuzClient.method2004().method2257().method2067();
         int minPos = prefix.length();
         if (keyCode == 256) {
            this.method0025();
            return true;
         } else if (keyCode != 257 && keyCode != 335) {
            if (keyCode == 258) {
               this.method0498();
               return true;
            } else if (ctrl && keyCode == 65) {
               this.field1332 = minPos;
               this.field0911 = this.field0842.length();
               return true;
            } else if (ctrl && keyCode == 67) {
               String selected = this.method1619();
               if (!selected.isEmpty()) {
                  GLFW.glfwSetClipboardString(class_310.method_1551().method_22683().method_4490(), selected);
               }

               return true;
            } else if (ctrl && keyCode == 86) {
               String clipboard = GLFW.glfwGetClipboardString(class_310.method_1551().method_22683().method_4490());
               if (clipboard != null && !clipboard.isEmpty()) {
                  this.method1812();
                  this.field0842.insert(this.field0911, clipboard);
                  this.field0911 += clipboard.length();
                  this.method1973();
               }

               return true;
            } else if (ctrl && keyCode == 88) {
               String selected = this.method1619();
               if (!selected.isEmpty()) {
                  GLFW.glfwSetClipboardString(class_310.method_1551().method_22683().method_4490(), selected);
                  this.method1812();
                  this.method1973();
               }

               return true;
            } else if (ctrl && keyCode == 259) {
               if (this.method2079()) {
                  this.method1812();
               } else if (this.field0911 > minPos) {
                  int pos;
                  for(pos = this.field0911; pos > minPos && this.field0842.charAt(pos - 1) == ' '; --pos) {
                  }

                  while(pos > minPos && this.field0842.charAt(pos - 1) != ' ') {
                     --pos;
                  }

                  this.field0842.delete(pos, this.field0911);
                  this.field0911 = pos;
               }

               this.field1332 = -1;
               this.method1973();
               return true;
            } else if (keyCode == 265) {
               if (!this.field0238.isEmpty()) {
                  this.field0290 = this.field0290 <= 0 ? this.field0238.size() - 1 : this.field0290 - 1;
               }

               return true;
            } else if (keyCode == 264) {
               if (!this.field0238.isEmpty()) {
                  this.field0290 = (this.field0290 + 1) % this.field0238.size();
               }

               return true;
            } else if (keyCode == 259) {
               if (this.method2079()) {
                  this.method1812();
                  this.method1973();
                  return true;
               } else {
                  if (this.field0911 > 0) {
                     if (this.field0911 <= minPos && this.field0842.toString().startsWith(prefix)) {
                        this.method0025();
                        return true;
                     }

                     this.field0842.deleteCharAt(this.field0911 - 1);
                     --this.field0911;
                     this.method1973();
                  }

                  return true;
               }
            } else if (keyCode == 261) {
               if (this.method2079()) {
                  this.method1812();
                  this.method1973();
                  return true;
               } else {
                  if (this.field0911 < this.field0842.length()) {
                     this.field0842.deleteCharAt(this.field0911);
                     this.method1973();
                  }

                  return true;
               }
            } else if (keyCode == 263) {
               this.field1332 = -1;
               if (!ctrl) {
                  if (this.field0911 > minPos) {
                     --this.field0911;
                  }
               } else {
                  while(this.field0911 > minPos && this.field0842.charAt(this.field0911 - 1) == ' ') {
                     --this.field0911;
                  }

                  while(this.field0911 > minPos && this.field0842.charAt(this.field0911 - 1) != ' ') {
                     --this.field0911;
                  }
               }

               return true;
            } else if (keyCode != 262) {
               if (keyCode == 268) {
                  this.field1332 = -1;
                  this.field0911 = minPos;
                  return true;
               } else if (keyCode == 269) {
                  this.field1332 = -1;
                  this.field0911 = this.field0842.length();
                  return true;
               } else {
                  return false;
               }
            } else {
               this.field1332 = -1;
               if (!ctrl) {
                  if (this.field0911 < this.field0842.length()) {
                     ++this.field0911;
                  }
               } else {
                  while(this.field0911 < this.field0842.length() && this.field0842.charAt(this.field0911) != ' ') {
                     ++this.field0911;
                  }

                  while(this.field0911 < this.field0842.length() && this.field0842.charAt(this.field0911) == ' ') {
                     ++this.field0911;
                  }
               }

               return true;
            }
         } else {
            String input = this.field0842.toString();
            if (!input.isEmpty()) {
               ArbuzClient.method2004().method2257().method0214(input);
            }

            this.method0025();
            class_310.method_1551().method_1507((class_437)null);
            return true;
         }
      }
   }

   private boolean method2079() {
      return this.field1332 != -1 && this.field1332 != this.field0911;
   }

   private void method1812() {
      if (this.method2079()) {
         int start = Math.min(this.field1332, this.field0911);
         int end = Math.max(this.field1332, this.field0911);
         String prefix = ArbuzClient.method2004().method2257().method2067();
         start = Math.max(start, prefix.length());
         this.field0842.delete(start, end);
         this.field0911 = start;
         this.field1332 = -1;
      }
   }

   private String method1619() {
      if (this.method2079()) {
         int start = Math.min(this.field1332, this.field0911);
         int end = Math.max(this.field1332, this.field0911);
         return this.field0842.substring(start, end);
      } else {
         String prefix = ArbuzClient.method2004().method2257().method2067();
         return this.field0842.length() > prefix.length() ? this.field0842.substring(prefix.length()) : "";
      }
   }

   public boolean method0607(char chr, int modifiers) {
      if (!this.field0890) {
         return false;
      } else if (chr < ' ') {
         return false;
      } else {
         this.method1812();
         this.field0842.insert(this.field0911, chr);
         ++this.field0911;
         this.method1973();
         return true;
      }
   }

   private void method1973() {
      this.field0238.clear();
      this.field0290 = -1;
      String prefix = ArbuzClient.method2004().method2257().method2067();
      String input = this.field0842.toString();
      if (input.startsWith(prefix)) {
         String afterPrefix = input.substring(prefix.length());
         if (afterPrefix.contains(" ")) {
            String[] parts = afterPrefix.split(" ", -1);
            String cmdName = parts[0];
            String[] args = new String[parts.length - 1];
            System.arraycopy(parts, 1, args, 0, args.length);

            for(Command cmd : ArbuzClient.method2004().method2257().method0018()) {
               if (cmd.method0214(cmdName)) {
                  List<String> completions = cmd.method1593(args);
                  Map<String, String> descriptions = cmd.method0351(args);
                  StringBuilder baseBuilder = (new StringBuilder(prefix)).append(cmdName);

                  for(int i = 0; i < args.length - 1; ++i) {
                     baseBuilder.append(' ').append(args[i]);
                  }

                  String base = baseBuilder.toString();

                  for(String c : completions) {
                     this.field0238.add(new Suggestion(c, (String)descriptions.get(c), base + " " + c));
                  }
                  break;
               }
            }
         } else {
            String lowerInput = afterPrefix.toLowerCase();

            for(Command cmd : ArbuzClient.method2004().method2257().method0018()) {
               if (!lowerInput.isEmpty() && !cmd.method0557().toLowerCase().startsWith(lowerInput)) {
                  for(String alias : cmd.method0019()) {
                     if (alias.toLowerCase().startsWith(lowerInput)) {
                        this.field0238.add(new Suggestion(alias + " (" + cmd.method0557() + ")", cmd.method2067(), prefix + alias));
                        break;
                     }
                  }
               } else {
                  this.field0238.add(new Suggestion(cmd.method0557(), cmd.method2067(), prefix + cmd.method0557()));
               }
            }
         }

      }
   }

   private String method0423() {
      String prefix = ArbuzClient.method2004().method2257().method2067();
      String input = this.field0842.toString();
      if (!input.startsWith(prefix)) {
         return "";
      } else {
         String afterPrefix = input.substring(prefix.length());
         if (!afterPrefix.contains(" ")) {
            return "";
         } else {
            String[] parts = afterPrefix.split(" ", -1);
            String cmdName = parts[0];
            String[] args = new String[parts.length - 1];
            System.arraycopy(parts, 1, args, 0, args.length);
            String lastArg = args.length > 0 ? args[args.length - 1] : "";
            if (!lastArg.isEmpty()) {
               return "";
            } else {
               for(Command cmd : ArbuzClient.method2004().method2257().method0018()) {
                  if (cmd.method0214(cmdName)) {
                     return cmd.method2179(args);
                  }
               }

               return "";
            }
         }
      }
   }

   private String method0368() {
      String prefix = ArbuzClient.method2004().method2257().method2067();
      String input = this.field0842.toString();
      if (!input.startsWith(prefix)) {
         return "";
      } else {
         String afterPrefix = input.substring(prefix.length());
         if (afterPrefix.contains(" ")) {
            String[] parts = afterPrefix.split(" ", -1);
            String cmdName = parts[0];
            String[] args = new String[parts.length - 1];
            System.arraycopy(parts, 1, args, 0, args.length);
            String lastArg = args.length > 0 ? args[args.length - 1] : "";

            for(Command cmd : ArbuzClient.method2004().method2257().method0018()) {
               if (cmd.method0214(cmdName)) {
                  List<String> completions = cmd.method1593(args);
                  if (!completions.isEmpty()) {
                     String completion = (String)completions.get(0);
                     if (completion.toLowerCase().startsWith(lastArg.toLowerCase()) && !completion.equalsIgnoreCase(lastArg)) {
                        return completion.substring(lastArg.length());
                     }
                  }
                  break;
               }
            }
         } else {
            String lowerInput = afterPrefix.toLowerCase();

            for(Command cmd : ArbuzClient.method2004().method2257().method0018()) {
               if (cmd.method0557().toLowerCase().startsWith(lowerInput) && !cmd.method0557().equalsIgnoreCase(afterPrefix)) {
                  return cmd.method0557().substring(afterPrefix.length());
               }

               for(String alias : cmd.method0019()) {
                  if (alias.toLowerCase().startsWith(lowerInput) && !alias.equalsIgnoreCase(afterPrefix)) {
                     return alias.substring(afterPrefix.length());
                  }
               }
            }
         }

         return "";
      }
   }

   private void method0498() {
      if (this.field0290 >= 0 && this.field0290 < this.field0238.size()) {
         Suggestion entry = (Suggestion)this.field0238.get(this.field0290);
         this.field0842.setLength(0);
         this.field0842.append(entry.fullText).append(' ');
         this.field0911 = this.field0842.length();
         this.method1973();
      } else {
         String ghost = this.method0368();
         if (!ghost.isEmpty()) {
            this.field0842.insert(this.field0911, ghost);
            this.field0911 += ghost.length();
            this.field0842.append(' ');
            ++this.field0911;
            this.method1973();
         }

      }
   }

   private static record Suggestion(String display, String description, String fullText) {
      public String method0557() {
         return this.display;
      }

      public String method0017() {
         return this.description;
      }

      public String method2067() {
         return this.fullText;
      }
   }
}
