package aethereal;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class SwordTrailBuffer {
   private final Deque<SwordTrailSample> field0718 = new ArrayDeque();
   private int field0004 = 40;

   public void method0729(int capacity) {
      this.field0004 = Math.max(2, capacity);

      while(this.field0718.size() > this.field0004) {
         this.field0718.pollFirst();
      }

   }

   public void method0827(SwordTrailSample s) {
      this.field0718.addLast(s);

      while(this.field0718.size() > this.field0004) {
         this.field0718.pollFirst();
      }

   }

   public void method0578() {
      this.field0718.clear();
   }

   public int method0003() {
      return this.field0718.size();
   }

   public Iterable<SwordTrailSample> method2065() {
      return this.field0718;
   }

   public SwordTrailSample method1773() {
      return (SwordTrailSample)this.field0718.peekLast();
   }

   public SwordTrailSample method1187(class_1657 player, float tickDelta) {
      class_310 mc = class_310.method_1551();
      class_243 eye = player.method_5836(tickDelta);
      class_243 look = player.method_5828(tickDelta).method_1029();
      class_1799 stack = player.method_6047();
      float blade = method1238(stack);
      class_243 right = look.method_1036(new class_243((double)0.0F, (double)1.0F, (double)0.0F)).method_1029();
      if (right.method_1027() < 1.0000000022797057E-6) {
         right = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
      }

      class_243 down = look.method_1036(right).method_1029();
      class_243 root = eye.method_1019(right.method_1021((double)0.25F)).method_1019(down.method_1021(-0.2000000471773113)).method_1019(look.method_1021((double)0.5F));
      class_243 tip = root.method_1019(look.method_1021((double)blade));
      float swing = player.method_6055(tickDelta);
      long tickStamp = mc.field_1687 != null ? mc.field_1687.method_8510() : 0L;
      return new SwordTrailSample(tip, root, swing, tickStamp);
   }

   public static float method1238(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         if (stack.method_7909() instanceof class_1829) {
            return 0.8F;
         } else if (stack.method_7909() instanceof class_1743) {
            return 0.7F;
         } else if (stack.method_7909() instanceof class_1810) {
            return 0.6F;
         } else if (stack.method_7909() instanceof class_1821) {
            return 0.6F;
         } else {
            return stack.method_7909() instanceof class_1766 ? 0.6F : 0.5F;
         }
      } else {
         return 0.5F;
      }
   }

   public void method0782(long currentTick, long maxAgeTicks) {
      Iterator<SwordTrailSample> it = this.field0718.iterator();

      while(it.hasNext()) {
         SwordTrailSample s = (SwordTrailSample)it.next();
         if (currentTick - s.method1764() <= maxAgeTicks) {
            break;
         }

         it.remove();
      }

   }
}
