package aethereal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1684;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2637;
import net.minecraft.class_2653;
import net.minecraft.class_266;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2775;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3944;
import net.minecraft.class_3988;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_5134;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_7439;
import net.minecraft.class_7924;
import net.minecraft.class_8646;
import net.minecraft.class_9279;
import net.minecraft.class_9285;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.apache.commons.lang3.StringUtils;

public class ServerAssist extends Module {
   private static final String field0136 = "ServerAssist";
   private final EnumSetting<ServerMode> field1448;
   private final BooleanSetting field0970;
   private final BooleanSetting field0184;
   private final BooleanSetting field0464;
   private final BooleanSetting field1619;
   private final MultiSelectSetting field1562;
   private final BooleanSetting field1709;
   private final MultiSelectSetting field1152;
   private final BooleanSetting field1093;
   private final BooleanSetting field1201;
   private final BooleanSetting field0875;
   private final BooleanSetting field0830;
   private final KeyBindListSetting field0926;
   private final List<TrackedPlayer> field1347;
   private final Map<String, PendingAction> field1309;
   private final Map<String, Boolean> field1385;
   private final Map<String, Long> field0401;
   private final List<String> field0366;
   private final Stopwatch field0433;
   private ActionState field0266;
   private long field0228;
   private long field0291;
   private int field0524;
   private int field0502;
   private int field0548;
   private String field1681;
   private boolean field1665;
   private boolean field1699;
   private boolean field1597;
   private boolean field1586;
   private boolean field1609;
   private final Map<class_2338, class_2680> field1760;
   private final List<EventInfo> field1746;
   private final List<ItemPosition> field1772;
   private final Map<Integer, class_1792> field1180;
   private final Map<String, Float> field1170;
   private final Stopwatch field1189;
   private final Stopwatch field1123;
   private final Stopwatch field1115;
   private final Stopwatch field1133;
   private final Stopwatch field1231;
   private final Stopwatch field1223;
   private final Stopwatch field1237;
   private boolean field0903;
   private String field0895;
   private boolean field0907;
   private int field0856;
   private UUID field0852;
   private UUID field0868;
   private static final Set<String> field0944 = new HashSet(Arrays.asList("Маяк убийца", "Вулкан", "Сундук смерти", "Адская резня", "Мистический сундук", "Гейзер", "Метеоритный дождь"));
   private int field0934;
   private boolean field0953;
   private final Stopwatch field1357;
   private String field1352;
   private final Set<String> field1365;
   private final List<TrackedItem> field1323;
   private String field1317;
   private boolean field1328;
   private int field1396;
   private long field1391;

   public ServerAssist() {
      super("ServerAssist", ModuleCategory.field0776, "Server keybind helper");
      this.field1448 = (EnumSetting)(new EnumSetting("serverassist.mode", ServerAssist.ServerMode.field1483)).method1007("Server Type").method2130("Тип сервера");
      this.field0970 = (BooleanSetting)(new BooleanSetting("serverassist.autoloot", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field0108)).method1007("Auto Loot").method2130("Авто-лут с ботов на ивенте");
      this.field0184 = (BooleanSetting)(new BooleanSetting("serverassist.autoshulker", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field0108)).method1007("Auto Shulker").method2130("Авто-складывание лута в шалкер");
      this.field0464 = (BooleanSetting)(new BooleanSetting("serverassist.autorepair", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field0108)).method1007("Auto Repair").method2130("Авто-ремонт брони пузырём опыта");
      this.field1619 = (BooleanSetting)(new BooleanSetting("serverassist.orbswap", false, () -> this.field1448.method0492() == ServerAssist.ServerMode.field0682)).method1007("Swap Orb").method2130("Свапать шар на тот что лучше по урону");
      this.field1562 = (MultiSelectSetting)(new MultiSelectSetting("serverassist.orbswap.conditions", Arrays.asList("Lower Health", "Enemy Eating", "Player Retreating", "Popped Totem"), false, () -> this.field1448.method0492() == ServerAssist.ServerMode.field0682 && (Boolean)this.field1619.method0492())).method1007("Swap Conditions").method2130("Какие условия проверять перед свапом шара (любое из выбранных)");
      this.field1709 = (BooleanSetting)(new BooleanSetting("serverassist.funtimeorbswap", false, () -> this.field1448.method0492() == ServerAssist.ServerMode.field1483)).method1007("Swap Item").method2130("Свапать сферу или талик в нужный момент на тот что лучше по урону");
      this.field1152 = (MultiSelectSetting)(new MultiSelectSetting("serverassist.funtimeorbswap.conditions", Arrays.asList("Enemy Eating", "Player Retreating", "Popped Totem"), false, () -> this.field1448.method0492() == ServerAssist.ServerMode.field1483 && (Boolean)this.field1709.method0492())).method1007("Swap Conditions").method2130("Какие условия проверять перед свапом предмета (любое из выбранных)");
      this.field1093 = (BooleanSetting)(new BooleanSetting("serverassist.consumables", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field1483)).method1007("Trap Tracker").method2130("Засекать таймер взрывных трапок");
      this.field1201 = (BooleanSetting)(new BooleanSetting("serverassist.autopoint", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field1483)).method1007("Auto Point").method2130("Ставить метки на ивенты");
      this.field0875 = (BooleanSetting)(new BooleanSetting("serverassist.eventcheck", true, () -> this.field1448.method0492() == ServerAssist.ServerMode.field1483)).method1007("Check Events").method2130("Проверять ивенты на анархии");
      this.field0830 = (BooleanSetting)(new BooleanSetting("serverassist.displayonscreen", true)).method1007("Display On Screen").method2130("Отображать предметы и их задержку на экране");
      this.field0926 = (KeyBindListSetting)(new KeyBindListSetting("serverassist.binds")).method1007("Server Binds").method0210("Per-mode consumable hotkeys").method2130("Бинды расходников по выбранному серверу");
      this.field1347 = new ArrayList();
      this.field1309 = new HashMap();
      this.field1385 = new HashMap();
      this.field0401 = new HashMap();
      this.field0366 = new ArrayList();
      this.field0433 = new Stopwatch();
      this.field0266 = ServerAssist.ActionState.field0681;
      this.field0228 = 0L;
      this.field0291 = 0L;
      this.field0524 = -1;
      this.field0502 = -1;
      this.field0548 = -1;
      this.field1681 = null;
      this.field1665 = false;
      this.field1760 = new HashMap();
      this.field1746 = new ArrayList();
      this.field1772 = new ArrayList();
      this.field1180 = new HashMap();
      this.field1170 = new HashMap();
      this.field1189 = new Stopwatch();
      this.field1123 = new Stopwatch();
      this.field1115 = new Stopwatch();
      this.field1133 = new Stopwatch();
      this.field1231 = new Stopwatch();
      this.field1223 = new Stopwatch();
      this.field1237 = new Stopwatch();
      this.field0903 = false;
      this.field0895 = null;
      this.field0907 = false;
      this.field0856 = 0;
      this.field0852 = null;
      this.field0934 = -1;
      this.field0953 = false;
      this.field1357 = new Stopwatch();
      this.field1352 = null;
      this.field1365 = new HashSet();
      this.field1323 = new ArrayList();
      this.field1317 = null;
      this.field1328 = false;
      this.field1396 = 0;
      this.field1391 = 0L;
      this.method1013("Помощник для комфортный игры на серверах");
      this.method0213("A");
      this.method2015();
      this.method2043();
      this.method2029();
   }

   public static ServerAssist method1717() {
      ArbuzClient arbuz = ArbuzClient.method2004();
      return arbuz != null && arbuz.method1783() != null ? (ServerAssist)arbuz.method1783().method0976(ServerAssist.class) : null;
   }

   public boolean method1692() {
      return this.method2195() && this.field1448.method0492() == ServerAssist.ServerMode.field0682;
   }

   private void method2029() {
      for(TrackedPlayer b : this.field1347) {
         this.field0926.method0884(b.field1259, b.field1519, () -> this.field1448.method0492() == b.field1014);
      }

      if (!this.method1914().contains(this.field0926)) {
         this.method1914().add(this.field0926);
      }

   }

   private void method2015() {
      this.method1052("Анти полёт", "антиполет", class_1802.field_8450, ServerAssist.ServerMode.field0682, 0);
      this.method1052("Свиток опыта", "свитокопыта", class_1802.field_8498, ServerAssist.ServerMode.field0682, 0);
      this.method1052("Взрывная трапка", "взрывнаятрапка", class_1802.field_8662, ServerAssist.ServerMode.field0108, 5);
      this.method1052("Обычная трапка", "трапка", class_1802.field_8882, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Стан", "стан", class_1802.field_8137, ServerAssist.ServerMode.field0108, 30);
      this.method1052("Взрывная штучка", "взрывнаяштучка", class_1802.field_8814, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Снежок HW", "снежок", class_1802.field_8543, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Светильник Джека", "светильникджека", class_1802.field_8693, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Пузырь опыта", "пузырьопыта", class_1802.field_8287, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Рюкзак 1 уровня", "рюкзак(iуровень)", class_1802.field_8520, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Рюкзак 2 уровня", "рюкзак(iiуровень)", class_1802.field_8350, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Рюкзак 3 уровня", "рюкзак(iiiуровень)", class_1802.field_8676, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Рюкзак 4 уровня", "рюкзак(ivуровень)", class_1802.field_8520, ServerAssist.ServerMode.field0108, 0);
      this.method1052("Божья аура", "божьяаура", class_1802.field_8614, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Арбалет", "арбалет", class_1802.field_8399, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Трапка", "трапка", class_1802.field_22021, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Пласт", "пласт", class_1802.field_8551, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Явная пыль", "явная", class_1802.field_8479, ServerAssist.ServerMode.field1483, 10);
      this.method1052("Огненный смерч", "огненныйсмерч", class_1802.field_8814, ServerAssist.ServerMode.field1483, 10);
      this.method1052("Дезориентация", "дезориентация", class_1802.field_8449, ServerAssist.ServerMode.field1483, 10);
      this.method1052("Снежок заморозка", "снежокзаморозка", class_1802.field_8543, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье отрыжки", "отрыжки", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье серной кислоты", "серная", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье вспышки", "вспышка", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье мочи Флеша", "мочафлеша", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье победителя", "победителя", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье агента", "агента", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье медика", "медика", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
      this.method1052("Зелье киллера", "киллера", class_1802.field_8436, ServerAssist.ServerMode.field1483, 0);
   }

   private void method2043() {
      for(TrackedPlayer b : this.field1347) {
         this.field1309.put(b.field0715, new PendingAction(b.field0136, b.field1519, b.field0715));
         this.field1385.put(b.field0715, false);
      }

   }

   private void method1052(String displayName, String searchName, class_1792 item, ServerMode requiredMode, int cooldownSec) {
      KeyBindSetting setting = (KeyBindSetting)(new KeyBindSetting("serverassist.bind." + displayName, new KeyBind(-1, false, false), () -> false)).method1007(displayName).method2130("Клавиша: " + displayName);
      TrackedPlayer bind = new TrackedPlayer(displayName, searchName, item, requiredMode, cooldownSec, setting);
      this.field1347.add(bind);
      if (!this.method1914().contains(setting)) {
         this.method1914().add(setting);
      }

   }

   public void method0025() {
      super.method0025();
      HudWidgetManager.method1605().method1019("ServerAssist", 10.0F, 200.0F, 22.0F, 25.0F);
      this.method0471();
   }

   public void method2078() {
      if (this.field1665) {
         this.method2251();
      }

      this.method0398();
      this.method0471();
      super.method2078();
   }

   private void method0471() {
      this.field1180.clear();
      this.field0366.clear();
      this.field0433.method1812();
      this.field1385.replaceAll((k, v) -> false);
      this.field0266 = ServerAssist.ActionState.field0681;
      this.field0524 = -1;
      this.field0502 = -1;
      this.field0548 = -1;
      this.field1681 = null;
      this.field0291 = 0L;
      this.field1665 = false;
      this.field0903 = false;
      this.field0895 = null;
      this.field0907 = false;
      this.field0856 = 0;
      this.field0852 = null;
      this.field1231.method1812();
      this.field1223.method0436(0L);
      this.field1237.method0436(0L);
      this.field0934 = -1;
      this.field0953 = false;
      this.field1352 = null;
      this.field1365.clear();
      this.field1317 = null;
      this.field1328 = false;
      this.field1396 = 0;
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound e) {
      if (field0796.field_1724 != null && field0796.field_1687 != null) {
         class_2596 var7 = e.method1970();
         if (var7 instanceof class_2775) {
            class_2775 pickup = (class_2775)var7;
            this.method1374(pickup);
         } else {
            var7 = e.method1970();
            if (var7 instanceof class_2653) {
               class_2653 slot = (class_2653)var7;
               this.method1358(slot);
            } else {
               var7 = e.method1970();
               if (var7 instanceof class_2637) {
                  class_2637 chunkDelta = (class_2637)var7;
                  if ((Boolean)this.field1093.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field1483) {
                     this.method1357(chunkDelta);
                     return;
                  }
               }

               var7 = e.method1970();
               if (var7 instanceof class_7439) {
                  class_7439 gameMessage = (class_7439)var7;
                  this.method1537(gameMessage);
               } else {
                  var7 = e.method1970();
                  if (var7 instanceof class_3944) {
                     class_3944 openScreen = (class_3944)var7;
                     if (openScreen.method_17594().getString().contains("Рюкзак") && !this.field1180.isEmpty()) {
                     }
                  }
               }
            }
         }

      }
   }

   private void method1374(class_2775 pickup) {
      if ((Boolean)this.field0184.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field0108) {
         if (pickup.method_11912() == field0796.field_1724.method_5628()) {
            class_1297 var3 = field0796.field_1687.method_8469(pickup.method_11915());
            if (var3 instanceof class_1542) {
               class_1542 entity = (class_1542)var3;
               class_1799 stack = entity.method_6983();
               if (stack.method_57824(class_9334.field_49622) == null) {
                  this.field1180.put(-MathHelper.method0736(1, 999999999), stack.method_7909());
                  this.field1123.method1812();
               }

            }
         }
      }
   }

   private void method1358(class_2653 pkt) {
      if (pkt.method_11452() == 0) {
         class_1792 item = pkt.method_11449().method_7909();
         new ArrayList();
         Integer updateKey = null;

         for(Map.Entry<Integer, class_1792> entry : this.field1180.entrySet()) {
            if ((Integer)entry.getKey() < 0 && ((class_1792)entry.getValue()).equals(item)) {
               updateKey = (Integer)entry.getKey();
               break;
            }
         }

         if (updateKey != null) {
            this.field1180.put(pkt.method_11450() + 18, item);
            this.field1180.remove(updateKey);
         }

      }
   }

   private void method1357(class_2637 chunkDelta) {
      chunkDelta.method_30621((pos, state) -> this.field1760.put(pos, state));
      if (this.field1760.size() > 50 && this.field1760.size() < 600) {
         chunkDelta.method_30621((pos, state) -> {
            class_243 vec = pos.method_46558();
            if (this.method1264(pos.method_10086(2))) {
               this.method1235(class_1802.field_22021, vec, (double)(System.currentTimeMillis() + 15000L));
            } else if (this.method0279(pos.method_10086(3))) {
               this.method1235(class_1802.field_22021, vec, (double)(System.currentTimeMillis() + 30000L));
            }

         });
      }

   }

   private void method1537(class_7439 gameMessage) {
      class_2561 content = gameMessage.comp_763();
      String contentString = content.toString();
      String message = content.getString();
      if ((Boolean)this.field1201.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field1483) {
         String name = StringUtils.substringBetween(message, "||| [", "] ");
         if (name != null) {
            String position = StringUtils.substringBetween(contentString, "value='/gps ", "'");
            String lvl = StringUtils.substringBetween(message, "Уровень лута: ", "\n ║");
            String owner = StringUtils.substringBetween(message, "Призван игроком: ", "\n ║");
            if (position != null) {
               String[] pose = position.split(" ");

               try {
                  class_243 center = class_2338.method_49637((double)Integer.parseInt(pose[0]), (double)Integer.parseInt(pose[1]), (double)Integer.parseInt(pose[2])).method_46558();
                  switch (name) {
                     case "Мистический сундук":
                        this.method1049(name, lvl, owner, center, "overworld", 300, 0);
                        break;
                     case "Вулкан":
                        this.method1049(name, lvl, owner, center, "overworld", 300, 120);
                        break;
                     case "Метеоритный дождь":
                     case "Маяк убийца":
                     case "Мистический Алтарь":
                        this.method1049(name, lvl, owner, center, "overworld", 360, 0);
                        break;
                     case "Загадочный маяк":
                        this.method1049(name, lvl, owner, center, "overworld", 60, 180);
                  }
               } catch (NumberFormatException var14) {
               }
            } else {
               switch (name) {
                  case "Сундук смерти" -> this.method1049(name, lvl, owner, class_2338.method_49637((double)-155.0F, (double)64.0F, (double)205.0F).method_46558(), "lobby", 300, 0);
                  case "Адская резня" -> this.method1049(name, lvl, owner, class_2338.method_49637((double)48.0F, (double)87.0F, (double)73.0F).method_46558(), "lobby", 180, 120);
               }
            }
         }
      }

      if (this.field0934 >= 0) {
         this.method2134(message);
      }

      if (message.contains("▶ Повторно активировать Пузырь опыта возможно через")) {
         String subString = StringUtils.substringBetween(message, "через ", " секунд");
         if (subString != null && !subString.isEmpty()) {
            try {
               int duration = Integer.parseInt(subString) * 20;
               class_1796 manager = field0796.field_1724.method_7357();
               manager.method_62835(class_1802.field_8287.method_7854(), duration);
            } catch (NumberFormatException var13) {
            }
         }
      }

   }

   private int method0451() {
      if (field0796.field_1687 != null && ServerEnvironment.method0376()) {
         class_269 sb = field0796.field_1687.method_8428();
         class_266 obj = sb.method_1189(class_8646.field_45157);
         if (obj == null) {
            return -1;
         } else {
            String title = obj.method_1114().getString();
            if (!title.contains("Анархия")) {
               return -1;
            } else {
               Matcher m = Pattern.compile("Анархия\\D*(\\d+)").matcher(title);
               if (m.find()) {
                  try {
                     return Integer.parseInt(m.group(1));
                  } catch (NumberFormatException var6) {
                  }
               }

               return 0;
            }
         }
      } else {
         return -1;
      }
   }

   private void method0479() {
      boolean active = this.field1448.method0492() == ServerAssist.ServerMode.field1483 && (Boolean)this.field0875.method0492();
      int num = active ? this.method0451() : -1;
      if (num >= 0 && num != this.field0934) {
         this.method0398();
         this.method0410();
         this.field1365.clear();
         this.field1352 = null;
         this.field1317 = null;
         this.field0953 = true;
         this.field1357.method1812();
      } else if (num < 0 && this.field0934 >= 0) {
         this.field0953 = false;
         this.field1365.clear();
         this.field1352 = null;
         this.field1317 = null;
         this.method0398();
      }

      this.field0934 = num;
      if (num >= 0) {
         if (this.field0953 && this.field1357.method0779(1500L)) {
            if (field0796.field_1724 != null && field0796.field_1724.field_3944 != null) {
               field0796.field_1724.field_3944.method_45730("event delay");
            }

            this.field0953 = false;
         }

         this.method0405();
      }
   }

   private void method2134(String message) {
      if (message != null && !message.isEmpty()) {
         long now = System.currentTimeMillis();

         for(String raw : message.split("\n")) {
            String line = raw.trim();
            if (!line.isEmpty()) {
               if (this.field1317 != null && now - this.field1391 > 8000L) {
                  this.field1317 = null;
               }

               if (line.contains("До следующего ивента")) {
                  this.method1846(StringUtils.substringAfter(line, "До следующего ивента").replaceFirst("^[\\s:»>]+", ""));
                  this.field1317 = null;
               } else if (line.endsWith(":")) {
                  this.field1317 = method1984(line);
                  this.field1328 = false;
                  this.field1396 = 0;
                  this.field1391 = now;
               } else if (this.field1317 != null) {
                  this.field1391 = now;
                  if (line.contains("Призван игроком")) {
                     this.field1328 = true;
                  }

                  if (!this.field1328 && (line.contains("Начнётся") || line.contains("до активации") || line.contains("активирован"))) {
                     this.method1045(this.field1317, method0441(line));
                  }

                  if (line.contains("Открытие через")) {
                     this.field1396 = method0383(line);
                  }

                  int ci = line.indexOf("Координаты");
                  if (ci >= 0) {
                     String coords = StringUtils.substringBetween(line.substring(ci), "[", "]");
                     if (coords != null && !this.field1328) {
                        this.method1047(this.field1317, coords, this.field1396);
                     }

                     this.field1317 = null;
                     this.field1328 = false;
                     this.field1396 = 0;
                  }
               }
            }
         }

      }
   }

   private void method1047(String name, String coordsStr, int openSec) {
      String[] p = coordsStr.trim().split("\\s+");
      if (p.length >= 3) {
         int x;
         int y;
         int z;
         try {
            x = Integer.parseInt(p[0]);
            y = Integer.parseInt(p[1]);
            z = Integer.parseInt(p[2]);
         } catch (NumberFormatException var19) {
            return;
         }

         double wx = (double)x + (double)0.5F;
         double wy = (double)y;
         double wz = (double)z + (double)0.5F;
         long expireAt = System.currentTimeMillis() + (long)(openSec > 0 ? openSec + 360 : 600) * 1000L;

         for(TrackedItem aw : this.field1323) {
            if (aw.field0715.equals(name) && aw.field0002 == wx && aw.field0956 == wz) {
               aw.field1244 = expireAt;
               return;
            }
         }

         WaypointManager wm = WaypointManager.method0552();
         if (wm != null) {
            String server = WaypointManager.method1791();
            boolean added = wm.method0941(new WaypointManager.Waypoint(name, wx, wy, wz, WaypointManager.method1947(), server, "minecraft:overworld"));
            if (added) {
               this.field1323.add(new TrackedItem(name, wx, wy, wz, server, expireAt));
               this.method1656(name);
            }

         }
      }
   }

   private void method0405() {
      if (!this.field1323.isEmpty()) {
         long now = System.currentTimeMillis();
         boolean overworld = "minecraft:overworld".equals(WaypointManager.method1619());
         String server = WaypointManager.method1791();
         Iterator<TrackedItem> it = this.field1323.iterator();

         while(it.hasNext()) {
            TrackedItem aw = (TrackedItem)it.next();
            boolean expired = now > aw.field1244;
            boolean arrived = false;
            if (overworld && field0796.field_1724 != null && aw.field0791.equals(server)) {
               double dx = field0796.field_1724.method_23317() - aw.field0002;
               double dz = field0796.field_1724.method_23321() - aw.field0956;
               if (dx * dx + dz * dz <= (double)36.0F) {
                  arrived = true;
               }
            }

            if (expired || arrived) {
               this.method0927(aw);
               it.remove();
            }
         }

      }
   }

   private void method0398() {
      if (!this.field1323.isEmpty()) {
         for(TrackedItem aw : this.field1323) {
            this.method0927(aw);
         }

         this.field1323.clear();
      }
   }

   private void method0927(TrackedItem aw) {
      WaypointManager wm = WaypointManager.method0552();
      if (wm != null) {
         boolean changed = wm.method2192().removeIf((w) -> w.method0557().equals(aw.field0715) && w.method1961().equals(aw.field0791) && "minecraft:overworld".equals(w.method0423()) && w.method0001() == aw.field0002 && w.method1761() == aw.field0956);
         if (changed) {
            wm.method0498();
         }

      }
   }

   private void method0410() {
      WaypointManager wm = WaypointManager.method0552();
      if (wm != null) {
         String server = WaypointManager.method1791();
         boolean changed = wm.method2192().removeIf((w) -> w.method1961().equals(server) && "minecraft:overworld".equals(w.method0423()) && field0944.contains(w.method0557()));
         if (changed) {
            wm.method0498();
         }

      }
   }

   private void method1846(String timeStr) {
      String t = timeStr == null ? "" : timeStr.trim();
      if (!t.isEmpty() && !t.equals(this.field1352)) {
         this.field1352 = t;
         NewHUD.method1050("Следующий ивент", "через " + t, ModuleCategory.field0776.method0017(), true);
      }
   }

   private void method1656(String name) {
      NewHUD.method1050("Установлена метка", "ивент \"" + name + "\"", ModuleCategory.field0776.method0017(), true);
   }

   private void method1045(String name, String timeText) {
      if (name != null && this.field1365.add(name)) {
         String t = timeText == null ? "" : timeText.trim();
         NewHUD.method1050(name, t.isEmpty() ? "скоро начнётся" : "начнётся через " + t, ModuleCategory.field0776.method0017(), true);
      }
   }

   private static String method1984(String line) {
      for(String name : field0944) {
         if (line.endsWith(name + ":")) {
            return name;
         }
      }

      return null;
   }

   private static String method0441(String line) {
      String key = line.contains("до активации") ? "до активации" : (line.contains("через") ? "через" : null);
      return key == null ? "" : StringUtils.substringAfter(line, key).replaceFirst("^[\\s:»>]+", "").trim();
   }

   private static int method0383(String s) {
      if (s == null) {
         return 0;
      } else {
         int total = 0;
         Matcher m = Pattern.compile("(\\d+)\\s*(ч|мин|сек|min|sec|h)").matcher(s);

         while(m.find()) {
            int v;
            try {
               v = Integer.parseInt(m.group(1));
            } catch (NumberFormatException var6) {
               continue;
            }

            switch (m.group(2)) {
               case "ч":
               case "h":
                  total += v * 3600;
                  break;
               case "мин":
               case "min":
                  total += v * 60;
                  break;
               default:
                  total += v;
            }
         }

         return total;
      }
   }

   @EventHandler
   public void onTick(PreTickEvent e) {
      if (!method1974()) {
         this.method2207();
         this.method0479();
         if (field0796.field_1755 == null || field0796.field_1755 instanceof class_408) {
            ServerMode cur = (ServerMode)this.field1448.method0492();

            for(TrackedPlayer bind : this.field1347) {
               if (bind.field1014 == cur) {
                  String key = bind.field0715;
                  KeyBind b = (KeyBind)bind.field1259.method0492();
                  boolean currentKey = b != null && b.method2048() != -1 && b.method0026();
                  boolean wasPressed = (Boolean)this.field1385.getOrDefault(key, false);
                  if (currentKey && !wasPressed) {
                     PendingAction info = (PendingAction)this.field1309.get(key);
                     if (info != null) {
                        class_1735 slot = InventorySearch.method1104((s) -> s.method_7677().method_7909().equals(info.field0153) && InventorySearch.method1345(s.method_7677().method_7964()).replace(" ", "").contains(info.field0715.toLowerCase(Locale.ROOT).replace(" ", "")));
                        if (slot != null) {
                           class_1799 stack = slot.method_7677();
                           if (field0796.field_1724.method_7357().method_7904(stack)) {
                              this.method0932(info);
                           } else if (!this.field0366.contains(key)) {
                              this.field0366.add(key);
                           }
                        } else {
                           this.method0187(info);
                        }
                     }
                  }

                  this.field1385.put(key, currentKey);
               }
            }

            boolean noMoveOrAction = System.currentTimeMillis() < this.field0291 || this.field0266 != ServerAssist.ActionState.field0681 && this.field0266 != ServerAssist.ActionState.field0331;
            if (noMoveOrAction) {
               field0796.field_1690.field_1894.method_23481(false);
               field0796.field_1690.field_1881.method_23481(false);
               field0796.field_1690.field_1913.method_23481(false);
               field0796.field_1690.field_1849.method_23481(false);
               if (field0796.field_1724.field_3913 != null) {
                  field0796.field_1724.field_3913.field_3905 = 0.0F;
                  field0796.field_1724.field_3913.field_3907 = 0.0F;
               }

               if (field0796.field_1724.method_5624()) {
                  field0796.field_1724.method_5728(false);
               }
            }

            if (this.field0266 != ServerAssist.ActionState.field0681) {
               this.method2243();
            }

            if (this.field0266 == ServerAssist.ActionState.field0681 && !this.field0366.isEmpty() && this.field0433.method0779(150L)) {
               String potionKey = (String)this.field0366.remove(0);
               PendingAction info = (PendingAction)this.field1309.get(potionKey);
               if (info != null) {
                  class_1735 slot = InventorySearch.method1104((s) -> s.method_7677().method_7909().equals(info.field0153) && InventorySearch.method1345(s.method_7677().method_7964()).replace(" ", "").contains(info.field0715.toLowerCase(Locale.ROOT).replace(" ", "")));
                  if (slot != null) {
                     class_1799 stack = slot.method_7677();
                     if (!field0796.field_1724.method_7357().method_7904(stack)) {
                        this.method1213(slot, info);
                     } else {
                        this.method0932(info);
                     }
                  } else {
                     this.method0187(info);
                  }

                  this.field0433.method1812();
               }
            }

            if ((Boolean)this.field0464.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field0108) {
               boolean anyDamagedWithMending = false;

               for(class_1799 stack : field0796.field_1724.method_5661()) {
                  if (!stack.method_7960() && stack.method_7936() != 0 && !((double)stack.method_7919() / (double)stack.method_7936() < 0.9400000271331854)) {
                     class_6880<class_1887> mendingEntry = (class_6880)field0796.field_1687.method_30349().method_30530(class_7924.field_41265).method_10223(class_1893.field_9101.method_29177()).orElse((Object)null);
                     if (mendingEntry != null && class_1890.method_8225(mendingEntry, stack) > 0) {
                        anyDamagedWithMending = true;
                        break;
                     }
                  }
               }

               if (anyDamagedWithMending && this.field1115.method0779(5000L)) {
                  class_1735 xpSlot = InventorySearch.method1104((s) -> {
                     class_1799 st = s.method_7677();
                     class_9279 component = (class_9279)st.method_57824(class_9334.field_49628);
                     return !field0796.field_1724.method_7357().method_7904(st) && st.method_7909().equals(class_1802.field_8287) && component != null && component.toString().contains("\"text\":\" - при нажатие ПКМ, полностью ремонтирует\"");
                  });
                  if (xpSlot != null) {
                     InventoryActionScheduler.method0991(() -> InventorySearch.method1206(xpSlot));
                     this.field1115.method1812();
                  }
               }
            }

            if (!InventorySearch.method0026() && !this.field1180.isEmpty() && InventoryActionScheduler.field0649.method0026() && this.field1123.method0779(300L)) {
               class_1735 bestShulker = InventorySearch.method1107((s) -> s.method_7677().method_57824(class_9334.field_49622) != null, Comparator.comparingInt((s) -> {
                  class_9288 comp = (class_9288)s.method_7677().method_57825(class_9334.field_49622, (Object)null);
                  if (comp == null) {
                     return 0;
                  } else {
                     int[] count = new int[]{0};
                     comp.method_59714().forEach((is) -> {
                        int var10002 = count[0]++;
                     });
                     return count[0];
                  }
               }));
               if (bestShulker != null) {
                  InventorySearch.method1215(bestShulker, class_1268.field_5808, false);
                  InventorySearch.method1570(false);
                  field0796.field_1761.method_2919(field0796.field_1724, class_1268.field_5808);
                  InventoryActionScheduler.field0078.method0578();
                  InventoryActionScheduler.field0078.method0765(0, () -> {
                     List<Integer> moved = new ArrayList();
                     InventorySearch.method0562().forEach((slot) -> {
                        for(Map.Entry<Integer, class_1792> entry : new ArrayList(this.field1180.entrySet())) {
                           if (slot.field_7871 == field0796.field_1724.method_31548() && ((class_1792)entry.getValue()).equals(slot.method_7677().method_7909()) && (Integer)entry.getKey() == slot.field_7874) {
                              InventorySearch.method1209(slot, 0, class_1713.field_7794, false);
                              moved.add(slot.field_7874);
                           }
                        }

                     });
                     Map var10001 = this.field1180;
                     Objects.requireNonNull(var10001);
                     moved.forEach(var10001::remove);
                     InventorySearch.method1570(false);
                     InventorySearch.method1215(bestShulker, class_1268.field_5808, false);
                     InventorySearch.method1570(false);
                     this.field1123.method1812();
                  }, 0);
               }
            }

            if ((Boolean)this.field0970.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field0108) {
               Stream var10000 = StreamSupport.stream(field0796.field_1687.method_18112().spliterator(), false);
               Objects.requireNonNull(class_3988.class);
               var10000 = var10000.filter(class_3988.class::isInstance);
               Objects.requireNonNull(class_3988.class);
               var10000.map(class_3988.class::cast).filter((m) -> m.method_6084(class_1304.field_6173) || m.method_6084(class_1304.field_6171)).findFirst().ifPresent((merchant) -> {
                  this.field1189.method1812();
                  this.field0868 = merchant.method_5667();
                  if (field0796.field_1724.method_33571().method_1022(merchant.method_5829().method_1005()) <= (double)6.0F) {
                     field0796.field_1724.field_3944.method_52787(class_2824.method_34208(merchant, false, class_1268.field_5808, merchant.method_5829().method_1005()));
                     field0796.field_1724.field_3944.method_52787(class_2824.method_34207(merchant, false, class_1268.field_5808));
                  }

               });
            }

            this.method0521();
            this.field1760.clear();
            this.field1772.removeIf((cons) -> cons.time - (double)System.currentTimeMillis() <= (double)0.0F);
            this.field1746.removeIf((event) -> event.timeEnd + (double)90000.0F - (double)System.currentTimeMillis() <= (double)0.0F);
         }
      }
   }

   private void method0521() {
      ServerMode m = (ServerMode)this.field1448.method0492();
      boolean enabledReally = m == ServerAssist.ServerMode.field0682 && (Boolean)this.field1619.method0492();
      boolean enabledFun = m == ServerAssist.ServerMode.field1483 && (Boolean)this.field1709.method0492();
      if (!enabledReally && !enabledFun) {
         if (this.field0903) {
            this.method0527();
         }

         this.field0907 = false;
         this.field0856 = field0796.field_1724 == null ? 0 : field0796.field_1724.field_6235;
         this.field0852 = null;
      } else {
         Aura aura = Aura.method1701();
         class_1309 target = aura == null ? null : (aura.method0409() != null && aura.method0409().method_5805() ? aura.method0409() : aura.method0520());
         UUID newUuid = target != null && target.method_5805() ? target.method_5667() : null;
         if (!Objects.equals(newUuid, this.field0852)) {
            this.field0852 = newUuid;
            this.field1231.method1812();
            this.field1223.method0436(0L);
            this.field1237.method0436(0L);
         }

         this.method1158(target);
         if (this.field0903) {
            if (this.field0907) {
               int slot = this.field0895 != null ? this.method1061(this.field0895, enabledFun) : -1;
               if (slot != -1) {
                  InventorySlotHelper.method2102(slot);
               }

               this.field1133.method1812();
               this.method0527();
            }

         } else {
            this.field0907 = false;
            if (this.field1133.method0779(1000L)) {
               if (target != null && target.method_5805()) {
                  float currentHealth = PlayerActionHelper.method0238(field0796.field_1724);
                  float targetHealth = PlayerActionHelper.method0238(target);
                  MultiSelectSetting activeConditions = enabledFun ? this.field1152 : this.field1562;
                  if (activeConditions.method1936().isEmpty() || this.method0896(activeConditions, target, currentHealth, targetHealth)) {
                     class_1799 offhand = field0796.field_1724.method_6079();
                     boolean validOffhand = enabledFun ? this.method0269(offhand) : this.method1241(offhand);
                     if (validOffhand) {
                        double currentDamage = this.method2155(offhand);
                        int bestSlot = enabledFun ? this.method1223(offhand.method_7909(), currentDamage) : this.method0609(currentDamage);
                        if (bestSlot != -1) {
                           this.field0895 = offhand.method_7964().getString();
                           InventorySlotHelper.method2102(bestSlot);
                           this.field0903 = true;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean method0517() {
      return this.field1231.method0779(2500L) || !this.field1223.method0779(3000L);
   }

   private boolean method0896(MultiSelectSetting conditions, class_1309 target, float currentHealth, float targetHealth) {
      if (conditions.method0387("Lower Health") && targetHealth < currentHealth) {
         return true;
      } else if (conditions.method0387("Enemy Eating") && target.method_6115() && target.method_6030().method_57824(class_9334.field_53964) != null) {
         return true;
      } else if (conditions.method0387("Player Retreating") && this.method0517()) {
         return true;
      } else {
         return conditions.method0387("Popped Totem") && !this.field1237.method0779(3000L);
      }
   }

   private void method0527() {
      this.field0903 = false;
      this.field0895 = null;
   }

   private void method1158(class_1309 target) {
      if (field0796.field_1724 != null) {
         int curHurt = field0796.field_1724.field_6235;
         boolean justHit = curHurt > this.field0856;
         this.field0856 = curHurt;
         if (justHit && target != null) {
            class_1282 src = field0796.field_1724.method_6081();
            class_1297 attacker = src != null ? src.method_5529() : null;
            boolean fromTarget;
            if (attacker != null) {
               fromTarget = attacker.method_5628() == target.method_5628();
            } else {
               fromTarget = (double)field0796.field_1724.method_5739(target) <= (double)6.0F;
            }

            if (fromTarget) {
               this.field1231.method1812();
               if (this.field0903) {
                  this.field0907 = true;
               }

            }
         }
      }
   }

   @EventHandler
   public void onSpawnEntity(EntitySpawnEvent e) {
      if (!method1974()) {
         if (this.method2247()) {
            if (this.field0852 != null) {
               class_1297 owner = e.method1798();
               if (owner instanceof class_1684) {
                  class_1684 pearl = (class_1684)owner;
                  owner = pearl.method_24921();
                  if (owner != null && this.field0852.equals(owner.method_5667())) {
                     this.field1223.method1812();
                  }

               }
            }
         }
      }
   }

   @EventHandler
   public void onPopTotem(TotemPopEvent e) {
      if (!method1974()) {
         if (this.method2247()) {
            if (this.field0852 != null && e.method1800() != null) {
               if (this.field0852.equals(e.method1800().method_5667())) {
                  this.field1237.method1812();
               }

            }
         }
      }
   }

   private boolean method2247() {
      ServerMode m = (ServerMode)this.field1448.method0492();
      return m == ServerAssist.ServerMode.field0682 && (Boolean)this.field1619.method0492() || m == ServerAssist.ServerMode.field1483 && (Boolean)this.field1709.method0492();
   }

   private boolean method1241(class_1799 stack) {
      if (stack != null && !stack.method_7960() && stack.method_7909() == class_1802.field_8575) {
         class_2561 name = stack.method_7964();
         if (name == null) {
            return false;
         } else {
            String s = name.getString();
            return s != null && s.contains("Шар");
         }
      } else {
         return false;
      }
   }

   private boolean method0269(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         if (stack.method_7909() != class_1802.field_8575 && stack.method_7909() != class_1802.field_8288) {
            return false;
         } else {
            return this.method2155(stack) > (double)0.0F;
         }
      } else {
         return false;
      }
   }

   private double method2155(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         class_9285 modifiers = (class_9285)stack.method_57824(class_9334.field_49636);
         if (modifiers == null) {
            return (double)0.0F;
         } else {
            double[] total = new double[]{(double)0.0F};
            modifiers.method_57482(class_1304.field_6171, (attribute, modifier) -> {
               if (attribute.comp_349() == class_5134.field_23721.comp_349()) {
                  total[0] += modifier.comp_2449();
               }

            });
            return total[0];
         }
      } else {
         return (double)0.0F;
      }
   }

   private int method0609(double currentDamage) {
      int best = -1;
      double bestDmg = currentDamage;

      for(int i = 0; i <= 35; ++i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (this.method1241(stack)) {
            double dmg = this.method2155(stack);
            if (dmg > bestDmg) {
               bestDmg = dmg;
               best = i;
            }
         }
      }

      return best;
   }

   private int method0504(String name) {
      for(int i = 0; i <= 35; ++i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (this.method1241(stack)) {
            class_2561 n = stack.method_7964();
            if (n != null && name.equals(n.getString())) {
               return i;
            }
         }
      }

      return -1;
   }

   private int method1223(class_1792 sameItem, double currentDamage) {
      int best = -1;
      double bestDmg = currentDamage;

      for(int i = 0; i <= 35; ++i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack != null && !stack.method_7960() && stack.method_7909() == sameItem) {
            double dmg = this.method2155(stack);
            if (dmg > bestDmg) {
               bestDmg = dmg;
               best = i;
            }
         }
      }

      return best;
   }

   private int method1061(String name, boolean funtimeMode) {
      for(int i = 0; i <= 35; ++i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack != null && !stack.method_7960()) {
            if (funtimeMode) {
               if (stack.method_7909() != class_1802.field_8575 && stack.method_7909() != class_1802.field_8288) {
                  continue;
               }
            } else if (!this.method1241(stack)) {
               continue;
            }

            class_2561 n = stack.method_7964();
            if (n != null && name.equals(n.getString())) {
               return i;
            }
         }
      }

      return -1;
   }

   private void method1213(class_1735 slot, PendingAction info) {
      this.field0524 = field0796.field_1724.method_31548().field_7545;
      this.field0548 = slot.field_7874;
      this.field0502 = slot.field_7874;
      this.field1681 = info.field0715;
      boolean needsSwap = (slot.field_7874 < 0 || slot.field_7874 >= 9) && (slot.field_7874 < 36 || slot.field_7874 >= 45);
      long window = field0796.method_22683().method_4490();
      this.field1699 = class_3675.method_15987(window, field0796.field_1690.field_1894.method_1429().method_1444());
      this.field1597 = class_3675.method_15987(window, field0796.field_1690.field_1881.method_1429().method_1444());
      this.field1586 = class_3675.method_15987(window, field0796.field_1690.field_1913.method_1429().method_1444());
      this.field1609 = class_3675.method_15987(window, field0796.field_1690.field_1849.method_1429().method_1444());
      this.field1665 = true;
      field0796.field_1690.field_1894.method_23481(false);
      field0796.field_1690.field_1881.method_23481(false);
      field0796.field_1690.field_1913.method_23481(false);
      field0796.field_1690.field_1849.method_23481(false);
      this.field0291 = System.currentTimeMillis() + 95L;
      this.field0228 = System.currentTimeMillis();
      this.field0266 = needsSwap ? ServerAssist.ActionState.field0107 : ServerAssist.ActionState.field1013;
      class_5250 text = class_2561.method_43473().method_10852(LegacyTextParser.method1064(info.field1504, LegacyTextParser.method1015(info.field1504), false)).method_27693("  " + method2236(info.field1504));
      NewHUD.method1350(text, ModuleCategory.field0776.method0017(), true);
   }

   private static String method2236(String displayName) {
      if (displayName == null) {
         return "использован";
      } else {
         String s = displayName.trim().toLowerCase();
         if (s.isEmpty()) {
            return "использован";
         } else {
            String[] words = s.split("\\s+");
            String first = words[0];
            boolean firstIsAdjective = first.endsWith("ый") || first.endsWith("ий") || first.endsWith("ой") || first.endsWith("ая") || first.endsWith("яя") || first.endsWith("ое") || first.endsWith("ее") || first.endsWith("ые") || first.endsWith("ие") || first.endsWith("ья");
            String noun = firstIsAdjective && words.length > 1 ? words[words.length - 1] : first;
            if (noun.isEmpty()) {
               return "использован";
            } else {
               char c = noun.charAt(noun.length() - 1);
               if (c != 1072 && c != 1103) {
                  if (c != 1086 && c != 1077) {
                     return c != 1100 || !noun.equals("пыль") && !noun.equals("часть") && !noun.equals("соль") ? "использован" : "использована";
                  } else {
                     return "использовано";
                  }
               } else {
                  return "использована";
               }
            }
         }
      }
   }

   private void method2243() {
      long now = System.currentTimeMillis();
      long elapsed = now - this.field0228;
      int syncId = field0796.field_1724.field_7498.field_7763;
      switch (this.field0266.ordinal()) {
         case 1:
            if (field0796.field_1724.field_3913 != null) {
               field0796.field_1724.field_3913.field_3905 = 0.0F;
               field0796.field_1724.field_3913.field_3907 = 0.0F;
            }

            if (field0796.field_1724.method_5624()) {
               field0796.field_1724.method_5728(false);
            }

            if (elapsed > 1L) {
               this.field0266 = ServerAssist.ActionState.field1482;
            }
            break;
         case 2:
            if (field0796.field_1724.field_3913 != null) {
               field0796.field_1724.field_3913.field_3905 = 0.0F;
               field0796.field_1724.field_3913.field_3907 = 0.0F;
            }

            double vx = Math.abs(field0796.field_1724.method_18798().field_1352);
            double vz = Math.abs(field0796.field_1724.method_18798().field_1350);
            if (vx < 9.999995420718636E-4 && vz < 9.999995420718636E-4 || elapsed > 75L) {
               this.field0266 = ServerAssist.ActionState.field1013;
               this.field0228 = now;
            }
            break;
         case 3:
            if (elapsed > 25L) {
               if (this.field0502 >= 0 && this.field0502 < 9) {
                  field0796.field_1724.field_3944.method_52787(new class_2868(this.field0502));
                  field0796.field_1724.method_31548().field_7545 = this.field0502;
               } else if (this.field0502 >= 36 && this.field0502 < 45) {
                  int hotbarSlot = this.field0502 - 36;
                  field0796.field_1724.field_3944.method_52787(new class_2868(hotbarSlot));
                  field0796.field_1724.method_31548().field_7545 = hotbarSlot;
                  this.field0502 = hotbarSlot;
               } else {
                  int swapSlot = 8;
                  InventorySearch.method0754(this.field0502, swapSlot, class_1713.field_7791, false);
                  this.field0502 = swapSlot;
                  field0796.field_1724.field_3944.method_52787(new class_2868(swapSlot));
                  field0796.field_1724.method_31548().field_7545 = swapSlot;
               }

               this.field0266 = ServerAssist.ActionState.field0780;
               this.field0228 = now;
            }
            break;
         case 4:
            if (elapsed > 40L) {
               field0796.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, field0796.field_1724.method_36454(), field0796.field_1724.method_36455()));
               field0796.field_1724.method_6104(class_1268.field_5808);
               if (this.field1681 != null) {
                  for(TrackedPlayer b : this.field1347) {
                     if (b.field0136.equals(this.field1681) && b.field0759 > 0) {
                        this.field0401.put(b.field0715, now + (long)b.field0759 * 1000L);
                        break;
                     }
                  }
               }

               this.field0266 = ServerAssist.ActionState.field1264;
               this.field0228 = now;
            }
            break;
         case 5:
            if (elapsed > 25L) {
               boolean wasFromInventory = (this.field0548 < 0 || this.field0548 >= 9) && (this.field0548 < 36 || this.field0548 >= 45);
               if (wasFromInventory) {
                  if (this.field0502 >= 0 && this.field0502 < 9) {
                     InventorySearch.method0754(this.field0548, this.field0502, class_1713.field_7791, false);
                  }
               } else if (this.field0548 >= 36 && this.field0548 < 45) {
                  int hotbarSlot = this.field0548 - 36;
                  if (this.field0502 != hotbarSlot) {
                     field0796.field_1724.field_3944.method_52787(new class_2868(hotbarSlot));
                     field0796.field_1724.method_31548().field_7545 = hotbarSlot;
                  }
               } else if (this.field0548 >= 0 && this.field0548 < 9 && this.field0502 != this.field0548) {
                  field0796.field_1724.field_3944.method_52787(new class_2868(this.field0548));
                  field0796.field_1724.method_31548().field_7545 = this.field0548;
               }

               if (field0796.field_1724.method_31548().field_7545 != this.field0524) {
                  field0796.field_1724.field_3944.method_52787(new class_2868(this.field0524));
                  field0796.field_1724.method_31548().field_7545 = this.field0524;
               }

               this.method2251();
               this.field0266 = ServerAssist.ActionState.field0331;
               this.field0228 = now;
            }
            break;
         case 6:
            if (elapsed > 75L) {
               this.field0266 = ServerAssist.ActionState.field0681;
               this.field0524 = -1;
               this.field0502 = -1;
               this.field0548 = -1;
               this.field1681 = null;
            }
      }

   }

   private void method2251() {
      if (this.field1665) {
         field0796.field_1690.field_1894.method_23481(this.field1699);
         field0796.field_1690.field_1881.method_23481(this.field1597);
         field0796.field_1690.field_1913.method_23481(this.field1586);
         field0796.field_1690.field_1849.method_23481(this.field1609);
         if (field0796.field_1724 != null && field0796.field_1724.field_3913 != null) {
            if (this.field1699) {
               field0796.field_1724.field_3913.field_3905 = 1.0F;
               if (!field0796.field_1724.method_5624()) {
                  field0796.field_1724.method_5728(true);
               }
            }

            if (this.field1597) {
               field0796.field_1724.field_3913.field_3905 = -1.0F;
            }

            if (this.field1586) {
               field0796.field_1724.field_3913.field_3907 = 1.0F;
            }

            if (this.field1609) {
               field0796.field_1724.field_3913.field_3907 = -1.0F;
            }
         }

         this.field1665 = false;
      }
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent.GamePass event) {
      if (!method1974()) {
         class_4587 matrix = event.method1629();

         for(TrackedPlayer bind : this.field1347) {
            if (bind.field1014 == this.field1448.method0492()) {
               KeyBind key = (KeyBind)bind.field1259.method0492();
               if (key != null && key.method2048() != -1 && key.method0026() && InventorySearch.method1220(bind.field1519) != null) {
                  class_2338 playerPos = field0796.field_1724.method_24515();
                  int[] gradientColors = LegacyTextParser.method1015(bind.field0715);
                  Color color = method0723(gradientColors.length > 1 ? ColorMath.method0758(10, 0, gradientColors) : gradientColors[0]);
                  switch (bind.field0715) {
                     case "Трапка":
                     case "Обычная трапка":
                        this.method1497(matrix, playerPos, 1.99F, color);
                        break;
                     case "Дезориентация":
                     case "Огненный смерч":
                     case "Явная пыль":
                        this.method1477(matrix, 5.0F, color);
                        break;
                     case "Взрывная штучка":
                        this.method1477(matrix, 5.0F, color);
                        break;
                     case "Взрывная трапка":
                        this.method1497(matrix, playerPos, 3.99F, color);
                        break;
                     case "Стан":
                        this.method1497(matrix, playerPos, 15.01F, color);
                  }
               }
            }
         }

      }
   }

   private void method1497(class_4587 matrix, class_2338 playerPos, float size, Color color) {
      class_238 box = (new class_238(playerPos.method_10084())).method_1014((double)size);
      WorldRenderHelper.method2173(matrix, box, color);
   }

   private void method1477(class_4587 matrix, float distance, Color color) {
      float playerHalfWidth = field0796.field_1724.method_17681() / 2.0F;
      class_243 pos = field0796.field_1724.method_19538().method_1031((double)playerHalfWidth, 0.020000008421942297, (double)playerHalfWidth);

      for(int i = 0; i < 90; ++i) {
         class_243 a = MathHelper.method0740(i, 90, (double)distance).method_1019(pos);
         class_243 b = MathHelper.method0740(i + 1, 90, (double)distance).method_1019(pos);
         WorldRenderHelper.method1507(matrix, a, b, color);
      }

   }

   @EventHandler
   public void onRender2D(HudRenderEvent e) {
      if (!method1974()) {
         if (!(field0796.field_1755 instanceof class_408)) {
            this.method1400(e.method1806());
         }
      }
   }

   public void method1400(class_332 ctx) {
      if (!method1974()) {
         class_4587 stack = ctx.method_51448();
         this.method2207();
         if ((Boolean)this.field0830.method0492()) {
            this.method1432(ctx, stack);
         }

         if ((Boolean)this.field1201.method0492() && this.field1448.method0492() == ServerAssist.ServerMode.field1483) {
            this.method0317(ctx, stack);
         }

      }
   }

   private void method2207() {
      if ((Boolean)this.field0830.method0492()) {
         if (Fonts.field0075 != null) {
            FontSize keyFont = Fonts.field0075.method0654(5.0F);
            float baseCardW = 22.0F;
            float vbPadH = 3.0F;
            float cardGap = 4.0F;
            float cardH = 25.0F;
            float totalW = 0.0F;
            int n = 0;

            for(TrackedPlayer b : this.field1347) {
               if (b.field1014 == this.field1448.method0492() && ((KeyBind)b.field1259.method0492()).method2048() != -1) {
                  String t = ((KeyBind)b.field1259.method0492()).toString();
                  float kw = keyFont.method0998(t);
                  float cardW = Math.max(baseCardW, kw + vbPadH * 2.0F + 2.0F);
                  totalW += cardW;
                  ++n;
               }
            }

            if (n == 0) {
               HudWidgetManager.method1605().method0215("ServerAssist", baseCardW, cardH);
            } else {
               totalW += (float)(n - 1) * cardGap;
               HudWidgetManager.method1605().method0215("ServerAssist", totalW, cardH);
            }
         }
      }
   }

   public boolean method1755() {
      return (Boolean)this.field0830.method0492();
   }

   private void method1432(class_332 ctx, class_4587 stack) {
      HudWidgetState el = HudWidgetManager.method1605().method1002("ServerAssist");
      if (el != null) {
         List<TrackedPlayer> activeBinds = new ArrayList();

         for(TrackedPlayer b : this.field1347) {
            if (b.field1014 == this.field1448.method0492() && ((KeyBind)b.field1259.method0492()).method2048() != -1) {
               activeBinds.add(b);
            }
         }

         if (activeBinds.isEmpty()) {
            HudWidgetManager.method1605().method0215("ServerAssist", 22.0F, 28.0F);
         } else {
            FontSize keyFont = Fonts.field0075.method0654(5.0F);
            float cardH = 25.0F;
            float cardGap = 4.0F;
            float cardRadius = 6.0F;
            float iconSize = 14.0F;
            float iconTop = 3.0F;
            float vbHeight = 11.0F;
            float vbRadius = 3.0F;
            float vbPadH = 3.0F;
            float baseCardW = 22.0F;
            float[] cardWidths = new float[activeBinds.size()];

            for(int i = 0; i < activeBinds.size(); ++i) {
               String t = ((KeyBind)((TrackedPlayer)activeBinds.get(i)).field1259.method0492()).toString();
               float kw = keyFont.method0998(t);
               cardWidths[i] = Math.max(baseCardW, kw + vbPadH * 2.0F + 2.0F);
            }

            int n = activeBinds.size();
            float totalW = 0.0F;

            for(int i = 0; i < n; ++i) {
               totalW += cardWidths[i];
            }

            if (n > 0) {
               totalW += (float)(n - 1) * cardGap;
            }

            HudWidgetManager.method1605().method0215("ServerAssist", totalW, cardH);
            float x = el.method1946();
            float y = el.method0413();
            Color cardBg = (Color)ThemePalette.field0930.get();
            Color cardBorder = ThemePalette.field0884;
            Color blurColor = ThemePalette.field0134;
            Color textPrimary = new Color(255, 255, 255);
            Color accent = ThemeColorManager.method1908().method2063();
            Color cooldownOverlay = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90);
            Color kvBg = new Color(255, 255, 255, 5);
            Color kvBorder = new Color(255, 255, 255, 10);
            long now = System.currentTimeMillis();
            float cx = x;

            for(int i = 0; i < n; ++i) {
               TrackedPlayer b = (TrackedPlayer)activeBinds.get(i);
               KeyBind bind = (KeyBind)b.field1259.method0492();
               float cardW = cardWidths[i];
               GuiRenderHelper.method1462(stack, cx, y, cardW, cardH, cardRadius, (Float)ThemePalette.field0367.get(), blurColor);
               GuiRenderHelper.method1463(stack, cx, y, cardW, cardH, cardRadius, cardBg);
               GuiRenderHelper.method1461(stack, cx, y, cardW, cardH, cardRadius, 0.5F, 0.5F, cardBorder);
               stack.method_22903();
               float iconScale = iconSize / 16.0F;
               float iconX = cx + (cardW - iconSize) / 2.0F;
               float iconY = y + iconTop;
               stack.method_46416(iconX, iconY, 0.0F);
               stack.method_22905(iconScale, iconScale, 1.0F);
               ctx.method_51427(new class_1799(b.field1519), 0, 0);
               stack.method_22909();
               String keyText = bind.toString();
               float keyW = keyFont.method0998(keyText);
               float vbWidth = vbPadH + keyW + vbPadH;
               float vbX = cx + (cardW - vbWidth) / 2.0F;
               float vbY = y + cardH - vbHeight - 2.0F;
               GuiRenderHelper.method1462(stack, vbX, vbY, vbWidth, vbHeight, vbRadius, (Float)ThemePalette.field0367.get(), ThemePalette.field0134);
               GuiRenderHelper.method1463(stack, vbX, vbY, vbWidth, vbHeight, vbRadius, (Color)ThemePalette.field0930.get());
               GuiRenderHelper.method0326(stack, vbX, vbY, vbWidth, vbHeight, vbRadius, kvBg);
               GuiRenderHelper.method1460(stack, vbX, vbY, vbWidth, vbHeight, vbRadius, 0.3F, 0.5F, 0.5F, kvBorder);
               float textX = vbX + (vbWidth - keyW) / 2.0F;
               float textY = vbY + (vbHeight - keyFont.method0530()) / 2.0F;
               GuiRenderHelper.method1491(stack, keyFont, keyText, textX, textY, textPrimary);
               Long next = (Long)this.field0401.get(b.field0715);
               boolean inCooldown = next != null && next > now && b.field0759 > 0;
               float targetVisible;
               if (inCooldown) {
                  float total = (float)b.field0759 * 1000.0F;
                  float remaining = (float)(next - now);
                  float progress = Math.clamp(1.0F - remaining / total, 0.0F, 1.0F);
                  targetVisible = 1.0F - progress;
               } else {
                  targetVisible = 0.0F;
               }

               float currentVisible = (Float)this.field1170.getOrDefault(b.field0715, 0.0F);
               currentVisible += (targetVisible - currentVisible) * 0.18F;
               if (Math.abs(currentVisible - targetVisible) < 0.005F) {
                  currentVisible = targetVisible;
               }

               this.field1170.put(b.field0715, currentVisible);
               float overlayH = cardH * currentVisible;
               if (overlayH > 0.5F) {
                  float overlayY = y + cardH - overlayH;
                  float topR = Math.clamp(cardRadius - (cardH - overlayH), 0.0F, cardRadius);
                  ((RectangleRenderCommand)RenderCommandFactory.method0548().method0925(new RenderSize(cardW, overlayH)).method0824(new CornerRadius(topR, cardRadius, cardRadius, topR)).method0916(new QuadColor(cooldownOverlay)).method0555()).method1551(stack.method_23760().method_23761(), cx, overlayY);
               }

               cx += cardW + cardGap;
            }

         }
      }
   }

   private void method0317(class_332 ctx, class_4587 stack) {
      FontSize font = Fonts.field0075.method0654(7.0F);
      Color panelBg = new Color(0, 0, 0, 150);
      Color white = new Color(255, 255, 255, 255);

      for(ItemPosition cons : this.field1772) {
         if (ServerEnvironment.method1961().equals(cons.world)) {
            class_243 screen = ViewFrustumHelper.method1299(cons.vec);
            if (ViewFrustumHelper.method0289(screen)) {
               double time = (cons.time - (double)System.currentTimeMillis()) / (double)1000.0F;
               String text = MathHelper.method0614(time, 0.10000000745064033) + "с";
               float width = font.method0998(text);
               float posX = (float)(screen.field_1352 - (double)(width / 2.0F));
               float posY = (float)screen.field_1351;
               GuiRenderHelper.method1463(stack, posX - 4.0F, posY - 2.0F, width + 8.0F, 10.0F, 1.5F, panelBg);
               GuiRenderHelper.method1491(stack, font, text, posX, posY, white);
            }
         }
      }

      for(EventInfo se : this.field1746) {
         if (ServerEnvironment.method1961().equals(se.world)) {
            class_243 screen = ViewFrustumHelper.method1299(se.vec);
            if (ViewFrustumHelper.method0289(screen)) {
               double distance = field0796.method_1561().field_4686.method_19326().method_1022(se.vec);
               double timeOpen = (se.timeOpen - (double)System.currentTimeMillis()) / (double)1000.0F;
               double timeEnd = (se.timeEnd - (double)System.currentTimeMillis()) / (double)1000.0F;
               String distStr = " [" + MathHelper.method0614(distance, 0.10000000745064033) + "m]";
               String timeStr = timeOpen > (double)0.0F ? ("До начала: " + MathHelper.method0614(timeOpen, timeOpen < (double)30.0F ? 0.10000000745064033 : (double)1.0F) + "с").replace(".0", "") : (timeEnd > (double)0.0F ? ("До конца: " + MathHelper.method0614(timeEnd, timeEnd < (double)30.0F ? 0.10000000745064033 : (double)1.0F) + "с").replace(".0", "") : "Конец ивента!");
               List<String> lines = new ArrayList();
               lines.add(se.name + distStr);
               if (se.owner != null) {
                  String var10001 = String.valueOf(class_124.field_1065);
                  lines.add("Призван: " + var10001 + se.owner);
               }

               lines.add(timeStr);
               if (se.lvl != null) {
                  lines.add(se.lvl);
               }

               float offsetY = 0.0F;

               for(String line : lines) {
                  float width = font.method0998(line);
                  float posX = (float)(screen.field_1352 - (double)(width / 2.0F));
                  float posY = (float)(screen.field_1351 + (double)offsetY);
                  GuiRenderHelper.method1463(stack, posX - 4.0F, posY - 2.0F, width + 8.0F, 10.0F, 2.0F, panelBg);
                  GuiRenderHelper.method1491(stack, font, line, posX, posY, white);
                  offsetY += 10.0F;
               }
            }
         }
      }

      if (this.field0868 != null) {
         StreamSupport.stream(field0796.field_1687.method_18112().spliterator(), false).filter((ent) -> ent.method_5667().equals(this.field0868)).findFirst().ifPresent((ent) -> {
            class_243 pos = ent.method_24515().method_10074().method_46558();
            class_243 screen = ViewFrustumHelper.method1299(pos);
            if (ViewFrustumHelper.method0289(screen)) {
               String text = !this.field1189.method0779(200L) ? "Можно забрать" : (!this.field1189.method0779(20000L) ? MathHelper.method0614((double)(20.0F - (float)this.field1189.method1948() / 1000.0F), 0.10000000745064033) + "с" : "Скоро");
               float width = font.method0998(text);
               float posX = (float)(screen.field_1352 - (double)(width / 2.0F));
               float posY = (float)screen.field_1351;
               GuiRenderHelper.method1463(stack, posX - 4.0F, posY - 2.0F, width + 8.0F, 10.0F, 2.0F, panelBg);
               GuiRenderHelper.method1491(stack, font, text, posX, posY, white);
            }
         });
      }

   }

   private void method0932(PendingAction info) {
      class_5250 text = class_2561.method_43473().method_10852(LegacyTextParser.method1064(info.field1504, LegacyTextParser.method1015(info.field1504), false)).method_27693("  в кулдауне");
      NewHUD.method1350(text, ModuleCategory.field0776.method0017(), false);
   }

   private void method0187(PendingAction info) {
      NewHUD.method1053("Нету предмета", "\"" + info.field1504 + "\"", new class_1799(info.field0153), false);
   }

   private void method1049(String name, String lvl, String owner, class_243 vec3d, String world, int timeOpenSec, int timeLootSec) {
      for(EventInfo se : this.field1746) {
         if (se.vec.equals(vec3d)) {
            return;
         }
      }

      long open = System.currentTimeMillis() + (long)timeOpenSec * 1000L;
      long loot = open + (long)timeLootSec * 1000L;
      this.field1746.add(new EventInfo(name, lvl, owner, vec3d, world, (double)open, (double)loot));
   }

   private void method1235(class_1792 item, class_243 vec, double time) {
      for(ItemPosition st : this.field1772) {
         if (st.vec.equals(vec)) {
            return;
         }
      }

      this.field1772.add(new ItemPosition(item, vec, ServerEnvironment.method1961(), time));
   }

   private boolean method1264(class_2338 center) {
      int inconsistencies = 0;

      for(class_2338 pos : BlockAreaScanner.method1268(center, 2, 2, true)) {
         if (pos.method_46558().method_1022(center.method_46558()) < (double)2.0F) {
            class_2680 state = (class_2680)this.field1760.get(pos);
            if (state != null && !state.method_26215()) {
               ++inconsistencies;
            }
         } else if (!pos.equals(center.method_10086(2).method_10095().method_10078()) && !pos.equals(center.method_10086(2).method_10095().method_10067()) && !pos.equals(center.method_10086(2).method_10072().method_10078()) && !pos.equals(center.method_10086(2).method_10072().method_10067())) {
            class_2680 state = (class_2680)this.field1760.get(pos);
            if (state == null || state.method_26215()) {
               ++inconsistencies;
            }
         }

         if (inconsistencies > 1) {
            return false;
         }
      }

      return true;
   }

   private boolean method0279(class_2338 center) {
      int inconsistencies = 0;

      for(class_2338 pos : BlockAreaScanner.method1268(center, 3, 3, true)) {
         if (Math.abs(pos.method_10263() - center.method_10263()) <= 2 && Math.abs(pos.method_10264() - center.method_10264()) <= 2 && Math.abs(pos.method_10260() - center.method_10260()) <= 2) {
            class_2680 state = (class_2680)this.field1760.get(pos);
            if (state != null && !state.method_26215()) {
               ++inconsistencies;
            }
         } else if (!pos.equals(center.method_10086(3))) {
            class_2680 state = (class_2680)this.field1760.get(pos);
            if (state == null || state.method_26215()) {
               ++inconsistencies;
            }
         }

         if (inconsistencies > 1) {
            return false;
         }
      }

      return true;
   }

   private static Color method0723(int argb) {
      return new Color(argb, true);
   }

   public static enum ServerMode implements DisplayNamed {
      field0682("ReallyWorld"),
      field0108("HolyWorld"),
      field1483("FunTime");

      private final String field1030;

      private ServerMode(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static ServerMode[] method0081() {
         return new ServerMode[]{field0682, field0108, field1483};
      }
   }

   private static enum ActionState {
      field0681,
      field0107,
      field1482,
      field1013,
      field0780,
      field1264,
      field0331;

      // $FF: synthetic method
      private static ActionState[] method0600() {
         return new ActionState[]{field0681, field0107, field1482, field1013, field0780, field1264, field0331};
      }
   }

   private static class PendingAction {
      final String field0715;
      final class_1792 field0153;
      final String field1504;

      PendingAction(String searchName, class_1792 item, String displayName) {
         this.field0715 = searchName;
         this.field0153 = item;
         this.field1504 = displayName;
      }
   }

   private static class TrackedPlayer {
      final String field0715;
      final String field0136;
      final class_1792 field1519;
      final ServerMode field1014;
      final int field0759;
      final KeyBindSetting field1259;

      TrackedPlayer(String displayName, String searchName, class_1792 item, ServerMode requiredMode, int cooldownSec, KeyBindSetting setting) {
         this.field0715 = displayName;
         this.field0136 = searchName;
         this.field1519 = item;
         this.field1014 = requiredMode;
         this.field0759 = cooldownSec;
         this.field1259 = setting;
      }
   }

   private static record ItemPosition(class_1792 item, class_243 vec, String world, double time) {
      public class_1792 method0566() {
         return this.item;
      }

      public class_243 method0024() {
         return this.vec;
      }

      public String method2067() {
         return this.world;
      }

      public double method1761() {
         return this.time;
      }
   }

   private static record EventInfo(String name, String lvl, String owner, class_243 vec, String world, double timeOpen, double timeEnd) {
      public String method0557() {
         return this.name;
      }

      public String method0017() {
         return this.lvl;
      }

      public String method2067() {
         return this.owner;
      }

      public class_243 method1803() {
         return this.vec;
      }

      public String method1619() {
         return this.world;
      }

      public double method1945() {
         return this.timeOpen;
      }

      public double method0412() {
         return this.timeEnd;
      }
   }

   private static class TrackedItem {
      final String field0715;
      final double field0002;
      final double field1409;
      final double field0956;
      final String field0791;
      long field1244;

      TrackedItem(String name, double x, double y, double z, String server, long expireAt) {
         this.field0715 = name;
         this.field0002 = x;
         this.field1409 = y;
         this.field0956 = z;
         this.field0791 = server;
         this.field1244 = expireAt;
      }
   }
}
