package aethereal;

import java.awt.Color;

public final class ColorConverter {
   public static int method0748(int var0, int var1, int var2, int var3) {
      return (var3 & 255) << 24 | (var0 & 255) << 16 | (var1 & 255) << 8 | (var2 & 255) << 0;
   }

   public static int[] method0731(int var0) {
      return new int[]{var0 >> 16 & 255, var0 >> 8 & 255, var0 & 255, var0 >> 24 & 255};
   }

   public static float[] method0962(Color var0) {
      return new float[]{(float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F};
   }

   public static float[] method0145(int var0) {
      int[] var1 = method0731(var0);
      return new float[]{(float)var1[0] / 255.0F, (float)var1[1] / 255.0F, (float)var1[2] / 255.0F, (float)var1[3] / 255.0F};
   }
}
