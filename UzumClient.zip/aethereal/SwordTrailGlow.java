package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.class_10142;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

public final class SwordTrailGlow {
   private static final class_2960 field0738 = ArbuzClient.method1012("textures/glow.png");
   private final List<SwordTrailFade> field0139 = new ArrayList();
   private final Random field1510 = new Random();

   public void method0578() {
      SwordTrail module = (SwordTrail)ArbuzClient.method2004().method1783().method0976(SwordTrail.class);
      if (module != null) {
         if (module.method2247() && module.method1692()) {
            SwordTrailSample last = module.method1712().method1773();
            if (last != null) {
               int rate = module.method2240();
               int lifetime = module.method2248();
               float spread = (float)Math.toRadians((double)module.method2209());
               class_243 tip = last.method0569();

               for(int i = 0; i < rate; ++i) {
                  double ang = this.field1510.nextDouble() * 3.1415933136871637 * (double)2.0F;
                  double lean = this.field1510.nextDouble() * (double)spread;
                  double vx = Math.cos(ang) * Math.sin(lean) * 0.150000071595892;
                  double vy = Math.cos(lean) * 0.150000071595892;
                  double vz = Math.sin(ang) * Math.sin(lean) * 0.150000071595892;
                  this.field0139.add(new SwordTrailFade(tip.field_1352, tip.field_1351, tip.field_1350, vx, vy, vz, lifetime));
               }
            }
         }

         float gravity = module.method2273();
         Iterator<SwordTrailFade> it = this.field0139.iterator();

         while(it.hasNext()) {
            SwordTrailFade p = (SwordTrailFade)it.next();
            p.field0956 = p.field0565;
            p.field0757 = p.field0002;
            p.field1241 = p.field1409;
            p.field0565 += p.field0313;
            p.field0002 += p.field0176;
            p.field1409 += p.field0457;
            p.field0176 -= (double)gravity;
            p.field0313 *= 0.8999997187437941;
            p.field0176 *= 0.9500000004989715;
            p.field0457 *= 0.8999997187437941;
            ++p.field1615;
            if (p.method0579()) {
               it.remove();
            }
         }

      }
   }

   public void method0665(float tickDelta) {
      SwordTrail module = (SwordTrail)ArbuzClient.method2004().method1783().method0976(SwordTrail.class);
      if (module != null && !this.field0139.isEmpty()) {
         class_310 mc = class_310.method_1551();
         class_4184 cam = mc.field_1773 != null ? mc.field_1773.method_19418() : null;
         if (cam != null) {
            class_243 camPos = cam.method_19326();
            Color color = module.method2205();
            float size = module.method2200();
            boolean useGlow = module.method2272();
            float yawRad = (float)Math.toRadians((double)cam.method_19330());
            double rightX = -Math.cos((double)yawRad);
            double rightZ = -Math.sin((double)yawRad);
            double upX = (double)0.0F;
            double upY = (double)1.0F;
            double upZ = (double)0.0F;
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(770, 32772);
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            RenderSystem.setShader(class_10142.field_53880);
            if (useGlow) {
               RenderSystem.setShaderTexture(0, field0738);
            }

            Matrix4f matrix = new Matrix4f();
            class_287 buf = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

            for(SwordTrailFade p : this.field0139) {
               double px = p.field0956 + (p.field0565 - p.field0956) * (double)tickDelta - camPos.field_1352;
               double py = p.field0757 + (p.field0002 - p.field0757) * (double)tickDelta - camPos.field_1351;
               double pz = p.field1241 + (p.field1409 - p.field1241) * (double)tickDelta - camPos.field_1350;
               float alpha = p.method0002() * ((float)color.getAlpha() / 255.0F);
               int a = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
               int argb = a << 24 | color.getRGB() & 16777215;
               double hx = rightX * (double)size;
               double hz = rightZ * (double)size;
               double vx = upX * (double)size;
               double vy = upY * (double)size;
               double vz = upZ * (double)size;
               buf.method_22918(matrix, (float)(px - hx - vx), (float)(py - vy), (float)(pz - hz - vz)).method_22913(0.0F, 0.0F).method_39415(argb);
               buf.method_22918(matrix, (float)(px + hx - vx), (float)(py - vy), (float)(pz + hz - vz)).method_22913(1.0F, 0.0F).method_39415(argb);
               buf.method_22918(matrix, (float)(px + hx + vx), (float)(py + vy), (float)(pz + hz + vz)).method_22913(1.0F, 1.0F).method_39415(argb);
               buf.method_22918(matrix, (float)(px - hx + vx), (float)(py + vy), (float)(pz - hz + vz)).method_22913(0.0F, 1.0F).method_39415(argb);
            }

            class_286.method_43433(buf.method_60800());
            RenderSystem.setShaderTexture(0, 0);
            RenderSystem.enableCull();
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
         }
      }
   }

   public void method0025() {
      this.field0139.clear();
   }
}
