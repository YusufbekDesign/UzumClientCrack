package aethereal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class StaffCommand extends Command implements MinecraftAccess {
   public StaffCommand() {
      super("staff", "Manage manual staff list", "sl");
      this.method1013("Управление ручным стафф-листом");
   }

   private StaffManager method1614() {
      return ArbuzClient.method2004().method0420();
   }

   public void method0800(CommandContext context) {
      String[] args = context.method1814();
      if (args.length == 0) {
         this.method1834(context);
      } else {
         switch (args[0].toLowerCase()) {
            case "add":
               this.method0803(context, args);
               break;
            case "del":
            case "remove":
               this.method0168(context, args);
               break;
            case "list":
               this.method0167(context);
               break;
            case "clear":
               this.method2112(context);
               break;
            default:
               this.method1834(context);
         }

      }
   }

   private void method0803(CommandContext context, String[] args) {
      if (args.length < 2) {
         context.method0213(method1813() ? "Использование: .staff add <имя>" : "Usage: .staff add <name>");
      } else {
         String name = args[1];
         if (name.contains("|")) {
            context.method0213(method1813() ? "Имя не может содержать '|'" : "Name cannot contain '|'");
         } else if (!this.method1614().method0214(name)) {
            context.method0213(method1813() ? "'" + name + "' уже в стафф-листе" : "'" + name + "' is already in staff list");
         } else {
            context.method1013(method1813() ? "Добавлен в стафф: " + name : "Added to staff: " + name);
         }
      }
   }

   private void method0168(CommandContext context, String[] args) {
      if (args.length < 2) {
         context.method0213(method1813() ? "Использование: .staff del <имя>" : "Usage: .staff del <name>");
      } else {
         String name = args[1];
         if (!this.method1614().method2135(name)) {
            context.method0213(method1813() ? "'" + name + "' не найден в стафф-листе" : "'" + name + "' not found in staff list");
         } else {
            context.method1013(method1813() ? "Удалён из стаффа: " + name : "Removed from staff: " + name);
         }
      }
   }

   private void method0167(CommandContext context) {
      List<StaffManager.StaffEntry> list = this.method1614().method0019();
      if (list.isEmpty()) {
         context.method2134(method1813() ? "стафф-лист пуст" : "Manual staff list is empty");
      } else {
         String var10001 = method1813() ? "Персонал (" : "Manual staff (";
         context.method2134(var10001 + list.size() + "):");

         for(StaffManager.StaffEntry e : list) {
            context.method0297(class_2561.method_43470("- " + e.method0017()).method_27694((s) -> s.method_36139(11184810)));
         }

      }
   }

   private void method2112(CommandContext context) {
      int removed = this.method1614().method1763();
      context.method1013(method1813() ? "Очищено: " + removed : "Cleared: " + removed);
   }

   private void method1834(CommandContext context) {
      String prefix = ArbuzClient.method2004().method2257().method2067();
      context.method0297(class_2561.method_43470(method1813() ? "Команды стаффа:" : "Staff commands:").method_27694((s) -> s.method_36139(8947848)));
      context.method0297(class_2561.method_43470(prefix + "staff add <" + (method1813() ? "имя" : "name") + ">").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(method1813() ? " - Добавить" : " - Add").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "staff del <" + (method1813() ? "имя" : "name") + ">").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(method1813() ? " - Удалить" : " - Remove").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "staff list").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(method1813() ? " - Показать список" : " - Show list").method_27694((s) -> s.method_36139(7829367))));
      context.method0297(class_2561.method_43470(prefix + "staff clear").method_27694((s) -> s.method_36139(11184810)).method_10852(class_2561.method_43470(method1813() ? " - Очистить" : " - Clear").method_27694((s) -> s.method_36139(7829367))));
   }

   public List<String> method1593(String[] args) {
      if (args.length <= 1) {
         String input = args.length == 1 ? args[0].toLowerCase() : "";
         return List.of("add", "del", "list", "clear").stream().filter((s) -> s.startsWith(input)).toList();
      } else if (args.length == 2 && args[0].equalsIgnoreCase("add")) {
         String input = args[1].toLowerCase();
         class_310 mc = class_310.method_1551();
         return mc.method_1562() != null ? mc.method_1562().method_2880().stream().map((entry) -> entry.method_2966().getName()).filter((name) -> name.toLowerCase().startsWith(input)).filter((name) -> this.method1614().method1008(name) == null).toList() : List.of();
      } else if (args.length == 2 && (args[0].equalsIgnoreCase("del") || args[0].equalsIgnoreCase("remove"))) {
         String input = args[1].toLowerCase();
         List<String> names = new ArrayList();

         for(StaffManager.StaffEntry e : this.method1614().method0019()) {
            if (e.method0017().toLowerCase().startsWith(input)) {
               names.add(e.method0017());
            }
         }

         return names;
      } else {
         return List.of();
      }
   }

   public String method2179(String[] args) {
      if (args.length == 2) {
         String var10000;
         switch (args[0].toLowerCase()) {
            case "add":
            case "del":
            case "remove":
               var10000 = method1813() ? "<имя>" : "<name>";
               break;
            default:
               var10000 = "";
         }

         return var10000;
      } else {
         return "";
      }
   }

   public Map<String, String> method0351(String[] args) {
      if (args.length <= 1) {
         return method1813() ? Map.of("add", "Добавить игрока в стафф-лист", "del", "Удалить", "list", "Показать список", "clear", "Очистить список") : Map.of("add", "Add a player to the staff list", "del", "Remove", "list", "Show list", "clear", "Clear list");
      } else {
         return Map.of();
      }
   }
}
