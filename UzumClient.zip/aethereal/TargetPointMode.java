package aethereal;

import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;

public enum TargetPointMode implements DisplayNamed {
   field0674("Eyes", class_1297::method_33571),
   field0102("Center", (var0) -> var0.method_19538().method_1031((double)0.0F, (double)var0.method_17682() / (double)2.0F, (double)0.0F));

   private final String field1504;
   private final Function<class_1309, class_243> field1035;

   private TargetPointMode(String var3, Function<class_1309, class_243> var4) {
      this.field1504 = var3;
      this.field1035 = var4;
   }

   public class_243 method1157(class_1309 var1) {
      return (class_243)this.field1035.apply(var1);
   }

   public String method0557() {
      return this.field1504;
   }

   // $FF: synthetic method
   private static TargetPointMode[] $values() {
      return new TargetPointMode[]{field0674, field0102};
   }
}
