package aethereal;

import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;
import lombok.Generated;

public class ActionSequence {
   private final IntervalTimer field0647 = new IntervalTimer();
   private final List<ScheduledStep> field0139 = Lists.newCopyOnWriteArrayList();
   private final List<RepeatingStep> field1508 = Lists.newCopyOnWriteArrayList();
   private int field0958;
   private int field0759;
   private boolean field1276;
   private SequenceStep field0326 = new ImmediateStep(1);

   public ActionSequence() {
      this.method1778();
   }

   public ActionSequence method0759(int delay, Action action) {
      return this.method0762(delay, action, () -> true, 0);
   }

   public ActionSequence method0761(int delay, Action action, BooleanSupplier condition) {
      return this.method0762(delay, action, condition, 0);
   }

   public ActionSequence method0760(int delay, Action action, int priority) {
      return this.method0762(delay, action, () -> true, priority);
   }

   public ActionSequence method0762(int delay, Action action, BooleanSupplier condition, int priority) {
      this.field0139.add(new ScheduledStep(delay, action, condition, priority));
      Collections.sort(this.field0139);
      return this;
   }

   public ActionSequence method0154(int ticks, Action action) {
      return this.method0157(ticks, action, () -> true, 0);
   }

   public ActionSequence method0156(int ticks, Action action, BooleanSupplier condition) {
      return this.method0157(ticks, action, condition, 0);
   }

   public ActionSequence method0155(int ticks, Action action, int priority) {
      return this.method0157(ticks, action, () -> true, priority);
   }

   public ActionSequence method0157(int ticks, Action action, BooleanSupplier condition, int priority) {
      this.field1508.add(new RepeatingStep(ticks, action, condition, priority));
      Collections.sort(this.field1508);
      return this;
   }

   public void method0578() {
      this.field0647.method0578();
   }

   public void method0025() {
      this.field0958 = 0;
      this.field0759 = 0;
   }

   public ActionSequence method2056() {
      if (this.method1974()) {
         this.method1778();
      }

      return this;
   }

   public ActionSequence method1778() {
      this.field0139.clear();
      this.field1508.clear();
      this.method0578();
      this.method0025();
      return this;
   }

   public void method1634() {
      if ((!this.field0139.isEmpty() || !this.field1508.isEmpty()) && !this.field1276) {
         this.field0139.forEach((step) -> {
            if (this.field0958 < this.field0139.size()) {
               ScheduledStep currentStep = (ScheduledStep)this.field0139.get(this.field0958);
               if (currentStep.method2070().getAsBoolean() && this.field0647.method0612((double)currentStep.method0531())) {
                  currentStep.method0008().perform();
                  ++this.field0958;
                  this.method0578();
                  if (this.field0326.method0739(this.field0958, this.field0139.size())) {
                     this.method0025();
                     this.field0326.method0578();
                  }
               }
            }

         });
         this.field1508.forEach((step) -> {
            if (this.field0759 < this.field1508.size()) {
               RepeatingStep currentTickStep = (RepeatingStep)this.field1508.get(this.field0759);
               if (currentTickStep.method1795().getAsBoolean() && currentTickStep.method0003() <= 0) {
                  currentTickStep.method2054().perform();
                  ++this.field0759;
                  this.method0578();
                  if (this.field0326.method0739(this.field0759, this.field1508.size())) {
                     this.method0025();
                     this.field0326.method0578();
                  }
               }

               currentTickStep.method0578();
            }

         });
         this.field0958 = Math.min(this.field0958, this.field0139.size());
         this.field0759 = Math.min(this.field0759, this.field1508.size());
      }
   }

   public ActionSequence method0854(SequenceStep loopStrategy) {
      this.field0326 = loopStrategy;
      return this;
   }

   public boolean method1974() {
      return this.field0958 >= this.field0139.size() && this.field0759 >= this.field1508.size() && !this.field1276 && this.field0326.method0026();
   }

   @Generated
   public IntervalTimer method0417() {
      return this.field0647;
   }

   @Generated
   public List<ScheduledStep> method0370() {
      return this.field0139;
   }

   @Generated
   public List<RepeatingStep> method0494() {
      return this.field1508;
   }

   @Generated
   public int method2214() {
      return this.field0958;
   }

   @Generated
   public int method2183() {
      return this.field0759;
   }

   @Generated
   public boolean method2267() {
      return this.field1276;
   }

   @Generated
   public SequenceStep method1909() {
      return this.field0326;
   }

   @Generated
   public void method0729(int currentStepIndex) {
      this.field0958 = currentStepIndex;
   }

   @Generated
   public void method0143(int currentTickStepIndex) {
      this.field0759 = currentTickStepIndex;
   }

   @Generated
   public void method1570(boolean interrupt) {
      this.field1276 = interrupt;
   }

   public static class ImmediateStep implements SequenceStep {
      private final int field0567;
      private int field0004;

      public ImmediateStep(int loopCount) {
         this.field0567 = loopCount - 1;
      }

      public boolean method0739(int currentStepIndex, int totalSteps) {
         return currentStepIndex >= totalSteps && this.field0004 < this.field0567;
      }

      public void method0578() {
         ++this.field0004;
      }

      public boolean method0026() {
         return this.field0004 >= this.field0567;
      }
   }

   public static final class ScheduledStep implements Comparable<ScheduledStep> {
      private int field0567;
      private Action field0069;
      private BooleanSupplier field1513;
      private int field0958;

      public ScheduledStep(int delay, Action action, BooleanSupplier condition, int priority) {
         this.field0567 = delay;
         this.field0069 = action;
         this.field1513 = condition;
         this.field0958 = priority;
      }

      public int method0855(ScheduledStep otherStep) {
         return Integer.compare(otherStep.method1763(), this.method1763());
      }

      @Generated
      public int method0531() {
         return this.field0567;
      }

      @Generated
      public Action method0008() {
         return this.field0069;
      }

      @Generated
      public BooleanSupplier method2070() {
         return this.field1513;
      }

      @Generated
      public int method1763() {
         return this.field0958;
      }

      @Generated
      public ScheduledStep method0720(int delay) {
         this.field0567 = delay;
         return this;
      }

      @Generated
      public ScheduledStep method0847(Action action) {
         this.field0069 = action;
         return this;
      }

      @Generated
      public ScheduledStep method1098(BooleanSupplier condition) {
         this.field1513 = condition;
         return this;
      }

      @Generated
      public ScheduledStep method0139(int priority) {
         this.field0958 = priority;
         return this;
      }

      // $FF: synthetic method
      public int compareTo(Object var1) {
         return this.method0855((ScheduledStep)var1);
      }
   }

   public static final class RepeatingStep implements Comparable<RepeatingStep> {
      private int field0567;
      private Action field0069;
      private BooleanSupplier field1513;
      private int field0958;

      public RepeatingStep(int ticks, Action action, BooleanSupplier condition, int priority) {
         this.field0567 = ticks;
         this.field0069 = action;
         this.field1513 = condition;
         this.field0958 = priority;
      }

      public int method0857(RepeatingStep otherStep) {
         return Integer.compare(otherStep.method1604(), this.method1604());
      }

      public void method0578() {
         --this.field0567;
      }

      @Generated
      public int method0003() {
         return this.field0567;
      }

      @Generated
      public Action method2054() {
         return this.field0069;
      }

      @Generated
      public BooleanSupplier method1795() {
         return this.field1513;
      }

      @Generated
      public int method1604() {
         return this.field0958;
      }

      @Generated
      public RepeatingStep method0721(int ticks) {
         this.field0567 = ticks;
         return this;
      }

      @Generated
      public RepeatingStep method0848(Action action) {
         this.field0069 = action;
         return this;
      }

      @Generated
      public RepeatingStep method1099(BooleanSupplier condition) {
         this.field1513 = condition;
         return this;
      }

      @Generated
      public RepeatingStep method0140(int priority) {
         this.field0958 = priority;
         return this;
      }

      // $FF: synthetic method
      public int compareTo(Object var1) {
         return this.method0857((RepeatingStep)var1);
      }
   }

   public static class ConditionalStep implements SequenceStep {
      public boolean method0739(int currentStepIndex, int totalSteps) {
         return currentStepIndex >= totalSteps;
      }

      public void method0578() {
      }

      public boolean method0026() {
         return false;
      }
   }

   public interface SequenceStep {
      boolean method0739(int var1, int var2);

      void method0578();

      boolean method0026();
   }
}
