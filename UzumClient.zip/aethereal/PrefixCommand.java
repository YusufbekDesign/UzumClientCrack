package aethereal;

public final class PrefixCommand extends Command {
   public PrefixCommand() {
      super("prefix", "Change command prefix", "p");
      this.method1013("Buyruq prefiksini o'zgartirish");
   }

   public void method0800(CommandContext var1) {
      String[] var2 = var1.method1814();
      if (var2.length == 0) {
         String var4 = ArbuzClient.method2004().method2257().method2067();
         var1.method2134("Joriy prefiks: " + var4);
         var1.method2134("Ishlatish: .prefix <yangi_prefiks>");
      } else {
         String var3 = var2[0];
         ArbuzClient.method2004().method2257().method1846(var3);
         var1.method1013("Prefiks o'zgartirildi: " + var3);
      }

   }

   public String method2179(String[] var1) {
      return var1.length > 1 || var1.length != 0 && !var1[0].isEmpty() ? "" : "<yangi prefiks>";
   }
}
