package aethereal;

public final class ProxyGeoService {
   private ProxyGeoService() {
   }

   public static void method0907(ProxyEntry proxyEntry) {
   }
}
