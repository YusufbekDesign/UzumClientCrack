package aethereal;

import java.util.List;
import lombok.Generated;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2371;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2815;
import net.minecraft.class_2851;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_304;
import net.minecraft.class_3489;
import net.minecraft.class_3675;
import net.minecraft.class_9282;
import org.patch.arbuzhack.api.mixins.accessors.IClientPlayerInteractionManager;

public final class InventoryManager implements MinecraftAccess {
   private static final DelayedAction field0999 = new DelayedAction();
   public static final int field0567 = 0;
   public static final int field0004 = 8;
   public static final int field1411 = 35;

   public static DelayedAction method0544() {
      return field0999;
   }

   public static boolean method0026() {
      return !field0999.method0026();
   }

   public static void method2078() {
      if (field0796.field_1724 != null) {
         field0999.method2078();
      }
   }

   public static void method0753(int slotId, int button, class_1713 type) {
      field0796.field_1761.method_2906(0, slotId, button, type, field0796.field_1724);
   }

   public static int method1217(class_1792 item) {
      int count = 0;

      for(int i = 0; i < field0796.field_1724.field_7512.field_7761.size(); ++i) {
         if (((class_1735)field0796.field_1724.field_7512.field_7761.get(i)).method_7677().method_7909() == item) {
            ++count;
         }
      }

      return count;
   }

   public static void method0996(Runnable task, int priority) {
      method0997(task, priority, true);
   }

   public static void method0997(Runnable task, int priority, boolean cleanup) {
      if (cleanup) {
         field0999.method0578();
      }

      field0999.method0765(1, () -> method1973(), priority).method0765(2, () -> {
         method1812();
         task.run();
         method1634();
         method0430();
      }, priority);
   }

   public static void method1077(List<class_2596<?>> task, int priority, boolean cleanup, long time) {
      if (cleanup) {
         field0999.method0578();
      }

      field0999.method0765(1, () -> method1973(), priority).method0765(2, () -> (new Thread(() -> {
            float divideTime = (float)time / (float)task.size();

            for(class_2596<?> p : task) {
               PacketQueue.method1354(p);
            }

            PacketQueue.method1354(new class_2815(field0796.field_1724.field_7512.field_7763));
            method0430();
            task.clear();
         })).start(), priority);
   }

   private static void method1973() {
      field0796.field_1690.field_1894.method_23481(false);
      field0796.field_1690.field_1881.method_23481(false);
      field0796.field_1690.field_1913.method_23481(false);
      field0796.field_1690.field_1849.method_23481(false);
      field0796.field_1690.field_1903.method_23481(false);
      field0796.field_1690.field_1832.method_23481(false);
      field0796.field_1690.field_1867.method_23481(false);
      if (field0796.field_1724 != null && field0796.field_1724.method_5624()) {
         field0796.field_1724.method_5728(false);
      }

      field0004 = Math.max(Sprint.field0004, 1);
   }

   private static void method0430() {
      long handle = field0796.method_22683().method_4490();
      class_304[] keys = new class_304[]{field0796.field_1690.field_1894, field0796.field_1690.field_1881, field0796.field_1690.field_1913, field0796.field_1690.field_1849, field0796.field_1690.field_1903, field0796.field_1690.field_1832, field0796.field_1690.field_1867};

      for(class_304 key : keys) {
         key.method_23481(class_3675.method_15987(handle, key.method_1429().method_1444()));
      }

   }

   public static void method1812() {
      if (field0796.method_1562() != null) {
         field0796.method_1562().method_52787(new class_2851(new class_10185(false, false, false, false, false, false, false)));
      }

   }

   public static void method1634() {
      if (field0796.method_1562() != null && field0796.field_1724 != null) {
         field0796.method_1562().method_52787(new class_2851(field0796.field_1724.field_3913.field_54155));
      }

   }

   public static int method0716(int index) {
      return index >= 0 && index <= 8 ? 36 + index : index;
   }

   public static int method1567(boolean inHotbar) {
      if (field0796.field_1724 == null) {
         return -1;
      } else {
         class_2371<class_1799> main = field0796.field_1724.method_31548().field_7547;
         int firstSlot = inHotbar ? 0 : 9;
         int lastSlot = inHotbar ? 9 : 36;

         for(int i = firstSlot; i < lastSlot; ++i) {
            if (((class_1799)main.get(i)).method_7909() instanceof class_1743) {
               return i;
            }
         }

         return -1;
      }
   }

   public static void method0808(SwitchMode mode, int slot, int previousSlot) {
      if (slot != -1 && previousSlot != -1 && slot != ArbuzClient.method2004().method2186().method0003()) {
         switch (mode.ordinal()) {
            case 0:
               field0796.field_1724.method_31548().field_7545 = slot;
               ((IClientPlayerInteractionManager)field0796.field_1761).syncSelectedSlot$drug();
               break;
            case 1:
               PacketQueue.method0300(new class_2868(slot));
               break;
            case 2:
               method0809(InventoryManager.ClickAction.field0047, slot, previousSlot);
         }

      }
   }

   public static void method0169(SwitchMode mode, int slot, int previousSlot) {
      if (slot != -1 && previousSlot != -1 && slot != ArbuzClient.method2004().method2186().method0003()) {
         switch (mode.ordinal()) {
            case 0:
               field0796.field_1724.method_31548().field_7545 = previousSlot;
               ((IClientPlayerInteractionManager)field0796.field_1761).syncSelectedSlot$drug();
               break;
            case 1:
               PacketQueue.method0300(new class_2868(previousSlot));
               break;
            case 2:
               method0809(InventoryManager.ClickAction.field0047, slot, previousSlot);
         }

      }
   }

   public static void method0143(int slot) {
      method0771(slot, true);
   }

   public static void method0771(int slot, boolean client) {
      if (field0796.field_1724 != null) {
         if (field0796.field_1724.method_31548().field_7545 != slot) {
            field0796.field_1724.field_3944.method_52787(new class_2868(slot));
            if (client) {
               field0796.field_1724.method_31548().field_7545 = slot;
            }

         }
      }
   }

   public static void method0809(ClickAction mode, int slot, int targetSlot) {
      if (slot != -1 && targetSlot != -1) {
         switch (mode.ordinal()) {
            case 0:
               field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, method0716(slot), 0, class_1713.field_7790, field0796.field_1724);
               field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, method0716(targetSlot), 0, class_1713.field_7790, field0796.field_1724);
               field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, method0716(slot), 0, class_1713.field_7790, field0796.field_1724);
               break;
            case 1:
               field0796.field_1761.method_2906(field0796.field_1724.field_7512.field_7763, slot, targetSlot, class_1713.field_7791, field0796.field_1724);
         }

      }
   }

   public static void method0738(int slot, int targetSlot) {
      if (slot != -1 && targetSlot != -1) {
         field0796.field_1761.method_2906(field0796.field_1724.field_7498.field_7763, method0716(slot), 0, class_1713.field_7790, field0796.field_1724);
         field0796.field_1761.method_2906(field0796.field_1724.field_7498.field_7763, targetSlot, 0, class_1713.field_7790, field0796.field_1724);
         field0796.field_1761.method_2906(field0796.field_1724.field_7498.field_7763, method0716(slot), 0, class_1713.field_7790, field0796.field_1724);
      }
   }

   public static void method0807(SwingHand mode) {
      switch (mode.ordinal()) {
         case 0 -> field0796.field_1724.method_6104(class_1268.field_5808);
         case 1 -> field0796.field_1724.method_6104(class_1268.field_5810);
         case 2 -> PacketQueue.method0300(new class_2879(class_1268.field_5808));
      }

   }

   public static class_1268 method1118(class_1268 hand) {
      return hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
   }

   public static int method0147(int start, int end) {
      int netheriteSlot = -1;
      int diamondSlot = -1;
      int ironSlot = -1;
      int goldenSlot = -1;
      int stoneSlot = -1;
      int woodenSlot = -1;

      for(int i = end; i >= start; --i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_22022) {
            netheriteSlot = i;
         } else if (stack.method_7909() == class_1802.field_8802) {
            diamondSlot = i;
         } else if (stack.method_7909() == class_1802.field_8371) {
            ironSlot = i;
         } else if (stack.method_7909() == class_1802.field_8845) {
            goldenSlot = i;
         } else if (stack.method_7909() == class_1802.field_8528) {
            stoneSlot = i;
         } else if (stack.method_7909() == class_1802.field_8091) {
            woodenSlot = i;
         }
      }

      if (netheriteSlot != -1) {
         return netheriteSlot;
      } else if (diamondSlot != -1) {
         return diamondSlot;
      } else if (ironSlot != -1) {
         return ironSlot;
      } else if (goldenSlot != -1) {
         return goldenSlot;
      } else if (stoneSlot != -1) {
         return stoneSlot;
      } else {
         return woodenSlot;
      }
   }

   public static int method2105(int start, int end) {
      int netheriteSlot = -1;
      int diamondSlot = -1;
      int ironSlot = -1;
      int goldenSlot = -1;
      int stoneSlot = -1;
      int woodenSlot = -1;

      for(int i = end; i >= start; --i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_22025) {
            netheriteSlot = i;
         } else if (stack.method_7909() == class_1802.field_8556) {
            diamondSlot = i;
         } else if (stack.method_7909() == class_1802.field_8475) {
            ironSlot = i;
         } else if (stack.method_7909() == class_1802.field_8825) {
            goldenSlot = i;
         } else if (stack.method_7909() == class_1802.field_8062) {
            stoneSlot = i;
         } else if (stack.method_7909() == class_1802.field_8406) {
            woodenSlot = i;
         }
      }

      if (netheriteSlot != -1) {
         return netheriteSlot;
      } else if (diamondSlot != -1) {
         return diamondSlot;
      } else if (ironSlot != -1) {
         return ironSlot;
      } else if (goldenSlot != -1) {
         return goldenSlot;
      } else if (stoneSlot != -1) {
         return stoneSlot;
      } else {
         return woodenSlot;
      }
   }

   public static int method1365(class_2680 blockState, int start, int end) {
      double bestScore = (double)-1.0F;
      int bestSlot = -1;

      for(int i = start; i <= end; ++i) {
         double score = (double)field0796.field_1724.method_31548().method_5438(i).method_7924(blockState);
         if (score > bestScore) {
            bestScore = score;
            bestSlot = i;
         }
      }

      return bestSlot;
   }

   public static int method1829(int start, int end) {
      int leatherSlot = -1;
      int chainmail = -1;
      int ironSlot = -1;
      int goldenSlot = -1;
      int diamondSlot = -1;
      int netheriteSlot = -1;

      for(int i = end; i >= start; --i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8577) {
            leatherSlot = i;
         } else if (stack.method_7909() == class_1802.field_8873) {
            chainmail = i;
         } else if (stack.method_7909() == class_1802.field_8523) {
            ironSlot = i;
         } else if (stack.method_7909() == class_1802.field_8678) {
            goldenSlot = i;
         } else if (stack.method_7909() == class_1802.field_8058) {
            diamondSlot = i;
         } else if (stack.method_7909() == class_1802.field_22028) {
            netheriteSlot = i;
         }
      }

      if (chainmail != -1) {
         return chainmail;
      } else if (ironSlot != -1) {
         return ironSlot;
      } else if (goldenSlot != -1) {
         return goldenSlot;
      } else if (diamondSlot != -1) {
         return diamondSlot;
      } else if (netheriteSlot != -1) {
         return netheriteSlot;
      } else {
         return leatherSlot;
      }
   }

   public static int method1191(class_1657 entity, int slot) {
      class_1799 stack = entity.method_31548().method_7372(slot);
      return stack.method_31573(class_3489.field_48803) ? class_9282.method_57470(stack, -6265536) : -1;
   }

   public static int method0262(class_1792 item) {
      return method1225(item, 0, 35);
   }

   public static int method2154(class_1792 item) {
      return method1225(item, 0, 8);
   }

   public static int method1859(class_1792 item) {
      return method1225(item, 9, 35);
   }

   public static int method0975(Class<? extends class_1792> item) {
      return method0978(item, 0, 35);
   }

   public static int method0200(Class<? extends class_1792> item) {
      return method0978(item, 0, 8);
   }

   public static int method2123(Class<? extends class_1792> item) {
      return method0978(item, 9, 35);
   }

   public static int method1225(class_1792 item, int start, int end) {
      for(int i = end; i >= start; --i) {
         if (field0796.field_1724.method_31548().method_5438(i).method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   public static int method0978(Class<? extends class_1792> item, int start, int end) {
      for(int i = end; i >= start; --i) {
         class_1799 stack = field0796.field_1724.method_31548().method_5438(i);
         if (stack.method_7909().getClass().isAssignableFrom(item)) {
            return i;
         }
      }

      return -1;
   }

   public static int method1643(int start, int end) {
      for(int i = end; i >= start; --i) {
         if (field0796.field_1724.method_31548().method_5438(i).method_7960()) {
            return i;
         }
      }

      return -1;
   }

   public static int method0303(class_2680 state, int start, int end) {
      if (field0796.field_1724 == null) {
         return -1;
      } else {
         int best = -1;
         float bestSpeed = 0.0F;

         for(int i = start; i <= end; ++i) {
            class_1799 stack = (class_1799)field0796.field_1724.method_31548().field_7547.get(i);
            if (stack != null && !stack.method_7960()) {
               float speed = stack.method_7924(state);
               if (speed > bestSpeed) {
                  bestSpeed = speed;
                  best = i;
               }
            }
         }

         return best;
      }
   }

   @Generated
   private InventoryManager() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static enum SwitchMode implements DisplayNamed {
      field0613("settings.normal"),
      field0046("settings.switch.silent"),
      field1440("settings.switch.alternative"),
      field0976("settings.none");

      private final String field0791;

      public String method0557() {
         return this.field0791;
      }

      @Generated
      private SwitchMode(final String name) {
         this.field0791 = name;
      }

      // $FF: synthetic method
      private static SwitchMode[] method0058() {
         return new SwitchMode[]{field0613, field0046, field1440, field0976};
      }
   }

   public static enum ClickAction {
      field0614,
      field0047;

      // $FF: synthetic method
      private static ClickAction[] method0586() {
         return new ClickAction[]{field0614, field0047};
      }
   }

   public static enum SwingHand implements DisplayNamed {
      field0612("settings.swing.mainhand"),
      field0045("settings.swing.offhand"),
      field1439("settings.packet"),
      field0975("settings.none");

      private final String field0791;

      public String method0557() {
         return this.field0791;
      }

      @Generated
      private SwingHand(final String name) {
         this.field0791 = name;
      }

      // $FF: synthetic method
      private static SwingHand[] method0057() {
         return new SwingHand[]{field0612, field0045, field1439, field0975};
      }
   }
}
