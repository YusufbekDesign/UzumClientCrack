package aethereal;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_7439;

public class AutoTpAccept extends Module {
   private final String[] field0173 = new String[]{"has requested teleport", "просит телепортироваться", "хочет телепортироваться к вам", "просит телепортироваться к Вам"};
   private final BooleanSetting field1432 = (BooleanSetting)(new BooleanSetting("autotpaccept.onlyfriends", true)).method1007("Faqat do'stlar").method0210("Only accept teleport requests from friends").method2130("Faqat do'stlardan teleportatsiya so'rovlarini qabul qilish");
   private boolean field1049;

   public AutoTpAccept() {
      super("AutoTpAccept", ModuleCategory.field0776, "Teleportatsiya so'rovlarini avtomatik qabul qiladi");
      this.method1013("Teleportatsiya so'rovlarini avtomatik qabul qiladi");
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound var1) {
      class_2596 var3 = var1.method1970();
      if (var3 instanceof class_7439 var2) {
         String var6 = var2.comp_763().getString().toLowerCase();
         if (this.method2135(var6)) {
            boolean var4 = true;
            if ((Boolean)this.field1432.method0492()) {
               ArbuzClient var5 = ArbuzClient.method2004();
               if (var5 != null && var5.method1608() != null) {
                  Stream var10000 = var5.method1608().method0424().stream().map(String::toLowerCase);
                  Objects.requireNonNull(var6);
                  var4 = var10000.anyMatch(var6::contains);
               }
            }

            this.field1049 = var4;
         }
      }

   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (!method1974() && this.field1049) {
         field0796.field_1724.field_3944.method_45730("tpaccept");
         this.field1049 = false;
      }

   }

   private boolean method2135(String var1) {
      Stream var10000 = Arrays.stream(this.field0173).map(String::toLowerCase);
      Objects.requireNonNull(var1);
      return var10000.anyMatch(var1::contains);
   }
}
