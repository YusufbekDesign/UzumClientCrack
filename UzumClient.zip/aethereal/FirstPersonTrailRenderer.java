package aethereal;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;

public final class FirstPersonTrailRenderer {
   private FirstPersonTrailRenderer() {
   }

   public static void method1543(class_759 instance, class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, Operation<Void> original) {
      SwordTrail module = (SwordTrail)ArbuzClient.method2004().method1783().method0976(SwordTrail.class);
      if (module != null && module.method2030()) {
         if (!module.method1755() || hand == class_1268.field_5808) {
            List<SwordTrailAnimation> ghosts = module.method1924();
            if (!ghosts.isEmpty()) {
               Shaders shaders = (Shaders)ArbuzClient.method2004().method1783().method0976(Shaders.class);
               boolean hasShaderOutline = shaders != null && shaders.method2195() && shaders.method1755();
               if (hasShaderOutline) {
                  float baseAlpha = module.method2001();
                  float fadeIn = module.method1919();
                  float fadeOut = module.method1925();
                  boolean tintEnabled = module.method0472();
                  Color effectiveColor = tintEnabled ? module.method0453() : shaders.method2023();

                  for(SwordTrailAnimation g : ghosts) {
                     float envelope = method0681(g.method0002(), fadeIn, fadeOut);
                     if (!(envelope <= 0.001F)) {
                        int outlineAlpha = (int)(255.0F * baseAlpha * envelope);
                        if (outlineAlpha > 0) {
                           class_4597 ghostVCP = shaders.method1708().method1518(DelegatingVertexConsumer.field0165, effectiveColor, outlineAlpha);
                           original.call(new Object[]{instance, player, tickDelta, pitch, hand, g.field0566, item, equipProgress, matrices, ghostVCP, light});
                        }
                     }
                  }

               }
            }
         }
      }
   }

   private static float method0681(float t, float fadeIn, float fadeOut) {
      if (!(t <= 0.0F) && !(t >= 1.0F)) {
         float rise = fadeIn > 0.0F ? Math.min(1.0F, t / fadeIn) : 1.0F;
         float fall = fadeOut > 0.0F ? Math.min(1.0F, (1.0F - t) / fadeOut) : 1.0F;
         return Math.max(0.0F, Math.min(rise, fall));
      } else {
         return 0.0F;
      }
   }
}
