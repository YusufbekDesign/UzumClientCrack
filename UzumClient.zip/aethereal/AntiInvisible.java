package aethereal;

public class AntiInvisible extends Module {
   private final BooleanSetting field0034 = (BooleanSetting)(new BooleanSetting("antiinvisible.self", false)).method1007("O'zim").method0210("Ko'rinmas o'zimni ko'rsatish").method2130("O'zini ko'rsatish");

   public AntiInvisible() {
      super("AntiInvisible", ModuleCategory.field1004, "Ko'rinmas obyektlarni ko'rsatadi");
      this.method1013("Ko'rinmas mavjudotlarni ko'rsatadi");
   }

   public boolean method1736() {
      return (Boolean)this.field0034.method0492();
   }
}
