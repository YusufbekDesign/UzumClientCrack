package aethereal;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

public class RectangleLayout {
   private float field0566;
   private float field0003;
   private float field1410;
   private float field0957;
   private float field0758 = 0.15F;
   private float field1242 = 5000.0F;
   private float field0314 = 0.98F;
   private float field0177 = 3.0F;
   private boolean field0497 = true;
   private float field1614 = -1.0F;
   private float field1538 = -1.0F;
   private final List<VerticalBounds> field1728 = new ArrayList();
   private final List<HorizontalBounds> field1155 = new ArrayList();
   private Color field1104 = new Color(84, 16, 178);

   public RectangleLayout method0958(Color color) {
      this.field1104 = color;
      return this;
   }

   public void method0686(float x, float y, float width, float height) {
      this.field0566 = x;
      this.field0003 = y;
      this.field1410 = width;
      this.field0957 = height;
   }

   public RectangleLayout method0656(float radius) {
      this.field0758 = radius;
      return this;
   }

   public RectangleLayout method0120(float force) {
      this.field1242 = force;
      return this;
   }

   public RectangleLayout method2094(float dissipation) {
      this.field0314 = dissipation;
      return this;
   }

   public RectangleLayout method1819(float curl) {
      this.field0177 = curl;
      return this;
   }

   public RectangleLayout method1568(boolean shading) {
      this.field0497 = shading;
      return this;
   }

   public void method1414(class_332 context, int mouseX, int mouseY, float alpha) {
      if (!(this.field1410 <= 0.0F) && !(this.field0957 <= 0.0F)) {
         float dt = 0.016F;
         boolean inMouse = (float)mouseX >= this.field0566 && (float)mouseX <= this.field0566 + this.field1410 && (float)mouseY >= this.field0003 && (float)mouseY <= this.field0003 + this.field0957;
         if (inMouse) {
            float localMx = (float)mouseX - this.field0566;
            float localMy = (float)mouseY - this.field0003;
            if (this.field1614 >= 0.0F && this.field1538 >= 0.0F) {
               float dx = localMx - this.field1614;
               float dy = localMy - this.field1538;
               float dist = (float)Math.sqrt((double)(dx * dx + dy * dy));
               if (dist > 1.0F) {
                  Color color = this.method0553();
                  this.method0696(localMx, localMy, dx * this.field1242 * 0.001F, dy * this.field1242 * 0.001F, color);
               }
            }

            this.field1614 = localMx;
            this.field1538 = localMy;
         } else {
            this.field1614 = -1.0F;
            this.field1538 = -1.0F;
         }

         this.method1638(dt);
         this.method1977(dt);
         this.method1401(context, alpha);
      }
   }

   private Color method0553() {
      float variation = 0.2F + (float)Math.random() * 0.3F;
      return new Color(Math.min(255, (int)((float)this.field1104.getRed() * variation)), Math.min(255, (int)((float)this.field1104.getGreen() * variation)), Math.min(255, (int)((float)this.field1104.getBlue() * variation)), 255);
   }

   private void method0696(float px, float py, float vx, float vy, Color color) {
      float radius = this.field0758 * Math.min(this.field1410, this.field0957) * 0.5F;
      this.field1728.add(new VerticalBounds(px, py, vx, vy, radius, color, 1.0F));
      int particleCount = 3 + (int)(Math.random() * (double)5.0F);

      for(int i = 0; i < particleCount; ++i) {
         float angle = (float)(Math.random() * 3.1415927169270965 * (double)2.0F);
         float speed = (float)(Math.random() * (double)30.0F + (double)10.0F);
         float pvx = vx * 0.3F + (float)Math.cos((double)angle) * speed;
         float pvy = vy * 0.3F + (float)Math.sin((double)angle) * speed;
         float size = (float)(Math.random() * (double)4.0F + (double)2.0F);
         this.field1155.add(new HorizontalBounds(px, py, pvx, pvy, size, color, 1.0F));
      }

   }

   private void method1638(float dt) {
      float time = (float)System.currentTimeMillis() * 0.001F;
      float curlEffect = this.field0177 * 0.1F;
      Iterator<VerticalBounds> iter = this.field1728.iterator();

      while(iter.hasNext()) {
         VerticalBounds s = (VerticalBounds)iter.next();
         s.field0566 += s.field1410 * dt;
         s.field0003 += s.field0957 * dt;
         s.field1410 *= this.field0314;
         s.field0957 *= this.field0314;
         s.field1410 += (float)Math.sin((double)(s.field0003 * 0.05F + time)) * curlEffect;
         s.field0957 += (float)Math.cos((double)(s.field0566 * 0.05F + time)) * curlEffect;
         s.field0314 -= dt * 0.5F;
         s.field0758 *= 0.995F;
         if (s.field0314 <= 0.0F || s.field0758 < 1.0F) {
            iter.remove();
         }
      }

   }

   private void method1977(float dt) {
      Iterator<HorizontalBounds> iter = this.field1155.iterator();

      while(iter.hasNext()) {
         HorizontalBounds p = (HorizontalBounds)iter.next();
         p.field0566 += p.field1410 * dt;
         p.field0003 += p.field0957 * dt;
         p.field1410 *= 0.95F;
         p.field0957 *= 0.95F;
         p.field0314 -= dt * 0.8F;
         if (p.field0314 <= 0.0F) {
            iter.remove();
         }
      }

   }

   private void method1401(class_332 context, float alpha) {
      class_4587 stack = context.method_51448();
      Matrix4f matrix = stack.method_23760().method_23761();
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
      RenderSystem.setShader(class_10142.field_53876);
      class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);

      for(VerticalBounds s : this.field1728) {
         float screenX = this.field0566 + s.field0566;
         float screenY = this.field0003 + s.field0003;
         float r = s.field0758;
         float lifeAlpha = s.field0314 * alpha;
         if (!(lifeAlpha < 0.01F)) {
            float cr = (float)s.field1268.getRed() / 255.0F;
            float cg = (float)s.field1268.getGreen() / 255.0F;
            float cb = (float)s.field1268.getBlue() / 255.0F;
            if (this.field0497) {
               float shade = 0.7F + s.field0314 * 0.3F;
               cr *= shade;
               cg *= shade;
               cb *= shade;
            }

            int segments = 12;

            for(int i = 0; i < segments; ++i) {
               float angle1 = (float)((double)i * 3.1415927169270965 * (double)2.0F / (double)segments);
               float angle2 = (float)((double)(i + 1) * 3.1415927169270965 * (double)2.0F / (double)segments);
               float x1 = screenX + (float)Math.cos((double)angle1) * r;
               float y1 = screenY + (float)Math.sin((double)angle1) * r;
               float x2 = screenX + (float)Math.cos((double)angle2) * r;
               float y2 = screenY + (float)Math.sin((double)angle2) * r;
               buffer.method_22918(matrix, screenX, screenY, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.8F);
               buffer.method_22918(matrix, x1, y1, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.3F);
               buffer.method_22918(matrix, x2, y2, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.3F);
               buffer.method_22918(matrix, screenX, screenY, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.8F);
            }
         }
      }

      for(HorizontalBounds p : this.field1155) {
         float screenX = this.field0566 + p.field0566;
         float screenY = this.field0003 + p.field0003;
         float size = p.field0758 * p.field0314;
         float lifeAlpha = p.field0314 * alpha;
         if (!(lifeAlpha < 0.01F)) {
            float cr = (float)p.field1268.getRed() / 255.0F;
            float cg = (float)p.field1268.getGreen() / 255.0F;
            float cb = (float)p.field1268.getBlue() / 255.0F;
            buffer.method_22918(matrix, screenX - size, screenY - size, 0.0F).method_22915(cr, cg, cb, lifeAlpha);
            buffer.method_22918(matrix, screenX - size, screenY + size, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.5F);
            buffer.method_22918(matrix, screenX + size, screenY + size, 0.0F).method_22915(cr, cg, cb, lifeAlpha * 0.5F);
            buffer.method_22918(matrix, screenX + size, screenY - size, 0.0F).method_22915(cr, cg, cb, lifeAlpha);
         }
      }

      try {
         class_286.method_43433(buffer.method_60800());
      } catch (Exception var23) {
      }

      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private static class VerticalBounds {
      float field0566;
      float field0003;
      float field1410;
      float field0957;
      float field0758;
      Color field1268;
      float field0314;

      VerticalBounds(float x, float y, float vx, float vy, float radius, Color color, float life) {
         this.field0566 = x;
         this.field0003 = y;
         this.field1410 = vx;
         this.field0957 = vy;
         this.field0758 = radius;
         this.field1268 = color;
         this.field0314 = life;
      }
   }

   private static class HorizontalBounds {
      float field0566;
      float field0003;
      float field1410;
      float field0957;
      float field0758;
      Color field1268;
      float field0314;

      HorizontalBounds(float x, float y, float vx, float vy, float size, Color color, float life) {
         this.field0566 = x;
         this.field0003 = y;
         this.field1410 = vx;
         this.field0957 = vy;
         this.field0758 = size;
         this.field1268 = color;
         this.field0314 = life;
      }
   }
}
