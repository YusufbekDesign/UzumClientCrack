package aethereal;

import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

public class Flight extends Module {
   private final EnumSetting<Mode> field0058;
   private final FloatSetting field1450;
   private final FloatSetting field0985;
   private final FloatSetting field0190;

   public Flight() {
      super("Flight", ModuleCategory.field0088, "O'yinchiga parvoz qilish imkonini beradi");
      this.field0058 = (EnumSetting)(new EnumSetting("flight.mode", Flight.Mode.field0627)).method1007("Rejim").method0210("Parvoz rejimi").method2130("Parvoz rejimi");
      this.field1450 = (FloatSetting)(new FloatSetting("flight.speed", 2.0F, 0.1F, 10.0F, 0.1F, () -> this.field0058.method0492() != Flight.Mode.field1449)).method1007("Tezlik").method0210("Parvoz tezligi").method2130("Parvoz tezligi");
      this.field0985 = (FloatSetting)(new FloatSetting("flight.dragonxz", 1.5F, 1.0F, 10.0F, 0.1F, () -> this.field0058.method0492() == Flight.Mode.field1449)).method1007("Dragon XZ Tezligi").method0210("Horizontal speed").method2130("Gorizontal tezlik");
      this.field0190 = (FloatSetting)(new FloatSetting("flight.dragony", 1.5F, 0.0F, 10.0F, 0.1F, () -> this.field0058.method0492() == Flight.Mode.field1449)).method1007("Dragon Y Tezligi").method0210("Vertical speed").method2130("Vertikal tezlik");
      this.method1013("O'yinchiga parvoz qilish imkonini beradi");
   }

   @EventHandler
   private void onPlayerTick(PlayerTickEvent var1) {
      if (!method1974()) {
         switch (((Mode)this.field0058.method0492()).ordinal()) {
            case 0 -> this.method1691();
            case 1 -> this.method1754();
            case 2 -> this.method1735();
         }
      }

   }

   private void method1735() {
      if (field0796.field_1724.method_31549().field_7479) {
         this.method0665((Float)this.field0985.method0492());
         double var1 = (double)0.0F;
         if (field0796.field_1690.field_1903.method_1434()) {
            var1 = (double)(Float)this.field0190.method0492();
         }

         if (field0796.field_1690.field_1832.method_1434()) {
            var1 = (double)(-(Float)this.field0190.method0492());
         }

         class_243 var3 = field0796.field_1724.method_18798();
         field0796.field_1724.method_18800(var3.field_1352, var1, var3.field_1350);
      }

   }

   private void method0665(float var1) {
      float var2 = field0796.field_1724.method_36454();
      float var3 = field0796.field_1724.field_6250;
      float var4 = field0796.field_1724.field_6212;
      double var5 = (double)0.0F;
      double var7 = (double)0.0F;
      if (var3 != 0.0F || var4 != 0.0F) {
         float var9 = (float)Math.sqrt((double)(var3 * var3 + var4 * var4));
         var3 /= var9;
         var4 /= var9;
         float var10 = (float)Math.toRadians((double)var2);
         var5 = (-Math.sin((double)var10) * (double)var3 + Math.cos((double)var10) * (double)var4) * (double)var1;
         var7 = (Math.cos((double)var10) * (double)var3 + Math.sin((double)var10) * (double)var4) * (double)var1;
      }

      field0796.field_1724.method_18800(var5, field0796.field_1724.method_18798().field_1351, var7);
   }

   private void method1691() {
      double var1;
      if (field0796.field_1690.field_1832.method_1434()) {
         var1 = (double)(-(Float)this.field1450.method0492()) / (double)1.5F;
      } else if (field0796.field_1690.field_1903.method_1434()) {
         var1 = (double)(Float)this.field1450.method0492() / (double)1.5F;
      } else {
         var1 = (double)0.0F;
      }

      field0796.field_1724.method_18800(field0796.field_1724.method_18798().field_1352, var1, field0796.field_1724.method_18798().field_1350);
      MovementHelper.method0103((double)(Float)this.field1450.method0492());
   }

   private void method1754() {
      MovementHelper.method0103((double)(Float)this.field1450.method0492());
      field0796.field_1724.method_18800(field0796.field_1724.method_18798().field_1352, -0.0059999982574654945, field0796.field_1724.method_18798().field_1350);
   }

   public static enum Mode implements DisplayNamed {
      field0627("Default"),
      field0059("Matrix"),
      field1449("Dragon");

      private final String field1030;

      @Generated
      public String method0557() {
         return this.field1030;
      }

      @Generated
      private Mode(String var3) {
         this.field1030 = var3;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0627, field0059, field1449};
      }
   }
}
