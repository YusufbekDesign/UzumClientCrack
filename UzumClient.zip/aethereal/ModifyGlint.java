package aethereal;

import java.awt.Color;

public class ModifyGlint extends Module {
   public static ModifyGlint field0087;
   public ColorSetting field1443 = (ColorSetting)(new ColorSetting("modifyglint.color", 215, 133, 255, 255)).method1882().method1007("Yaltiroq rangi").method0210("Maxsus yaltiroq rangi").method2130("Rang");
   public FloatSetting field0985 = (FloatSetting)(new FloatSetting("modifyglint.alpha", 2.0F, 0.0F, 2.0F, 0.05F)).method1007("Shaffoflik").method0210("Yaltiroq shaffofligi").method2130("Shaffoflik");
   public FloatSetting field0190 = (FloatSetting)(new FloatSetting("modifyglint.speed", 0.1F, 0.1F, 5.0F, 0.1F)).method1007("Tezlik").method0210("Yaltiroq animatsiya tezligi").method2130("Tezlik");
   public FloatSetting field0470 = (FloatSetting)(new FloatSetting("modifyglint.brightness", 3.0F, 0.5F, 3.0F, 0.1F)).method1007("Yorug'lik").method0210("Yaltiroq yorug'lik ko'paytmasi").method2130("Yorug'lik");

   public ModifyGlint() {
      super("ModifyGlint", ModuleCategory.field1004, "Sehr yaltiroqining ko'rinishini o'zgartiradi");
      this.method1013("Sehr yaltiroqining ko'rinishini o'zgartiradi");
      field0087 = this;
   }

   public Color method1726() {
      if (!this.method2195()) {
         return new Color(255, 255, 255, 255);
      } else {
         Color var1 = this.field1443.method1726();
         float var2 = (Float)this.field0470.method0492();
         int var3 = Math.min(255, (int)((float)var1.getRed() * var2));
         int var4 = Math.min(255, (int)((float)var1.getGreen() * var2));
         int var5 = Math.min(255, (int)((float)var1.getBlue() * var2));
         return new Color(var3, var4, var5, var1.getAlpha());
      }
   }

   public float method1679() {
      return !this.method2195() ? 1.0F : (Float)this.field0985.method0492();
   }

   public float method1741() {
      return !this.method2195() ? 1.0F : (Float)this.field0190.method0492();
   }
}
