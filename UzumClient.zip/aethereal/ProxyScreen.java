package aethereal;

import java.awt.Color;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;

public class ProxyScreen extends class_437 {
   private final class_437 field0742;
   private static final float field0003 = 360.0F;
   private static final float field1410 = 280.0F;
   private static final float field0957 = 26.0F;
   private static final float field0758 = 8.0F;
   private static final float field1242 = 3.0F;
   private final Animation field0327;
   private final Animation field0198;
   private final Animation field0477;
   private final Animation field1635;
   private final Map<ProxyEntry, Long> field1566;
   private final Map<String, Animation> field1729;
   private final Map<String, Animation> field1156;
   private float field1087;
   private float field1196;
   private float field0871;
   private float field0826;
   private boolean field0931;
   private int field1332;
   private long field1294;
   private final ProxyListEntryWidget field1381;
   private final ProxyListEntryWidget field0397;
   private final ProxyListEntryWidget field0362;
   private final ProxyListEntryWidget field0432;
   private ProxyType field0265;

   public ProxyScreen(class_437 parent) {
      super(class_2561.method_43470("Proxy Manager"));
      this.field0327 = new Animation(150L, (double)1.0F, false, EasingCurve.field1477);
      this.field0198 = new Animation(280L, (double)1.0F, false, EasingCurve.field1011);
      this.field0477 = new Animation(220L, (double)1.0F, false, EasingCurve.field1011);
      this.field1635 = new Animation(320L, (double)1.0F, true, EasingCurve.field0330);
      this.field1566 = new IdentityHashMap();
      this.field1729 = new HashMap();
      this.field1156 = new HashMap();
      this.field0871 = 0.0F;
      this.field0826 = 0.0F;
      this.field0931 = false;
      this.field1332 = -1;
      this.field1294 = 0L;
      this.field1381 = new ProxyListEntryWidget(() -> ProxyAddressHelper.method1044("Host", "Хост"), false, false, 45, "O");
      this.field0397 = new ProxyListEntryWidget(() -> ProxyAddressHelper.method1044("Port", "Порт"), true, false, 5, "P");
      this.field0362 = new ProxyListEntryWidget(() -> ProxyAddressHelper.method1044("Username (optional)", "Логин (опц.)"), false, false, 64, "A");
      this.field0432 = new ProxyListEntryWidget(() -> ProxyAddressHelper.method1044("Password (optional)", "Пароль (опц.)"), false, true, 64, "N");
      this.field0265 = ProxyType.field0678;
      this.field0742 = parent;
   }

   protected void method_25426() {
      this.field1087 = ((float)this.field_22789 - 360.0F) / 2.0F;
      this.field1196 = ((float)this.field_22790 - 280.0F) / 2.0F;
      this.field1294 = System.currentTimeMillis();
      this.field0198.method1973();
      this.field0477.method1973();
      this.field0327.method1973();
      this.field1635.method1570(true);
      this.field1635.method1634();

      for(ProxyEntry e : ProxyStorage.method1786().method1620()) {
         this.field1566.put(e, this.field1294);
         if (e.method0365() == ProxyEntry.ProxyProtocol.field0675) {
            ProxyTester.method0907(e);
         }
      }

   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.method_25420(context, mouseX, mouseY, delta);
      this.field0871 = this.field0826;
      this.field1566.keySet().retainAll(ProxyStorage.method1786().method1620());
      boolean anyTesting = false;

      for(ProxyEntry e : ProxyStorage.method1786().method1620()) {
         if (e.method0365() == ProxyEntry.ProxyProtocol.field0104) {
            anyTesting = true;
            break;
         }
      }

      this.method1400(context);
      this.method1413(context, mouseX, mouseY);
      if (this.field0931) {
         this.method1673(context, mouseX, mouseY);
      } else {
         this.method2169(context, mouseX, mouseY);
         this.method1870(context, mouseX, mouseY);
      }

      if (anyTesting) {
         this.method1401(context, 1.0F);
      }

   }

   private void method1401(class_332 context, float visibility) {
      float popW = 140.0F;
      float popH = 60.0F;
      float popX = this.field1087 + (360.0F - popW) / 2.0F;
      float popY = this.field1196 + (280.0F - popH) / 2.0F;
      GuiRenderHelper.method1462(context.method_51448(), popX, popY, popW, popH, 8.0F, (Float)ThemePalette.field0367.get() * 0.6F, new Color(-1));
      GuiRenderHelper.method0326(context.method_51448(), popX, popY, popW, popH, 8.0F, (Color)ThemePalette.field0930.get());
      GuiRenderHelper.method1461(context.method_51448(), popX, popY, popW, popH, 8.0F, 0.5F, 0.5F, ThemePalette.field0884);
      FontSize f = Fonts.field0995.method0654(7.0F);
      String label = ProxyAddressHelper.method1044("Testing", "Тестирую");
      float fw = f.method0998(label);
      float tx = popX + (popW - fw - 24.0F) / 2.0F;
      float ty = popY + (popH - f.method0530()) / 2.0F + 0.5F;
      GuiRenderHelper.method1491(context.method_51448(), f, label, tx, ty, ThemePalette.field0789);
      float dotsX = tx + fw + 6.0F;
      float dotsY = popY + popH / 2.0F;
      long t = System.currentTimeMillis();
      Color m = (Color)ThemePalette.field1036.get();

      for(int i = 0; i < 3; ++i) {
         double phase = (double)t / (double)200.0F - (double)i * 0.5500001459852684;
         float pulse = (float)(0.3000001807989365 + 0.7000001046902076 * Math.max((double)0.0F, Math.sin(phase)));
         float r = 1.6F + pulse * 0.5F;
         int alpha = (int)(90.0F + 165.0F * pulse);
         GuiRenderHelper.method0326(context.method_51448(), dotsX + (float)i * 5.0F - r, dotsY - r, r * 2.0F, r * 2.0F, r - 1.0F, new Color(m.getRed(), m.getGreen(), m.getBlue(), alpha));
      }

   }

   private void method1400(class_332 context) {
      GuiRenderHelper.method1462(context.method_51448(), this.field1087, this.field1196, 360.0F, 280.0F, 10.0F, (Float)ThemePalette.field0367.get() * 0.6F, new Color(-1));
      GuiRenderHelper.method0326(context.method_51448(), this.field1087, this.field1196, 360.0F, 280.0F, 10.0F, (Color)ThemePalette.field0930.get());
      GuiRenderHelper.method1461(context.method_51448(), this.field1087, this.field1196, 360.0F, 280.0F, 10.0F, 0.5F, 0.5F, ThemePalette.field0884);
   }

   private void method1413(class_332 context, int mouseX, int mouseY) {
      FontSize titleFont = Fonts.field0995.method0654(9.0F);
      FontSize subFont = Fonts.field0075.method0654(5.5F);
      String title = this.field0931 ? (this.field1332 < 0 ? ProxyAddressHelper.method1044("Add Proxy", "Добавить прокси") : ProxyAddressHelper.method1044("Edit Proxy", "Редактировать прокси")) : ProxyAddressHelper.method1044("Proxy Manager", "Менеджер прокси");
      GuiRenderHelper.method1491(context.method_51448(), titleFont, title, this.field1087 + 12.0F, this.field1196 + 12.0F, ThemePalette.field0789);
      ProxyEntry active = ProxyStorage.method1786().method0547();
      String sub = this.field0931 ? ProxyAddressHelper.method1044("Fill the fields and save", "Заполните поля и сохраните") : (active == null ? ProxyAddressHelper.method1044("No proxy selected - direct connection", "Прокси не выбран - прямое подключение") : ProxyAddressHelper.method1044("Active: ", "Активен: ") + active.method0017());
      GuiRenderHelper.method1491(context.method_51448(), subFont, sub, this.field1087 + 12.0F, this.field1196 + 24.0F, ThemePalette.field0207);
      this.method0315(context, mouseX, mouseY);
   }

   private void method0315(class_332 context, int mouseX, int mouseY) {
      FontSize closeFont = Fonts.field0774.method0654(6.0F);
      float closeFw = closeFont.method0998("F");
      float closeFh = closeFont.method0530();
      float closeX = this.field1087 + 360.0F - closeFw - 10.0F;
      float closeY = this.field1196 + 12.0F - closeFh / 2.0F;
      boolean hovered = MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeFw + 6.0F, closeFh + 6.0F, (float)mouseX, (float)mouseY);
      if (this.field0327.method0376() != hovered) {
         this.field0327.method1570(hovered);
      }

      float hv = this.field0327.method0002();
      int cR = Math.min(255, (int)(170.0F + 70.0F * hv));
      int cG = Math.min(255, (int)(170.0F + 75.0F * hv));
      int cB = Math.min(255, (int)(170.0F + 80.0F * hv));
      int cA = Math.min(255, (int)(2.55F * (52.0F + 90.0F * hv)));
      Color closeColor = new Color(cR, cG, cB, cA);
      float closeScale = 1.0F + 0.18F * hv;
      float closeCx = closeX + closeFw / 2.0F;
      float closeCy = closeY + closeFh / 2.0F;
      context.method_51448().method_22903();
      context.method_51448().method_46416(closeCx, closeCy, 0.0F);
      context.method_51448().method_22905(closeScale, closeScale, 1.0F);
      context.method_51448().method_46416(-closeCx, -closeCy, 0.0F);
      GuiRenderHelper.method1491(context.method_51448(), closeFont, "F", closeX, closeY, closeColor);
      context.method_51448().method_22909();
   }

   private boolean method0616(double mouseX, double mouseY) {
      FontSize closeFont = Fonts.field0774.method0654(6.0F);
      float closeFw = closeFont.method0998("F");
      float closeFh = closeFont.method0530();
      float closeX = this.field1087 + 360.0F - closeFw - 10.0F;
      float closeY = this.field1196 + 12.0F - closeFh / 2.0F;
      return MathHelper.method0689(closeX - 3.0F, closeY - 3.0F, closeFw + 6.0F, closeFh + 6.0F, (float)mouseX, (float)mouseY);
   }

   private void method2169(class_332 context, int mouseX, int mouseY) {
      float listX = this.field1087 + 8.0F;
      float listY = this.field1196 + 44.0F;
      float listW = 344.0F;
      float listH = 194.0F;
      GuiRenderHelper.method1404(context, listX, listY, listW, listH);
      List<ProxyEntry> all = ProxyStorage.method1786().method1620();
      if (all.isEmpty()) {
         FontSize f = Fonts.field0075.method0654(6.5F);
         String pre = ProxyAddressHelper.method1044("No proxies yet. Click ", "Прокси пока нет. Нажмите ");
         String mid = ProxyAddressHelper.method1044("Add", "Добавить");
         String post = ProxyAddressHelper.method1044(" to create one.", " чтобы создать.");
         float wPre = f.method0998(pre);
         float wMid = f.method0998(mid);
         float wPost = f.method0998(post);
         float total = wPre + wMid + wPost;
         float tx = listX + (listW - total) / 2.0F;
         float ty = listY + listH / 2.0F - f.method0530() / 2.0F;
         GuiRenderHelper.method1491(context.method_51448(), f, pre, tx, ty, ThemePalette.field0207);
         GuiRenderHelper.method1491(context.method_51448(), f, mid, tx + wPre, ty, (Color)ThemePalette.field1514.get());
         GuiRenderHelper.method1491(context.method_51448(), f, post, tx + wPre + wMid, ty, ThemePalette.field0207);
      } else {
         float y = listY - this.field0871;
         int activeIdx = ProxyStorage.method1786().method1947();

         for(int i = 0; i < all.size(); ++i) {
            this.method1423(context, (ProxyEntry)all.get(i), i == activeIdx, listX, y, listW, (float)mouseX, (float)mouseY, i);
            y += 30.0F;
         }
      }

      GuiRenderHelper.method1400(context);
      float total = (float)all.size() * 30.0F;
      this.field0826 = class_3532.method_15363(this.field0826, 0.0F, Math.max(0.0F, total - listH));
   }

   private void method1423(class_332 context, ProxyEntry e, boolean isActive, float x, float y, float w, float mx, float my, int index) {
      boolean hovered = MathHelper.method0689(x, y, w, 26.0F, mx, my);
      Color bg = isActive ? new Color(((Color)ThemePalette.field1036.get()).getRed(), ((Color)ThemePalette.field1036.get()).getGreen(), ((Color)ThemePalette.field1036.get()).getBlue(), 38) : (hovered ? ThemePalette.field1641 : ThemePalette.field1564);
      GuiRenderHelper.method0326(context.method_51448(), x, y, w, 26.0F, 6.0F, bg);
      FontSize typeFont = Fonts.field0995.method0654(5.5F);
      String typeText = e.method2060().method0557();
      float typeW = typeFont.method0998(typeText) + 10.0F;
      float typeH = 13.0F;
      float typeX = x + 6.0F;
      float typeY = y + (26.0F - typeH) / 2.0F;
      GuiRenderHelper.method0326(context.method_51448(), typeX, typeY, typeW, typeH, 3.0F, new Color(((Color)ThemePalette.field1036.get()).getRed(), ((Color)ThemePalette.field1036.get()).getGreen(), ((Color)ThemePalette.field1036.get()).getBlue(), 90));
      GuiRenderHelper.method1491(context.method_51448(), typeFont, typeText, typeX + 5.0F, typeY + (typeH - typeFont.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
      float countryW = 22.0F;
      float countryX = typeX + typeW + 4.0F;
      Color countryBg = new Color(255, 255, 255, 24);
      GuiRenderHelper.method0326(context.method_51448(), countryX, typeY, countryW, typeH, 3.0F, countryBg);
      String code = e.method2224() != null && !e.method2224().isEmpty() ? e.method2224() : "?";
      FontSize cFont = Fonts.field0995.method0654(5.5F);
      float cFw = cFont.method0998(code);
      GuiRenderHelper.method1491(context.method_51448(), cFont, code, countryX + (countryW - cFw) / 2.0F, typeY + (typeH - cFont.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
      float btnW = 40.0F;
      float btnH = 16.0F;
      float btnGap = 3.0F;
      float btnY = y + (26.0F - btnH) / 2.0F;
      float delX = x + w - btnW - 6.0F;
      float editX = delX - btnW - btnGap;
      float useX = editX - btnW - btnGap;
      float pingX = useX - 34.0F - 4.0F;
      FontSize addrFont = Fonts.field0075.method0654(6.5F);
      FontSize subFont = Fonts.field0075.method0654(5.0F);
      String var10000 = e.method1791();
      String addr = var10000 + ":" + e.method1604();
      String sub = e.method0579() ? e.method1961() : ProxyAddressHelper.method1044("anonymous", "анонимно");
      float addrX = countryX + countryW + 6.0F;
      float addrMaxW = pingX - addrX - 6.0F;
      GuiRenderHelper.method1404(context, addrX, y, addrMaxW, 26.0F);
      GuiRenderHelper.method1491(context.method_51448(), addrFont, addr, addrX, y + 4.0F, ThemePalette.field0789);
      GuiRenderHelper.method1491(context.method_51448(), subFont, sub, addrX, y + 14.0F, ThemePalette.field0207);
      GuiRenderHelper.method1400(context);
      this.method1422(context, e, pingX, btnY, 34.0F, btnH);
      this.method1426(context, "row:" + index + ":use", isActive ? "H" : "M", isActive ? ProxyAddressHelper.method1044("Active", "Активен") : ProxyAddressHelper.method1044("Use", "Вкл."), useX, btnY, btnW, btnH, mx, my, isActive ? ProxyScreen.ProxyTab.field0105 : ProxyScreen.ProxyTab.field0676);
      this.method1426(context, "row:" + index + ":edit", "F", ProxyAddressHelper.method1044("Edit", "Изм."), editX, btnY, btnW, btnH, mx, my, ProxyScreen.ProxyTab.field0676);
      this.method1426(context, "row:" + index + ":del", "E", ProxyAddressHelper.method1044("Del", "Удал."), delX, btnY, btnW, btnH, mx, my, ProxyScreen.ProxyTab.field1479);
   }

   private float method1020(String key, float x, float y, float w, float h, float mx, float my) {
      Animation anim = (Animation)this.field1729.computeIfAbsent(key, (k) -> new Animation(160L, (double)1.0F, false, EasingCurve.field1011));
      boolean hovered = MathHelper.method0689(x, y, w, h, mx, my);
      if (anim.method0376() != hovered) {
         anim.method1570(hovered);
      }

      return anim.method0002();
   }

   private float method0208(String key) {
      Animation anim = (Animation)this.field1156.get(key);
      if (anim == null) {
         return 0.0F;
      } else {
         if (anim.method0376() && anim.method0579()) {
            anim.method1570(false);
         }

         return anim.method0002();
      }
   }

   public void method1013(String key) {
      Animation anim = (Animation)this.field1156.computeIfAbsent(key, (k) -> new Animation(140L, (double)1.0F, false, EasingCurve.field1011));
      anim.method1570(true);
      anim.method1634();
   }

   private void method1405(class_332 context, float x, float y, float w, float h, float hv, float pv) {
      float scale = 1.0F + 0.05F * hv - 0.06F * pv;
      float cx = x + w / 2.0F;
      float cy = y + h / 2.0F;
      context.method_51448().method_22903();
      context.method_51448().method_46416(cx, cy, 0.0F);
      context.method_51448().method_22905(scale, scale, 1.0F);
      context.method_51448().method_46416(-cx, -cy, 0.0F);
   }

   private void method1426(class_332 context, String key, String glyph, String text, float x, float y, float w, float h, float mx, float my, ProxyTab tone) {
      float hv = this.method1020(key, x, y, w, h, mx, my);
      float pv = this.method0208(key);
      this.method1405(context, x, y, w, h, hv, pv);
      Color bg;
      switch (tone.ordinal()) {
         case 1:
            Color m = (Color)ThemePalette.field1036.get();
            int boost = (int)(35.0F * hv);
            bg = new Color(Math.min(255, m.getRed() + boost), Math.min(255, m.getGreen() + boost), Math.min(255, m.getBlue() + boost), Math.min(255, 200 + (int)(35.0F * hv)));
            break;
         case 2:
            int boost = (int)(40.0F * hv);
            bg = new Color(Math.min(255, 220 + boost / 3), Math.min(255, 80 + boost), Math.min(255, 80 + boost), Math.min(255, 90 + (int)(90.0F * hv)));
            break;
         default:
            int alpha = 30 + (int)(60.0F * hv);
            bg = new Color(255, 255, 255, alpha);
      }

      GuiRenderHelper.method0326(context.method_51448(), x, y, w, h, 4.0F, bg);
      FontSize iconF = Fonts.field1148.method0654(6.5F);
      FontSize textF = Fonts.field0075.method0654(5.5F);
      float iconW = iconF.method0998(glyph);
      float textW = textF.method0998(text);
      float gap = 3.0F;
      float totalW = iconW + gap + textW;
      float startX = x + (w - totalW) / 2.0F;
      GuiRenderHelper.method1491(context.method_51448(), iconF, glyph, startX, y + (h - iconF.method0530()) / 2.0F, ThemePalette.field0789);
      GuiRenderHelper.method1491(context.method_51448(), textF, text, startX + iconW + gap, y + (h - textF.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
      context.method_51448().method_22909();
   }

   private void method1422(class_332 context, ProxyEntry e, float x, float y, float w, float h) {
      FontSize f = Fonts.field0995.method0654(5.5F);
      String text;
      Color color;
      switch (e.method0365()) {
         case field0104:
            text = "...";
            color = ThemePalette.field0334;
            break;
         case field1478:
            text = e.method0484() + "ms";
            color = this.method0723(e.method0484());
            break;
         case field1012:
            text = "FAIL";
            color = new Color(235, 90, 90);
            break;
         default:
            text = "?";
            color = ThemePalette.field0207;
      }

      float fw = f.method0998(text);
      GuiRenderHelper.method1491(context.method_51448(), f, text, x + (w - fw) / 2.0F, y + (h - f.method0530()) / 2.0F + 0.5F, color);
   }

   private Color method0723(int ms) {
      if (ms < 100) {
         return new Color(110, 220, 130);
      } else {
         return ms < 250 ? new Color(220, 200, 100) : new Color(230, 140, 90);
      }
   }

   private void method1424(class_332 context, String label, float x, float y, float w, float h, float mx, float my, boolean filled) {
      Color bg;
      if (filled) {
         Color m = (Color)ThemePalette.field1036.get();
         bg = new Color(m.getRed(), m.getGreen(), m.getBlue(), 200);
      } else {
         bg = ThemePalette.field1641;
      }

      GuiRenderHelper.method0326(context.method_51448(), x, y, w, h, 4.0F, bg);
      FontSize f = Fonts.field0075.method0654(5.5F);
      float fw = f.method0998(label);
      GuiRenderHelper.method1491(context.method_51448(), f, label, x + (w - fw) / 2.0F, y + (h - f.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
   }

   private void method1870(class_332 context, int mouseX, int mouseY) {
      float footerY = this.field1196 + 280.0F - 34.0F;
      float btnW = 100.0F;
      float gap = 6.0F;
      float totalW = btnW * 3.0F + gap * 2.0F;
      float startX = this.field1087 + (360.0F - totalW) / 2.0F;
      this.method1427(context, "footer:add", "C", ProxyAddressHelper.method1044("Add", "Добавить"), startX, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY, true);
      this.method1427(context, "footer:test", "K", ProxyAddressHelper.method1044("Test All", "Тест все"), startX + btnW + gap, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY, false);
      this.method1427(context, "footer:direct", "Q", ProxyAddressHelper.method1044("Direct", "Прямой"), startX + (btnW + gap) * 2.0F, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY, false);
   }

   private void method1427(class_332 context, String key, String glyph, String text, float x, float y, float w, float h, float mx, float my, boolean accent) {
      float hv = this.method1020(key, x, y, w, h, mx, my);
      float pv = this.method0208(key);
      this.method1405(context, x, y, w, h, hv, pv);
      Color bg;
      if (accent) {
         Color m = (Color)ThemePalette.field1036.get();
         int boost = (int)(40.0F * hv);
         bg = new Color(Math.min(255, m.getRed() + boost), Math.min(255, m.getGreen() + boost), Math.min(255, m.getBlue() + boost), Math.min(255, 200 + (int)(40.0F * hv)));
      } else {
         int alpha = 30 + (int)(70.0F * hv);
         bg = new Color(255, 255, 255, alpha);
      }

      GuiRenderHelper.method0326(context.method_51448(), x, y, w, h, 6.0F, bg);
      if (hv > 0.01F) {
         Color border = accent ? new Color(((Color)ThemePalette.field1036.get()).getRed(), ((Color)ThemePalette.field1036.get()).getGreen(), ((Color)ThemePalette.field1036.get()).getBlue(), (int)(180.0F * hv)) : new Color(255, 255, 255, (int)(90.0F * hv));
         GuiRenderHelper.method1461(context.method_51448(), x, y, w, h, 6.0F, 0.6F, 0.6F, border);
      }

      FontSize iconF = Fonts.field1148.method0654(8.0F);
      FontSize textF = Fonts.field0995.method0654(6.5F);
      float iconW = iconF.method0998(glyph);
      float textW = textF.method0998(text);
      float gap = 4.0F;
      float totalW = iconW + gap + textW;
      float startX = x + (w - totalW) / 2.0F;
      GuiRenderHelper.method1491(context.method_51448(), iconF, glyph, startX, y + (h - iconF.method0530()) / 2.0F, ThemePalette.field0789);
      GuiRenderHelper.method1491(context.method_51448(), textF, text, startX + iconW + gap, y + (h - textF.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
      context.method_51448().method_22909();
   }

   private void method0316(class_332 context, String label, float x, float y, float w, float h, float mx, float my, boolean accent) {
      Color bg;
      if (accent) {
         Color m = (Color)ThemePalette.field1036.get();
         bg = new Color(m.getRed(), m.getGreen(), m.getBlue(), 200);
      } else {
         bg = ThemePalette.field1641;
      }

      GuiRenderHelper.method0326(context.method_51448(), x, y, w, h, 6.0F, bg);
      FontSize f = Fonts.field0995.method0654(6.5F);
      float fw = f.method0998(label);
      GuiRenderHelper.method1491(context.method_51448(), f, label, x + (w - fw) / 2.0F, y + (h - f.method0530()) / 2.0F + 0.5F, ThemePalette.field0789);
   }

   private void method1673(class_332 context, int mouseX, int mouseY) {
      float formX = this.field1087 + 20.0F;
      float formY = this.field1196 + 50.0F;
      float formW = 320.0F;
      float fieldH = 22.0F;
      float gap = 10.0F;
      this.method0313(context, formX, formY, formW, fieldH, (float)mouseX, (float)mouseY);
      float y = formY + fieldH + gap;
      this.field1381.method0686(formX, y, formW * 0.7F - 4.0F, fieldH);
      this.field0397.method0686(formX + formW * 0.7F + 4.0F, y, formW * 0.3F - 4.0F, fieldH);
      this.field1381.method1402(context, (float)mouseX, (float)mouseY);
      this.field0397.method1402(context, (float)mouseX, (float)mouseY);
      y += fieldH + gap;
      this.field0362.method0686(formX, y, formW, fieldH);
      this.field0362.method1402(context, (float)mouseX, (float)mouseY);
      y += fieldH + gap;
      this.field0432.method0686(formX, y, formW, fieldH);
      this.field0432.method1402(context, (float)mouseX, (float)mouseY);
      float btnY = this.field1196 + 280.0F - 34.0F;
      float saveW = 92.0F;
      float cancelW = 92.0F;
      float btnGap = 8.0F;
      float totalW = saveW + btnGap + cancelW;
      float startX = this.field1087 + (360.0F - totalW) / 2.0F;
      this.method1427(context, "editor:save", "G", ProxyAddressHelper.method1044("Save", "Сохранить"), startX, btnY, saveW, 22.0F, (float)mouseX, (float)mouseY, true);
      this.method1427(context, "editor:cancel", "L", ProxyAddressHelper.method1044("Cancel", "Отмена"), startX + saveW + btnGap, btnY, cancelW, 22.0F, (float)mouseX, (float)mouseY, false);
   }

   private void method0313(class_332 context, float x, float y, float w, float h, float mx, float my) {
      ProxyType[] types = ProxyType.values();
      float seg = w / (float)types.length;
      GuiRenderHelper.method0326(context.method_51448(), x, y, w, h, 6.0F, ThemePalette.field1564);

      for(int i = 0; i < types.length; ++i) {
         float sx = x + seg * (float)i;
         boolean selected = types[i] == this.field0265;
         String key = "type:" + types[i].name();
         float hv = this.method1020(key, sx, y, seg, h, mx, my);
         float pv = this.method0208(key);
         float scale = 1.0F + 0.04F * hv - 0.05F * pv;
         float cx = sx + seg / 2.0F;
         float cy = y + h / 2.0F;
         context.method_51448().method_22903();
         context.method_51448().method_46416(cx, cy, 0.0F);
         context.method_51448().method_22905(scale, scale, 1.0F);
         context.method_51448().method_46416(-cx, -cy, 0.0F);
         if (selected) {
            Color m = (Color)ThemePalette.field1036.get();
            int boost = (int)(30.0F * hv);
            GuiRenderHelper.method0326(context.method_51448(), sx + 2.0F, y + 2.0F, seg - 4.0F, h - 4.0F, 4.0F, new Color(Math.min(255, m.getRed() + boost), Math.min(255, m.getGreen() + boost), Math.min(255, m.getBlue() + boost), Math.min(255, 200 + (int)(40.0F * hv))));
         } else if (hv > 0.01F) {
            int alpha = 12 + (int)(50.0F * hv);
            GuiRenderHelper.method0326(context.method_51448(), sx + 2.0F, y + 2.0F, seg - 4.0F, h - 4.0F, 4.0F, new Color(255, 255, 255, alpha));
         }

         FontSize f = Fonts.field0995.method0654(6.0F);
         float fw = f.method0998(types[i].method0557());
         Color textColor;
         if (selected) {
            textColor = ThemePalette.field0789;
         } else {
            int alpha = 184 + (int)(71.0F * hv);
            textColor = new Color(255, 255, 255, Math.min(255, alpha));
         }

         GuiRenderHelper.method1491(context.method_51448(), f, types[i].method0557(), sx + (seg - fw) / 2.0F, y + (h - f.method0530()) / 2.0F + 0.5F, textColor);
         context.method_51448().method_22909();
      }

   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.method0616(mouseX, mouseY)) {
         this.method1812();
         return true;
      } else {
         return this.field0931 ? this.method0112(mouseX, mouseY, button) : this.method0627(mouseX, mouseY, button);
      }
   }

   private boolean method0627(double mouseX, double mouseY, int button) {
      float listX = this.field1087 + 8.0F;
      float listY = this.field1196 + 44.0F;
      float listW = 344.0F;
      List<ProxyEntry> all = ProxyStorage.method1786().method1620();
      float y = listY - this.field0871;

      for(int i = 0; i < all.size(); ++i) {
         float btnW = 40.0F;
         float btnH = 16.0F;
         float btnGap = 3.0F;
         float btnY = y + (26.0F - btnH) / 2.0F;
         float delX = listX + listW - btnW - 6.0F;
         float editX = delX - btnW - btnGap;
         float useX = editX - btnW - btnGap;
         if (MathHelper.method0689(useX, btnY, btnW, btnH, (float)mouseX, (float)mouseY)) {
            this.method1013("row:" + i + ":use");
            ProxyStorage.method1786().method0729(i);
            return true;
         }

         if (MathHelper.method0689(editX, btnY, btnW, btnH, (float)mouseX, (float)mouseY)) {
            this.method1013("row:" + i + ":edit");
            this.method0143(i);
            return true;
         }

         if (MathHelper.method0689(delX, btnY, btnW, btnH, (float)mouseX, (float)mouseY)) {
            this.method1013("row:" + i + ":del");
            ProxyStorage.method1786().method0143(i);
            return true;
         }

         y += 30.0F;
      }

      float footerY = this.field1196 + 280.0F - 34.0F;
      float btnW = 100.0F;
      float gap = 6.0F;
      float totalW = btnW * 3.0F + gap * 2.0F;
      float startX = this.field1087 + (360.0F - totalW) / 2.0F;
      if (MathHelper.method0689(startX, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY)) {
         this.method1013("footer:add");
         this.method0143(-1);
         return true;
      } else if (MathHelper.method0689(startX + btnW + gap, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY)) {
         this.method1013("footer:test");
         ProxyTester.method0578();
         return true;
      } else if (MathHelper.method0689(startX + (btnW + gap) * 2.0F, footerY, btnW, 22.0F, (float)mouseX, (float)mouseY)) {
         this.method1013("footer:direct");
         ProxyStorage.method1786().method0025();
         return true;
      } else {
         return false;
      }
   }

   private boolean method0112(double mouseX, double mouseY, int button) {
      float formX = this.field1087 + 20.0F;
      float formY = this.field1196 + 50.0F;
      float formW = 320.0F;
      float fieldH = 22.0F;
      ProxyType[] types = ProxyType.values();
      float seg = formW / (float)types.length;

      for(int i = 0; i < types.length; ++i) {
         float sx = formX + seg * (float)i;
         if (MathHelper.method0689(sx, formY, seg, fieldH, (float)mouseX, (float)mouseY)) {
            this.method1013("type:" + types[i].name());
            this.field0265 = types[i];
            return true;
         }
      }

      this.field1381.method0627(mouseX, mouseY, button);
      this.field0397.method0627(mouseX, mouseY, button);
      this.field0362.method0627(mouseX, mouseY, button);
      this.field0432.method0627(mouseX, mouseY, button);
      float btnY = this.field1196 + 280.0F - 34.0F;
      float saveW = 92.0F;
      float cancelW = 92.0F;
      float btnGap = 8.0F;
      float totalW = saveW + btnGap + cancelW;
      float startX = this.field1087 + (360.0F - totalW) / 2.0F;
      if (MathHelper.method0689(startX, btnY, saveW, 22.0F, (float)mouseX, (float)mouseY)) {
         this.method1013("editor:save");
         this.method2078();
         return true;
      } else if (MathHelper.method0689(startX + saveW + btnGap, btnY, cancelW, 22.0F, (float)mouseX, (float)mouseY)) {
         this.method1013("editor:cancel");
         this.method0578();
         return true;
      } else {
         return true;
      }
   }

   private void method0143(int index) {
      this.field0931 = true;
      this.field1332 = index;
      if (index >= 0) {
         ProxyEntry e = (ProxyEntry)ProxyStorage.method1786().method1620().get(index);
         this.field0265 = e.method2060();
         this.field1381.method1013(e.method1791());
         this.field0397.method1013(String.valueOf(e.method1604()));
         this.field0362.method1013(e.method1961());
         this.field0432.method1013(e.method0423());
      } else {
         this.field0265 = ProxyType.field0678;
         this.field1381.method1013("");
         this.field0397.method1013("");
         this.field0362.method1013("");
         this.field0432.method1013("");
      }

   }

   private void method0578() {
      this.field0931 = false;
      this.field1332 = -1;
      this.method0025();
   }

   private void method0025() {
      this.field1381.method1570(false);
      this.field0397.method1570(false);
      this.field0362.method1570(false);
      this.field0432.method1570(false);
   }

   private void method2078() {
      String host = this.field1381.method0557().trim();
      String portStr = this.field0397.method0557().trim();
      if (!host.isEmpty() && !portStr.isEmpty()) {
         int port;
         try {
            port = Integer.parseInt(portStr);
         } catch (NumberFormatException var5) {
            return;
         }

         if (port >= 1 && port <= 65535) {
            ProxyEntry entry = new ProxyEntry(this.field0265, host, port, this.field0362.method0557(), this.field0432.method0557());
            if (this.field1332 < 0) {
               ProxyStorage.method1786().method0907(entry);
            } else {
               ProxyStorage.method1786().method0763(this.field1332, entry);
            }

            ProxyTester.method0907(entry);
            this.method0578();
         }
      }
   }

   private void method1812() {
      this.field_22787.method_1507(this.field0742);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (this.field0931) {
         if (this.field1381.method0746(keyCode, scanCode, modifiers)) {
            return true;
         }

         if (this.field0397.method0746(keyCode, scanCode, modifiers)) {
            return true;
         }

         if (this.field0362.method0746(keyCode, scanCode, modifiers)) {
            return true;
         }

         if (this.field0432.method0746(keyCode, scanCode, modifiers)) {
            return true;
         }
      }

      if (keyCode == 256) {
         if (this.field0931) {
            this.method0578();
         } else {
            this.method1812();
         }

         return true;
      } else {
         return super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   public boolean method_25400(char chr, int modifiers) {
      if (this.field0931) {
         if (this.field1381.method0607(chr, modifiers)) {
            return true;
         }

         if (this.field0397.method0607(chr, modifiers)) {
            return true;
         }

         if (this.field0362.method0607(chr, modifiers)) {
            return true;
         }

         if (this.field0432.method0607(chr, modifiers)) {
            return true;
         }
      }

      return super.method_25400(chr, modifiers);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (!this.field0931) {
         List<ProxyEntry> all = ProxyStorage.method1786().method1620();
         if (all.isEmpty()) {
            this.field0826 = 0.0F;
            return true;
         } else {
            float listH = 194.0F;
            float total = (float)all.size() * 30.0F;
            float maxScroll = Math.max(0.0F, total - listH);
            if (maxScroll <= 0.0F) {
               this.field0826 = 0.0F;
               return true;
            } else {
               this.field0826 = class_3532.method_15363(this.field0826 - (float)verticalAmount * 18.0F, 0.0F, maxScroll);
               return true;
            }
         }
      } else {
         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   public boolean method_25421() {
      return false;
   }

   private static enum ProxyTab {
      field0676,
      field0105,
      field1479;

      // $FF: synthetic method
      private static ProxyTab[] method0599() {
         return new ProxyTab[]{field0676, field0105, field1479};
      }
   }
}
