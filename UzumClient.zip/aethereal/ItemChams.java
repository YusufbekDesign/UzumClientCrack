package aethereal;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;

public class ItemChams extends Module {
   private final OutlineShaderRenderer field1710 = new OutlineShaderRenderer();
   public final EnumSetting<Shape> field0058;
   public final EnumSetting<RenderMode> field1448;
   public final FloatSetting field0985;
   public final FloatSetting field0190;
   public final FloatSetting field0470;
   public final ColorSetting field1623;
   public final BooleanSetting field1544;

   public ItemChams() {
      super("ItemChams", ModuleCategory.field1004, "Applies a Solid or Glow shader to the held hand viewmodel");
      this.field0058 = (EnumSetting)(new EnumSetting("itemchams.shape", ItemChams.Shape.field1467)).method1007("Shape").method0210("The portions of the effect that will be rendered").method2130("Тип отрисовки");
      this.field1448 = (EnumSetting)(new EnumSetting("itemchams.mode", ItemChams.RenderMode.field0084)).method1007("Mode").method0210("The shader algorithm used for rendering").method2130("Мод отрисовки");
      this.field0985 = (FloatSetting)(new FloatSetting("itemchams.glowstrength", 6.0F, 1.0F, 20.0F, 1.0F, () -> this.field1448.method0492() == ItemChams.RenderMode.field0084)).method1007("Glow Strength").method0210("The strength of the glow halo").method2130("Сила");
      this.field0190 = (FloatSetting)(new FloatSetting("itemchams.glowmultiplier", 1.0F, 0.1F, 3.0F, 0.05F, () -> this.field1448.method0492() == ItemChams.RenderMode.field0084)).method1007("Glow Multiplier").method0210("Brightness multiplier on top of the glow").method2130("Множитель яркости");
      this.field0470 = (FloatSetting)(new FloatSetting("itemchams.glowquality", 10.0F, 1.0F, 10.0F, 1.0F, () -> this.field1448.method0492() == ItemChams.RenderMode.field0084)).method1007("Glow Quality").method0210("Sample quality of the glow halo (higher = smoother + slower)").method2130("Качество семплинга свечения (выше = плавнее, но медленнее)");
      this.field1623 = (ColorSetting)(new ColorSetting("itemchams.color", 255, 255, 255, 255)).method1882().method1007("Color").method0210("Base shader color").method2130("Основной цвет");
      this.field1544 = (BooleanSetting)(new BooleanSetting("itemchams.optimize", true, () -> this.field1448.method0492() == ItemChams.RenderMode.field0084)).method1007("Optimize").method0210("Use cheap edge sampling + early-out blur. Disable for the original full-quality blur (slower but smoother gradient).").method2130("Оптимизация шейдера (быстрее, чуть упрощённый внутренний glow)");
      this.method1013("Применяет шейдер на руки");
   }

   @EventHandler
   public void onRenderShader(RenderShaderEvent event) {
      if (this.method2195()) {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            this.field1710.method0578();
         }
      }
   }

   @EventHandler
   public void onRenderHand(RenderHandEvent event) {
      if (this.method2195()) {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            event.method1516(this.field1710.method1517(event.method1809(), this.field1623.method1726()));
         }
      }
   }

   @EventHandler
   public void onRenderHand$POST(RenderHandEvent.Pre event) {
      if (this.method2195()) {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            this.field1710.method2058().method0578();
         }
      }
   }

   @EventHandler
   public void onRenderShader$POST(RenderShaderEvent.Pre event) {
      if (this.method2195()) {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            this.method1735();
         }
      }
   }

   private void method1735() {
      Color c = this.field1623.method1726();
      int gEnabled = 0;
      float gSpeed = 1.0F;
      float gScale = 10.0F;
      float gStrength = 0.01F;
      int gCount = 3;
      int opt = (Boolean)this.field1544.method0492() ? 1 : 0;
      if (this.field1448.method0492() == ItemChams.RenderMode.field0084) {
         int shapeMode = this.field0058.method0492() == ItemChams.Shape.field0656 ? 0 : 2;
         float fillOpacity = this.field0058.method0492() == ItemChams.Shape.field0083 ? 0.0F : (float)c.getAlpha() / 255.0F;
         this.field1710.method0743(shapeMode, ((Float)this.field0985.method0492()).intValue(), (Float)this.field0190.method0492(), ((Float)this.field0470.method0492()).intValue(), fillOpacity, gEnabled, gSpeed, gScale, gStrength, gCount, opt);
      } else {
         byte var10000;
         switch (((Shape)this.field0058.method0492()).ordinal()) {
            case 0 -> var10000 = 0;
            case 1 -> var10000 = 1;
            case 2 -> var10000 = 2;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         int shapeMode = var10000;
         float fillOpacity = (float)c.getAlpha() / 255.0F;
         this.field1710.method0735(shapeMode, fillOpacity, gEnabled, gSpeed, gScale, gStrength, gCount);
      }

   }

   public static enum Shape implements DisplayNamed {
      field0656("Fill"),
      field0083("Outline"),
      field1467("Both");

      private final String field1030;

      private Shape(String name) {
         this.field1030 = name;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static Shape[] method0068() {
         return new Shape[]{field0656, field0083, field1467};
      }
   }

   public static enum RenderMode implements DisplayNamed {
      field0657("Solid"),
      field0084("Glow");

      private final String field1504;

      private RenderMode(String name) {
         this.field1504 = name;
      }

      public String method0557() {
         return this.field1504;
      }

      // $FF: synthetic method
      private static RenderMode[] method0069() {
         return new RenderMode[]{field0657, field0084};
      }
   }
}
