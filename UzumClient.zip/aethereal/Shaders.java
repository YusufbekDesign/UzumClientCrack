package aethereal;

import java.awt.Color;
import java.util.Arrays;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class Shaders extends Module {
   private static Shaders field0268;
   private final OutlineShaderRenderer field0230 = new OutlineShaderRenderer();
   public EnumSetting<Mode> field0058;
   public ColorSetting field1443;
   public MultiSelectSetting field1005;
   public MultiSelectSetting field0202;
   public ColorSetting field0466;
   public ColorSetting field1623;
   public ColorSetting field1550;
   public ColorSetting field1711;
   public FloatSetting field1144;
   public FloatSetting field1097;
   public FloatSetting field1206;
   public ColorSetting field0878;
   public FloatSetting field0836;
   public FloatSetting field0919;
   public FloatSetting field1341;
   public ColorSetting field1299;
   public FloatSetting field1377;
   public FloatSetting field0393;
   public ColorSetting field0357;
   public BooleanSetting field0426;
   private boolean field0302;
   private boolean field0538;
   private boolean field0514;
   private boolean field0558;
   private boolean field1683;
   private boolean field1665;
   private boolean field1699;
   private boolean field1597;
   private boolean field1586;

   public OutlineShaderRenderer method1708() {
      return this.field0230;
   }

   public Shaders() {
      super("Shaders", ModuleCategory.field1004, "Mavjudotlarga shader effektlarini qo'llaydi");
      this.field0058 = (EnumSetting)(new EnumSetting("Mode", Shaders.Mode.field1485)).method1007("Rejim").method0210("Shader ko'rsatish rejimi").method2130("Ko'rsatish turi");
      this.field1443 = (ColorSetting)(new ColorSetting("Color", 255, 152, 236, 75)).method1882().method1007("Rang").method0210("Asosiy shader rangi").method2130("Rang");
      this.field1005 = (MultiSelectSetting)(new MultiSelectSetting("Target", Arrays.asList("Players", "Hostiles", "Animals", "Ambient", "Invisibles", "Items", "Crystals", "Others", "Hands"), false, () -> true)).method1007("Maqsad").method0210("Shader qo'llaniladigan mavjudot turlari").method2130("Mavjudot turlari");
      this.field0202 = (MultiSelectSetting)(new MultiSelectSetting("Enhance", Arrays.asList("Shine", "Glint", "Noise", "Circuit"), () -> this.field0058.method0492() != Shaders.Mode.field0110)).method1007("Yaxshilash").method0210("Shader yaxshilash effektlari").method2130("Shader effektlari");
      this.field0466 = (ColorSetting)(new ColorSetting("HostilesColor", 250, 150, 255, 80, () -> (Boolean)this.field1005.method0439("Hostiles").method0492())).method1882().method1007("Dushmamonlar rangi").method0210("Dushman moblar uchun shader rangi").method2130("Dushman moblar rangi");
      this.field1623 = (ColorSetting)(new ColorSetting("AnimalsColor", 100, 255, 100, 80, () -> (Boolean)this.field1005.method0439("Animals").method0492())).method1882().method1007("Hayvonlar rangi").method0210("Hayvonlar uchun shader rangi").method2130("Hayvonlar rangi");
      this.field1550 = (ColorSetting)(new ColorSetting("AmbientColor", 150, 150, 255, 80, () -> (Boolean)this.field1005.method0439("Ambient").method0492())).method1882().method1007("Atrof-muhit rangi").method0210("Atrof-muhit mavjudotlari uchun shader rangi").method2130("Atrof-muhit mavjudotlari rangi");
      this.field1711 = (ColorSetting)(new ColorSetting("InvisiblesColor", 253, 121, 218, 80, () -> (Boolean)this.field1005.method0439("Invisibles").method0492())).method1882().method1007("Ko'rinmaslar rangi").method0210("Ko'rinmas mavjudotlar uchun shader rangi").method2130("Ko'rinmas mavjudotlar rangi");
      this.field1144 = (FloatSetting)(new FloatSetting("GlintSpeed", 1.0F, 0.1F, 2.0F, 0.05F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Glint").method0492())).method1007("Yaltiroq tezligi").method0210("Yaltiroq animatsiyasining tezligi").method2130("Animatsiya tezligi");
      this.field1097 = (FloatSetting)(new FloatSetting("GlintWidth", 2.0F, 0.1F, 2.0F, 0.05F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Glint").method0492())).method1007("Yaltiroq kengligi").method0210("Yaltiroq lenta kengligi").method2130("Lenta kengligi");
      this.field1206 = (FloatSetting)(new FloatSetting("GlintGrad", 3.0F, 1.0F, 10.0F, 0.5F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Glint").method0492())).method1007("Yaltiroq gradienti").method0210("Yaltiroq gradienti yumshoqligi").method2130("Gradient yumshoqligi");
      this.field0878 = (ColorSetting)(new ColorSetting("GlintColor", 255, 0, 200, 175, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Glint").method0492())).method1882().method1007("Yaltiroq rangi").method0210("Yaltiroq effektining rangi").method2130("Yaltiroq rangi");
      this.field0836 = (FloatSetting)(new FloatSetting("NoiseSpeed", 5.0F, 0.1F, 5.0F, 0.1F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Noise").method0492())).method1007("Shovqin tezligi").method0210("Shovqin animatsiyasining tezligi").method2130("Animatsiya tezligi");
      this.field0919 = (FloatSetting)(new FloatSetting("NoiseAngle", 360.0F, 0.0F, 360.0F, 1.0F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Noise").method0492())).method1007("Shovqin burchagi").method0210("Shovqin naqshining burchagi").method2130("Naqsh burchagi");
      this.field1341 = (FloatSetting)(new FloatSetting("NoiseScale", 20.0F, 1.0F, 20.0F, 0.5F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Noise").method0492())).method1007("Shovqin masshtabi").method0210("Shovqin naqshining masshtabi").method2130("Naqsh masshtabi");
      this.field1299 = (ColorSetting)(new ColorSetting("NoiseColor", 255, 110, 221, 255, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Noise").method0492())).method1882().method1007("Shovqin rangi").method0210("Shovqin effektining rangi").method2130("Shovqin rangi");
      this.field1377 = (FloatSetting)(new FloatSetting("CircuitSpeed", 0.2F, 0.1F, 2.0F, 0.1F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Circuit").method0492())).method1007("Zanjir tezligi").method0210("Zanjir animatsiyasining tezligi").method2130("Animatsiya tezligi");
      this.field0393 = (FloatSetting)(new FloatSetting("CircuitIntensity", 2.4F, 0.1F, 3.0F, 0.1F, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Circuit").method0492())).method1007("Zanjir intensivligi").method0210("Zanjir naqshining intensivligi").method2130("Naqsh intensivligi");
      this.field0357 = (ColorSetting)(new ColorSetting("CircuitColor", 212, 35, 129, 255, () -> this.field0058.method0492() != Shaders.Mode.field0110 && (Boolean)this.field0202.method0439("Circuit").method0492())).method1882().method1007("Zanjir rangi").method0210("Zanjir effektining rangi").method2130("Effekt rangi");
      this.field0426 = (BooleanSetting)(new BooleanSetting("FriendColor", true)).method1007("Do'stlar rangi").method0210("Do'stlarni asosiy rang o'rniga yashil rang bilan chizish").method2130("Do'stlarni yashil rang bilan chizish");
      this.method1013("Mavjudotlarga shader qo'llaydi");
      field0268 = this;
      this.field1005.method0439("Players").method0206(true);
      this.field1005.method0439("Hostiles").method0206(true);
      this.field1005.method0439("Animals").method0206(true);
      this.field1005.method0439("Ambient").method0206(true);
      this.field1005.method0439("Invisibles").method0206(true);
      this.field1005.method0439("Items").method0206(true);
      this.field1005.method0439("Crystals").method0206(true);
      this.field1005.method0439("Others").method0206(true);
      this.field1005.method0439("Hands").method0206(true);
      this.field0202.method0439("Shine").method0206(true);
      this.field0202.method0439("Glint").method0206(true);
      this.field0202.method0439("Noise").method0206(true);
      this.field0202.method0439("Circuit").method0206(true);
   }

   @EventHandler
   public void onRenderShader(RenderShaderEvent var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null) {
         this.method0457();
         this.field0230.method0578();
      }

   }

   @EventHandler
   public void onRenderEntity(RenderEntityEvent var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.method1129(var1.method1798())) {
         Color var2 = this.method0234(var1.method1798());
         var1.method1516(this.field0230.method1517(var1.method1630(), var2));
      }

   }

   @EventHandler
   public void onRenderEntity$POST(RenderEntityEvent.Pre var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.method0472()) {
         this.field0230.method2058().method0578();
         if (!this.field1586) {
            this.method2043();
         }
      }

   }

   @EventHandler
   public void onRenderHand(RenderHandEvent var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.field1586) {
         Color var2 = this.field1443.method1726();
         var1.method1516(this.field0230.method1517(var1.method1809(), var2));
      }

   }

   @EventHandler
   public void onRenderHand$POST(RenderHandEvent.Pre var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.field1586) {
         this.field0230.method2058().method0578();
      }

   }

   @EventHandler
   public void onRenderShader$POST(RenderShaderEvent.Pre var1) {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.field1586) {
         this.method2043();
      }

   }

   private void method2043() {
      this.field0230.method0764(this.field0058.method0492() == Shaders.Mode.field0686 ? 0 : (this.field0058.method0492() == Shaders.Mode.field0110 ? 1 : 2), this.field1443.method1726(), (Boolean)this.field0202.method0439("Shine").method0492(), (Boolean)this.field0202.method0439("Glint").method0492(), (Float)this.field1144.method0492(), (Float)this.field1097.method0492(), (Float)this.field1206.method0492(), this.field0878.method1726(), (Boolean)this.field0202.method0439("Noise").method0492(), (Float)this.field0836.method0492(), (Float)this.field0919.method0492(), (Float)this.field1341.method0492(), this.field1299.method1726(), (Boolean)this.field0202.method0439("Circuit").method0492(), (Float)this.field1377.method0492(), (Float)this.field0393.method0492(), this.field0357.method1726());
   }

   public void method1691() {
      if (this.method2195() && field0796.field_1724 != null && field0796.field_1687 != null && this.field1586) {
         this.field0230.method2058().method0578();
         this.method2043();
      }

   }

   private boolean method0472() {
      return this.field0302 || this.field0538 || this.field0514 || this.field0558 || this.field1683 || this.field1665 || this.field1699 || this.field1597;
   }

   public boolean method1755() {
      return this.field1586;
   }

   public Color method2023() {
      return this.field1443.method1726();
   }

   private void method0457() {
      this.field0302 = (Boolean)this.field1005.method0439("Players").method0492();
      this.field0538 = (Boolean)this.field1005.method0439("Hostiles").method0492();
      this.field0514 = (Boolean)this.field1005.method0439("Animals").method0492();
      this.field0558 = (Boolean)this.field1005.method0439("Ambient").method0492();
      this.field1683 = (Boolean)this.field1005.method0439("Invisibles").method0492();
      this.field1665 = (Boolean)this.field1005.method0439("Items").method0492();
      this.field1699 = (Boolean)this.field1005.method0439("Crystals").method0492();
      this.field1597 = (Boolean)this.field1005.method0439("Others").method0492();
      this.field1586 = (Boolean)this.field1005.method0439("Hands").method0492();
   }

   public boolean method1129(class_1297 var1) {
      if (this.field0302 && EntityFilter.method1129(var1)) {
         return true;
      } else if (this.field0538 && EntityFilter.method0235(var1)) {
         return true;
      } else if (this.field0514 && EntityFilter.method2144(var1)) {
         return true;
      } else if (this.field0558 && EntityFilter.method1851(var1)) {
         return true;
      } else if (this.field1683 && var1.method_5767()) {
         return true;
      } else if (this.field1665 && EntityFilter.method1660(var1)) {
         return true;
      } else {
         return this.field1699 && EntityFilter.method1988(var1) ? true : this.field1597;
      }
   }

   private Color method0234(class_1297 var1) {
      if (!(var1 instanceof class_1657 var2)) {
         EntityFilter.EntityKind var5 = EntityFilter.method2237(var1);
         Color var10000;
         switch (var5) {
            case field0644:
               var10000 = this.field1443.method1726();
               break;
            case field0074:
               var10000 = this.field0466.method1726();
               break;
            case field1459:
               var10000 = this.field1623.method1726();
               break;
            case field0994:
               var10000 = this.field1550.method1726();
               break;
            case field0773:
               var10000 = this.field1711.method1726();
               break;
            case field1257:
            case field0324:
            case field0196:
               var10000 = this.field1443.method1726();
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         boolean var3 = (Boolean)this.field0426.method0492() && ArbuzClient.method2004().method1608().method2135(var2.method_5477().getString());
         if (var3) {
            Color var4 = this.field1443.method1726();
            return new Color(66, 245, 149, var4.getAlpha());
         } else {
            return this.field1443.method1726();
         }
      }
   }

   @Generated
   public static Shaders method2009() {
      return field0268;
   }

   public static enum Mode implements DisplayNamed {
      field0686("Fill"),
      field0110("Outline"),
      field1485("Both");

      private final String field1030;

      private Mode(String var3) {
         this.field1030 = var3;
      }

      public String method0557() {
         return this.field1030;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0686, field0110, field1485};
      }
   }
}
