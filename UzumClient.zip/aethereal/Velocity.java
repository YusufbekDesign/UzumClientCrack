package aethereal;

import java.lang.reflect.Field;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_6373;
import net.minecraft.class_2846.class_2847;

public class Velocity extends Module {
   private final EnumSetting<Mode> field0058;
   private final FloatSetting field1450;
   private final BooleanSetting field0970;
   private final FloatSetting field0190;
   private boolean field0497;
   private int field1615;
   private int field1539;
   private int field1705;
   private boolean field1161;

   public Velocity() {
      super("Velocity", ModuleCategory.field0661, "Modifies knockback velocity from attacks");
      this.field0058 = (EnumSetting)(new EnumSetting("velocity.mode", Velocity.Mode.field0707)).method1007("Rejim").method0210("Anti-itarish chetlab o'tish usuli").method2130("Rejim");
      this.field1450 = (FloatSetting)(new FloatSetting("velocity.jumpreset.chance", 100.0F, 0.0F, 100.0F, 1.0F, () -> this.field0058.method0492() == Velocity.Mode.field0787)).method1007("Ehtimollik").method0210("Shartlar bajarilganda sakrashni tiklash ehtimoli").method2130("Ishga tushish ehtimoli");
      this.field0970 = (BooleanSetting)(new BooleanSetting("velocity.jumpreset.jumpByDelay", true, () -> this.field0058.method0492() == Velocity.Mode.field0787)).method1007("KechikishBilanSakrash").method0210("Tiklashlar orasida ma'lum tik kechikishidan keyin sakrash").method2130("Tiklar kechikishi bilan sakrash");
      this.field0190 = (FloatSetting)(new FloatSetting("velocity.jumpreset.ticksUntilJump", 2.0F, 0.0F, 20.0F, 1.0F, () -> this.field0058.method0492() == Velocity.Mode.field0787 && this.field0970.method1938())).method1007("Sakrashgacha").method0210("Sakrash tiklashlari orasida kutish tiklari").method2130("Sakrashlar orasida necha tik kutish kerak");
      this.method1013("Itarishni o'chiradi");
   }

   @EventHandler
   public void onPacket(PacketEvent.Inbound var1) {
      if (!method1974() && !field0796.field_1724.method_5799() && !field0796.field_1724.method_5869() && !field0796.field_1724.method_5771()) {
         if (this.field1539 > 0) {
            --this.field1539;
         } else {
            class_2596 var3 = var1.method1970();
            if (var3 instanceof class_2743) {
               class_2743 var2 = (class_2743)var3;
               if (var2.method_11818() == field0796.field_1724.method_5628()) {
                  switch (((Mode)this.field0058.method0492()).ordinal()) {
                     case 0:
                        var1.method0578();
                        this.field0497 = true;
                        break;
                     case 1:
                        var1.method0578();
                        this.field1615 = 6;
                        break;
                     case 2:
                        if (!this.field0497) {
                           var1.method0578();
                           this.field0497 = true;
                        } else {
                           this.field0497 = false;
                           this.method1369(var2, (int)(var2.method_11815() * -0.10000000398723294));
                           this.method0304(var2, (int)(var2.method_11819() * -0.10000000398723294));
                        }
                        break;
                     case 3:
                        var1.method0578();
                        break;
                     case 4:
                        this.field1161 = var2.method_11815() == (double)0.0F && var2.method_11819() == (double)0.0F && var2.method_11816() < (double)0.0F;
                  }
               }
            }

            if (this.field0058.method0492() == Velocity.Mode.field0131 && var1.method1970() instanceof class_6373 && this.field1615 > 0) {
               var1.method0578();
               --this.field1615;
            }

            if (var1.method1970() instanceof class_2708 && this.field0058.method0492() == Velocity.Mode.field0707) {
               this.field1539 = 5;
            }
         }
      }

   }

   @EventHandler
   public void onTick(PreTickEvent var1) {
      if (!method1974() && !field0796.field_1724.method_5799() && !field0796.field_1724.method_5869()) {
         if (this.field0058.method0492() == Velocity.Mode.field1499 && field0796.field_1724.field_6235 > 0 && !field0796.field_1724.method_24828()) {
            double var2 = (double)(field0796.field_1724.method_36454() * ((float)Math.PI / 180F));
            double var4 = Math.sqrt(field0796.field_1724.method_18798().field_1352 * field0796.field_1724.method_18798().field_1352 + field0796.field_1724.method_18798().field_1350 * field0796.field_1724.method_18798().field_1350);
            field0796.field_1724.method_18800(-Math.sin(var2) * var4, field0796.field_1724.method_18798().field_1351, Math.cos(var2) * var4);
            field0796.field_1724.method_5728(field0796.field_1724.field_6012 % 2 != 0);
         }

         if (this.field0058.method0492() == Velocity.Mode.field0707 && this.field0497) {
            if (this.field1539 <= 0) {
               field0796.field_1724.field_3944.method_52787(new class_2828.class_2830(field0796.field_1724.method_23317(), field0796.field_1724.method_23318(), field0796.field_1724.method_23321(), field0796.field_1724.method_36454(), field0796.field_1724.method_36455(), field0796.field_1724.method_24828(), false));
               field0796.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12973, class_2338.method_49638(field0796.field_1724.method_19538()), class_2350.field_11033));
            }

            this.field0497 = false;
         }

         if (this.field1615 > 0) {
            --this.field1615;
         }
      }

   }

   @EventHandler
   public void onInput(KeyboardInputEvent var1) {
      if (!method1974() && this.field0058.method0492() == Velocity.Mode.field0787 && !field0796.field_1724.method_5799() && !field0796.field_1724.method_5869() && !field0796.field_1724.method_5771()) {
         boolean var2 = (Float)this.field1450.method0492() != 100.0F && Math.random() * (double)100.0F > (double)(Float)this.field1450.method0492();
         if (field0796.field_1724.field_6235 == 9 && field0796.field_1724.method_24828() && field0796.field_1724.method_5624() && !this.field1161 && this.method1736() && !var2) {
            var1.method0345(true);
            this.field1705 = 0;
         } else {
            this.method1691();
         }
      }

   }

   private boolean method1736() {
      return this.field0970.method1938() ? this.field1705 >= ((Float)this.field0190.method0492()).intValue() : true;
   }

   private void method1691() {
      ++this.field1705;
   }

   public void method0025() {
      this.field1615 = 0;
      this.field0497 = false;
      this.field1539 = 0;
      this.field1705 = 0;
      this.field1161 = false;
      super.method0025();
   }

   private void method1369(class_2743 var1, int var2) {
      try {
         Field var3 = class_2743.class.getDeclaredField("velocityX");
         var3.setAccessible(true);
         var3.setInt(var1, var2);
      } catch (Exception var4) {
      }

   }

   private void method0304(class_2743 var1, int var2) {
      try {
         Field var3 = class_2743.class.getDeclaredField("velocityZ");
         var3.setAccessible(true);
         var3.setInt(var1, var2);
      } catch (Exception var4) {
      }

   }

   public static enum Mode implements DisplayNamed {
      field0707("NewGrim"),
      field0131("OldGrim"),
      field1499("Matrix"),
      field1023("Normal"),
      field0787("JumpReset");

      private final String field1269;

      private Mode(String var3) {
         this.field1269 = var3;
      }

      public String method0557() {
         return this.field1269;
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{field0707, field0131, field1499, field1023, field0787};
      }
   }
}
