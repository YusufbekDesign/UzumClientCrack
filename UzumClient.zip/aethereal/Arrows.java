package aethereal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1044;
import net.minecraft.class_1657;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import net.minecraft.class_7833;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class Arrows extends Module {
   private static final class_2960 field1159 = class_2960.method_60655("arbuzhack", "textures/arrow.png");
   private static final float field1087 = 0.9F;
   private static final float field1196 = 0.15F;
   public EnumSetting<Style> field0058;
   public FloatSetting field1450;
   public FloatSetting field0985;
   public BooleanSetting field0184;
   public BooleanSetting field0464;
   public ColorSetting field1623;
   public BooleanSetting field1544;
   public BooleanSetting field1709;
   private float field0871;
   private float field0826;
   private float field0910;
   private float field1331;
   private float field1292;
   private boolean field1388;
   private float field0385;
   private float field0351;
   private float field0423;
   private final Map<UUID, Float> field0271;

   public Arrows() {
      super("Arrows", ModuleCategory.field1004, "Renders directional arrows pointing to nearby players");
      this.field0058 = (EnumSetting)(new EnumSetting("arrows.style", Arrows.Style.field0574)).method1007("Style").method0210("Arrow rendering style").method2130("Стиль отрисовки");
      this.field1450 = (FloatSetting)(new FloatSetting("arrows.distance", 30.0F, 20.0F, 150.0F, 5.0F)).method1007("Distance").method0210("Distance of arrows from screen center").method2130("Расстояние стрелок от центра экрана");
      this.field0985 = (FloatSetting)(new FloatSetting("arrows.size", 24.0F, 6.0F, 30.0F, 1.0F)).method1007("Size").method0210("Size of arrow indicators").method2130("Размер");
      this.field0184 = (BooleanSetting)(new BooleanSetting("arrows.expandoninventory", true)).method1007("Expand On Inventory").method0210("Expand arrow radius when inventory is open").method2130("Увеличить радиус при открытом инвентаре");
      this.field0464 = (BooleanSetting)(new BooleanSetting("arrows.showdistance", true)).method1007("Show Distance").method0210("Display distance text below arrows").method2130("Показывать расстояние");
      this.field1623 = (ColorSetting)(new ColorSetting("arrows.color", 255, 156, 249, 200)).method1882().method1007("Arrow Color").method0210("Default arrow color").method2130("Цвет по умолчанию");
      this.field1544 = (BooleanSetting)(new BooleanSetting("arrows.friendcolor", true)).method1007("Friend Color").method0210("Render friends in green instead of the default color").method2130("Отображать друзей зелёным вместо обычного цвета");
      this.field1709 = (BooleanSetting)(new BooleanSetting("arrows.dynamic", true)).method1007("Dynamic").method0210("Arrows react to camera and player movement").method2130("Реагировать на движения");
      this.field0826 = 0.0F;
      this.field0910 = 0.0F;
      this.field1331 = 0.0F;
      this.field1292 = 0.0F;
      this.field1388 = true;
      this.field0385 = 0.0F;
      this.field0351 = 0.0F;
      this.field0423 = 0.0F;
      this.field0271 = new HashMap();
      this.method1013("Рисует стрелки к ближайшим игрокам");
   }

   public void method2078() {
      super.method2078();
      this.field0271.clear();
      this.field1388 = true;
   }

   private static float method1186(class_1657 entity, float tickDelta) {
      double ex = entity.field_6014 + (entity.method_23317() - entity.field_6014) * (double)tickDelta;
      double ez = entity.field_5969 + (entity.method_23321() - entity.field_5969) * (double)tickDelta;
      double px = field0796.field_1724.field_6014 + (field0796.field_1724.method_23317() - field0796.field_1724.field_6014) * (double)tickDelta;
      double pz = field0796.field_1724.field_5969 + (field0796.field_1724.method_23321() - field0796.field_1724.field_5969) * (double)tickDelta;
      return (float)(-(Math.atan2(ex - px, ez - pz) * 57.29577954311793));
   }

   @EventHandler
   public void onRender2D(HudRenderEvent event) {
      if (this.method2195()) {
         if (field0796.field_1724 != null && field0796.field_1687 != null) {
            float currentYaw = field0796.field_1724.method_36454();
            float currentPitch = field0796.field_1724.method_36455();
            if (this.field1388) {
               this.field1331 = currentYaw;
               this.field1292 = currentPitch;
               this.field1388 = false;
            }

            if ((Boolean)this.field1709.method0492()) {
               float deltaYaw = this.field1331 - currentYaw;

               float deltaPitch;
               for(deltaPitch = this.field1292 - currentPitch; deltaYaw > 180.0F; deltaYaw -= 360.0F) {
               }

               while(deltaYaw < -180.0F) {
                  deltaYaw += 360.0F;
               }

               float targetOffsetX = deltaYaw * 2.0F;
               float targetOffsetY = deltaPitch * 2.0F;
               float rawVelX = (float)field0796.field_1724.method_18798().field_1352;
               float rawVelY = (float)field0796.field_1724.method_18798().field_1351;
               float rawVelZ = (float)field0796.field_1724.method_18798().field_1350;
               this.field0385 += (rawVelX - this.field0385) * 0.15F;
               this.field0351 += (rawVelY - this.field0351) * 0.15F;
               this.field0423 += (rawVelZ - this.field0423) * 0.15F;
               float yawRadDyn = (float)Math.toRadians((double)field0796.field_1724.method_36454());
               float sideMovement = (float)((double)(-this.field0385) * Math.sin((double)yawRadDyn) + (double)this.field0423 * Math.cos((double)yawRadDyn));
               float forwardMovement = (float)((double)this.field0385 * Math.cos((double)yawRadDyn) + (double)this.field0423 * Math.sin((double)yawRadDyn));
               targetOffsetX += forwardMovement * 10.0F;
               targetOffsetY += sideMovement * 10.0F;
               targetOffsetY -= this.field0351 * 8.0F;
               this.field0826 += (targetOffsetX - this.field0826) * 0.05F;
               this.field0910 += (targetOffsetY - this.field0910) * 0.05F;
               if (Math.abs(this.field0826) < 0.01F) {
                  this.field0826 = 0.0F;
               }

               if (Math.abs(this.field0910) < 0.01F) {
                  this.field0910 = 0.0F;
               }
            } else {
               this.field0826 *= 0.85F;
               this.field0910 *= 0.85F;
            }

            this.field1331 = currentYaw;
            this.field1292 = currentPitch;
            float targetSize = (Float)this.field1450.method0492();
            if ((Boolean)this.field0184.method0492() && field0796.field_1755 instanceof class_465) {
               targetSize += 100.0F;
            }

            this.field0871 += (targetSize - this.field0871) * 0.1F;
            FontSize distFont = Fonts.field0075.method0654(6.0F);
            float tickDelta = event.method1632().method_60637(false);
            float screenCenterX = ScreenLayoutHelper.method2047() / 2.0F;
            float screenCenterY = ScreenLayoutHelper.method1762() / 2.0F;
            float interpYaw = field0796.field_1724.field_5982 + (field0796.field_1724.method_36454() - field0796.field_1724.field_5982) * tickDelta;
            List<float[]> arrowData = new ArrayList();
            List<Object[]> textData = new ArrayList();
            AntiBot antiBot = AntiBot.method1700();

            for(class_1657 player : field0796.field_1687.method_18456()) {
               if (player != field0796.field_1724 && !player.method_5477().getString().isEmpty() && (antiBot == null || !antiBot.method0250(player))) {
                  float targetAngle = method1186(player, tickDelta) - interpYaw;
                  UUID uuid = player.method_5667();
                  float smoothAngle = (Float)this.field0271.getOrDefault(uuid, targetAngle);

                  float delta;
                  for(delta = targetAngle - smoothAngle; delta > 180.0F; delta -= 360.0F) {
                  }

                  while(delta < -180.0F) {
                     delta += 360.0F;
                  }

                  smoothAngle += delta * 0.15F;
                  this.field0271.put(uuid, smoothAngle);
                  float rad = (float)Math.toRadians((double)smoothAngle);
                  float x2 = this.field0871 * class_3532.method_15374(rad) + screenCenterX + this.field0826;
                  float y2 = -this.field0871 * class_3532.method_15362(rad) + screenCenterY + this.field0910;
                  boolean isFriend = (Boolean)this.field1544.method0492() && ArbuzClient.method2004().method1608().method2135(player.method_5477().getString());
                  Color baseColor = isFriend ? new Color(66, 245, 149, this.field1623.method2036()) : this.field1623.method1726();
                  arrowData.add(new float[]{x2, y2, smoothAngle, Float.intBitsToFloat(baseColor.getRGB())});
                  if ((Boolean)this.field0464.method0492()) {
                     double dx = player.field_6014 + (player.method_23317() - player.field_6014) * (double)tickDelta - (field0796.field_1724.field_6014 + (field0796.field_1724.method_23317() - field0796.field_1724.field_6014) * (double)tickDelta);
                     double dy = player.field_6036 + (player.method_23318() - player.field_6036) * (double)tickDelta - (field0796.field_1724.field_6036 + (field0796.field_1724.method_23318() - field0796.field_1724.field_6036) * (double)tickDelta);
                     double dz = player.field_5969 + (player.method_23321() - player.field_5969) * (double)tickDelta - (field0796.field_1724.field_5969 + (field0796.field_1724.method_23321() - field0796.field_1724.field_5969) * (double)tickDelta);
                     double dist = Math.sqrt(dx * dx + dz * dz);
                     textData.add(new Object[]{(double)x2, (double)y2, dist, baseColor});
                  }
               }
            }

            this.method0845(event, arrowData);

            for(Object[] td : textData) {
               double tx = (Double)td[0];
               double ty = (Double)td[1];
               double dist = (Double)td[2];
               Color textColor = (Color)td[3];
               String distText = String.format("%.1fm", dist);
               float textWidth = distFont.method0998(distText);
               float textX = (float)tx - textWidth / 2.0F;
               float textY = (float)ty + (Float)this.field0985.method0492() / 2.0F + 3.0F;
               GuiRenderHelper.method1491(event.method1806().method_51448(), distFont, distText, textX, textY, textColor);
            }

            this.field0271.keySet().removeIf((uuidx) -> field0796.field_1687.method_18456().stream().noneMatch((p) -> p.method_5667().equals(uuidx)));
         }
      }
   }

   private void method0845(HudRenderEvent event, List<float[]> arrowData) {
      RenderSystem.setShader(class_10142.field_53880);
      RenderSystem.setShaderTexture(0, field1159);
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.disableCull();
      RenderSystem.depthMask(false);
      class_1044 tex = field0796.method_1531().method_4619(field1159);
      if (tex != null) {
         tex.method_4527(true, true);
      }

      GL11.glHint(3155, 4354);
      GL11.glEnable(2881);

      for(float[] data : arrowData) {
         class_4587 matrices = event.method1806().method_51448();
         matrices.method_22903();
         matrices.method_46416(data[0], data[1], 0.0F);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(data[2]));
         float arrowHeight = (Float)this.field0985.method0492();
         float arrowWidth = arrowHeight * 0.9F;
         float halfW = arrowWidth / 2.0F;
         float halfH = arrowHeight / 2.0F;
         int rgba = Float.floatToRawIntBits(data[3]);
         Matrix4f matrix = matrices.method_23760().method_23761();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
         buffer.method_22918(matrix, -halfW, -halfH, 0.0F).method_22913(0.0F, 0.0F).method_39415(rgba);
         buffer.method_22918(matrix, -halfW, halfH, 0.0F).method_22913(0.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrix, halfW, halfH, 0.0F).method_22913(1.0F, 1.0F).method_39415(rgba);
         buffer.method_22918(matrix, halfW, -halfH, 0.0F).method_22913(1.0F, 0.0F).method_39415(rgba);
         class_286.method_43433(buffer.method_60800());
         matrices.method_22909();
      }

      GL11.glDisable(2881);
      if (tex != null) {
         tex.method_4527(false, false);
      }

      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      RenderSystem.defaultBlendFunc();
   }

   public static enum Style implements DisplayNamed {
      field0574("Default");

      private final String field0136;

      private Style(String name) {
         this.field0136 = name;
      }

      public String method0557() {
         return this.field0136;
      }

      // $FF: synthetic method
      private static Style[] method0029() {
         return new Style[]{field0574};
      }
   }
}
